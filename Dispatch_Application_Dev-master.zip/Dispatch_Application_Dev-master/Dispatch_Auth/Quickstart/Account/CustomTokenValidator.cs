﻿using IdentityServer.Data;
using IdentityServer.Models;
using IdentityServer.Quickstart.UI;
using Duende.IdentityServer.Validation;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer.CustomValidators
{
    public class PaulsCustomValidator : ICustomAuthorizeRequestValidator
    {
        private readonly ApplicationDbContext _context;


        public PaulsCustomValidator(ApplicationDbContext ctx)
        {
            _context = ctx;
        }

        public Task ValidateAsync(CustomAuthorizeRequestValidationContext context)
        {
/*

            try
            {
                string id = context.Result.ValidatedRequest.Subject?.FindFirst("sub")?.Value;

                ApplicationUser user = _context.Users.Where(user => user.Id.ToUpper() == id).Single();


               if(user.IsEnabled == false)
                {
                    context.Result.IsError = true;
                }

                return Task.CompletedTask;
            }
            catch
            {
                context.Result.IsError = true;
            }*/

            return Task.CompletedTask;

        }

    }
}
