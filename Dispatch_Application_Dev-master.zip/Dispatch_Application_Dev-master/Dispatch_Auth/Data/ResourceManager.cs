﻿using Duende.IdentityServer.Models;
using System.Collections.Generic;

namespace IdentityServer.TokenServer.Data
{
    internal static class ResourceManager
    {
        public static IEnumerable<ApiScope> GetApiScopes()
        {
            return new List<ApiScope>
                {
                    new ApiScope(name: "dispatchapp",   displayName: "The main scope"),

                };
        }
        public static IEnumerable<ApiResource> Apis =>
            new List<ApiResource>
            {
                new ApiResource {
                    Name = "dispatchapp",
                    DisplayName = "api",
                    ApiSecrets = { new Secret(Startup.APISecret.Sha256()) },
                    Scopes = new List<string> {
                        "dispatchapp",
                    }
                }
                
            };
    }
}
