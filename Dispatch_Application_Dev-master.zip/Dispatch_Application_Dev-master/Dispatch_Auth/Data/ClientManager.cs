﻿using Duende.IdentityServer.Models;
using System;
using System.Collections.Generic;

namespace IdentityServer.TokenServer.Data
{
    internal static class ClientManager
    {
        public static IEnumerable<Client> Clients =>
            new List<Client>
            {

                    new Client
                    {
                         ClientName = "dispatchapp",
                         ClientId = "dispatchapp",
                         AllowedGrantTypes = GrantTypes.ClientCredentials,
                         ClientSecrets = { new Secret(Startup.APISecret.Sha256()) },
                         AllowedScopes = { "dispatchapp" }
                    },
                    new Client {
                         RequireConsent = false,
                         ClientId = "angular_spa",
                         ClientName = "Angular Client",
                         AllowedGrantTypes = GrantTypes.Code,
                         //RequirePkce = true,
                         RequireClientSecret = false,
                         AllowedScopes = { "dispatchapp" },
                         RedirectUris = { Startup.FrontendServerString + "/auth-callback" }, // test client runs on same host
                         AllowedCorsOrigins = {Startup.FrontendServerString }, // test client runs on same host
                         AccessTokenLifetime = (int)TimeSpan.FromDays(30).TotalSeconds
                },
                     new Client {
                         RequireConsent = false,
                         ClientId = "xamarin",
                         ClientName = "xamarin",
                         AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,
                         RequireClientSecret = false,
                         AllowedScopes = { "dispatchapp" },
                         AccessTokenLifetime = (int)TimeSpan.FromDays(120).TotalSeconds
                }
                     
            };
    }
}
