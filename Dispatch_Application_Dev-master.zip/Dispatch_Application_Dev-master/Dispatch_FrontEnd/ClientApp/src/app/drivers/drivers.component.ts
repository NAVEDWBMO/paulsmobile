import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { isFilterable } from '@progress/kendo-angular-grid/dist/es2015/filtering/filterable';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';

@Component({
  selector: 'app-drivers',
  templateUrl: './drivers.component.html',
  styleUrls: ['./drivers.component.sass']
})
export class DriversComponent implements OnInit {
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];

  private access: any;


  public gridData: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  selectedCompanyId: string = "";
  public sort: SortDescriptor[] = [{
      field: 'driver_IsEnabled',
      dir: 'desc'
    },
    {
      field: 'company.company_Name',
      dir: 'asc'
    }];
  public state: State = {
    filter: {
      logic: 'and',
      filters: []
    }
  };
  selectedCompany: any;
  userCompaniesAccess: any;
  constructor(public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
      this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.gridData = [];
      if(access?.company_Id){
        this.access = access;
        this.selectedCompanyId = access.company_Id;

        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: access.company_Id
          }     
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_registered_drivers_info/', httpOptionsTwo).subscribe(result => {
          this.gridData = result;
          this.loadItems();
        })
      }
    });
    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
}
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
}
  public dataStateChange(state: DataStateChangeEvent): void {
    this.skip = 0;
    this.state = state;
    this.loadItems();
  }
  private loadItems(): void {
    this.gridData = orderBy(this.gridData, this.sort);
    var filterdat = this.gridData;
    filterdat = filterBy(this.gridData, this.state.filter)
    this.gridView = {
      data: filterdat.slice(this.skip, this.skip + this.pageSize),
      total: filterdat.length
    };
   }


  ngOnInit(): void {}

  openDialog(dataItem): void {
    const dialogRef = this.dialog.open(SetupDialog, {
      data: dataItem,
      disableClose: true

    });
    dialogRef.afterClosed().subscribe(result => {
      this.refreshDriverList()
    });
  }
  openEditTruckImeiDialog(dataItem): void {
    const dialogRef = this.dialog.open(EditTruckImeiDialog, {
      data: dataItem,
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshDriverList()
    });
  }

  refreshDriverList(){

        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: this.access.company_Id
          }     
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_registered_drivers_info/', httpOptionsTwo).subscribe(result => {
          this.gridData = result;
          this.loadItems();
        })
      }
}


@Component({
  selector: 'setup-dialog',
  templateUrl: 'setup-dialog.html',
  styleUrls: ['./drivers.component.sass']

})
export class SetupDialog {
  
  lowerCharacters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  upperCharacters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  symbols = ['!', '?', '@', '+', '=', '-', '_'];
  DriverRoles: any[] = [];
  fname = new FormControl();
  lname = new FormControl();
  email = new FormControl('', [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,4}$")]);
  password = new FormControl("");
  changed: boolean = false;
  httpOptions: any;
  CompanyType: string;
  Company_Id: string;
  selectedRole: string;

  constructor(
    public dialogRef: MatDialogRef<SetupDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any,private _snackBar: MatSnackBar, public dialog: MatDialog,public http: HttpClient, private configService: ConfigService, private authService: AuthService, ) {
    dialogRef.disableClose = true;

      this.fname.setValue(data.driver_Firstname);
      this.lname.setValue(data.driver_Lastname);
      this.email.setValue(data.driver_Email);
      this.selectedRole = data.driver_Role_Id;
      this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
        if (access?.company_Id) {
          this.CompanyType = access.company_Type_Id;
         // console.log(access.company_Id);
          this.Company_Id = access.company_Id;
        }

      });
      this.httpOptions = {
        headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
        })
      };
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          'Company_Type_Id': this.CompanyType
        }

      };
      this.http.get<any>(this.configService.resourceApiURI + '/get_driver_roles/', httpOptionsTwo).subscribe(result => {
        this.DriverRoles = result;
      })

    }

    updateUser(){
      this.http.post<any>(this.configService.resourceApiURI + '/update_driver_user/', 
      { "User_Email_Old":  this.data.driver_Email,
       "User_Email":  this.email.value,
       "User_FirstName":  this.fname.value,
       "User_LastName":  this.lname.value,
       "User_Password": this.password.value,
       "User_Id": this.data.user_Id,
       "User_Role_Id": this.selectedRole
      }, 
      this.httpOptions).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 3000,
        });
      })
      this.dialogRef.close();

    }

  enableUser() {

    if ((this.Company_Id.toLowerCase() == 'dd7e7bdc-b578-4e89-8425-b4ffea61e798' || this.Company_Id.toLowerCase() == '96aa4673-c3cd-40a9-9f69-df2290e20c8e') && this.data.driver_Role_Id.toUpperCase() != '57AEAC25-F052-4FA0-B383-92C564C803A6') {
      const dialogRef = this.dialog.open(ReactiveDriverDialog, {
        data: this.data,
        disableClose: true,
        width: '450px',
        panelClass: 'custom-reactive-dialog',
        autoFocus: false
      });

      dialogRef.afterClosed().subscribe(result => {
      });
    }
    else {
      const dialogR = this.dialog.open(ConfirmActionDialog, {
        disableClose: true

      });
      dialogR.afterClosed().subscribe(result => {
        if (result == true) {
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/enable_driver/',
            {
              "User_Id": this.data.user_Id,
              "Driver_Email": this.data.driver_Email
            },
            httpOptions).subscribe(result => {
              this.data.driver_IsEnabled = 1;
            })
        }
      });
    }
    }
    disableUser(){
      const dialogR = this.dialog.open(ConfirmActionDialog, {
        disableClose: true
      });
      dialogR.afterClosed().subscribe(result => {
        if(result == true){
          const  httpOptions = {
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/disable_driver/', 
          { 
            "User_Id": this.data.user_Id,
            "Driver_Email": this.data.driver_Email
              
          }, 
          httpOptions).subscribe(result => {
            this.data.driver_IsEnabled = 0;
      
          })
        }
      });
      
    }
  check() {
   
    if (
      this.fname.value?.trim() == this.data.driver_Firstname.trim() &&
      this.lname.value?.trim() == this.data.driver_Lastname.trim() &&
      this.email.value?.trim().toLowerCase() == this.data.driver_Email.trim().toLowerCase()
      && this.selectedRole.toUpperCase() == this.data.driver_Role_Id.toUpperCase()) {

      if (this.password.value?.trim() != "") {
        this.changed = true;
      } else {
        this.changed = false;
      }
      
    }
    else if (this.fname.value?.trim() == "" ||
      this.lname.value?.trim() == "" ||
      this.email.value?.trim() == "" ){
      this.changed = false;
    }
    else {
      this.changed = true;
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  getRandom(array){
    return array[Math.floor(Math.random() * array.length)];
  }

  generatePassword() {

    var finalCharacters = "";
    finalCharacters = finalCharacters.concat(this.getRandom(this.upperCharacters));
    finalCharacters = finalCharacters.concat(this.getRandom(this.numbers));
    finalCharacters = finalCharacters.concat(this.getRandom(this.symbols));

    for (var i = 1; i < 10 - 3; i++) {
      finalCharacters = finalCharacters.concat(this.getRandom(this.lowerCharacters));
    }
    let pass = finalCharacters.split('').sort(function () {
      return 0.5 - Math.random()
    }).join('');

    this.password.setValue(pass);
    this.check();
  }

}


@Component({
  selector: 'setup-imei-truck-dialog',
  templateUrl: 'setup-imei-truck-dialog.html',
  styleUrls: ['./drivers.component.sass']

})
export class EditTruckImeiDialog {

  lstTruck: any[] = [];
  selectedTruck = new FormControl();
  selectedTruck_new: any;
  lstDevice: any[] = [];
  selectedDevice = new FormControl();
  selectedDevice_new: any;
  httpOptions: { headers: any; };
  prev_selectedTruck: any;
  prev_selectedDevice: any;
  changed: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<EditTruckImeiDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService, 
    private _snackBar: MatSnackBar) {
    var company_Id = '';
    dialogRef.disableClose = true;
    var company_access_id = this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      company_Id = access.company_Id
    })

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
    };
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: data.company.company_Id
      }
    };

    this.http.get<any>(this.configService.resourceApiURI + '/get_devices', httpOptionsTwo).subscribe(result => {
        
      this.http.get<any>(this.configService.resourceApiURI + '/get_available_devices/', httpOptionsTwo).subscribe(resAv => {
          
        this.lstDevice = resAv;
      
        
          var selectedDevice = result.filter(element => {
            if(element.device_Id == data.driver_Device_Id){
              return true;
            }else{
              return false;
            }
          })

        if (selectedDevice.length > 0) {
          this.lstDevice.push(selectedDevice[0]);
          this.selectedDevice.setValue(selectedDevice[0]);
          this.selectedDevice_new = selectedDevice[0];
          this.prev_selectedDevice = selectedDevice[0];
        } else {
          this.prev_selectedDevice = null;
        }
        })

      })
    this.http.get<any>(this.configService.resourceApiURI + '/get_trucks/', httpOptionsTwo).subscribe(result => {

      this.http.get<any>(this.configService.resourceApiURI + '/get_available_trucks/', httpOptionsTwo).subscribe(resAv => {

        this.lstTruck = resAv;
        var selectedTruck = result.filter(element => {
          if(element.truck_Id == data.driver_Truck_Id){
            return true;
          }else{
            return false;
          }
        })
        if (selectedTruck.length > 0) {
          this.lstTruck.push(selectedTruck[0]);
          this.selectedTruck.setValue(selectedTruck[0]);
          this.selectedTruck_new = selectedTruck[0];
          this.prev_selectedTruck = selectedTruck[0];
        }
        else {
          this.prev_selectedTruck = null;

        }
      })
    })
  }
  selectchange(e) {
    this.check();
  }
  check() {
   
    if (this.prev_selectedTruck == this.selectedTruck_new &&
      this.prev_selectedDevice == this.selectedDevice_new 
    ) {

      this.changed = false;
    }
 
    else {
      this.changed = true;
    }
  }
    updateDeviceTruck(){
      this.http.post<any>(this.configService.resourceApiURI + '/update_driver_truck_device/', 
      { 
        "User_Id":  this.data.user_Id,
        "Driver_Truck_Id": this.selectedTruck_new?.truck_Id,
        "Driver_Device_Id": this.selectedDevice_new?.device_Id,

      }, 
      this.httpOptions).subscribe(result => {
        this._snackBar.open("Device updated", "Close", {
          duration: 3000,
        });
      })
      this.dialogRef.close();

    }

    clearDevice(){
      this.selectedDevice.setValue(null);
      this.selectedDevice_new = null;
      this.check();
    }
    clearTruck(){
      this.selectedTruck.setValue(null);
      this.selectedTruck_new = null;
      this.check();
    }
}



@Component({
  selector: 'reactivate-driver-dialog',
  templateUrl: 'reactivate-driver-dialog.html',
  styleUrls: ['./drivers.component.sass']

})
export class ReactiveDriverDialog {

  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<ReactiveDriverDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
  
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
   
   
  }
  new_Driver() {


    const dialogRef2 = this.dialog.open(NewDriversDialog, {
        data: this.data

      });

    dialogRef2.afterClosed().subscribe(result => {
      this.dialogRef.close();

      });
  

  }

  existing_Driver() {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/enable_driver/',
      {
        "User_Id": this.data.user_Id,
        "Driver_Email": this.data.driver_Email

      },
      httpOptions).subscribe(result => {

        this.data.driver_IsEnabled = 1;

      })
    this.dialogRef.close();
  }

}


@Component({
  selector: 'new-drivers-dialog',
  templateUrl: 'new-drivers-dialog.html',
  styleUrls: ['./drivers.component.sass']

})
export class NewDriversDialog {

  httpOptions: { headers: any; };
  lstDrivers: any[] = [];
  selectedDriver: any;

  constructor(
    public dialogRef: MatDialogRef<NewDriversDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

    this.http.get<any>(this.configService.resourceApiURI + '/get_drivers_info/', this.httpOptions).subscribe(result => {
      this.lstDrivers = result;

    });

  }
  
  update_New_Driver() {

    var words = this.selectedDriver.driver_Firstname.split(' ');
    this.http.post<any>(this.configService.resourceApiURI + '/activate_new_driver/',
      {
        "User_Id": this.data.user_Id,
        "Driver_Firstname": words[0],
        "Driver_Lastname": words[words.length - 1],
        "Driver_Id": this.selectedDriver.driver_Id,
        "Driver_Email": this.data.driver_Email
      },
      this.httpOptions).subscribe(result => {
      });

    this.dialogRef.close();
  }

}
