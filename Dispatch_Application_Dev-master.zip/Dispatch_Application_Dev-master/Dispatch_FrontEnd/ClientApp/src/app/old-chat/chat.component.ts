import { animate, state, style, transition, trigger } from '@angular/animations';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, ElementRef, Inject, OnInit, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BehaviorSubject, EMPTY, Subject, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { ChatContainerComponent } from '../chat-container/chat-container.component';
import { AuthService } from '../core/authentication/auth.service';
import { SignalRService } from '../core/chat/signalr';
import { SelectCompanyComponent } from '../select-company/select-company.component';
import { ConfigService } from '../shared/config.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.sass'],
  animations: [
    trigger('openClose', [

      state('open', style({

        opacity: 1,
        backgroundColor: 'yellow'
      })),
      state('closed', style({

        opacity: 0.5,
        backgroundColor: 'green'
      })),
      transition('open => closed', [
        animate('1s')
      ]),
      transition('closed => open', [
        animate('0.5s')
      ]),
    ]),
  ],
})
export class ChatComponent implements OnInit {
  // @ViewChild('messageContainer') container: ElementRef<HTMLElement>;
  // msgContainer: HTMLElement;
  
  @ViewChild(CdkVirtualScrollViewport)
  viewport: CdkVirtualScrollViewport;
  @ViewChild(ChatContainerComponent) child:ChatContainerComponent;
  @ViewChild("messageinput") messageinputField: ElementRef;

  //Important info fields
  connection: string = "";
  userName = "";
  userRole = "";
  userId = "";
  companyID = "";
  userDefaultCompanyId: string;

  yellowFilter: boolean = true;
  blueFilter: boolean = true;
  greenFilter: boolean = true;

  companyID2: any = [];
  chats: any = [];
  filteredChats: any = [];
  selectedChat: any = [];
  openedChat: any = {
    messages: []
  };

  //Search
  searchValue: string = '';
  searchMessagesContainer: boolean = false;
  foundMessages: any;

  statusChatOpened: boolean = false;
  lastStatusMessage: string = "";
  lastStatusTimeout: any;

  unreadMessagesInRooms: boolean = false;
  unreadMessagesInDrivers: boolean = false;
//History

  loadingChat: boolean = false;
  loadingMessages: boolean = false;

  inHistory: boolean = false;
  endOfHistory: boolean = false;

  httpOptions: any;
  value: string = '';

  //Typing handlers
  typing: string = '';
  typingArray: string[];
  isTyping = false;
  private chatTypingSubscription: Subscription;
  term$ = new Subject<string>();
  private driverTypingSubscription: Subscription;
  driverTyping$ = new Subject<string>();
  

  messageScope: string = "All";

  //Users handlers
  allDispatchUsers: any = [];
  
  //Breaks
  breakTime: number = 107;
  breakType: string = "Short";
  breakTimeSelected: number = 900;
  breakVisible: boolean = false;
  breakTimer: any;

  //TESTING


  driverInfoOpened: boolean = false;
  driverInfo: any = {
    driver_Id: "",
    d_Id: "",
    driver_Email: "",
    driver_Firstname: "",
    driver_Lastname: "",
    driver_Phone: ""
  };

  //Critical error
  applicationCrashed: boolean = false;
  errorMessage: string = "";
  loginToCn: boolean;
  userCompaniesAccess: any = [];
  selectedCompany = new FormControl();

  constructor(public http: HttpClient, private signalRService: SignalRService, private authService: AuthService, private configService: ConfigService, public dialog: MatDialog, private _snackBar: MatSnackBar) {



    this.typingArray = new Array<string>();
    this.chatTypingSubscription = this.term$.pipe(
      debounceTime(1500),
      distinctUntilChanged(),
      switchMap(term => {
        this.isTyping = false;
        this.signalRService.sendToServer("UserStoppedTyping", {userName: this.userName, chat_Id: this.openedChat.chat_Id });
        return EMPTY;
      })
    ).subscribe();

    this.driverTypingSubscription = this.driverTyping$.pipe(
      debounceTime(1500),
      switchMap(term => {

        this.typingArray = this.typingArray.filter(str => str != "Driver");
        this.handleTypingDisplay();

        return EMPTY;
      })
    ).subscribe();
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
  }
  ngAfterViewChecked(): void{
    //console.log("FIRED");
  }

  ngOnInit() {
    

    //Get username, role, id of the current user
    this.authService.userNameStatus$.subscribe(uName => this.userName = uName);
    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userIdStatus$.subscribe(uId => this.userId = uId);
    this.signalRService.connectionStatus$.subscribe(connection => this.connection = connection);

    this.http.get<any>(this.configService.resourceApiURI + '/get_dispatch_users/', this.httpOptions).subscribe(result => {

      this.allDispatchUsers = result;

    })
    
    this.authService.userCompanyId$.subscribe(access => {
      if (access) {
        this.userDefaultCompanyId = access;
        //console.log(this.userDefaultCompanyId);
      }
    });
  

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.companyID = access?.company_Id;
      /*  this.http.post<any>(this.configService.resourceApiURI + '/get_company_type/',
          this.companyID,
          this.httpOptions).subscribe(result => {
            this.companyID2 = result;

          });*/
        this.selectedCompany.setValue(access);
        this.chats = [];
        this.filteredChats = [];
        this.openedChat = {
          messages: []
        };


        this.loadChats();
      }
    });

    
    
    //this.loadFirstChat();

    //Handler for receiving new messages
    this.signalRService.getMessage(
      (message: any) => {
        if(message.from_User_Id != this.userId){
            var chat = this.chats.find(chat => chat.chat_Id.toLowerCase() === message.chat_Id.toLowerCase());
            if(chat){
                chat.messages.push(message)
         //     console.log(message)
              if(this.openedChat.chat_Id.toLowerCase() == message.chat_Id.toLowerCase()){
                setTimeout(()=>{
                  this.child.newMessage();
                },400)
                
              }
            }
            if(chat.chat_Type == 'CUSTOM' || chat.chat_Type == 'GENERAL'){
              this.unreadMessagesInRooms = true;
            }
            if(chat.chat_Type == 'DRIVER' ){
              this.unreadMessagesInDrivers = true;
            }
          
          
        } else {
         // console.log(message);
          this.openedChat.messages.find(mess => mess.message_Text == message.message_Text && mess.message_Id == null).message_Id = message.message_Id;
          this.openedChat.messages = [...this.openedChat.messages];
        //  console.log(message);
          
        }
        
        if(message.chat_Id = this.openedChat.chat_Id){
          if(!this.inHistory){
            this.child.scrollChat();
            
          }
        }
      }
    );


    //Typing methods

    this.signalRService.onStartedTyping(
      (typing: any) => {
        if(typing.chat_Id == this.openedChat.chat_Id && typing.username != this.userName){
          this.typingArray.push(typing.username);
          this.handleTypingDisplay();
        }
      }
    );
    this.signalRService.onStoppedTyping(
      (typing: any) => {
        this.typingArray = this.typingArray.filter(str => str != typing.username);
        this.handleTypingDisplay();
      }
    );
    this.signalRService.onSetChatLevel(
      (chat_Id: any, level: any) => {
        var chat = this.chats.find(chat => chat.chat_Id.toLowerCase() === chat_Id.toLowerCase());
        if(chat){
          chat.chat_Level = level;
          this.organiseChatList();
          if(level == 2){
            clearInterval(chat.interval);
            chat.timer = 30;
            chat.interval = setInterval(() => {
              chat.timer--;
            },1000)
          }else {
            chat.timer = "";
            clearInterval(chat.interval);
          }
        }
      }
    );

    this.signalRService.onDriverTyping(
      (typing: any) => {
        if(typing.chat_Id == this.openedChat.chat_Id){
          if(!this.typingArray.includes("Driver")){
            this.typingArray.unshift("Driver")
          }
  
          this.driverTyping$.next();
          this.handleTypingDisplay();
        }
        
      }
    );

    this.signalRService.onBroadcastMessage(
      (broadcast: any) => {

        this.chats.forEach(chat => {
          if(broadcast.chat_Ids.includes(chat.chat_Table)){
            chat.messages = [...chat.messages, broadcast.message]
          }
        });
        this.openedChat.messages = [...this.openedChat.messages];

      }
    );

    this.signalRService.onClosedConnection(
      (mes) => {
        if(!this.applicationCrashed){
          this.applicationCrashed = true;
          this.errorMessage = "You lost connection to the server";
          this.authService._userName.next("error");

        }
      }
    )



    this.signalRService.onCurrentUsersOnlineList(
      (list) => {
        this.allDispatchUsers.forEach(user => {
          user.status = "Offline";
        })

        list.forEach(onlineUser => {
          this.allDispatchUsers.forEach(user => {
            if(user.user_Id == onlineUser.user_Id){
              user.status = onlineUser.status
            }
          });
        });
       }
    );
    this.signalRService.onUserStatusUpdate(
      (md) => {

        if(this.selectedCompany.value?.company_Id == md.company_Id){
          
            var chat = this.chats.find(chat => chat.chat_Type == "STATUS");
          if(chat){
            chat.messages = [...chat.messages, {from_User_Id: md.message.from_User_Id, 
              message_From_User_Role: md.message.message_From_User_Role,
              message_From_User_Name: md.message.message_From_User_Name,
              message_Text: md.message.message_Text, 
              chat_Id: md.message.chat_Id, 
              message_Date: md.message.message_Date}];
              
          }
      //  this.scrollChat();
       this.child.scrollChat();
        }
        //clearTimeout(this.lastStatusTimeout);
     
      }

    );
    this.signalRService.onUpdateChats(
      (typing: any) => {
        setTimeout(()=>{
          
          this.loadChats();
        }, 1000)
        
        
      }
    );
  // Buttons functionality

    this.signalRService.onHideMessage(
      (message: any) => {
        this.chats.find(chat => chat.chat_Id == message.chat_Id).messages.find(mes => mes.message_Id == message.message_Id).message_Is_Visible = message.message_Is_Visible;
      }
    );
    this.signalRService.onAssignChatToDispatch(
      (am: any) => {
        let check = false;
        am.user_Ids.forEach(element => {
          if(element == this.userId){
            check = true;
          }
        });
        if(check){
          let chat = this.chats.find(chat => chat.chat_Id === am.chat_Id);
          if(chat){
            chat.assignedId = this.userId;
          }
        }
 
      }
    );
    this.signalRService.onReleaseAssignedChat(
      (chat_Id: any) => {
        let chat = this.chats.find(chat => chat.chat_Id === chat_Id);
        chat.assignedId = null;
 
      }
    );

  }

//loadChats
  onTabSelect(e) {


    if (e.title == "Drivers") {
      this.openedChat = {messages:[]};
    }
    else if (e.title == "Rooms") {
      this.loadChats();
    }

  }
loadChats(){
  var httpOptionsTwo = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': this.authService.authorizationHeaderValue
    }),
    params: {
      Company_Id: this.selectedCompany.value.company_Id,
      User_Id: this.userId

    }     
  };
  this.http.get<any>(this.configService.resourceApiURI + '/get_chats/', httpOptionsTwo).subscribe(result => {
    this.chats = result;
    
    //this.openedChat = {};
    this.organiseChatList();
    this.openedChat = this.chats.filter(elem => {
      if(elem.chat_Type == 'GENERAL'){
        return true
      }else{
        return false
      }
    })[0];
    setTimeout(()=>{
      //this.child.newMessage();
      this.closeStatusChat();
    },30)
    
  })
  
}




// Properly display who is typing

  handleTypingDisplay(){
    if(this.typingArray.length == 1){
      this.typing = this.typingArray[0] + " is typing..."
    }else if(this.typingArray.length >= 2 ){
      this.typing = this.typingArray[0] + " and " + (this.typingArray.length - 1) + " other are typing..."
    }else{
      this.typing = "";
    }
  }

  //Sending notification to the server that the user is typing

  handleTypingNotification($event){
    if(this.isTyping == false){
      this.isTyping = true;
      this.signalRService.sendToServer("UserStartedTyping", {userName: this.userName, chat_Id: this.openedChat.chat_Id });
    }
    this.term$.next($event.target.value);
  }

  //Search
  search(event){
    if (event.key === "Enter") {
      this.searchMessagesContainer = true;
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Search_Value: this.searchValue,
          Company_Id: this.selectedCompany.value.company_Id
        }       
      };
      this.http.get<any>(this.configService.resourceApiURI + '/search_messages_in_chats/', httpOptions).subscribe(result => {        
        this.foundMessages = result;

      })
    }
    this.organiseChatList();
  }

  closeSearch(){
    this.searchMessagesContainer = false;
    this.searchValue = "";
    this.organiseChatList();
  }

  //Filter by color
  toggleFilter(str){
    if(str == "yellow"){
      this.yellowFilter = !this.yellowFilter;
    }else if(str == "blue"){
      this.blueFilter = !this.blueFilter;
    }else if(str == "green"){
      this.greenFilter = !this.greenFilter;
    }

    this.organiseChatList();
  }

  //Sort
  organiseChatList(){
    if(this.searchValue != '' && this.searchMessagesContainer != true){
      this.filteredChats = this.chats.filter(chat => {
        if(chat.chat_Name.includes(this.searchValue)){
          return true
        }else{
          return false
        }
      })
    }else{
      this.filteredChats = this.chats.filter(chat => {
        if(this.yellowFilter && chat.chat_Level == 2){
          return true
        }else if (this.blueFilter && chat.chat_Level == 1){
          return true
        }else if(this.greenFilter && chat.chat_Level == 0){
          return true
        }else{
          return false
        }
      })
      if(this.filteredChats.length > 1){

        this.filteredChats.sort((a, b) => Date.parse(a.messages[a.messages.length-1]?.message_Date) > Date.parse(b.messages[b.messages.length-1]?.message_Date) ? 1 : -1);
          this.filteredChats.sort((a, b) => a.chat_Level < b.chat_Level ? 1 : -1);
          this.filteredChats.sort((a, b) => a.assignedId == this.userId || a.assignedId == "ME"  ? -1 : 0);
    
      }


    }
    
  }

  ngOnDestroy(): void {
    //this.signalRService.disconnect();
 }



/*onScroll(event){

   if(!this.loadingChat){
     if(this.container?.nativeElement.scrollHeight > this.container?.nativeElement.scrollTop + 800){
       this.inHistory = true;
     }else{
       this.inHistory = false;
     }
     if(!this.endOfHistory && this.openedChat.chat_Type != "STATUS"){
       if(this.container?.nativeElement.scrollTop < 30){
        
         if(!this.loadingMessages){

           this.loadingMessages = true;
          
           let httpOptions = {
             headers: new HttpHeaders({
               'Content-Type':  'application/json',
               'Authorization': this.authService.authorizationHeaderValue
             }),
             params: {
               Chat_Table: this.openedChat.chat_Table,
               Last_Message_Id: this.openedChat.messages[0]?.message_Id
             }       
           };

           this.http.get<any>(this.configService.resourceApiURI + '/get_messages_from_history/', httpOptions).subscribe(result => {
            
             this.container.nativeElement.scrollTo({
               top: 2
             })
             result.forEach(element => {
               this.openedChat.messages = [element, ...this.openedChat.messages];
             });
            
  
             if(result.length < 10){
               this.endOfHistory = true;
             }

               setTimeout (() => {
                 this.loadingMessages = false;
              }, 500);

           })
         }
       }
     }
    
   }

}*/

scrollToBottomBtnHandler(){
  this.inHistory = false;
  // this.scrollChat();
  this.child.scrollChat();

}

 //loading messages for the specific chat
 loadChat(){
  this.selectedChat[0] = this.openedChat;
  this.searchMessagesContainer = false;
  this.driverInfoOpened = false;
  this.inHistory = false;
  this.endOfHistory = false;
  this.loadingChat = true;
  if(this.openedChat.messages.length > 30){
    this.openedChat.messages = this.openedChat.messages.slice(this.openedChat.messages.length - 30)
  }
  
  this.openedChat.messages  = this.chats.find(chat => chat.chat_Id === this.openedChat.chat_Id).messages;
  if(this.openedChat.messages.length < 20){
    this.endOfHistory = true;
  }

  setTimeout(()=>{
    this.child.loadingNewChat();
  },50)
  setTimeout (() => {
    //this.child.scrollChat();
    
    this.loadingChat = false;
 }, 500);
 }

 //Sending a message
 /*sendMessage(){
   
   if(this.value != ''){
    let message = this.value;
    let mes: MessageModel = {
      from_User_Id: this.userId,
      message_Text: message,
      chat_Id: this.openedChat.chat_Id,
      message_Date:  new Date().toISOString(),
      message_From_User_Role: this.userRole,
      chat_Table: this.openedChat.chat_Table,
      message_From_User_Name: this.userName,
      message_Is_Visible: true,
      message_To_Group: this.messageScope
    };

    this.value = '';
    this.searchValue = '';
    if(this.messageScope == "Broadcast"){
      let chatIds = [];
      this.chats.forEach(element => {
        chatIds.push(element.chat_Table)
      });

      this.signalRService.sendToServer("BroadcastMessage", {'Chat_Ids':chatIds, 'Message': mes});
    }
    else if (this.openedChat.chat_Type == 'YARD') {
      this.signalRService.sendToServer("SendToYard", mes);
      this.openedChat.messages = [...this.openedChat.messages, mes]
    }
    else {
      this.signalRService.sendToServer("MessageToServer", mes);
      this.openedChat.messages = [...this.openedChat.messages, mes]
    }
    this.messageScope = "All"
    this.signalRService.sendToServer("UserStoppedTyping", {userName: this.userName, chat_Id: this.openedChat.chat_Id });
    this.inHistory = false;
    // this.scrollChat();
    this.child.scrollChat();


   }

 }*/

  sendMessage() {
   
    if (this.value != '') {
      let message = this.value;
      let mes: MessageModel = {
        from_User_Id: this.userId,
        message_Text: message,
        chat_Id: this.openedChat.chat_Id,
        message_Date: new Date().toISOString(),
        message_From_User_Role: this.userRole,
        chat_Table: this.openedChat.chat_Table,
        message_From_User_Name: this.userName,
        message_Is_Visible: true,
        message_To_Group: this.messageScope
      };

      this.value = '';
      this.searchValue = '';
      if (this.messageScope == "Broadcast") {
        let chatIds = [];
        this.chats.forEach(element => {
          chatIds.push(element.chat_Table)
        });

        this.signalRService.sendToServer("BroadcastMessage", { 'Chat_Ids': chatIds, 'Message': mes });
      } else if (this.openedChat.chat_Type == 'YARD') {
        this.signalRService.sendToServer("SendToYard", mes);
        this.openedChat.messages = [...this.openedChat.messages, mes]
      } else {
        this.signalRService.sendToServer("MessageToServer", mes);
        this.openedChat.messages = [...this.openedChat.messages, mes]
      }
      this.messageScope = "All"
      this.signalRService.sendToServer("UserStoppedTyping", { userName: this.userName, chat_Id: this.openedChat.chat_Id });
      this.inHistory = false;
     // this.scrollChat();
      this.child.scrollChat();
    }

  }


 //Hide message
 hideMessage(mes){
   mes.message_Is_Visible = !mes.message_Is_Visible;
   this.signalRService.sendToServer("HideMessage", mes);
   
 }

 readMessagesInRooms(){
   this.unreadMessagesInRooms = false;
 }
 readMessagesInDrivers(){
  this.unreadMessagesInRooms = false;
}
// Mark the task as closed (blue)

markChatAsClosed(code)
{
  this.signalRService.sendToServer("SetChatLevelAsClosed", {chat_Id: this.openedChat.chat_Id, chat_Level: code} );
  this.openedChat.chat_Level = code;
  this.openedChat.timer = "";
  var chat = this.chats.find(chat => chat.chat_Id.toLowerCase() === this.openedChat.chat_Id.toLowerCase());
  clearInterval(chat.interval);
}

// On click in list load new chat

  loadNewChat(event) {
  this.messageScope = "All";
  this.messageinputField.nativeElement.focus();
  this.statusChatOpened = false;
  this.signalRService.sendToServer("UserStoppedTyping", {userName: this.userName, chat_Id: this.openedChat.chat_Id });
  if(event[0]){
    if(this.openedChat.chat_Id != event[0].chat_Id){
      this.openedChat = event[0];
      this.loadChat();
     }
     if(event[0].chat_Type == 'GENERAL' || event[0].chat_Type == 'CUSTOM' ){
       this.unreadMessagesInRooms = false;
     }
  }
  
  
 }

 //Opening general chat
 openStatusChat(){
   if(this.statusChatOpened == true){
     this.closeStatusChat();
   }else{
    this.statusChatOpened = true;
    this.selectedChat = [];
    this.openedChat = this.chats.filter(chat => chat.chat_Type == "STATUS")[0];
    // this.scrollChat();
    this.child.scrollChat();

   }
 }

 closeStatusChat(){
  this.statusChatOpened = false;
  this.openedChat = this.chats.filter(chat => chat.chat_Type == "GENERAL")[0];
  setTimeout(()=>{
    this.child?.scrollChat();
  },10)


}
selectCompany($e){
  this.chats = [];
  this.filteredChats = [];
  this.openedChat = {
    messages: []
  };


  this.loadChats();
}
 // Open dialogs

 /* openDialog(event, message): void {
    
    const dialogRef = this.dialog.open(ChatDialog, {
      data: {latitude: message.message_Latitude, longitude: message.message_Longitude}
    });

    dialogRef.afterClosed().subscribe(result => {
    });

  }*/

  openCreateChatDialog() : void{
    const dialogRef = this.dialog.open(ChatControlDialog, {
      
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }
  openAssignDialog() : void{
    let assignedToMe;
    if(this.openedChat.assignedId == this.userId){
      assignedToMe = true;
    }else{
      assignedToMe = false;
    }

    let users = this.allDispatchUsers;

    const dialogRef = this.dialog.open(AssignDialog, {
      data: {chat_Id: this.openedChat.chat_Id, assignedToMe: assignedToMe, usersOnline: users, userId: this.userId}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.organiseChatList();
    });
  }

 /* openImagesDialog() : void{
    const dialogRef = this.dialog.open(ImagesDialog, {
      data: {test: 1}
    });
  }*/

 //Breaks

startBreak(number){
  //clearTimeout(this.idleTimeout);
  if(number == 5){
    this.breakType = "Short";
    this.breakTimeSelected = 300;
  }else if(number == 30){
    this.breakType = "Lunch";
    this.breakTimeSelected = 1800;
  }else if(number == 60){
    this.breakType = "Meeting";
    this.breakTimeSelected = 3600;
  }else if(number == -1){
    this.breakType = "Indefinite";
    this.breakTimeSelected = -1;
  }
  this.breakTime = 0;
  this.breakTimer = setInterval(()=>{
    this.breakTime++;
  }, 1000)

  this.signalRService.sendToServer("StartBreak", this.userId);
  this.breakVisible = true;
}

finishBreak(){
  this.breakVisible = false;
  clearInterval(this.breakTimer);
  this.signalRService.sendToServer("EndBreak", this.userId);
  // this.idleTimeout = setTimeout(() => {
  //   this.timeoutUser();
  // }, this.idleTime)
}

  openDriverInfo(driverId){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        User_Id: driverId,
      }       
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_driver_info_for_chat/', httpOptions).subscribe(result => {
      this.driverInfo = result;
      this.driverInfoOpened = true;
      

    })
    
  }

  closeDriverInfo(){
    this.driverInfoOpened = false;
  }

  timeoutUser(){
    this.signalRService.timeoutUser();
    this.applicationCrashed = true;
    this.errorMessage = "You have been inactive for too long!"
    this.authService._userName.next("error");
  }

  refresh(): void {
    window.location.reload();
}




}



/*@Component({
  selector: 'map-dialog',
  templateUrl: 'map-dialog.html',
})
export class ChatDialog {

  zoom = 15;
  center = {
    lat: 43.643455,
    lng: -79.628178,
  }
  constructor(
    public dialogRef: MatDialogRef<ChatDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.center = {
        lat: parseFloat(data.latitude),
        lng: parseFloat(data.longitude)
      }
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

}*/



@Component({
  selector: 'chat-control',
  templateUrl: 'chat-control.html',
  styleUrls: ['./chat.component.sass']
})
export class ChatControlDialog {

nameValue: string = '';

chats: any[] = [];


rolesLst: any[] = [];

selRoles: any[] = [];

selectedChat: any = [];

chatRolesSelected : any[] = [];


chatCreation: boolean = false;
selectedCompany = new FormControl();
companies: any[] = [];
newChatName = new FormControl();

httpOptions: any
  chatsLst: any;

  constructor(
    public dialogRef: MatDialogRef<ChatControlDialog>,public http: HttpClient, private authService: AuthService, private configService: ConfigService, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      
      const  httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };

    this.http.get<any>(this.configService.resourceApiURI + '/get_roles/', httpOptions).subscribe(result => {
      let notDisplayed = [];
      notDisplayed.push("Driver");
      notDisplayed.push("Admin");
      this.rolesLst = result.filter((elem) => {
        return !notDisplayed.includes(elem.role_Name)
      } );
    })
    
    this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', httpOptions).subscribe(result => {
      this.companies = result;
    })

    }

    selectCompany($e){
      
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          company_Id: $e.company_Id
        }       
      };
      this.http.get<any>(this.configService.resourceApiURI + '/get_chats_for_chat_control/', httpOptions).subscribe(result => {
        
        let chatsLst = [];
        result.forEach(element => {
          if(element.chat_Type != 'STATUS' && element.chat_Type != 'DRIVER' ){
            chatsLst.push(element);
          }
        });
        this.chats = chatsLst.sort((a, b) => {
          if(a.chat_Status == true){
            return -1
          }else{
            return 1
          }
        } );
      })
    }


    selectChat($e){

      if(this.selectedChat[0]?.chat_Type == 'CUSTOM'){
        let selectedRoles = [];
        this.selectedChat[0].roles.forEach(chR => {
          this.rolesLst.forEach(rol => {
            if(chR.toLowerCase() == rol.role_Id.toLowerCase()){
              selectedRoles.push(rol);
            }
          });
        });
        this.chatRolesSelected = selectedRoles;
      }
      

    }

    /*disableChatClick(){
      const dialogRef = this.dialog.open(ConfirmActionDialog, {
        
      });
      dialogRef.afterClosed().subscribe(result => {

        if(result == true){
          const  httpOptions = {
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/disable_chat/', 
          { 
              "Chat_Id": this.selectedChat[0].chat_Id,
              "Chat_Type": this.selectedChat[0].chat_Type,
              
          }, 
          httpOptions).subscribe(result => {
            this.selectedChat[0].chat_Status = false;
            
          })
          this.chats = this.chats.sort((a, b) => {
            if(a.chat_Status == true){
              return -1
            }else{
              return 1
            }
          } );
        }
      });
    }

    enableChatClick(){
      const dialogRef = this.dialog.open(ConfirmActionDialog, {
        
      });
      dialogRef.afterClosed().subscribe(result => {

        if(result == true){
          const  httpOptions = {
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/enable_chat/', 
          { 
              "Chat_Id": this.selectedChat[0].chat_Id,
              "Chat_Type": this.selectedChat[0].chat_Type,
              
          }, 
          httpOptions).subscribe(result => {
            this.selectedChat[0].chat_Status = true;

      
          })
    
        }
      });
    }*/

    editChatRoles(){
      let rolesSelected = [];
      this.chatRolesSelected.forEach(elem => {
        rolesSelected.push(elem.role_Id);
      })

      const  httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };
      this.http.post<any>(this.configService.resourceApiURI + '/edit_chat_roles/', 
      { 
          "Chat_Id": this.selectedChat[0].chat_Id,
          "Roles": rolesSelected
      }, 
      httpOptions).subscribe(result => {
        this.newChatName.setValue("");
        this.selRoles = [];
  
      })

    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  createNewChat(){
    this.chatCreation = true;
  }
  backToChatList(){
    this.chatCreation = false;

  }

  createChat(){

    var chatRoles = new Array;
    this.selRoles.forEach(elem => {
      chatRoles.push(elem.role_Id);
    })

    const  httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/create_custom_chat/', 
    { 
        "Chat_Name": this.newChatName.value,
        "Chat_Company": this.selectedCompany.value.company_Id,
        "Chat_Roles": chatRoles
    }, 
    httpOptions).subscribe(result => {
      this.newChatName.setValue("");
      this.selRoles = [];

    })
    this.chatCreation = false;
    let httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        company_Id: this.selectedCompany.value.company_Id
      }       
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_chats_for_chat_control/', httpOptionsTwo).subscribe(result => {
      let chatsLst = [];
        result.forEach(element => {
          if(element.chat_Type != 'STATUS' && element.chat_Type != 'DRIVER' ){
            chatsLst.push(element);
          }
        });
        this.chats = chatsLst;
    })
    
  }

}




@Component({
  selector: 'assign-dialog',
  templateUrl: 'assign-dialog.html',
  styleUrls: ['./chat.component.sass']
})
export class AssignDialog {


  userLst: any[] = [];
  rolesLst: any[] = [];

  selUsers: any[] = [];
selRoles: any[] = [];



public chat_Id: string;

public assignedToMe;
  userId: any;

  constructor(
    public dialogRef: MatDialogRef<ChatControlDialog>,public http: HttpClient,private signalRService: SignalRService, private authService: AuthService, private configService: ConfigService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.chat_Id = data.chat_Id;
      this.assignedToMe = data.assignedToMe;
      this.userLst = data.usersOnline;
      this.userId = data.userId;
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };

  //On load receive the available chats
  this.http.get<any>(this.configService.resourceApiURI + '/get_roles/', httpOptions).subscribe(result => {
      let notDisplayed = [];
      notDisplayed.push("Driver");
      this.rolesLst = result.filter((elem) => {
        return !notDisplayed.includes(elem.role_Name)
      } );
    })
    }

selectRole(role){
      let selUsersOld = this.selUsers;

      if(this.selRoles.includes(role)){
       this.selUsers = this.userLst.filter(user => {
         if(selUsersOld.includes(user)){
           return true;
         }
         if(user.user_Role == role.role_Id){
           return true;
         }else{
           return false;
         }
       });

      }else{
        this.selUsers = this.userLst.filter(user => {
          if(selUsersOld.includes(user)){
            if(user.user_Role == role.role_Id){
              return false;
            }else{
              return true
            }
          }else{
            return false
          }
        });
      }

      this.userLst.sort((a,b)=> {
        if(this.selUsers.includes(a)){
          return -1
        }
        if(this.selUsers.includes(b)){
          return 1
        }else{
          return 0
        }
        
      })
      


    }

    assignToDispatch(){
     
     let selIds = [];

     this.selUsers.forEach(element => {
       selIds.push(element.user_Id)
     });

     this.signalRService.sendToServer("AssignChatToDispatch", {Chat_Id: this.chat_Id, User_Ids: selIds });
     
    }

    releaseAssign(){
      
      this.signalRService.sendToServer("ReleaseAssignedChat", {Chat_Id: this.chat_Id, User_Ids: [this.userId] });
     }
  
    onNoClick(): void {
      this.dialogRef.close();
    }

}


/*@Component({
  selector: 'images-dialog',
  templateUrl: 'images-dialog.html',
})
export class ImagesDialog {

  imgs: any = []
  
  constructor(
    public dialogRef: MatDialogRef<ChatDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      let todayDate = Date.now();
      let startDate  = Date.parse('12-01-2020');
      for(let i = 0; i < 30; i++){
        this.imgs.push({date: this.randomDate(startDate, todayDate)})
      }
      
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  randomDate(start, end) {
    var date = new Date(+start + Math.random() * (end - start));
    return date;
  }

}*/





export interface Chat {
  chat_Id: string;
  chat_Name: string;
  chat_Level: string;
}

export interface MessageModel {
  message_Id?: any;
  from_User_Id: string;
  message_From_User_Role?: string;
  message_From_User_Name?: string;
  message_Text: string;
  chat_Id: string;
  message_Date?: any;
  message_Latitude?: string;
  message_Longitude?: string;
  chat_Table: string;
  message_Is_Visible: boolean;
  message_To_Group: string;
}

