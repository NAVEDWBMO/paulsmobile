import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, SelectableSettings, RowArgs} from '@progress/kendo-angular-grid';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router'
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
//import { Console } from 'console';


@Component({
  selector: 'app-permissions',
  templateUrl: './permissions.component.html',
  styleUrls: ['./permissions.component.sass']
})
export class PermissionsComponent implements OnInit {
  locations: any;
  httpOptions: { headers: any; };

  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  public gridData: any[] = [];
  public permissionTypes: any[] = [];
  public permissions: any[] = [];
  public Selectedpermissions: any = [];
  public filteredPermissions: any = [];

  public selectedPermission: any = [];
  public selectedCompanyId: string;
  public selectedPermissionType: any = [];
  public selectableSettings: SelectableSettings;
  public mySelection: any[] = [];
  
  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {


    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })

    };
    this.authService.userCompanyAccessSelectedStatus$
      .subscribe(access => {
        this.selectedCompanyId = access.company_Id;
        if (this.router.url === '/permissions') {
          if (this.selectedCompanyId.toUpperCase() != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E') {
            this.router.navigateByUrl('/home');
          }
        }
     
      });
/*    this.selectableSettings = {
      checkboxOnly: true,
      mode: 'multiple'
    };*/
   }

  ngOnInit(): void {

   
    this.http.get<any>(this.configService.resourceApiURI + '/get_permission_types/', this.httpOptions)
      .subscribe(result => {
        this.permissionTypes = result.sort(function (a, b) {
          if (a.permission_Type_Name < b.permission_Type_Name) { return -1; }
          if (a.permission_Type_Name > b.permission_Type_Name) { return 1; }
          return 0;
        });

        this.selectedPermissionType[0]=this.permissionTypes[0];
        this.get_permissions();

     })



  }

  pageChange(event: PageChangeEvent): void
  {
    this.skip = event.skip;
    this.loadItems();
  }

  loadItems(): void
  {
   
  this.gridView = {
    data: this.gridData.slice(this.skip, this.skip + this.pageSize),
      total: this.gridData.length
  };
  }

/*  selectedKeysChange(rows: any[]) {

  }
  public onSelectedKey(context: RowArgs): any {
    return context.dataItem;
  }*/

  selectType(e)
  {
    this.selectedPermissionType = e;
    this.filteredPermissions=this.permissions.filter(ele => {
        if (ele.permission_Type_Id.toLowerCase() == this.selectedPermissionType[0].permission_Type_Id.toLowerCase()) {
            return true;
          }
          else {
            return false;
      }
    });
    this.selectedPermission = [];
    this.gridData = [];
    this.skip = 0;
    this.loadItems();
  }
  selectPermission(data)
  {
    this.selectedPermission = data;
    this.get_access_level();
  }

  get_permissions() {
    this.http.get<any>(this.configService.resourceApiURI + '/get_permissions/', this.httpOptions)
      .subscribe(result => {
        this.permissions = result
        /* .sort(function (a, b) {
         if (a.permission_Function < b.permission_Function) { return -1; }
         if (a.permission_Function > b.permission_Function) { return 1; }
         return 0;
       });*/
        this.filteredPermissions = result.filter(ele => {
          if (ele.permission_Type_Id.toLowerCase() == this.selectedPermissionType[0].permission_Type_Id.toLowerCase()) {
            return true;
          }
          else {
            return false;
          }
        });
      })
  }
  get_access_level()
  {
    const httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        "Permission_Id": this.selectedPermission[0].permission_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_permission_access_level/', httpOptionsTwo)
      .subscribe(result => {
        this.gridData = result;
        this.skip = 0;
        this.loadItems();
      })
  }

  openDialog(dataItem)
  {
    const dialogRef = this.dialog.open(EditPermissionsAccessLevelDialog, {
      width: '500px',
      data: { 'selectedPermissionAccess': dataItem, 'selectedPermission': this.selectedPermission},
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.get_access_level();

    });
  }
  openEditPermissionsDialog(dataItem) {
    const dialogRef = this.dialog.open(EditPermissionsDialog, {
      width: '500px',
      data: { 'selectedPermission': dataItem, 'selectedPermissionType': this.selectedPermissionType[0],'allPermissions': this.filteredPermissions },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != true) {
        this.refreshPermissions();
        this.gridData = [];
        this.skip = 0;
        this.loadItems();
      }

    });
  }
  openEditPermissionsTypeDialog(dataItem) {
    const dialogRef = this.dialog.open(EditPermissionsTypeDialog, {
      width: '500px',
      data: { 'selectedPermissionType': dataItem, 'allPermissionsTypes': this.permissionTypes },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result =="delete") {
        this.refreshpermissiontypes();
        this.gridData = [];
        this.skip = 0;
        this.loadItems();
      }
      
    });
  }
  refreshpermissiontypes() {
    this.http.get<any>(this.configService.resourceApiURI + '/get_permission_types/', this.httpOptions)
      .subscribe(result => {
        this.permissionTypes = result.sort(function (a, b) {
          if (a.permission_Type_Name < b.permission_Type_Name) { return -1; }
          if (a.permission_Type_Name > b.permission_Type_Name) { return 1; }
          return 0;
        });

        this.selectedPermissionType[0]=this.permissionTypes[0];
        this.refreshPermissions();
        this.gridData = [];
        this.loadItems;
      })


  }
  refreshPermissions() {
    this.get_permissions();

    
  }

  openAddDialog(){
    const dialogRef = this.dialog.open(AddPermissionsDialog, {
      width: '500px',
      data: { 'selectedPermissionType': this.selectedPermissionType[0], 'allPermissions': this.filteredPermissions },
    disableClose: true
  });

  dialogRef.afterClosed().subscribe(result => {
    this.refreshPermissions();
   
  });

  }
  openAddPermissionTypeDialog() {
    const dialogRef = this.dialog.open(AddPermissionsTypeDialog, {
      width: '500px',
      data: { 'allPermissionsTypes': this.permissionTypes },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshpermissiontypes();

    });

  }


 

}

@Component({
  selector: 'edit-permissions-dialog',
  templateUrl: 'edit-permissions-dialog.html',
})
export class EditPermissionsDialog {


  httpOptions: { headers: any; };
  dataItems: any = [];
  permission_Function: string = '';
  sort_Order: number;
  IsValid: boolean;

  constructor(
    public dialogRef: MatDialogRef<EditPermissionsDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar)
    {
      dialogRef.disableClose = true;
      this.httpOptions = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
      };
    this.dataItems = this.data.selectedPermission;
    this.permission_Function = this.dataItems.permission_Function?.trim();
    this.sort_Order = this.dataItems.sort_Order;

    this.data.allPermissions = this.data.allPermissions.filter(ele => { if (ele.permission_Function.toLowerCase() != this.dataItems.permission_Function.toLowerCase()) { return ele;} });


    }
  check_validation() {
    if (this.permission_Function?.trim() != '' && this.sort_Order > 0 && this.sort_Order != null  ){
      if (this.permission_Function?.trim() != this.dataItems.permission_Function?.trim()
        || this.sort_Order != this.dataItems.sort_Order) {
        this.IsValid = true;
      } else {
        this.IsValid = false;

      }
    }
    else {
      this.IsValid = false;
    }

  }
  delete_permission() {

    const dialogR = this.dialog.open(ConfirmActionDialog, {

    });
    dialogR.afterClosed().subscribe(result => {

      if (result == true) {
        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),

        };
        this.http.post<any>(this.configService.resourceApiURI + '/delete_permission/', {

          "permission_Id": this.dataItems.permission_Id,
          "permission_Type_Id": this.data.selectedPermissionType.permission_Type_Id,
          "sort_Order": this.sort_Order

        }, httpOptionsTwo).subscribe(result => {

          this.dialogRef.close();


        })
      }
    })


  }
  onEditClick(): void {
    
    const index = this.data.allPermissions.map(ele => { return ele.permission_Function?.trim().toUpperCase() }).indexOf(this.permission_Function?.trim().toUpperCase());

    if (index > -1) {
      this.dialog.open(PermissionsDialogAlert, { data: { 'msg': 'This permission already exists!' } });
    }
    else {
      this.http.post<any>(this.configService.resourceApiURI + '/update_permission/', {

        "Permission_Id": this.dataItems.permission_Id,
        "permission_Type_Id": this.data.selectedPermissionType.permission_Type_Id,
        "Permission_Function": this.permission_Function,
        "sort_Order": this.sort_Order


      },
        this.httpOptions).subscribe(result => {
          this.dataItems.permission_Function = this.permission_Function?.trim();
          this._snackBar.open(" Updated Permission.", "Close", {
            duration: 2000,
          });
        })

      this.dialogRef.close();

    }
  }
  onNoClick(){
    this.dialogRef.close();
  }
}
@Component({
  selector: 'edit-permissions-type-dialog',
  templateUrl: 'edit-permissions-type-dialog.html',
})
export class EditPermissionsTypeDialog {


  httpOptions: { headers: any; };
  dataItems: any = [];
  permission_Type_Name: string = '';
  constructor(
    public dialogRef: MatDialogRef<EditPermissionsTypeDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.dataItems = this.data.selectedPermissionType;
    this.permission_Type_Name = this.dataItems.permission_Type_Name
    this.data.allPermissionsTypes = this.data.allPermissionsTypes.filter(ele => { if (ele.permission_Type_Name.toLowerCase() != this.dataItems.permission_Type_Name.toLowerCase()) { return ele; } });

  }

  delete_permission_type() {
    const dialogR = this.dialog.open(ConfirmActionDialog, {

    });
    dialogR.afterClosed().subscribe(result => {

      if (result == true) {
        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),

        };
        this.http.post<any>(this.configService.resourceApiURI + '/delete_permission_type/', {

          "Permission_Type_Id": this.dataItems.permission_Type_Id,


        }, httpOptionsTwo).subscribe(result => {
          this.dialogRef.close("delete");



        })
      }
    })


  }
  onEditClick(): void {
    const index = this.data.allPermissionsTypes.map(ele => { return ele.permission_Type_Name?.trim().toUpperCase() }).indexOf(this.permission_Type_Name?.trim().toUpperCase());

    if (index > -1) {
      this.dialog.open(PermissionsDialogAlert, { data: { 'msg': 'This permission type already exists!' } });
    }
    else {
      this.http.post<any>(this.configService.resourceApiURI + '/update_permission_type/', {

        "permission_Type_Id": this.dataItems.permission_Type_Id,
        "permission_Type_Name": this.permission_Type_Name


      },
        this.httpOptions).subscribe(result => {
          this.dataItems.permission_Type_Name = this.permission_Type_Name;
          this._snackBar.open(" Updated Permission.", "Close", {
            duration: 2000,
          });
        })

      this.dialogRef.close("save");
    }

  }

}
@Component({
  selector: 'edit-permissions-access-level-dialog',
  templateUrl: 'edit-permissions-access-level-dialog.html',
})
export class EditPermissionsAccessLevelDialog {


  httpOptions: { headers: any; };
  dataItems: any = [];
  permission_Function: string = '';
  access_Level: number;
  router_Link: string = '';
  image_Link: string = '';
  IsValid: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<EditPermissionsAccessLevelDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.dataItems = this.data.selectedPermissionAccess;
    this.access_Level = this.dataItems.access_Level;
    this.router_Link = this.dataItems.router_Link;
    this.image_Link = this.dataItems.image_Link;
  }
  check_validation() {
    if (this.router_Link.trim() == this.dataItems.router_Link.trim() && this.image_Link.trim() == this.dataItems.image_Link.trim()) {
      this.IsValid = false;
    }
    else {
      this.IsValid = true;
    }

  }
  enable_disable_permission(status) {
    this.dataItems.permission_Status = status;
    this.http.post<any>(this.configService.resourceApiURI + '/enable_disable_permission_access_level/',
      {
        "access_Level_Id": this.dataItems.access_Level_Id,
        "permission_Id": this.data.selectedPermission[0].permission_Id,
        "permission_Status": status,

      },
      this.httpOptions).subscribe(result => {
        this._snackBar.open(" Updated Permission.", "Close", {
          duration: 2000,
        });
      })

    //this.dialogRef.close();

  }
  onEditClick(): void {


    this.http.post<any>(this.configService.resourceApiURI + '/update_permission_access_level/',
      {
        "access_Level_Id": this.dataItems.access_Level_Id,
        "permission_Id": this.data.selectedPermission[0].permission_Id,
        "access_Level": this.access_Level,
        "image_Link": this.image_Link,
        "router_Link": this.router_Link

      },
      this.httpOptions).subscribe(result => {
        this._snackBar.open(" Updated Permission.", "Close", {
          duration: 2000,
        });
      })

    this.dialogRef.close();


  }
  onNoClick() {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'add-permissions-dialog',
  templateUrl: 'add-permissions-dialog.html',
})
export class AddPermissionsDialog {

  httpOptions: { headers: any; };
  dataItems: any = [];
  formGroup: FormGroup;
  constructor(
    public dialogRef: MatDialogRef<AddPermissionsDialog>, @Inject(MAT_DIALOG_DATA) public data: any, private formBuilder: FormBuilder ,public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar, public dialog: MatDialog) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    dialogRef.disableClose = true;
  
    this.dataItems = this.data.selectedPermissionType;
  }
  ngOnInit() {
    this.createForm();
  }
  onNoClick(): void {
    var str_PF = this.formGroup.value.permission_Function?.trim();

    const index = this.data.allPermissions.map(ele => { return ele.permission_Function?.trim().toUpperCase() }).indexOf(str_PF.toUpperCase());

    if (index > -1)
    {
      this.dialog.open(PermissionsDialogAlert, { data: { 'msg':'This permission already exists!'}});
    }
    else
    {
      if (this.formGroup.value.permission_Function.trim() != ''  )
      {
     

        this.http.post<any>(this.configService.resourceApiURI + '/add_permission/',
            {
              "permission_Function": str_PF,
              "permission_Type_Id": this.dataItems.permission_Type_Id,
              "sort_Order": this.formGroup.value.sort_Order
            },
            this.httpOptions).subscribe(result => {
              this._snackBar.open("Permission Added.", "Close", {
                duration: 2000,
              });
            })
          this.dialogRef.close();

        }
      }

  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'permission_Function': [null, [Validators.required, this.cannotContainSpace]],
      'sort_Order': [1, [Validators.required, Validators.min(1)]]

    });
  }

  cannotContainSpace(control) {
   
    let val = String(control.value);
    if (val?.trim()=='' ) { return { 'requirements': true } }
     else { return null };

  }

}
@Component({
  selector: 'add-permissions-type-dialog',
  templateUrl: 'add-permissions-type-dialog.html'
})
export class AddPermissionsTypeDialog {

  permission_Type: string = '';
  httpOptions: { headers: any; };
  constructor(
    public dialogRef: MatDialogRef<AddPermissionsTypeDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar, public dialog: MatDialog) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    dialogRef.disableClose = true;

  }

  onNoClick(): void {
    var str_PF = this.permission_Type?.trim();

    const index = this.data.allPermissionsTypes.map(ele => { return ele.permission_Type_Name?.trim().toUpperCase() }).indexOf(str_PF.toUpperCase());

    if (index > -1) {
      this.dialog.open(PermissionsDialogAlert, { data: { 'msg': 'This permission type already exists!' } });
    }
    else {
      if (this.permission_Type.trim() != '') {


        this.http.post<any>(this.configService.resourceApiURI + '/add_permission_type/',
          {
            "Permission_Type_Name": str_PF,
          },
          this.httpOptions).subscribe(result => {
            this._snackBar.open("Permission Type Added.", "Close", {
              duration: 2000,
            });
          })
        this.dialogRef.close();

      }
    }

  }

  close() {
    this.dialogRef.close();
  }
}
@Component({
  selector: 'permissions-dialog-alert-dialog',
  templateUrl: 'permissions-dialog-alert.html',
})
export class PermissionsDialogAlert {

  constructor(
    public dialogRe: MatDialogRef<PermissionsDialogAlert>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  finish(): void {
    this.dialogRe.close();
  }

}
