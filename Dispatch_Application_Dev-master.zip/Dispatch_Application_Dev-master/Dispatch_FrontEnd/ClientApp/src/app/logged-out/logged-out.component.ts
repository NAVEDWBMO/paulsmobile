import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../core/authentication/auth.service';

@Component({
  selector: 'app-logged-out',
  templateUrl: './logged-out.component.html',
  styleUrls: ['./logged-out.component.sass']
})
export class LoggedOutComponent implements OnInit {

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      this.router.navigateByUrl('/home', { skipLocationChange: true }).then(() => {
        this.router.navigateByUrl('/home');
      });

    }
    else {
        this.router.navigateByUrl('/');

    }

   

  }

  
}
