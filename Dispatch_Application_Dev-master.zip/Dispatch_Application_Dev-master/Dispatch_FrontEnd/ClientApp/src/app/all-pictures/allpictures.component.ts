import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, SelectableSettings, RowArgs, DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router'
import { FormGroup, FormControl, Validators, Form, FormBuilder } from '@angular/forms';
import {  ImageDialog, AlertDialog, EmailDialog } from '../pictures/pictures.component';
import { NgxSpinnerService  } from "ngx-spinner";
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import * as _moment from 'moment';
import { default as _rollupMoment, Moment } from 'moment';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-all-pictures',
  templateUrl: './allpictures.component.html',
  styleUrls: ['./allpictures.component.sass'],
  providers: [
  
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],

})

export class AllPicturesComponent implements OnInit {

  public gridView: GridDataResult;
  public pageSize = 6;
  public skip = 0;
  public gridData: any[] = [];
  public mySelection: any[] = [];
  public selectableSettings: SelectableSettings;
  public searchValue ="";
  public selectImages: boolean = false;
  public selectedCompanyId: string;
  public Drivers: any[] = [];
  public selectedDriver = "";
  public httpOptionsTwo: { headers: any; params: any; };
  public folders = [
    "CHASSIS", "LINEUP", "TRUCK", "FREIGHT BILLS", "DOCUMENTS", "POD", "SIGNATURES", "CONTAINER","GENERIC"
  ];
  public selectedFolder = "";

  date = new FormControl();
  year: number;
  month: number;

  chosenYearHandler(normalizedYear: Moment) {
     this.date.setValue(moment());
     const ctrlValue = this.date.value;
     ctrlValue.year(normalizedYear.year());
     this.year = normalizedYear.year();
     this.date.setValue(ctrlValue);
    }

    chosenMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
      const ctrlValue = this.date.value;
      ctrlValue.month(normalizedMonth.month());
      this.month = normalizedMonth.month();
      this.date.setValue(ctrlValue);
      datepicker.close();

    }
  public sort: SortDescriptor[] = [
        {
          field: "driver_u_id",
          dir: "asc",
        },
        {
          field: "folder_type",
          dir: "asc",
        }
  
  ];
  public state: State = {
    skip: 0,
    take: 6,
    filter: {
      logic: 'and',
      filters: []
    }
  };
  @ViewChild('picker') datePickerElement = MatDatepicker;

  constructor(public http: HttpClient, private spinner: NgxSpinnerService, private router: Router, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {

   

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.selectedCompanyId = access.company_Id;
      }    
    });
    this.httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.selectedCompanyId
      }
    };
    if (this.selectedCompanyId.toLowerCase() != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E'.toLowerCase()) {
      this.http.get<any>(this.configService.resourceApiURI + '/get_registered_drivers_info/', this.httpOptionsTwo)
        .subscribe(result => {
          this.Drivers = result;

        })
    }

    this.selectableSettings = {
      checkboxOnly: true,
      mode: 'multiple'
    };
   
   }

  ngOnInit(): void {
   
  }
  close() {

  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();

  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  selectimage(e, filepath) {
    e.preventDefault()
    //if (filepath.substring(filepath.length - 3) != "pdf") {
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          filepath: filepath
        }
      };
      //  this.spinner.show();

      this.http.get<any>(this.configService.resourceApiURI + '/get_driver_ftp_files_image/', httpOptionsTwo)
        .subscribe(result => {
          // console.log(result);
          if (filepath.substring(filepath.length - 3) == "pdf") {
            const pdfData = result[0].image; // Assuming result[0].pdf contains the base64-encoded PDF data
            const pdfBlob = this.base64toBlob(pdfData, 'application/pdf');
            const pdfUrl = URL.createObjectURL(pdfBlob);
            window.open(pdfUrl, '_blank');
          } else {
            const dialogRef = this.dialog.open(ImageDialog, {
              data: result[0].image
            });

          }
        })
 //   }
   
  }
  private base64toBlob(base64Data: string, contentType: string): Blob {
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: contentType });
  }

  search() {
    this.clear();
    
    var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Month: this.month+1,
          Year: this.year,
          Company_Id: this.selectedCompanyId,
          Search: this.searchValue.trim(),
          User_Id: this.selectedDriver,
          Folder: this.selectedFolder

        }
    };
        this.spinner.show();

    this.http.get<any>(this.configService.resourceApiURI + '/get_driver_ftp_files_by_search/', httpOptionsTwo)
      .subscribe(result => {
        this.skip = 0;

        this.gridData = result.map((elem) => {
          var user = this.Drivers.find(x => x.user_Id.toUpperCase() === elem.driver_u_id.toUpperCase())
          if (user) {
            elem.driver_u_id = user.driver_Id;
            elem.fileCreatedDate = new Date(elem.fileCreatedDate);
          }
          return elem

        });

        this.loadItems();
        this.spinner.hide();
      })
      
    
   
  }


  pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }

  loadItems(): void {

    this.gridData = orderBy(this.gridData, this.sort);
    var filterdat = this.gridData;
    filterdat = filterBy(this.gridData, this.state.filter)
    this.gridView = {
      data: filterdat.slice(this.skip, this.skip + this.pageSize),
      total:filterdat.length
    };
    /* this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
      total: this.gridData.length
    };*/
  }

  saveAFile() {
    
    var filepaths = [];
    this.mySelection.map((elem) => filepaths.push(elem.filePath));
    console.log(filepaths);
    if (this.mySelection.length > 6) {
      const dialogRef = this.dialog.open(AlertDialog, {
        data: "You can download upto 6 files at a time!"
      });
    }
    else {
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
       
      };
      //  this.spinner.show();

      this.http.post<any>(this.configService.resourceApiURI + '/get_driver_ftp_files_images/', {
        filepaths: filepaths
      }, httpOptionsTwo)
        .subscribe(result => {
        //  console.log(result);
          result.map((elem) => {
            var a = document.createElement("a");
            a.href = "data:image/png;base64," + elem.image;
            a.download = elem.fileName;
            a.click();
          })
        })

    
    }
  }
  clear() {
    this.skip = 0;
    this.state.skip = 0;
    this.gridData = [];
    this.mySelection = [];
    this.isImagesSelected();
  }

  selectedKeysChange(rows: any[]) {
    this.isImagesSelected();

  }
  public onSelectedKey(context: RowArgs): any {
    return context.dataItem;
  }
  isImagesSelected() {
    if (!this.mySelection.length)
      this.selectImages = false;
    else
      this.selectImages = true;
  }

  form = new FormGroup({

    subject: new FormControl(""),
    message: new FormControl(""),
    request: new FormControl(""),
    email: new FormControl({}),
    attachments: new FormControl({}),
    signature: new FormControl("")
  })


  sendMail() {

    var attachedfiles = [];
    if (this.mySelection.length > 6) {
      const dialogRef = this.dialog.open(AlertDialog, {
        data: "You can send upto 6 images at a time!"
      });
    }
    else {
      this.mySelection.map((ele) => {
        attachedfiles.push(ele.filePath);
      });
      this.form.patchValue({ attachments: attachedfiles });
      const dialogRef = this.dialog.open(EmailDialog, {
        data: this.form,
        disableClose: true

      });
      dialogRef.afterClosed().subscribe(result => {
      });
    }

  }
}

