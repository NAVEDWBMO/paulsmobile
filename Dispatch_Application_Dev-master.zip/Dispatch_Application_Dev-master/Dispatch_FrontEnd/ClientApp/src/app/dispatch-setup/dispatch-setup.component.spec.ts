import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DispatchSetupComponent } from './dispatch-setup.component';

describe('DispatchSetupComponent', () => {
  let component: DispatchSetupComponent;
  let fixture: ComponentFixture<DispatchSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DispatchSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DispatchSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
