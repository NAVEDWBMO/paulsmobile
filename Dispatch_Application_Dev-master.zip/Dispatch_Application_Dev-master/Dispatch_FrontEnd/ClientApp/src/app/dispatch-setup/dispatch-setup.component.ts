import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import {map, startWith} from 'rxjs/operators';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ConfigService } from '../shared/config.service';
import { AuthService } from '../core/authentication/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Driver } from '../driver-setup/driver-setup.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { access } from 'fs/promises';


@Component({
  selector: 'app-dispatch-setup',
  templateUrl: './dispatch-setup.component.html',
  styleUrls: ['./dispatch-setup.component.sass']
})
export class DispatchSetupComponent implements OnInit {

  selectedCompany = new FormControl();
  selectedAccess = new FormControl();
  selectedRole: any = {role_Name: "", role_Id: ""};

  selectedLocation: any = {};

  companies: any[] = [];

  companyresults: any[] = [];

  companyresultsfiltered: any[] = [];

  transComp: any[] = [];

  roles: any[] = [];

  locations: any[] = [];

  availableLoc: any[] = [];


  selectedCompanies: any[] = [
  ];


  fname = new FormControl();
  lname = new FormControl();
  email = new FormControl('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]);
  password = new FormControl();
  companyId: string = "";
  userDefaultCompanyId: string = "";
  companyName: string = "";
  companyType: string = "";

  lowerCharacters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  upperCharacters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  symbols = ['!', '?', '@', '+', '=', '-', '_'];

  httpOptions: { headers: any; };
  httpOptionsTwo: { headers: any; params: any; };

  userInfoError: boolean = false;
  selectedDriver: any;
  selectedChats: any;
  userCompanyAccess: any[];
  userRole: string;


  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {


    this.authService.userCompanyAccessStatus$.subscribe(uCompany => this.userCompanyAccess = uCompany);
    this.authService.userRoleStatus$.subscribe(uCompany => {this.userRole = uCompany;
  });
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.authService.userCompanyId$.subscribe(access => {
      if (access) {
        this.userDefaultCompanyId = access;
      }
    });

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.companyId = access.company_Id;
        this.companyName = access.company_Name;
        this.companyType = access.company_Type_Name;
        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: this.companyId
          }
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_locations_by_companyId/', httpOptionsTwo).subscribe(result => {
          this.locations = result;

        });


        if (this.userRole != '25942536-c57d-4e18-a82d-0cdcc77a74c5') {
          if (this.companyId != this.userDefaultCompanyId) {
/*            alert('Dont have access ' + this.companyName + ' users');
*/            this.router.navigateByUrl('/home');
          }
          else {
            this.httpOptionsTwo = {
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': this.authService.authorizationHeaderValue
              }),
              params: {
                Company_Id: this.userDefaultCompanyId
              }
            };
          /*  this.http.get<any>(this.configService.resourceApiURI + '/get_roles_based_on_user/', httpOptionsTwo).subscribe(result => {
              this.roles = result;
            
            });*/
          }
        }
        else {
          this.httpOptionsTwo = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            }),
            params: {
              Company_Id: this.companyId
            }
          };
           /* this.http.get<any>(this.configService.resourceApiURI + '/get_roles_based_on_user/', httpOptionsThree).subscribe(result => {
              this.roles = result;
              if (result.some(e => e.role_Name === 'Admin')) {
                this.selectedRole = result[0];
              }

            });*/
          
        }
        this.http.get<any>(this.configService.resourceApiURI + '/get_current_company_roles/', httpOptionsTwo).subscribe(result => {
          this.roles = result;
          if (result.some(e => e.role_Id === '25942536-c57d-4e18-a82d-0cdcc77a74c5')) {
            this.selectedRole = result[0];
          }
        });


        this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions).subscribe(result => {
          //if(this.userRole.toLowerCase() != '25942536-C57D-4E18-A82D-0CDCC77A74C5'.toLowerCase()){
          this.transComp = [];
          this.companyresults = result;
          this.companyresultsfiltered = this.companyresults.filter(compresults => {
            return compresults.company_Name != 'Admin';
          });
          result.forEach(resultComp => {
            if (resultComp.company_Id.toUpperCase() == this.companyId.toUpperCase()) {
              this.selectedCompanies.push(resultComp);
            }
          });
          this.userCompanyAccess.forEach(accessComp => {
            if (this.companyId.toUpperCase() != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E'.toUpperCase() && this.userRole.toUpperCase() != '25942536-C57D-4E18-A82D-0CDCC77A74C5') {

              if (accessComp.company_Id.toUpperCase() != this.companyId.toUpperCase()) {
                this.transComp.push(accessComp);
              }
            }
            else if (this.userRole.toUpperCase() == '25942536-C57D-4E18-A82D-0CDCC77A74C5' && this.companyId.toUpperCase() != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E'.toUpperCase()) {
                      /*     if (this.companyType == "OUTSOURCE") {

                let httpOptionsTwo = {
                  headers: new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Authorization': this.authService.authorizationHeaderValue
                  }),
                  params: {
                    company_Id: this.companyId
                  }
                };
                this.http.get<any>(this.configService.resourceApiURI + '/get_outsource_access/', httpOptionsTwo).subscribe(result => {
                  this.transComp = result;

                })
              }
              else*/ {
                if (accessComp.company_Id != this.companyId && accessComp.company_Name != 'Admin') {
                  this.transComp.push(accessComp);
                }
              }
            }
            else {
              this.transComp = this.companyresultsfiltered;
            }
          });

        });
      }


    });

    // get default company id




    
  }
  ngOnInit(): void {

  }


  getRandom(array){
    return array[Math.floor(Math.random() * array.length)];
  }

  generatePassword(){
    var finalCharacters = "";
    finalCharacters = finalCharacters.concat(this.getRandom(this.upperCharacters));
    finalCharacters = finalCharacters.concat(this.getRandom(this.numbers));
    finalCharacters = finalCharacters.concat(this.getRandom(this.symbols));

    for (var i = 1; i < 10 - 3; i++) {
      finalCharacters = finalCharacters.concat(this.getRandom(this.lowerCharacters));
    }
    let pass = finalCharacters.split('').sort(function () {
      return 0.5 - Math.random()
    }).join('');

    this.password.setValue(pass);

  }


  //selectCompany($e){
  //  //this.availableLoc = [];
  //  //$e.value.locations.forEach(res => {
      
  //  //  this.locations.forEach(loc => {
  //  //    if(loc.location_Id == res.location_Id){
  //  //      this.availableLoc.push(loc);
  //  //    }
        
  //  //  });
  //  //});
  //  var httpOptionsTwo = {
  //    headers: new HttpHeaders({
  //      'Content-Type': 'application/json',
  //      'Authorization': this.authService.authorizationHeaderValue
  //    }),
  //    params: {
  //      Company_Id: this.selectedCompany.value.company_Id
  //    }
  //  };

  //  this.http.get<any>(this.configService.resourceApiURI + '/get_locations_by_companyId/', httpOptionsTwo).subscribe(result => {
  //    this.locations = result;

  //    this.selectedLocation = this.locations.filter((elem) => {
  //      if (elem.location_Id.toLowerCase() == this.selectedCompany.value.user_Location) {
  //        return true
  //      } else {
  //        return false
  //      }
  //    })[0];
  //  })

    
  //}

  registerDispatch(){
    var selectedCompanyIds = new Array;
    
    
    if (this.companyId == '96aa4673-c3cd-40a9-9f69-df2290e20c8e') {
      
      this.companyresultsfiltered.forEach(element => {
        selectedCompanyIds.push(element.company_Id)
      });
    }
    else {
      if (this.selectedAccess.value != undefined && this.selectedAccess.value.length>0) {
        this.selectedAccess.value.forEach(element => {
          selectedCompanyIds.push(element.company_Id)
        });
      }
      
    }

    this.http.post<any>(this.configService.resourceApiURI + '/register_user/', 
    { "User_Email":  this.email.value,
     "User_Password":  this.password.value, 
     "User_FirstName": this.fname.value, 
     "User_LastName": this.lname.value, 
     "User_Role": this.selectedRole.role_Id,
      "User_Company": this.companyId,
     "User_Company_Access": selectedCompanyIds,
     "User_Location": this.selectedLocation.location_Id,
    }, 
    this.httpOptions).subscribe( 
      val => {

      this.email.setValue("");
      this.password.setValue("");
      this.fname.setValue("");
      this.lname.setValue("");
      this.selectedCompany.setValue([]);
      this.selectedLocation = {};
      this.selectedRole = {};

      const dialogRef = this.dialog.open(DialogComplete);

      dialogRef.afterClosed().subscribe(result => {

      });

      },
      error => {
          this._snackBar.open(error.error, "Close", {
            duration: 4000,
          });
      }


    )
  }
  handleFName(){

    if(this.fname.value.length > 0){
      this.fname.setValue(this.fname.value[0].toUpperCase() + this.fname.value.substring(1))
    }
  }
  handleLName(){
    if(this.lname.value.length > 0){
      this.lname.setValue(this.lname.value[0].toUpperCase() + this.lname.value.substring(1))
    }
    
  }

  handleEmail(){
    if(this.email.value.length > 0){
      this.email.setValue(this.email.value.toLowerCase())
    }
  
  }

  clearForm(){
     this.email.setValue("");
      this.password.setValue("");
      this.fname.setValue("");
      this.lname.setValue("");
   /*   this.selectedCompany.setValue([]);
      this.selectedLocation = {};
      this.selectedRole = {};*/
  }
  AccessToCompanies() {
  }

}

@Component({
  selector: 'dialog-complete-dialog',
  templateUrl: 'dialog-complete.html',
})
export class DialogComplete {

  constructor(
    public dialogRef: MatDialogRef<DialogComplete>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  finish(): void {
    this.dialogRef.close();
  }

}
