import {trigger,state,style,animate,transition } from '@angular/animations';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor} from '@progress/kendo-data-query';
import { parse } from 'querystring';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { SignalRService } from '../core/chat/signalr';
import * as signalR from "@microsoft/signalr";
import { exit } from 'process';
@Component({
  selector: 'app-tablet',
  templateUrl: './tablet.component.html',
  styles: [`
    >>> .k-grid .k-grouping-row .k-icon {
      margin-left: 2px;
    }
  `],
  styleUrls: ['./tablet.component.sass']
})
export class TabletComponent implements OnInit {

  public gridView: GridDataResult;
  public pageSize = 8;
  public skip = 0;
  private data: Object[];
  public selectedDriver: any = [];
  private access: any;
  public gridData: any[] = [];
  public drivers: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  selectedCompanyId: string = "";
  selectedCompany: any;
  userCompaniesAccess: any;

  public groups: GroupDescriptor[] = [{ field: 'driverID'}];
  public products: any[] = [];
  public sort: SortDescriptor[] = [
    {
      field: "lO_Status_Name",
      dir: "asc",
    },
    {
      field: "trip_Status_Name",
      dir: "asc",
    }
  ];
  public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  @ViewChild('grid') private grid;

  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.gridData = [];
      if (access?.company_Id)
      {
          this.access = access;
          this.selectedCompanyId = access.company_Id;
          if (access.company_Id.toUpperCase() != "")
          {
            var httpOptionsTwo = {
                headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': this.authService.authorizationHeaderValue
                }),
                params:
                {
                    Company_Id: access.company_Id
                }
            };
            this.http.get<any>(this.configService.resourceApiURI + '/driver_gettabletdrivers/', httpOptionsTwo).subscribe(result => {
              this.drivers = result.sort(this.sorter);
              this.gridData = [];
              this.selectedDriver =[];
              this.loadItems();
            })
          }
       
      }

    });
    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);

  }
  sorter(a, b) {
    if (a.d_Id < b.d_Id) {
      return -1;
    }
    if (a.d_Id > b.d_Id) {
      return 1;
    }
    return 0;
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();

  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }

  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }

  private loadItems(): void {
    this.gridData = orderBy(this.gridData, this.sort);
    var filterdat = this.gridData;
    filterdat = filterBy(this.gridData, this.state.filter)
    this.gridView = {
        data: filterdat.slice(this.skip, this.skip + this.pageSize),
      total: filterdat.length
      };
  }
  selectDriver() {

    if (this.selectedDriver != undefined && this.selectedDriver.length>0) {
      this.skip = 0;
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          user_Id: this.selectedDriver[0].user_Id
        }
      };
      this.http.get<any>(this.configService.resourceApiURI + '/driver_getdrivertabletstatus/', httpOptionsTwo).subscribe(result => {
        this.gridData = result;
        this.loadItems();

      })
    }
    
  }
  search(e) {
    if (this.drivers != undefined) {
      this.drivers = this.drivers.map((elem) => {
        if (elem.driver_Id.includes(e.target.value)) { return elem; }
      })
    }
  }

  ngOnInit(): void {
  
  }

  openChangeFreightBIllDialog(dataItem): void {
    const dialogRef = this.dialog.open(ChangeFreightBillDialog, {
      data: { tab_data: dataItem, selectedCompanyId: this.selectedCompanyId, driver: this.selectedDriver[0] },
      disableClose: true,
      width: '650px',
      panelClass: 'custom-fb-dialog',
      autoFocus: false,

    });
    dialogRef.afterClosed().subscribe(result => {
      this.refreshDriverList()
    });

  }
/*  openDialog(dataItem): void {
    const dialogRef = this.dialog.open(ConfirmDeleteDialog, {
      data: { tab_data: dataItem, driver: this.selectedDriver[0] },
      width: '450px',
      panelClass: 'custom-delete-dialog-container',

    });
    dialogRef.afterClosed().subscribe(result => {
      this.refreshDriverList()
    });
    
  }
  openChangeAddressDialog(dataItem): void {
    const dialogRef = this.dialog.open(ChangeAddressDialog, {
      data: { fb_data: dataItem, driver: this.selectedDriver[0] },
      disableClose: true,
      width: '450px',
      panelClass: 'custom-address-dialog',
      autoFocus: false,
      

    });
    dialogRef.afterClosed().subscribe(result => {
      this.refreshDriverList();
      
    });

  }

  driverAssignDialog(dataItem): void {

    const dialogRef = this.dialog.open(DriverAssignDialog, {

      data: { tab_data: dataItem, company_Id: this.selectedCompanyId, driver: this.selectedDriver[0]},
      disableClose: true,
      panelClass: 'custom-dialog-container'
      

    });
    dialogRef.afterClosed().subscribe(result => {
      this.refreshDriverList()
    });

  }*/
  refreshDriverList() {
    if (this.selectedDriver != undefined &&  this.selectedDriver.length > 0)
    {
        var httpOptionsTwo = {
        headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
        }),
          params:
          {
             user_Id: this.selectedDriver[0].user_Id
          }
        };
        this.http.get<any>(this.configService.resourceApiURI + '/driver_getdrivertabletstatus/', httpOptionsTwo).subscribe(result => {
          this.gridData = result;
          this.loadItems();
        })
    }
  }

}

@Component({
  selector: 'change-freightbill-dialog',
  templateUrl: 'change-freightbill-dialog.html',
  styleUrls: ['./tablet.component.sass']
})

export class ChangeFreightBillDialog {
  public driver: any[] = [];
  public newDriver: any = [];
  public Data: any = [];
  public selectedCompanyId="";
  public old_driver: any = [];
  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog,
    public dialogRef: MatDialogRef<ChangeFreightBillDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this.driver = data.driver;
    this.Data = data.tab_data;
    this.selectedCompanyId = data.selectedCompanyId;
  }
  openChangeAddressDialog(): void {
    const dialogRef1 = this.dialog.open(ChangeAddressDialog, {
      data: { fb_data: this.Data , driver: this.driver },
      disableClose: true,
      width: '450px',
      panelClass: 'custom-address-dialog',
      autoFocus: false
    });
    dialogRef1.afterClosed().subscribe(result => {
      if (result == "confirmed") {
        this.dialogRef.close();
      }
    });


  }
  driverAssignDialog(): void {

    const dialogRef2 = this.dialog.open(DriverAssignDialog, {

      data: { tab_data: this.Data, company_Id: this.selectedCompanyId, driver: this.driver },
      disableClose: true,
      autoFocus: false,
      panelClass: 'custom-dialog-container'
    });
   
    dialogRef2.afterClosed().subscribe(result => {
      if (result == "confirmed") {
        this.dialogRef.close();
      }
    });
  }
  openDeleteDialog(): void {
    const dialogRef3 = this.dialog.open(ConfirmDeleteDialog, {
      data: { tab_data: this.Data, driver: this.driver },
      disableClose: true,
      width: '450px',
      panelClass: 'custom-delete-dialog-container',
      autoFocus: false

    });
    dialogRef3.afterClosed().subscribe(result => {
      if (result == "confirmed") {
        this.dialogRef.close();
       // console.log(result)
      }
    });
  }
}

@Component({
  selector: 'confirm-delete-dialog',
  templateUrl: 'confirm-delete-dialog.html',
  styleUrls: ['./tablet.component.sass']
})

export class ConfirmDeleteDialog {  
  public dataItem: any;
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  public driver: any;

  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private configService: ConfigService, private authService: AuthService, private signalRService: SignalRService,
    public dialogRef: MatDialogRef<ConfirmDeleteDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.dataItem = data.tab_data;
    this.driver = data.driver;
    this.authService.userInfoStatus$.subscribe(userinfo => { this.user_id = userinfo.user_Id; this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name })
    var chat_Permissions: any;

    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });
  }
  deleteLoadOffer() {
    var statusFlag = 2;
    if ((this.dataItem.lO_Status.toUpperCase() == '5BE46ECD-20B2-6D02-A312-53786A2643E5' && this.dataItem.status_Flag == "0") || (this.dataItem.lO_Status.toUpperCase() == '7AE46EAB-10A1-3D01-A125-53786A2643A7' && this.dataItem.status_Flag == "4")) {
      statusFlag = 3;
    } 
    
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/driver_driverdeleteloadofferstablet/',
      {
        "LoadOffers_ID": this.dataItem.loadOffers_ID,
        "Status_Flag": statusFlag,
      },
      httpOptionsTwo).subscribe(result => {
        if (this.dataItem.lO_Status.toUpperCase() == '5BE46ECD-20B2-6D02-A312-53786A2643E5' && this.dataItem.status_Flag == "1" || (this.dataItem.lO_Status.toUpperCase() == '1AE46EAB-10A1-3D01-A125-53786A2643A1' && this.dataItem.status_Flag == "5")) {

          if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
            let message = "Freight bill has been deleted, please press refresh button on shift page";
            let mes: MessageModel = {
              from_User_Id: this.user_id,
              message_Text: message,
              chat_Id: this.driver.chat_Id,
              message_Date: new Date().toISOString(),
              message_From_User_Role: this.Permission_Id,
              chat_Table: this.driver.chat_Table,
              message_From_User_Name: this.User_Name,
              message_Is_Visible: true,
              message_To_Group: "All"
            };
            this.signalRService.sendToServer("MessageToServer", mes);
          }
        }
          this._snackBar.open("Deleting Freight Bill", "Close", {
            duration: 3000,
          });
          this.dialogRef.close("confirmed");
        });
  
  }

}
@Component({
  selector: 'driver-assign-dialog',
  templateUrl: 'driver-assign-dialog.html',
  styles: [`

   
  `],
  styleUrls: ['./tablet.component.sass']
 
})

export class DriverAssignDialog {
  public drivers: any[] = [];
  public newDriver: any ;
  public Data: any = [];
  public old_driver: any = [];
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private configService: ConfigService, private authService: AuthService, private signalRService: SignalRService,
    public dialogRef: MatDialogRef<DriverAssignDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this.authService.userInfoStatus$.subscribe(userinfo => { this.user_id = userinfo.user_Id; this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name })
    var chat_Permissions: any;

    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });


    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params:
      {
        Company_Id: data.company_Id
      }
    };

    this.http.get<any>(this.configService.resourceApiURI + '/driver_gettabletdrivers/', httpOptionsTwo).subscribe(result => {
      if (this.Data.lO_Status.toUpperCase() == "4ae46eab-10a1-3d01-a125-53786a2643d4".toUpperCase()) {

        this.drivers = result.sort(this.sorter);
        result.filter(ele => { if (ele.driver_Id == data.driver.driver_Id) { this.newDriver = ele; } });

        
      } else
      {
        this.drivers = result.filter(ele => { if (ele.driver_Id != data.driver.driver_Id) { return ele; } else { } }).sort(this.sorter);


      }
      
      // this.drivers = result.filter((ele) => { if (ele.driver_Id.toUpperCase() != data.tab_data.driverID.toUpperCase()) return ele; }).sort(this.sorter);

    });
    this.Data = data.tab_data;
    this.old_driver = data.driver;
    


  }
  sorter(a, b) {
    if (a.d_Id < b.d_Id) {
      return -1;
    }
    if (a.d_Id > b.d_Id) {
      return 1;
    }
    return 0;
  }
  AssignfreightBill() {


    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    }
    // Scenario one if declined fb assigned to same driver 
    if (this.Data.lO_Status.toUpperCase() == "4ae46eab-10a1-3d01-a125-53786a2643d4".toUpperCase() && this.newDriver.user_Id == this.old_driver.user_Id) {
      this.http.post<any>(this.configService.resourceApiURI + '/driver_updateloadofferstatus/', {
        "LoadOffers_ID": this.Data.loadOffers_ID,
        "LO_Status": "5BE46ECD-20B2-6D02-A312-53786A2643E5",
        "Status_Flag": "0",

      }, httpOptionsTwo).subscribe(result => {
        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
          let message = "Dispatcher has reassigned freight bill to you, Please press refresh button on shift page and accept it.";
          let mes: MessageModel = {
            from_User_Id: this.user_id,
            message_Text: message,
            chat_Id: this.newDriver.chat_Id,
            message_Date: new Date().toISOString(),
            message_From_User_Role: this.Permission_Id,
            chat_Table: this.newDriver.chat_Table,
            message_From_User_Name: this.User_Name,
            message_Is_Visible: true,
            message_To_Group: "All"
          };
          this.signalRService.sendToServer("MessageToServer", mes);
        }
      })
      this._snackBar.open("Freight Bill Assigned to  " + this.newDriver.driver_Id, "Close", {
        duration: 3000,
      });

    }
    else if (this.newDriver.user_Id.toUpperCase() != this.old_driver.user_Id.toUpperCase())
      {

      this.http.post<any>(this.configService.resourceApiURI + '/driver_reassignloadoffer/', {

        "LoadOffers_ID"     : this.Data.loadOffers_ID,
        "Trip"              : this.Data.trip,
        "Prev_Driver"       : this.old_driver.driver_Id,
        "Prev_Driver_UID"   : this.old_driver.user_Id,
        "Prev_Punit"        : this.old_driver.d_Id,
        "New_Driver_UID"    : this.newDriver.user_Id,
        "New_Driver"        : this.newDriver.driver_Id,
        "New_Punit"         : this.newDriver.d_Id,
        "Lo_Status"         : this.Data.lO_Status,
        "Trip_Status"       : this.Data.trip_Status_ID,
        "Status_Flag"       : this.Data.status_Flag
      }, httpOptionsTwo).subscribe(result => {

        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected ) {

          if (this.Data.lO_Status.toUpperCase() == '1AE46EAB-10A1-3D01-A125-53786A2643A1' || (this.Data.lO_Status.toUpperCase() == '5BE46ECD-20B2-6D02-A312-53786A2643E5' && this.Data.status_Flag == "1"  )) {
            let message = "Dispatcher has reassigned your freight bill to another driver. Please press refresh button on shift page.";
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: this.old_driver.chat_Id,
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: this.old_driver.chat_Table,
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);
            }
              let message = "Dispatcher has reassigned freight bill to you, Please press refresh button on shift page and accept it.";
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: this.newDriver.chat_Id,
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: this.newDriver.chat_Table,
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);
            
        }
        this.dialogRef.close("confirmed");

      })

      this._snackBar.open("Freight Bill Assigned to  " + this.newDriver.driver_Id, "Close", {
        duration: 3000,
      });
    }
    
      this.dialogRef.close("confirmed");

  }

  selectDriver(e) {
  //  console.log(this.newDriver);

  }
  close() {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'location-alert-dialog',
  templateUrl: 'location-alert-dialog.html',
  styleUrls: ['./tablet.component.sass']
})

export class LocationAlertDialog {

  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    public dialogRef: MatDialogRef<LocationAlertDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {


  }

}

@Component({
  selector: 'change-address-dialog',
  templateUrl: 'change-address-dialog.html',
  styleUrls: ['./tablet.component.sass']
})

export class ChangeAddressDialog {
  public dataItem: any;
  public driver: any;
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";

  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private dialog: MatDialog, private configService: ConfigService, private authService: AuthService, private signalRService: SignalRService,
    public dialogRef: MatDialogRef<ChangeAddressDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;

    this.dataItem = data.fb_data;
    this.driver = data.driver;
    this.authService.userInfoStatus$.subscribe(userinfo => { this.user_id = userinfo.user_Id; this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name})
    var chat_Permissions: any;

    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });

  }


  ChangeAddress(type): void {
    this.dialogRef.close("confirmed");

    
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
    
     
    };
    this.http.post<any>(this.configService.resourceApiURI + '/driver_update_loadoffers_consignee_address/', {
      "loadOffers_ID": this.dataItem.loadOffers_ID,
      "user_Id": this.driver.user_Id,
      "address_Type": type,
      "dld": this.dataItem.dld

    }, httpOptionsTwo).subscribe(result => {


      if (this.dataItem.lO_Status.toUpperCase() == '1AE46EAB-10A1-3D01-A125-53786A2643A1') {

        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
          let message = "your destination has been changed, please press refresh button on shift page.";
          let mes: MessageModel = {
            from_User_Id: this.user_id,
            message_Text: message,
            chat_Id: this.driver.chat_Id,
            message_Date: new Date().toISOString(),
            message_From_User_Role: this.Permission_Id,
            chat_Table: this.driver.chat_Table,
            message_From_User_Name: this.User_Name,
            message_Is_Visible: true,
            message_To_Group: "All"
          };
          this.signalRService.sendToServer("MessageToServer", mes);
        }

      }


      const dialogRef2 = this.dialog.open(LocationAlertDialog, {
        data: this.dataItem,

      });
      dialogRef2.afterClosed().subscribe(result => {
      });
      /*      this._snackBar.open("Freight Bill " + dataItem.freightBill +" Location Updated", "Close", {
              duration: 3000,
            });*/
      //this.refreshDriverList()

    })
  }


}
export interface MessageModel {
  message_Id?: any;
  from_User_Id: string;
  message_From_User_Role?: string;
  message_From_User_Name?: string;
  message_Text: string;
  chat_Id: string;
  message_Date?: any;
  message_Latitude?: string;
  message_Longitude?: string;
  chat_Table: string;
  message_Is_Visible: boolean;
  message_To_Group: string;
}
