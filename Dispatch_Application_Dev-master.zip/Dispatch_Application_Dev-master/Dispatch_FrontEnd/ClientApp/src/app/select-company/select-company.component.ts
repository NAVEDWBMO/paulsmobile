import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Injectable, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ChatUnsubscribeService } from '../core/chat/chat-unsubscribe';

@Component({
  selector: 'app-select-company',
  templateUrl: './select-company.component.html',
  styleUrls: ['./select-company.component.sass']
})
@Injectable({
  providedIn: 'root'
})
export class SelectCompanyComponent  {

  userCompaniesAccess: any = [];
  userDefaultCompanyId: string;
  selectedCompany = new FormControl();
  user_Id: string;
  httpOptions: any;
  permission_Id: string;


  constructor(public http: HttpClient, private router: Router, private authService: AuthService, private configService: ConfigService, private chatUnsubscribeService: ChatUnsubscribeService) {
    // this.httpOptions = {
    //   headers: new HttpHeaders({
    //     'Content-Type':  'application/json',
    //     'Authorization': this.authService.authorizationHeaderValue
    //   })
    // };
    // get default company id
    this.authService.userCompanyId$.subscribe(access => {
      if (access) {
        this.userDefaultCompanyId = access;
        //console.log(this.userDefaultCompanyId);
      }
    });

    this.authService.userCompanyAccessStatus$.subscribe(access => {
      if (this.userDefaultCompanyId) {
        this.userCompaniesAccess = access;
        this.userCompaniesAccess.sort(function (a, b) {
          if (a.company_Name < b.company_Name) { return -1; }
          if (a.company_Name > b.company_Name) { return 1; }
          return 0;
        });
            const sorter = (a, b) => {
              if (a.company_Id === this.userDefaultCompanyId) {
                return -1;
              };
              if (b.company_Id === this.userDefaultCompanyId) {
                return 1;
              };
              //return a.company_Id < b.company_Id ? -1 : 1;
              return a.company_Sort_Order - b.company_Sort_Order;
            };
        this.userCompaniesAccess.sort(sorter)
/*        console.log(this.userCompaniesAccess);
*/        this.selectedCompany.setValue(access[0]);
        this.chatUnsubscribeService.subscribe_Status.next(0);
        this.authService._userCompanyAccessSelected.next(access[0]);

        if (access[0]?.company_Id != "00000000-0000-0000-0000-000000000000" && access[0]?.company_Id != null) {
         // this.updateUserCurrentCompany();
        }
      }
    });
    this.authService.userIdStatus$.subscribe(user_Id => {
      if (user_Id) {
        this.user_Id = user_Id;
        //console.log(this.userDefaultCompanyId);
      }
    });

 
   }

  ngOnInit(): void {
    
  }

  setfontcolor(company) {
    if (company.company_Type_Name === 'ADMIN') {
      return 'black';
    }
    else if (company.company_Type_Name === 'TRANSPORTATION' ) {
      return 'red';
    }
    else if (company.company_Type_Name === 'OUTSOURCE') {
      return 'green';
    }
    else {
      return 'blue';
    }
  }


/*updateUserStatusOnServer(){
  this.httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': this.authService?.authorizationHeaderValue
    })
  };
  
  this.http.post<any>(this.configService.resourceApiURI + '/handle_login_logout/', 
  { 
    "Company_Id": this.selectedCompany.value.company_Id
  }, 
  this.httpOptions).subscribe(result => {

  })
}*/

  selectCompany($e) {
    this.authService._userCompanyAccessSelected.next(this.selectedCompany.value);
   /* if (this.selectedCompany.value?.company_Id != "00000000-0000-0000-0000-000000000000" && this.selectedCompany.value?.company_Id != null) {
      this.authService.updateUserCurrentCompany(this.user_Id, this.selectedCompany.value?.company_Id)
    }*/

    this.authService.get_Role_Permissions(this.user_Id, this.selectedCompany.value?.company_Id);

    if (this.chatUnsubscribeService.subscribe_Status.value == 1) {
      this.chatUnsubscribeService.change_User_Signalr_Connection(this.user_Id, this.selectedCompany.value?.company_Id);
      this.chatUnsubscribeService.Unsubscribe_All();
      this.chatUnsubscribeService.subscribe_Status.next(0);
    } 

    this.router.navigateByUrl('/home');
  }
 
}

