import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TruckSetupComponent } from './truck-setup.component';

describe('TruckSetupComponent', () => {
  let component: TruckSetupComponent;
  let fixture: ComponentFixture<TruckSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TruckSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TruckSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
