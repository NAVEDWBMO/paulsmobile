import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverSetupComponent } from './driver-setup.component';

describe('DriverSetupComponent', () => {
  let component: DriverSetupComponent;
  let fixture: ComponentFixture<DriverSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DriverSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
