import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthCallbackComponent } from './auth-callback/auth-callback.component';
import { AuthGuard } from './core/authentication/auth.guard';
import { DriversComponent } from './drivers/drivers.component';
import { DriverSetupComponent } from './driver-setup/driver-setup.component';
import { TruckSetupComponent } from './truck-setup/truck-setup.component';
import { TabletComponent } from './tablet/tablet.component';
import { ChatComponent } from './old-chat/chat.component';
import { ChatContainerComponent } from './chat-container/chat-container.component';
import { DispatchersComponent } from './dispatchers/dispatchers.component';
import { ChatSearchComponent } from './chat_search/chat_search.component';
import { LoggedOutComponent } from './logged-out/logged-out.component';
import { DisabledChatsComponent } from './disabled-chats/disabled-chats.component';
import { DispatchSetupComponent } from './dispatch-setup/dispatch-setup.component';
import { LocationsComponent } from './locations/locations.component';
import { CompaniesComponent } from './companies/companies.component';
import { TrucksComponent } from './trucks/trucks.component';
import { DevicesComponent } from './devices/devices.component';
import { ImeisComponent } from './imeis/imeis.component';
import { HomeComponent } from './home/home.component';
import { ChatSettingsComponent } from './chat-settings/chat-settings.component';
import { CellCompaniesComponent } from './cell-companies/cell-companies.component';
import { RolesComponent } from './roles/roles.component';
import { PicturesComponent } from './pictures/pictures.component';
import { AllPicturesComponent } from './all-pictures/allpictures.component';
import { PermissionsComponent } from './permissions/permissions.component';
import { SignOutComponent } from './signout/signout.component';
import { CompanyComponent } from './Company/Company.component';
import { AccountComponent } from './account/account.component';
import { ChatLevel1Component } from './chat-level1/chat-level1.component';
import { ChatLevel2Component } from './chat-level2/chat-level2.component';
import { ChatLevel3Component } from './chat-level3/chat-level3.component';
import { ChatsComponent } from './chats/chats.component';
import { OutsourceDriverSetupComponent } from './outsource-driver-setup/outsource-driver-setup.component';
import { GateComponent } from './gate/gate.component';
import { MapComponent } from './map/map.component';
import { ManageDriversChatComponent } from './manage-drivers-chat/manage-drivers-chat.component';


const routes: Routes = [
  { path: 'auth-callback', component: AuthCallbackComponent },
  // Fallback when no prior route is matched
  { path: '', component: LoggedOutComponent, pathMatch: 'full' },
  { path: 'logout', component: SignOutComponent, pathMatch: 'full' },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'chats', component: ChatsComponent, canActivate: [AuthGuard] },
  { path: 'chats_container', component: ChatContainerComponent, canActivate: [AuthGuard] },
  { path: 'tablet', component: TabletComponent, canActivate: [AuthGuard] },
  { path: 'drivers', component: DriversComponent, canActivate: [AuthGuard] },
  { path: 'driver_setup', component: DriverSetupComponent, canActivate: [AuthGuard] },
  { path: 'outsource_driver_setup', component: OutsourceDriverSetupComponent, canActivate: [AuthGuard] },
  { path: 'truck_setup', component: TruckSetupComponent, canActivate: [AuthGuard] },
  { path: 'user_setup', component: DispatchSetupComponent, canActivate: [AuthGuard] },
  { path: 'users', component: DispatchersComponent, canActivate: [AuthGuard] },
  { path: 'account', component: AccountComponent, canActivate: [AuthGuard] },
  { path: 'chat_search', component: ChatSearchComponent, canActivate: [AuthGuard] },
  { path: 'disabledchats', component: DisabledChatsComponent, canActivate: [AuthGuard] },
  { path: 'locations', component: LocationsComponent, canActivate: [AuthGuard] },
  { path: 'companies', component: CompaniesComponent, canActivate: [AuthGuard] },
  { path: 'trucks', component: TrucksComponent, canActivate: [AuthGuard] },
  { path: 'devices', component: DevicesComponent, canActivate: [AuthGuard] },
  { path: 'imeis', component: ImeisComponent, canActivate: [AuthGuard] },
  { path: 'roles', component: RolesComponent, canActivate: [AuthGuard] },
  { path: 'chat_settings', component: ChatSettingsComponent, canActivate: [AuthGuard] },
  { path: 'cell_companies', component: CellCompaniesComponent, canActivate: [AuthGuard] },
  { path: 'pictures', component: PicturesComponent, canActivate: [AuthGuard] },
  { path: 'allpictures', component: AllPicturesComponent, canActivate: [AuthGuard] },
  { path: 'permissions', component: PermissionsComponent, canActivate: [AuthGuard] },
  { path: 'company', component: CompanyComponent, canActivate: [AuthGuard] },
  { path: 'chats/chat_level1', component: ChatLevel1Component, canActivate: [AuthGuard] },
  { path: 'chats/chat_level2', component: ChatLevel2Component, canActivate: [AuthGuard] },
  { path: 'chats/chat_level3', component: ChatLevel3Component, canActivate: [AuthGuard]},
  { path: 'old-chats', component: ChatComponent, canActivate: [AuthGuard] },
  { path: 'gate', component: GateComponent, canActivate: [AuthGuard] },
  { path: 'map', component: MapComponent, canActivate: [AuthGuard] },
  { path: 'manage_drivers_chat', component: ManageDriversChatComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '/' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
