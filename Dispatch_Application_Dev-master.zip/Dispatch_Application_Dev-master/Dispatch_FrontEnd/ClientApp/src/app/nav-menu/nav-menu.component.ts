import { Component } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { AuthService } from '../core/authentication/auth.service';
import { Subscription } from 'rxjs';
/*import { ChatControlDialog } from '../chat/chat.component';
*/import { MatDialog } from '@angular/material/dialog';
import { Router,ActivatedRoute }      from '@angular/router';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent {
  isExpanded = false;

  userRole: string;
  userName: string;
  isAuthenticated: boolean = false;
  subscription:Subscription;
  connection: string;
  userCompaniesAccess: any = [];
  userDefaultCompanyId: string;
  selectedCompanyId: string;
  gearWheel_Permissions: any[];
  nav_Permissions: any[];

  constructor(private authService: AuthService, private router: Router, public dialog: MatDialog, public route: ActivatedRoute) {
    this.subscription = this.authService.authNavStatus$.subscribe(status => this.isAuthenticated = status);

    this.authService.userNameStatus$.subscribe(uName => this.userName = uName);
    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userCompanyId$.subscribe(access => {
      if (access) {
        this.userDefaultCompanyId = access;

      }
    });
 
    this.userCompanies();
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {

      if (access.company_Id != undefined ) {
        this.selectedCompanyId = access.company_Id.toUpperCase();
      }

    });
   
  }

  ngOnInit() {
    //console.log('inside oninit');
    this.authService._userPermissionsStatus$.subscribe(permissions => { this.gearWheel_Permissions = permissions["Gear_Wheel"]; this.nav_Permissions = permissions["Nav_Bar"];});

  
  } 

  async userCompanies() {
  /*  await this.authService.userCompanyAccessStatus$.subscribe(access => {
      if (this.userDefaultCompanyId) {
        this.userCompaniesAccess = access;
        this.userCompaniesAccess.sort(function (a, b) {
          if (a.company_Name < b.company_Name) { return -1; }
          if (a.company_Name > b.company_Name) { return 1; }
          return 0;
        });
        const sorter = (a, b) => {
          if (a.company_Id === this.userDefaultCompanyId) {
            return -1;
          };
          if (b.company_Id === this.userDefaultCompanyId) {
            return 1;
          };
          //return a.company_Id < b.company_Id ? -1 : 1;
          return a.company_Sort_Order - b.company_Sort_Order;
        };

        this.userCompaniesAccess.sort(sorter)
      }
    });*/
  }
  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }
  login() {     
    this.authService.login();
  }
  
/*  async signout() {
    

    await this.authService.signout();     
  }*/

 /* openCreateChatDialog() : void{
    const dialogRef = this.dialog.open(ChatControlDialog, {
      
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }*/

}
