import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 
@Injectable()
export class ConfigService {

  private configuration: any;

  public authUrl: string;
  public resourceUrl: string;
  public frontendUrl: string;
  public mapboxKey: string;

  constructor(public http: HttpClient) {
  }

  setConfig(): Promise<any> {
    return this.http
      .get<any>('/api/Configuration/ConfigurationData')
      .toPromise()
      .then(config => {
        this.authUrl = config.Auth;
        this.resourceUrl = config.Resource;
        this.frontendUrl = config.Frontend;
        this.mapboxKey = config.Mapboxkey;
        this.configuration = config
      } );
  }
  readConfig(): any {
    return this.configuration;
  }


    get authApiURI() {
      return this.authUrl + '/api';
    }    
     
    get resourceApiURI() {
      return this.resourceUrl +'/api';
    } 
    get frontEndURI() {
      return this.frontendUrl;
  }
  get mapBoxEndKey() {
    return this.mapboxKey;
  }

}
