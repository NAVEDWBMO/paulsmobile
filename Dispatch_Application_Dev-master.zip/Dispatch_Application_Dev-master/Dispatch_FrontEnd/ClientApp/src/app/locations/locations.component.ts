import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.sass']
})
export class LocationsComponent implements OnInit {
  locations: any;
  httpOptions: { headers: any; params: any;};

  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  public gridData: any[] = [];
  public selectedCompanyId: string;
  public sort: SortDescriptor[] = [
    {
      field: "location_IsEnabled",
      dir: "desc",
    },

  ]; public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {


    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.gridData = [];
      if (access?.company_Id) {
        this.selectedCompanyId = access.company_Id;
        this.httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: access.company_Id
          }
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_locations_by_companyId/', this.httpOptions).subscribe(result => {
          this.gridData = result;

          this.loadItems();
        });
      }

    });

    /* this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };*/
/*    this.authService.userCompanyAccessSelectedStatus$
      .subscribe(access => {
        this.selectedCompanyId = access.company_Id;
        if (this.router.url === '/locations') {
          if (this.selectedCompanyId.toUpperCase() != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E') {
            this.router.navigateByUrl('/home');
          }
        }

      });*/
   }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();

  }
  ngOnInit(): void {

  
/*    this.http.get<any>(this.configService.resourceApiURI + '/get_locations/', this.httpOptions).subscribe(result => {
      this.gridData = result;

      this.loadItems();
    })
*/

  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
}

private loadItems(): void {
   /* this.gridView = {
        data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
        total: this.gridData.length
  };*/
  this.gridData = orderBy(this.gridData, this.sort);
  var filterdat = this.gridData;
  filterdat = filterBy(this.gridData, this.state.filter)
  this.gridView = {
    data: filterdat.slice(this.skip, this.skip + this.pageSize),
    total: filterdat.length
  };
}

openDialog(dataItem){
  const dialogRef = this.dialog.open(LocationEditDialog, {
    width: '400px',
    data: dataItem,
    disableClose: true

  });

  dialogRef.afterClosed().subscribe(result => {
    this.refreshLocation();

 /*   this.http.get<any>(this.configService.resourceApiURI + '/get_locations/', this.httpOptions).subscribe(result => {
      this.gridData = result;

      this.loadItems();
    })*/
  });

}
openAddDialog(){
  const dialogRef = this.dialog.open(AddLocationDialog, {
    width: '400px',
    disableClose: true,
    data: {
      Company_Id: this.selectedCompanyId
    } 

  });

  dialogRef.afterClosed().subscribe(result => {
    this.refreshLocation();
   /* this.http.get<any>(this.configService.resourceApiURI + '/get_locations/', this.httpOptions).subscribe(result => {
      this.gridData = result;
      this.loadItems();
    })*/
  });

}

  refreshLocation() {

    this.http.get<any>(this.configService.resourceApiURI + '/get_locations_by_companyId/', this.httpOptions).subscribe(result => {
      this.gridData = result;

      this.loadItems();
    });
  }

}

@Component({
  selector: 'edit-locations-dialog',
  templateUrl: 'edit-locations-dialog.html',
})
export class LocationEditDialog {

  fullName: string = '';
  shortName: string = '';
  isActive: boolean = false;

  companies: any[] = [];
  selectedCompanies = new FormControl();
  companyList: any[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];
  
  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<LocationEditDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService, 
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

      this.fullName = data.location_Full_Name;
      this.shortName = data.location_Short_Name;
      this.isActive = data.location_IsEnabled;
      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };

      this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions).subscribe(result => {
        this.companies = result;
      })
      
    }

  onEditClick(): void {
    if(this.data.location_Full_Name != this.fullName || this.shortName != this.data.location_Short_Name || this.isActive != this.data.location_IsEnabled){
      this.http.post<any>(this.configService.resourceApiURI + '/update_location/', 
        { "Location_Id":  this.data.location_Id,
         "Location_Full_Name":  this.fullName,
         "Location_Short_Name":  this.shortName,
         "Location_IsEnabled":  this.isActive,
        }, 
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Committing changes.", "Close", {
            duration: 2000,
          });
        })
    }
    this.dialogRef.close();
  }
  onNoClick(){
    this.dialogRef.close();

  }
}


@Component({
  selector: 'add-location-dialog',
  templateUrl: 'add-location-dialog.html',
})
export class AddLocationDialog {

  fullName: string = '';
  shortName: string = '';

  
  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<AddLocationDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService, 
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };
      
    }

  onNoClick(): void {
    if('' != this.fullName || this.shortName != ''){
      this.http.post<any>(this.configService.resourceApiURI + '/create_location/', 
        { 
         "Location_Full_Name":  this.fullName,
         "Location_Short_Name": this.shortName,
         "Company_Id": this.data.Company_Id
        }, 
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Committing changes.", "Close", {
            duration: 2000,
          });
        })
    }
    this.dialogRef.close();
  }
  close(){
    this.dialogRef.close();

  }

}
