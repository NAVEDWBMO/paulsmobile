import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { orderBy, SortDescriptor, State, filterBy } from '@progress/kendo-data-query';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router'
import { MatSelectionList, MatListOption } from '@angular/material/list';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';

@Component({
  selector: 'app-manage-drivers-chat',
  templateUrl: './manage-drivers-chat.component.html',
  styleUrls: ['./manage-drivers-chat.component.sass']
})
export class ManageDriversChatComponent implements OnInit {
  httpOptions: { headers: any; };
  public gridView: GridDataResult;
  public pageSize = 8;
  public skip = 0;
  public gridData: any[] = [];

  userDefaultCompanyId: string = "";
  selectedCompany: string = "";
  userRole: string;

  public sort: SortDescriptor[] = [
    {
      field: "user_IsEnabled",
      dir: "desc",
    },
    {
      field: "sort_Order",
      dir: "asc",
    },
  ]; public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {
    this.authService.userRoleStatus$.subscribe(uCompany => this.userRole = uCompany);
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.authService.userCompanyId$.subscribe(access => {
      if (access) {
        this.userDefaultCompanyId = access;
      }
    });


    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.selectedCompany = access.company_Id;
      this.http.get<any>(this.configService.resourceApiURI + '/get_dispatch_users/', this.httpOptions).subscribe(result => {
        if (this.userRole == '25942536-c57d-4e18-a82d-0cdcc77a74c5') {
          result.forEach(user => {
            if (user.user_Company == access.company_Id && user.user_IsEnabled == true) {
              this.gridData.push(user);
            }
          });
        }
        else {
          result.forEach(user => {
            if (user.user_Company == this.userDefaultCompanyId && user.user_IsEnabled == true) {
              this.gridData.push(user);
            }
          });
        }
        this.loadItems();
      });
    });
   }

  ngOnInit(): void {}

  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();

  }

  public loadItems(): void {

    this.gridData = orderBy(this.gridData, this.sort);
    var filterdat = this.gridData;
    filterdat = filterBy(this.gridData, this.state.filter)
    this.gridView = {
      data:  filterdat.slice(this.skip, this.skip + this.pageSize),
      total: filterdat.length
    };
  }
  selectPermission(data)
  {

  }

  openAssignChatDialog(dataItem) {
    const dialogRef = this.dialog.open(AssignDriverChatDialog, {
      width: '700px',
      data: dataItem,
      disableClose: true,
      panelClass: 'custom-assign-dialog-container'

    });

    dialogRef.afterClosed().subscribe(result => {


    });
  }

  }

@Component({
  selector: 'Assign-driver-chat-dialog',
  templateUrl: 'Assign-driver-chat-dialog.html',
  styleUrls: ['./manage-drivers-chat.component.sass']

})
export class AssignDriverChatDialog {
  @ViewChild(CdkVirtualScrollViewport)
  viewport: CdkVirtualScrollViewport;

  public ischanged: boolean = true;
  httpOptions: { headers: any; };
  companies: any[] = [];
  selectedCompany: any = [];
  driversChat: any[] = [];
  selectedChat: any = [];
  searchForChats: string = "";
  filteredChat: any[] = [];
  searchDriver = '';

  @ViewChild('allSelected') private allSelected: MatListOption;
  @ViewChild('list') private list: MatSelectionList;
  
  constructor(
    public dialogRef: MatDialogRef<AssignDriverChatDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;
    var default_Company = { "company_Id": this.data.user_Company, "company_Name": this.data.user_Company_Name };

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.data.user_Company
      }
    };

    this.http.get<any>(this.configService.resourceApiURI + '/get_current_company_access/', httpOptionsTwo).subscribe(result => {

      this.companies = [default_Company, ...result];

    });

  

  }


  selectChange(e) {
    this.selectedChat = [];
    this.searchForChats = "";
    if (this.allSelected?.selected == true) {
      this.allSelected.selected = false;

    }

  //  this.allSelected.selected = false;
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.selectedCompany[0]["company_Id"],
        User_Id: this.data.user_Id

      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_assigned_dispatcher_drivers/', httpOptionsTwo).subscribe(result => {
      this.driversChat = this.filteredChat = result;
      this.selectedChat = result.filter(ele => { if (ele.isSelected == 1) { return ele; } });

    });
    if (this.selectedChat.length == this.filteredChat.length) {
      this.list?.selectAll();
    }
  }

  save() {
    var data: any[];
/*    if (this.allSelected.selected == true) {
      data = this.selectedChat.slice(1);
    } else {
      data = this.selectedChat;
    }*/
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_assigned_dispatcher_drivers/',
      {
        "Assigned_Drivers": this.selectedChat,
        "User_Id": this.data.user_Id,
        "Company_Id": this.selectedCompany[0].company_Id
      },
      httpOptionsTwo).subscribe(result => {
        this._snackBar.open("commiting changes.", "Close", {
          duration: 2000,
        });
      })

  }


  selectChat(option: any) {

    if (option.value == 0) {
      if (this.allSelected.selected)
      {
          this.list.selectAll();
          this.selectedChat = this.driversChat;
      } else {
          this.list.deselectAll();
          this.selectedChat = [];
      }

      
    } else {

      if (option.selected) this.selectedChat.push(option.value);
      else this.selectedChat = this.selectedChat.filter((x: any) => x != option.value);

      if (this.searchDriver.trim() == '' && this.selectedChat.length == this.driversChat.length) {
        this.allSelected.selected = true;
      } else if (this.searchDriver.trim() == '' && this.selectedChat.length != this.driversChat.length) {
        this.allSelected.selected = false;

      }

    }
  }
  search(event) {
    if (this.searchDriver.trim() != '') {
      this.filteredChat = this.driversChat.filter(chat => {
        if (chat.chat_Name.toLowerCase().includes(this.searchDriver.toLowerCase())) {
          return true
        } else {
          return false
        }
      })
    } else if (this.searchDriver.trim() == '') {
      this.filteredChat = this.driversChat;
    }
  }

  Close() {
    this.dialogRef.close();
  }
  
}
