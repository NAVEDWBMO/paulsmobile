import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageDriversChatComponent } from './manage-drivers-chat.component';

describe('ManageDriverChatComponent', () => {
  let component: ManageDriversChatComponent;
  let fixture: ComponentFixture<ManageDriversChatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ManageDriversChatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageDriversChatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
