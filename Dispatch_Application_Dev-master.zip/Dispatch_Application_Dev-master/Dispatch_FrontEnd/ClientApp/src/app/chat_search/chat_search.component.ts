import { animate, state, style, transition, trigger } from '@angular/animations';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, ElementRef, Inject, OnInit, OnDestroy, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router, NavigationExtras } from '@angular/router';
import { MatSelectionList, MatListOption } from '@angular/material/list';

@Component({
  selector: 'app-chat_search',
  templateUrl: './chat_search.component.html',
  styleUrls: ['./chat_search.component.sass'],
  animations: [
    trigger('openClose', [

      state('open', style({

        opacity: 1,
        backgroundColor: 'yellow'
      })),
      state('closed', style({

        opacity: 0.5,
        backgroundColor: 'green'
      })),
      transition('open => closed', [
        animate('1s')
      ]),
      transition('closed => open', [
        animate('0.5s')
      ]),
    ]),
  ],
})

export class ChatSearchComponent implements OnInit {


  @ViewChild(CdkVirtualScrollViewport)
  viewport: CdkVirtualScrollViewport;

  //Important info fields
  connection: string = "";
  userName = "";
  userRole = "";
  userId = "";
  company_Id: string;

  yellowFilter: boolean = true;
  blueFilter: boolean = true;
  greenFilter: boolean = true;

  chats: any = [];
  filteredChats: any = [];
  searchedChats: any = [];

  selectedChat: any = [];
  days: string = "7";
  searchForChats: string = "";

  searchValue: string = "";
  searchDriver: string = "";
  selected_Tab: string = "Rooms";

  searchMessagesContainer: boolean = false;
  foundMessages: any;






  //Critical error
  applicationCrashed: boolean = false;
  errorMessage: string = "";
  @ViewChild('allSelected') private allSelected: MatListOption;
  @ViewChild('list') private list: MatSelectionList;
  @ViewChild('allSelected2') private allSelected2: MatListOption;
  @ViewChild('roomlist') private roomlist: MatSelectionList;
  @ViewChild('allSelected3') private allSelected3: MatListOption;
  @ViewChild('outsourcelist') private outsourcelist: MatSelectionList;
  constructor(public http: HttpClient, private elementRef: ElementRef, private router: Router, private authService: AuthService, private configService: ConfigService) {

    if (this.router.getCurrentNavigation().extras.state) {
      const searchInfo = this.router.getCurrentNavigation().extras.state.searchInfo;
      this.company_Id = searchInfo.Company_Id;
      this.selected_Tab = searchInfo.Selected_Tab;
      this.userId = searchInfo.User_Id;
    }

  }

  ngOnInit(): void {
    this.getChats();
   
  }
  closeSearch() {

    this.router.navigateByUrl('/chats')
  }
  getChats() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.company_Id,
        User_Id: this.userId

      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_chats/', httpOptionsTwo).subscribe(result => {
      this.chats = result;
      this.organiseChatList();


    })

  }
  organiseChatList() {
    if (this.searchDriver != '') {
      this.filteredChats = this.chats.filter(chat => {
        if (chat.chat_Name.toLowerCase().includes(this.searchDriver.toLowerCase())) {
          return true
        } else {
          return false
        }
      })
    } else {
      this.filteredChats = this.chats.filter(chat => {
        if (this.yellowFilter && chat.chat_Level == 2) {
          return true
        } else if (this.blueFilter && chat.chat_Level == 1) {
          return true
        } else if (this.greenFilter && chat.chat_Level == 0) {
          return true
        } else {
          return false
        }
      })
      if (this.filteredChats.length > 1) {

      //  this.filteredChats.sort((a, b) => Date.parse(a.messages[a.messages.length - 1]?.message_Date) > Date.parse(b.messages[b.messages.length - 1]?.message_Date) ? 1 : -1);
        this.filteredChats.sort((a, b) => a.chat_Name > b.chat_Name ? 1 : -1);
        //var chatlevel1 = [];

    /*    var Chatlevels = this.filteredChats.reduce((acc, curr) => {
          if (curr.chat_Level === 1) {
            chatlevel1.push(curr)
          } else {
            acc.push(curr)
          }
          return acc;
        }, []).sort((a, b) => a.chat_Level < b.chat_Level ? 1 : -1);

        chatlevel1.forEach((item, index) => {
          Chatlevels.unshift(item)
        });*/
     //   this.filteredChats = Chatlevels;
      //  this.filteredChats.sort((a, b) => a.assignedId == this.userId || a.assignedId == "ME" ? -1 : 0);

      }


    }

  }
  onTabSelect(e) {

    this.selected_Tab = e.title;
    if (e.title == "Drivers") {
      this.selectedChat = [];
      

    }
    else if (e.title == "Rooms") {
      this.selectedChat = [];
    
    }
    else if (e.title == "Outsourced") {
      this.selectedChat = [];

    }
    this.clear();
  }
 

  search(event) {
    this.selectedChat = [];
    this.organiseChatList();
    this.get_chat_string();
  }
  Search_Text() {
   // console.log(this.get_chat_string());
    this.searchedChats = [];
    this.foundMessages = [];
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
      
      };
    this.http.post<any>(this.configService.resourceApiURI + '/search_messages_in_chats/',  {
      Search_Value: this.searchValue,
      Search_For_Chats: this.searchForChats,
      Days: this.days

    },httpOptions).subscribe(result => {
      this.searchedChats = result.filter(ele => { if (ele.messages.length > 0) { return ele; } });


      this.searchedChats.map(ele => {
        this.selectedChat.map(ele1 => {
          if (ele1!=0 && ele.chat_Id.toUpperCase() == ele1.chat_Id.toUpperCase()) { ele.chat_Name = ele1.chat_Name }
        })
      }
      )
    })

  }
  selectAll() {
    

    if (this.allSelected.selected) {
      this.list.selectAll();
    } else {
      this.list.deselectAll();
    }
    this.get_chat_string();

  }
  Show_chat(chat) {

    this.foundMessages = chat.messages;
  }
  selectRoomAll() {

    if (this.allSelected2.selected) {
       this.roomlist.selectAll();
    } else {
      this.roomlist.deselectAll();
    }
    this.get_chat_string();

  }
  selectOutAll() {

    if (this.allSelected3.selected) {
      this.outsourcelist.selectAll();
    } else {
      this.outsourcelist.deselectAll();
    }
    this.get_chat_string();

  }
  selectChat(e) {
   // console.log(e);
   // console.log(this.selectedChat.length)
    if (this.selectedChat.length == 1 && this.selectedChat[0].chat_Name != '') {
      this.allSelected.selected = false;
    }
    this.get_chat_string();
  }
  selectRoomChat(e) {

    if (this.selectedChat.length == 1 && this.selectedChat[0].chat_Name != '') {
      this.allSelected2.selected = false;
    }
    this.get_chat_string();
  }
  selectOutChat(e) {

    if (this.selectedChat.length == 1 && this.selectedChat[0].chat_Name != '') {
      this.allSelected3.selected = false;
    }
    this.get_chat_string();
  }
  get_chat_string() {

    var chat_str = this.selectedChat.map(ele => { return ele.chat_Id }).join(",");
    if (chat_str[0] == ",") {
      chat_str = this.selectedChat.map(ele => { return ele.chat_Id }).join(",").substring(1)
    }
    this.searchForChats = chat_str;
     
  }
  clear() {
    this.searchDriver = '';
    this.searchValue = '';
    this.days = "7";
    this.selectedChat = [];
    this.searchMessagesContainer = false;
    this.searchedChats = [];
    this.foundMessages = [];
    this.organiseChatList();
  }

}
