import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { Observable, Subscription } from 'rxjs';
import { FormControl } from '@angular/forms';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  userRole: string;
  subscription: Subscription;
  public httpOptions: any;

  public resultFromApi: any;
  userDefaultCompanyId: string;
  userCompaniesAccess: any = [];
  selectedCompany = new FormControl();

  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService) {


    this.resultFromApi = "No result yet;"
    //this.userRole = "test";
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.userCompanies();
    this.authService.userCompanyId$.subscribe(access => {
      if (access) {
        this.userDefaultCompanyId = access;
      }
    });
    
    //this.getRole();
  }

  ngOnInit() {
    this.subscription = this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
   
  }
  async userCompanies() {
  /*  await this.authService.userCompanyAccessStatus$.subscribe(access => {
      if (this.userDefaultCompanyId) {
        this.userCompaniesAccess = access;
        this.userCompaniesAccess.sort(function (a, b) {
          if (a.company_Name < b.company_Name) { return -1; }
          if (a.company_Name > b.company_Name) { return 1; }
          return 0;
        });
        const sorter = (a, b) => {
          if (a.company_Id === this.userDefaultCompanyId) {
            return -1;
          };
          if (b.company_Id === this.userDefaultCompanyId) {
            return 1;
          };
          //return a.company_Id < b.company_Id ? -1 : 1;
          return a.company_Sort_Order - b.company_Sort_Order;
        };

        this.userCompaniesAccess.sort(sorter)
      }
    });*/
  }
  

  //getRole() {
  //  this.http.get<any>(this.configService.resourceApiURI + '/get_user_info/', this.httpOptions).subscribe(result => {
  //    console.log(result);
  //    this.userRole = result;
  //    console.log(this.userRole);
  //  })
  //}

}



export interface Item {
  id: string;
  vehicleName: string;
  date: string;
  status: string;
  order_Invoice: string;
  order_Current_Location: string;
  order_Booking: string;
  order_Container: string;
  order_Consignee: string;
}
