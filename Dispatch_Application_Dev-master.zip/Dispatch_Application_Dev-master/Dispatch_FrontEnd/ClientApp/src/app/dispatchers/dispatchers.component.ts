import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router';
import { config } from 'rxjs';


@Component({
  selector: 'app-dispatchers',
  templateUrl: './dispatchers.component.html',
  styleUrls: ['./dispatchers.component.sass']
})
export class DispatchersComponent implements OnInit {

  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  selectedCompany = new FormControl();

  public gridData: any[] = [];
  httpOptions: { headers: any; };
  access: any;
  userRole: string;
  userCompanyAccess: any[];
  companyId: string = "";
  userDefaultCompanyId: string = "";
  companyType: string = "";
  companyName: string = "";
  public sort: SortDescriptor[] = [
    {
      field: "user_IsEnabled",
      dir: "desc",
    },
    {
      field: "sort_Order",
      dir: "asc",
    },
  ]; public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
   

    this.authService.userCompanyAccessStatus$.subscribe(uCompany => this.userCompanyAccess = uCompany);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userRole = uCompany);

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.access = access;
      this.gridData = [];
      if (access?.company_Id) {
        this.selectedCompany = access.company_Name;
        this.companyType = access.company_Sort_Order;
        this.companyId = access.company_Id;
        this.companyName = access.company_Name;
      

        this.authService.userCompanyId$.subscribe(access => {
          if (access) {
            this.userDefaultCompanyId = access;
          }
        });
        if ( this.userRole != '25942536-c57d-4e18-a82d-0cdcc77a74c5') {
          if (this.companyId != this.userDefaultCompanyId) {
            this.router.navigateByUrl('/home');
          }
          else {
            var httpOptionsTwo = {
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': this.authService.authorizationHeaderValue
              })
            };
            this.http.get<any>(this.configService.resourceApiURI + '/get_dispatch_users/', httpOptionsTwo).subscribe(result => {
              result.forEach(user => {
                if (user.user_Company_Name == access.company_Name) {
                  this.gridData.push(user);
                }
              });
              // this.gridData = result;
              this.loadItems();
            })
          }
        }
        else {
          var httpOptionsTwo = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.get<any>(this.configService.resourceApiURI + '/get_dispatch_users/', httpOptionsTwo).subscribe(result => {
            result.forEach(user => {
              if (user.user_Company_Name == access.company_Name) {
                this.gridData.push(user);
              }
            });
            // this.gridData = result;
            this.loadItems();
          })
        }
    
      }
      
    });


  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();

  }

  public loadItems(): void {
   /* this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
      total: this.gridData.length
    };*/
    this.gridData = orderBy(this.gridData, this.sort);
    var filterdat = this.gridData;
    filterdat = filterBy(this.gridData, this.state.filter)
    this.gridView = {
      data: filterdat.slice(this.skip, this.skip + this.pageSize),
      total: filterdat.length
    };


}


  ngOnInit(): void {
   
  }

  openDialog(dataItem) {
   // console.log(dataItem)
    if (dataItem.user_Role.toLowerCase() == '25942536-c57d-4e18-a82d-0cdcc77a74c5') {
      const dialogRef = this.dialog.open(DispatchersTypeEditDialog, {
        data: dataItem,
        disableClose: true

      });

      dialogRef.afterClosed().subscribe(result => {
        this.refreshUsers();
        this.loadItems();
      });
    } else {
      const dialogRef = this.dialog.open(DispatchersDialog, {
        data: dataItem,
        disableClose: true

      });

      dialogRef.afterClosed().subscribe(result => {
        this.refreshUsers();
        this.loadItems();
      });

    }
    
  
  }

  refreshUsers() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
     
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_dispatch_users/', httpOptionsTwo).subscribe(result => {
      this.gridData = [];

      result.forEach(user => {
        if (user.user_Company_Name == this.companyName) {
          this.gridData.push(user);
        }
      });
      this.loadItems();
    })
  }

}


@Component({
  selector: 'dispatchers-edit-dialog',
  templateUrl: 'dispatchers-edit-dialog.html',
  styleUrls: ['./dispatchers.component.sass']

})
export class DispatchersDialog {

  lowerCharacters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  upperCharacters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  symbols = ['!', '?', '@', '+', '=', '-', '_'];

  fname = new FormControl();
  lname = new FormControl();
  email = new FormControl('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]);
  password = new FormControl("");

  prev_fname: string;;
  prev_lname: string;;
  prev_email: string;;


  roles: any[] = [];
  selectedRole: any = {};
  Prev_selectedRole: any = {};
  Prev_selectedLocation: any = {};
  selectedLocation: any = {};

  companyList: any[] = [];
  locationList: any[] = [];
  companyresults: any[] = [];
  companyresultsfiltered: any[] = [];
  httpOptions: { headers: any; };

  transComp: any[] = [];
  selectedAccess: any[] = [];
  prev_selectedAccess: any[] = [];

  selectedCompany = new FormControl();
  userRole: string;
  availableLoc: any[] = [];
  locations: any[] = [];
  companyId: string = "";
  userDefaultCompanyId: string = "";
  companyName: string = "";
  companyLocation: string = "";
  companyType: string = "";
  userCompanyAccess: any[];
  Changed: boolean = false;
  httpOptionsTwo: { headers: any; params: any;};

  constructor(
    public dialogRef: MatDialogRef<DispatchersDialog>, @Inject(MAT_DIALOG_DATA) public data: any, private router: Router,public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.authService.userCompanyAccessStatus$.subscribe(uCompany => this.userCompanyAccess = uCompany);
    this.authService.userRoleStatus$.subscribe(uCompany => {
      this.userRole = uCompany;
    });
    // get default company id
    this.authService.userCompanyId$.subscribe(access => {
      if (access) {
        this.userDefaultCompanyId = access;
      }
    });

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.companyId = access.company_Id;
        this.companyName = access.company_Name;
        this.companyType = access.company_Type_Name;
        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: this.companyId
          }
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_locations_by_companyId/', httpOptionsTwo).subscribe(result => {          
          this.locations = result;
          this.selectedLocation =  result.filter((elem) => {
            if (elem.location_Id.toLowerCase() == data.user_Location.toLowerCase()) {
              return true
            } else {
              return false
            }
          })[0];
          this.Prev_selectedLocation = this.selectedLocation;
        });

        if (this.userRole != '25942536-c57d-4e18-a82d-0cdcc77a74c5') {
          if (this.companyId != this.userDefaultCompanyId) {
          this.router.navigateByUrl('/home');
          }
          else {
            this.httpOptionsTwo = {
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': this.authService.authorizationHeaderValue
              }),
              params: {
                Company_Id: this.userDefaultCompanyId
              }
            };

 /*           this.http.get<any>(this.configService.resourceApiURI + '/get_roles_based_on_user/', httpOptionsTwo).subscribe(result => {
              this.roles = result;

              this.selectedRole = result.filter((elem) => {
                if (elem.role_Id.toLowerCase() == data.user_Role.toLowerCase()) {
                  return true
                } else {
                  return false
                }
              })[0];*/
          /*  this.http.get<any>(this.configService.resourceApiURI + '/get_roles_based_on_company/', httpOptionsTwo).subscribe(result => {
              this.roles = result;

              this.selectedRole = result.filter((elem) => {
                if (elem.role_Id.toLowerCase() == data.user_Role.toLowerCase()) {
                  return true
                } else {
                  return false
                }
              })[0];
              this.fname.setValue(data.user_First_Name);
              this.lname.setValue(data.user_Last_Name);
              this.email.setValue(data.user_Email);
              this.prev_fname = data.user_First_Name.trim();
              this.prev_lname = data.user_Last_Name.trim();
              this.prev_email = data.user_Email.trim();
              this.Prev_selectedRole = this.selectedRole;
            });*/
          }
        }
        else {

          this.httpOptionsTwo = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            }),
            params: {
              Company_Id: this.companyId
            }
          };
        /*  var httpOptionsThree = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            }),
            params: {
              Company_Id: this.companyId
            }
          };
          this.http.get<any>(this.configService.resourceApiURI + '/get_roles_based_on_company/', httpOptionsThree).subscribe(result => {
            this.roles = result;

            this.selectedRole = result.filter((elem) => {
              if (elem.role_Id.toLowerCase() == data.user_Role.toLowerCase()) {
                return true
              } else {
                return false
              }
            })[0];

            this.fname.setValue(data.user_First_Name);
            this.lname.setValue(data.user_Last_Name);
            this.email.setValue(data.user_Email);
            this.prev_fname = data.user_First_Name.trim();
            this.prev_lname = data.user_Last_Name.trim();
            this.prev_email = data.user_Email.trim();
            this.Prev_selectedRole = this.selectedRole;

          });*/

        }

        this.http.get<any>(this.configService.resourceApiURI + '/get_current_company_roles/', httpOptionsTwo).subscribe(result => {
          this.roles = result;

          this.selectedRole = result.filter((elem) => {
            if (elem.role_Id.toLowerCase() == data.user_Role.toLowerCase()) {
              return true
            } else {
              return false
            }
          })[0];

          this.fname.setValue(data.user_First_Name);
          this.lname.setValue(data.user_Last_Name);
          this.email.setValue(data.user_Email);
          this.prev_fname = data.user_First_Name.trim();
          this.prev_lname = data.user_Last_Name.trim();
          this.prev_email = data.user_Email.trim();
          this.Prev_selectedRole = this.selectedRole;

        });
      }
    });

    this.authService.userRoleStatus$.subscribe(uCompany => this.userRole = uCompany);

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };
  /*  this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions).subscribe(result => {
      if (this.userDefaultCompanyId && this.companyId) {      
        this.companyresults = result;
        this.companyresultsfiltered = this.companyresults.filter(compresults => {
          this.userCompanyAccess.forEach(accessComp => {
            this.data.user_Company_Access.forEach(userreceivingaccess => {
              return compresults.company_Name != 'Admin' && userreceivingaccess != accessComp.company_Id;
            });
          });
        });

        this.userCompanyAccess.forEach(accessComp => {
          //this.data.user_Company_Access.forEach(userreceivingaccess => {
            if (this.companyId != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E'.toLowerCase() && this.userRole.toUpperCase() != '25942536-C57D-4E18-A82D-0CDCC77A74C5') {
              if (accessComp.company_Id != this.companyId) {
            this.transComp.push(accessComp);
          }
        }
        // Admin not in admin page
            else if (this.userRole.toUpperCase() == '25942536-C57D-4E18-A82D-0CDCC77A74C5' && this.companyId != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E'.toLowerCase()) {
              if (this.companyType == "OUTSOURCE") {
                let httpOptionsTwo = {
                  headers: new HttpHeaders({
                    'Content-Type': 'application/json',
                    'Authorization': this.authService.authorizationHeaderValue
                  }),
                  params: {
                    company_Id: this.companyId
                  }
                };
               *//* this.http.get<any>(this.configService.resourceApiURI + '/get_outsource_access/', httpOptionsTwo).subscribe(result => {
                  this.transComp = result;

                })*//*
              } else {
                if (accessComp.company_Id != this.companyId && accessComp.company_Name != 'Admin') {
                  this.transComp.push(accessComp);
                }
              }
             
        }
         // Admin in admin page
        else {
          this.transComp = this.companyresultsfiltered;                   
        }
      });
        //});

      this.companyList = result;
      //this.selectedCompany.setValue(this.data.user_Company_Name);
      //If not admin
      this.selectedCompany.setValue(this.companyList.filter(element => {
        if (this.data.user_Company == element.company_Id) {
          return true
        } else {
          return false;
        }
      })[0]);

      let accessLst = [];

      this.data.user_Company_Access.forEach(access => {
        this.companyList.forEach(comp => {
          if (access.toLowerCase() == comp.company_Id.toLowerCase()) {
            accessLst.push(comp);
            this.prev_selectedAccess.push(comp.company_Id)
          }
        })
      })
        this.selectedAccess = accessLst;
    }
    });*/
    
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.companyId = access.company_Id;        

      }
    });


  }
/*  comparer(o1: any, o2: any): boolean {
    // if possible compare by object's name, and not by reference.
    return o1 && o2 ? o1.company_Id === o2.company_Id : o2 === o2;
  }*/
  selectchange(e) {
    this.check();
  }
/*  selectaccess(e) {
 
    this.check();
  }*/
  check() {
  /*  var accessLst = [];
    this.selectedAccess.forEach(comp => {
      accessLst.push(comp.company_Id);
     })

    var check_access = false;
    if (this.prev_selectedAccess.length == accessLst.length && JSON.stringify(this.prev_selectedAccess.sort()) === JSON.stringify(accessLst.sort())) {
       check_access = true; 
    }*/
/*    else { check_access = false; }
*/
    if (
      this.Prev_selectedLocation == this.selectedLocation &&
      this.Prev_selectedRole == this.selectedRole &&
      this.prev_fname == this.fname.value?.trim() &&
      this.prev_lname == this.lname.value?.trim() &&
      this.prev_email.toLowerCase() == this.email.value?.trim().toLowerCase() )
    {
        if (this.password.value?.trim() != "") {
          this.Changed = true;
        } else {
          this.Changed = false;
        }
    } else if (this.fname.value?.trim() == "" ||
      this.lname.value?.trim() == "" ||
      this.email.value?.trim() == "") {
      this.Changed = false;
    }
      else {
        this.Changed = true;
      }
    }
  
  
  updateUser() {
    /*  let accessLst = [];
      this.selectedAccess.forEach(element => {
        accessLst.push(element.company_Id)
      });*/

   /*   let loc;
      if(this.selectedCompany.value?.company_Type == 'OUTSOURCE'){
        loc = "";
      }else{
        loc = this.selectedLocation?.location_Id;
      }*/
      let pass;
      if(this.password.value){
        pass = this.password.value;
      }else{
        pass = ""
    }

      this.http.post<any>(this.configService.resourceApiURI + '/update_user/',
        {
          "User_Id": this.data.user_Id,
          "User_Email_Old": this.data.user_Email,
          "User_Email":  this.email.value,
          "User_FirstName":  this.fname.value,
          "User_LastName":  this.lname.value,
          "User_Role_Id":  this.selectedRole.role_Id,
          "Company_Id": this.data.user_Company,
          "User_Location_Id": this.selectedLocation?.location_Id,
          "User_Password":  pass,
   //       "User_Access":  accessLst,
        }, 
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Saving changes.", "Close", {
            duration: 2000,
          });
        this.dialogRef.close();
        })
        
  }

  close() {
    this.dialogRef.close();
  }


  disableUser(){
      const dialogR = this.dialog.open(ConfirmActionDialog, {
        disableClose: true

      });
      dialogR.afterClosed().subscribe(result => {

        if(result == true){
          const  httpOptions = {
            headers: new HttpHeaders({
              'Content-Type':  'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/disable_user/', 
          { 
              "User_Email": this.data.user_Email
              
          }, 
          httpOptions).subscribe(result => {
            this.data.user_IsEnabled = 0;
      
          })
    
        }

      });
    }
  enableUser() {
    const dialogR = this.dialog.open(ConfirmActionDialog, {
      disableClose: true

    });
    dialogR.afterClosed().subscribe(result => {

      if (result == true) {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.post<any>(this.configService.resourceApiURI + '/enable_user/',
          {
            "User_Email": this.data.user_Email

          },
          httpOptions).subscribe(result => {
            this.data.user_IsEnabled = 1;

          })

      }

    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  getRandom(array){
    return array[Math.floor(Math.random() * array.length)];
  }

  generatePassword(){
    var finalCharacters = "";
    finalCharacters = finalCharacters.concat(this.getRandom(this.upperCharacters));
    finalCharacters = finalCharacters.concat(this.getRandom(this.numbers));
    finalCharacters = finalCharacters.concat(this.getRandom(this.symbols));

    for (var i = 1; i < 10 - 3; i++) {
      finalCharacters = finalCharacters.concat(this.getRandom(this.lowerCharacters));
    }
    let pass = finalCharacters.split('').sort(function () {
      return 0.5 - Math.random()
    }).join('');

    this.password.setValue(pass);
    this.check();
  }
  accessToCompaniesDialog(dataItem) {
    const dialogRef = this.dialog.open(DispatchersAccessCompanyDialog, {
      data: { 'user_info': dataItem, },
      disableClose: true,
      'width':'800px'
    });

    dialogRef.afterClosed().subscribe(result => {
  
    });

  }
}
@Component({
  selector: 'dispatchers-access-company-dialog',
  templateUrl: 'dispatchers-access-company-dialog.html',
  styleUrls: ['./dispatchers.component.sass']

})
export class DispatchersAccessCompanyDialog {
  companies: any[] = [];
  selectedCompany: any = [];
  roles: any[] = [];
  selectedRole: any = [];
  prev_selectedRole: any = [];
  constructor(
    public dialogRef: MatDialogRef<DispatchersAccessCompanyDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private _snackBar: MatSnackBar, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {

    //console.log(data);

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.data.user_info.user_Company
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_current_company_access/', httpOptionsTwo).subscribe(result => {
      this.companies = result;
    });
    
  }
  selectChange(e) {
    //console.log(this.selectedCompany);

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Current_Company_Id: this.data.user_info.user_Company,
        Access_Company_Id: e[0].company_Id,
        User_Id: this.data.user_info.user_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_current_company_other_roles/', httpOptionsTwo).subscribe(result => {
      this.roles = result;
      this.prev_selectedRole = this.selectedRole = result.filter(ele => { if (ele.role_Access == 1) { return ele; } })[0];
    

    });

  }

  save() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_user_company_roles/',
      {
        "User_Id": this.data.user_info.user_Id,
        "Company_Id": this.selectedCompany[0].company_Id,
        "Role_Id": this.selectedRole.role_Id
      },
      httpOptionsTwo).subscribe(result => {
        this._snackBar.open("commiting changes.", "Close", {
          duration: 2000,
        });
        //this.dialogRef.close();
      })


  }
  Close(){
    this.dialogRef.close();
  }

}


@Component({
  selector: 'dispatchers-type-edit-dialog',
  templateUrl: 'dispatchers-type-edit-dialog.html',
  styleUrls: ['./dispatchers.component.sass']

})
export class DispatchersTypeEditDialog {
  lowerCharacters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  upperCharacters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  symbols = ['!', '?', '@', '+', '=', '-', '_'];

  fname = new FormControl();
  lname = new FormControl();
  email = new FormControl('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]);
  password = new FormControl("");

  prev_fname: string;;
  prev_lname: string;;
  prev_email: string;;

  httpOptions: { headers: any; };
/*
  transComp: any[] = [];
  selectedAccess: any[] = [];
  prev_selectedAccess: any[] = [];*/

  //selectedCompany = new FormControl();
  //userRole: string;
 // availableLoc: any[] = [];
 // locations: any[] = [];
 // companyId: string = "";
 // userDefaultCompanyId: string = "";
  //companyName: string = "";
  //companyLocation: string = "";
  //companyType: string = "";
 // userCompanyAccess: any[];
  Changed: boolean = false;
  //httpOptionsTwo: { headers: any; params: any; };

  constructor(
    public dialogRef: MatDialogRef<DispatchersTypeEditDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private _snackBar: MatSnackBar, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {

    this.fname.setValue(data.user_First_Name);
    this.lname.setValue(data.user_Last_Name);
    this.email.setValue(data.user_Email);
    this.prev_fname = data.user_First_Name.trim();
    this.prev_lname = data.user_Last_Name.trim();
    this.prev_email = data.user_Email.trim();


  }
  getRandom(array) {
    return array[Math.floor(Math.random() * array.length)];
  }

  generatePassword() {
    var finalCharacters = "";
    finalCharacters = finalCharacters.concat(this.getRandom(this.upperCharacters));
    finalCharacters = finalCharacters.concat(this.getRandom(this.numbers));
    finalCharacters = finalCharacters.concat(this.getRandom(this.symbols));

    for (var i = 1; i < 10 - 3; i++) {
      finalCharacters = finalCharacters.concat(this.getRandom(this.lowerCharacters));
    }
    let pass = finalCharacters.split('').sort(function () {
      return 0.5 - Math.random()
    }).join('');

    this.password.setValue(pass);
    this.check();
  }
  check() {

    if (
      this.prev_fname == this.fname.value?.trim() &&
      this.prev_lname == this.lname.value?.trim() &&
      this.prev_email.toLowerCase() == this.email.value?.trim().toLowerCase()) {
      if (this.password.value?.trim() != "") {
        this.Changed = true;
      } else {
        this.Changed = false;
      }
    } else if (this.fname.value?.trim() == "" ||
      this.lname.value?.trim() == "" ||
      this.email.value?.trim() == "") {
      this.Changed = false;
    }
    else {
      this.Changed = true;
    }
  }
  
  updateUser() {

    let pass;
    if (this.password.value) {
      pass = this.password.value;
    } else {
      pass = ""
    }
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_user/',
      {
        "User_Id": this.data.user_Id,
        "User_Email_Old": this.data.user_Email,
        "User_Email": this.email.value,
        "User_FirstName": this.fname.value,
        "User_LastName": this.lname.value,
        "User_Role_Id": this.data.user_Role,
        "Company_Id": this.data.user_Company,
        "User_Location_Id": this.data.user_Location,
        "User_Password": pass
      
      },
      this.httpOptions).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 2000,
        });
        this.dialogRef.close();
      })

  }

  close() {
    this.dialogRef.close();
  }


  disableUser() {
    const dialogR = this.dialog.open(ConfirmActionDialog, {
      disableClose: true

    });
    dialogR.afterClosed().subscribe(result => {

      if (result == true) {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.post<any>(this.configService.resourceApiURI + '/disable_user/',
          {
            "User_Email": this.data.user_Email

          },
          httpOptions).subscribe(result => {
            this.data.user_IsEnabled = 0;

          })

      }

    });
  }
  enableUser() {
    const dialogR = this.dialog.open(ConfirmActionDialog, {
      disableClose: true

    });
    dialogR.afterClosed().subscribe(result => {

      if (result == true) {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.post<any>(this.configService.resourceApiURI + '/enable_user/',
          {
            "User_Email": this.data.user_Email

          },
          httpOptions).subscribe(result => {
            this.data.user_IsEnabled = 1;

          })

      }

    });
  }

/*  onNoClick(): void {
    this.dialogRef.close();
  }
  Close() {
    this.dialogRef.close();
  }*/

}
