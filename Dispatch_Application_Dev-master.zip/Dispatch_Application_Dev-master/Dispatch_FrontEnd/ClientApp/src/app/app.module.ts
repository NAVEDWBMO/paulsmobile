import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER} from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ConfigService } from './shared/config.service';
import { AuthCallbackComponent } from './auth-callback/auth-callback.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { GridModule } from '@progress/kendo-angular-grid';
import { DriversComponent, EditTruckImeiDialog, SetupDialog, ReactiveDriverDialog, NewDriversDialog } from './drivers/drivers.component';
import { DriverSetupComponent } from './driver-setup/driver-setup.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AssignDialog, ChatComponent, ChatControlDialog } from './old-chat/chat.component';
import { ChatContainerComponent, } from './chat-container/chat-container.component';
import { GoogleMapsModule } from '@angular/google-maps';
import { MatChipsModule } from '@angular/material/chips';
import { DispatchersComponent, DispatchersDialog, DispatchersAccessCompanyDialog, DispatchersTypeEditDialog} from './dispatchers/dispatchers.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ChatSearchComponent } from './chat_search/chat_search.component';
import { MatTabsModule } from '@angular/material/tabs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { MinuteSecondsPipe } from './minute-seconds.pipe';
import { LoggedOutComponent } from './logged-out/logged-out.component';
import { DisabledChatsComponent } from './disabled-chats/disabled-chats.component';
import { DialogComplete, DispatchSetupComponent } from './dispatch-setup/dispatch-setup.component';
import { LocationsComponent, LocationEditDialog, AddLocationDialog } from './locations/locations.component';
import { CompaniesComponent, CreateCompanyDialog, EditCompanyDialog, AccessToCompanyDialog, CompanyLoactionsDialog } from './companies/companies.component';
import { AddDeviceDialog, AddImeiDialog, DevicesComponent, EditDeviceDialog, DeviceStatusDialog } from './devices/devices.component';
import { AddTruckDialog, EditTruckDialog, TrucksComponent, AddOutsourceTruckDialog } from './trucks/trucks.component';
import { EditImeiDialog, ImeisComponent } from './imeis/imeis.component';

import { SelectCompanyComponent } from './select-company/select-company.component';
import { ChatSettingsComponent, ConfirmActionDialog, AddChatDialog, EditChatDialog } from './chat-settings/chat-settings.component';
import { TruckSetupComponent } from './truck-setup/truck-setup.component';
import { TabletComponent, ChangeFreightBillDialog, ConfirmDeleteDialog, DriverAssignDialog, LocationAlertDialog, ChangeAddressDialog } from './tablet/tablet.component';
import { CellCompaniesComponent, PhonePipe, AddCellCompanyDialog, CellPlansDialog, AddCellPlansDialog, EditCellCompanyDialog, EditCellPlanDialog } from './cell-companies/cell-companies.component';
import { RolesComponent, AddRoleDialog, RoleEditDialog, RolesCompanyAccessDialog, DialogAlert } from './roles/roles.component';
import { PicturesComponent, ImageDialog, AlertDialog, EmailDialog } from './pictures/pictures.component';
import { EditorModule } from "@progress/kendo-angular-editor";
import { AllPicturesComponent  } from './all-pictures/allpictures.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { PermissionsDialogAlert, PermissionsComponent, AddPermissionsDialog, AddPermissionsTypeDialog, EditPermissionsDialog, EditPermissionsAccessLevelDialog, EditPermissionsTypeDialog} from './permissions/permissions.component';
import { CompanyComponent, EditMyCompanyDialog, AccessToMyCompanyDialog, MyCompanyLoactionsDialog } from './Company/Company.component';
import { AccountComponent } from './account/account.component';
import { ChatLevel1Component, ChatLevel1ControlDialog, ChatLevel1AssignDialog, ChatContainerDialog, ImagesContainerDialog, DriverChatImage1Dialog, BroadcastMsg1Dialog } from './chat-level1/chat-level1.component';
import { ChatLevel2Component, ChatLevel2ControlDialog, ChatLevel2AssignDialog, ChatContainer2Dialog, ImagesContainer2Dialog, DriverChatImage2Dialog, BroadcastMsg2Dialog } from './chat-level2/chat-level2.component';
import { ChatLevel3Component, ChatLevel3ControlDialog, ChatLevel3AssignDialog, ChatContainer3Dialog, ImagesContainer3Dialog, DriverChatImage3Dialog, BroadcastMsg3Dialog } from './chat-level3/chat-level3.component';
import { ChatsComponent } from './chats/chats.component';
import { MatMomentDateModule, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from "@angular/material-moment-adapter";
import { TooltipModule } from 'ng2-tooltip-directive';
import { OutsourceDriverSetupComponent } from './outsource-driver-setup/outsource-driver-setup.component';
import { GateComponent, PickupRequestDialog, PickupNumberDialog, AddPickupDialog, LineupRemoveReasonDialog, ContainerNumberDialog } from './gate/gate.component';
import { LineupComponent, ChangeLineupDialog, LanePositionDialog} from './lineup/lineup.component';
import { InGateComponent, YardLocationDialog, ChangeIngateDialog} from './ingate/ingate.component';
import { OutGateComponent, OutgateDriverDialog, ChangeOutgateDialog, SendHoldDriverDialog } from './outgate/outgate.component';
import { MapComponent } from './map/map.component';
import { ManageDriversChatComponent, AssignDriverChatDialog } from './manage-drivers-chat/manage-drivers-chat.component';

const appInitializerFn = (configService: ConfigService) => {
  return () => {
    return configService.setConfig();
  };
};


@NgModule({
  declarations: [
    AppComponent,
    AuthCallbackComponent,
    NavMenuComponent,
    DriversComponent,
    HomeComponent,
    DriverSetupComponent,
    SetupDialog,
    ChatComponent,
    ChatContainerDialog,
    ChatControlDialog,
    AssignDialog,
    DispatchersComponent,
    DispatchersDialog,
    DispatchersAccessCompanyDialog,
    DispatchersTypeEditDialog,
    ChatSearchComponent,
    MinuteSecondsPipe,
    ImagesContainerDialog,
    LoggedOutComponent,
    DisabledChatsComponent,
    DispatchSetupComponent,
    DialogComplete,
    LocationEditDialog,
    LocationsComponent,
    AddLocationDialog,
    CompaniesComponent,
    CreateCompanyDialog,
    EditCompanyDialog,
    ConfirmActionDialog,
    AddChatDialog,
    EditChatDialog,
    DevicesComponent,
    TrucksComponent,
    AddTruckDialog,
    AddDeviceDialog,
    AddImeiDialog,
    EditTruckImeiDialog,
    EditDeviceDialog,
    EditTruckDialog,
    ImeisComponent,
    EditImeiDialog,
    SelectCompanyComponent,
    ChatContainerComponent,
    ChatSettingsComponent,
    TruckSetupComponent,
    TabletComponent,
    ChangeFreightBillDialog,
    ConfirmDeleteDialog,
    DriverAssignDialog,
    CellCompaniesComponent,
    AddCellCompanyDialog,
    AddCellPlansDialog,
    CellPlansDialog,
    EditCellCompanyDialog,
    EditCellPlanDialog,
    DeviceStatusDialog,
    RolesComponent,
    RoleEditDialog,
    AddRoleDialog,
    DialogAlert,
    PhonePipe,
    PicturesComponent,
    ImageDialog,
    AlertDialog,
    EmailDialog,
    AllPicturesComponent,
    PermissionsDialogAlert,
    PermissionsComponent,
    AddPermissionsDialog,
    EditPermissionsDialog,
    AccessToCompanyDialog,
    CompanyLoactionsDialog,
    RolesCompanyAccessDialog,
    AddPermissionsTypeDialog,
    EditPermissionsAccessLevelDialog,
    EditPermissionsTypeDialog,
    CompanyComponent,
    EditMyCompanyDialog,
    AccessToMyCompanyDialog,
    MyCompanyLoactionsDialog,
    AccountComponent,
    ChatLevel1Component,
    ChatLevel1ControlDialog,
    ChatLevel1AssignDialog,
    ChatLevel2Component,
    ChatLevel2ControlDialog,
    ChatLevel2AssignDialog,
    ChatLevel3Component,
    ChatLevel3ControlDialog,
    ChatLevel3AssignDialog,
    ChatsComponent,
    ChatContainer2Dialog,
    ImagesContainer2Dialog,
    ChatContainer3Dialog,
    ImagesContainer3Dialog,
    LocationAlertDialog,
    ChangeAddressDialog,
    OutsourceDriverSetupComponent,
    AddOutsourceTruckDialog,
    GateComponent,
    MapComponent,
    LanePositionDialog,
    YardLocationDialog,
    ReactiveDriverDialog,
    NewDriversDialog,
    InGateComponent,
    LineupComponent,
    OutGateComponent,
    ChangeLineupDialog,
    LanePositionDialog,
    PickupNumberDialog,
    LineupRemoveReasonDialog,
    PickupRequestDialog,
    ContainerNumberDialog,
    OutgateDriverDialog,
    SendHoldDriverDialog,
    ChangeIngateDialog,
    AddPickupDialog,
    ChangeOutgateDialog,
    ManageDriversChatComponent,
    AssignDriverChatDialog,
    DriverChatImage3Dialog,
    BroadcastMsg3Dialog,
    DriverChatImage2Dialog,
    BroadcastMsg2Dialog,
    DriverChatImage1Dialog,
    BroadcastMsg1Dialog
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CoreModule,
    MatNativeDateModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule, BrowserAnimationsModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatGridListModule,
    MatInputModule,
    MatDividerModule,
    MatProgressBarModule,
    MatSelectModule,
    MatListModule,
    MatTableModule,
    MatCardModule,
    MatMenuModule,
    MatRadioModule,
    MatCheckboxModule,
    MatSnackBarModule,           
    MatDatepickerModule,       
    MatDialogModule,
    MatProgressSpinnerModule,
    GridModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    GoogleMapsModule,
    MatChipsModule,
    MatTooltipModule,
    ScrollingModule,
    MatTabsModule,
    LayoutModule,
    EditorModule,
    NgxSpinnerModule,
    MatMomentDateModule,
    TooltipModule
  ],
  exports: [
    MatDatepickerModule,
    MatNativeDateModule,
  ],
  providers: [
    ConfigService,
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializerFn,
      multi: true,
      deps: [ConfigService]
    },
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
  ],
  bootstrap: [AppComponent],
  entryComponents: [],
})
export class AppModule { }
