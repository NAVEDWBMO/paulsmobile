import {trigger,state,style,animate,transition } from '@angular/animations';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { parse } from 'querystring';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';


@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styles: [`
    >>> .k-grid .k-grouping-row .k-icon {
      margin-left: 2px;
    }
  `],
  styleUrls: ['./map.component.sass']
})
export class MapComponent implements OnInit {


  private data: Object[];
  public selectedDriver: any = [];
  private access: any;
  public gridData: any[] = [];
  public drivers: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  selectedCompanyId: string = "";
  selectedCompany: any;
  userCompaniesAccess: any;
  searchValue: string = '';
  filteredDriver: any = [];
  markers: any = [
    
    {
      "position": {
        "lat": 43.62412052916568,
        "lng": -79.69698575387764
      },
      "label": {
        "color": "White"
      },
      "title": "Pauls Transport",
      "options": {
        "animation": 2
      }
    },
    {
      "position": {
        "lat": 43.7340,
        "lng": -79.6727
      },
      "label": {
        "color": "White"
      },
      "title": "CN",
      "options": {
        "animation": 2
      }
    },
       {
      "position": {
           "lat": 43.6532,
           "lng": -79.3832
      },
      "label": {
        "color": "White"
      },
      "title": "CN",
      "options": {
        "animation": 2
      }
    }
  ];
  styles: Record<string, google.maps.MapTypeStyle[]> = {
    default: [],
    hide: [
      {
        featureType: "poi.business",
        stylers: [{ visibility: "off" }],
      },
      {
        featureType: "transit",
        elementType: "labels.icon",
        stylers: [{ visibility: "off" }],
      },
    ],
  };
  public products: any[] = [];
 
  mapa: mapboxgl.Map;

  
  @ViewChild('grid') private grid;

  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
 

  

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.gridData = [];
      if (access?.company_Id)
      {
          this.access = access;
          this.selectedCompanyId = access.company_Id;
          if (access.company_Id.toUpperCase() != "")
          {
            var httpOptionsTwo = {
                headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': this.authService.authorizationHeaderValue
                }),
                params:
                {
                    Company_Id: access.company_Id
                }
            };
            this.http.get<any>(this.configService.resourceApiURI + '/driver_gettabletdrivers/', httpOptionsTwo).subscribe(result => {
              this.filteredDriver= this.drivers = result.sort(this.sorter);
              this.gridData = [];
              this.selectedDriver =[];
            })
          }
       
      }

    });
    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);

  }
  sorter(a, b) {
    if (a.d_Id < b.d_Id) {
      return -1;
    }
    if (a.d_Id > b.d_Id) {
      return 1;
    }
    return 0;
  }

  selectDriver() {

    
    
  }

  search(e) {
    if (this.drivers != undefined) {
      this.filteredDriver = this.drivers.map((elem) => {
        if (elem.driver_Id.includes(e.target.value)) { return elem; }
      })
    }
  }

  ngOnInit(): void {
    mapboxgl.accessToken = this.configService.mapBoxEndKey;
    
    this.mapa = new mapboxgl.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [-75.50, 40],
      zoom: 9,


    });
    this.mapa.on('style.load', () => {
      this.mapa.setFog({}); // Set the default atmosphere style
    });

  }
  onTabSelect(e) {

    /*this.selectedTab = e.title;
    this.selectedChat = [];
    this.openedChat = {
      messages: []
    };


    if (e.title == "Drivers") {
      this.unreadMessagesInDrivers = false;

    }
    else if (e.title == "Rooms") {
      this.unreadMessagesInRooms = false;

    } else if (e.title == "Outsourced") {
      this.unreadMessagesInOutsourced = false;

    }
    if (this.searchValue?.trim() != "") {
      this.searchValue = "";
      this.search_In_List();
    }*/
  }
  

  refreshDriverList() {
    if (this.selectedDriver != undefined &&  this.selectedDriver.length > 0)
    {
        var httpOptionsTwo = {
        headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
        }),
          params:
          {
             user_Id: this.selectedDriver[0].user_Id
          }
        };
        this.http.get<any>(this.configService.resourceApiURI + '/driver_getdrivertabletstatus/', httpOptionsTwo).subscribe(result => {
          this.gridData = result;
        })
    }
  }

}


