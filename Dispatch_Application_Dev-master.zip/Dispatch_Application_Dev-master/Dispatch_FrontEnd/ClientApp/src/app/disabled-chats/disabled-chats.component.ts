import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';

@Component({
  selector: 'app-disabled-chats',
  templateUrl: './disabled-chats.component.html',
  styleUrls: ['./disabled-chats.component.sass']
})
export class DisabledChatsComponent implements OnInit {

  @ViewChild(CdkVirtualScrollViewport)
  viewport: CdkVirtualScrollViewport;

  chats: any = [];
  filteredChats: any = [];
  selectedChat: any = [];
  openedChat: any = {
    messages: []
  };
  applicationCrashed: boolean = false;
  searchValue: string = '';
  searchMessagesContainer: boolean = false;
  foundMessages: any;
  httpOptions: { headers: HttpHeaders; };
  loadingChat: boolean;
  endOfHistory: boolean;
  inHistory: boolean;

  constructor(public http: HttpClient, private authService: AuthService, private configService: ConfigService) {


    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
   }

  ngOnInit(): void {

    this.http.get<any>(this.configService.resourceApiURI + '/get_disabled_chats/', this.httpOptions).subscribe(result => {
      this.chats = result;
      //select chat on load
      if(result.length != 0){
        this.openedChat = this.chats[0];
        this.loadChat();
      }

    })


  }

  loadChat(){
    this.selectedChat[0] = this.openedChat;
    this.searchMessagesContainer = false;
    this.inHistory = false;
    this.endOfHistory = false;
    this.loadingChat = true;
    if(this.openedChat.messages.length > 30){
      this.openedChat.messages = this.openedChat.messages.slice(this.openedChat.messages.length - 30)
    }
    
    this.openedChat.messages  = this.chats.find(chat => chat.chat_Name === this.openedChat.chat_Name).messages;
    if(this.openedChat.messages.length < 20){
      this.endOfHistory = true;
    }
    this.scrollChat();
  
    setTimeout (() => {
  
      this.loadingChat = false;
   }, 500);
   }

   scrollChat(){
    requestAnimationFrame(() => {
      this.viewport.scrollToIndex(this.openedChat.messages.length, 'smooth');
      setTimeout(()=>{
        this.viewport.scrollToOffset(999999, 'smooth');
      }, 200)
    });
  
  }

search($e){

}

}
