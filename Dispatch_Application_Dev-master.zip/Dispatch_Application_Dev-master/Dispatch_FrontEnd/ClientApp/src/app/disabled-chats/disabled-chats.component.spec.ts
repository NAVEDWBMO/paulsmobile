import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisabledChatsComponent } from './disabled-chats.component';

describe('DisabledChatsComponent', () => {
  let component: DisabledChatsComponent;
  let fixture: ComponentFixture<DisabledChatsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisabledChatsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisabledChatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
