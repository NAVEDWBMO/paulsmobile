import { Component, ElementRef } from '@angular/core';
import { AuthService } from './core/authentication/auth.service';
import { Subscription } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { ConfigService } from './shared/config.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  name: string;
  isAuthenticated: boolean = false;
  subscription:Subscription;

  constructor(private authService:AuthService, public http: HttpClient, private configService: ConfigService, private _elementRef: ElementRef) { }

  ngOnInit() {
    this.subscription = this.authService.authNavStatus$.subscribe(status => this.isAuthenticated = status);
    this._elementRef.nativeElement.removeAttribute("ng-version");
  } 

}
