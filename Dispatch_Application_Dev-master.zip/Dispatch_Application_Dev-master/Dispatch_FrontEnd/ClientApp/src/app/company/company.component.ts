import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router';
import { orderBy, SortDescriptor } from '@progress/kendo-data-query';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.sass']
})
export class CompanyComponent implements OnInit {

  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  private selectedCompanyId: string;

  public gridData: any[] = [];
  httpOptions: { headers: any;   params: any; };
  public sort: SortDescriptor[] = [
    {
      field: "company_IsEnabled",
      dir: "desc",
    },

  ];
  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {

    this.authService.userCompanyId$.subscribe(company_id => {
      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          company_Id: company_id
        }
      };

    })    
    this.http.get<any>(this.configService.resourceApiURI + '/get_company/', this.httpOptions).subscribe(result => {

      this.gridData = result;
      this.loadItems();
    })
 
  }
  ngOnInit(): void {
    //throw new Error('Method not implemented.');
   
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
}
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
private loadItems(): void {
    this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
        total: this.gridData.length
    };
}

openEditDialog(dataitem){
  const dialogRef = this.dialog.open(EditMyCompanyDialog, {
    data: dataitem,
    disableClose: true

  });

  dialogRef.afterClosed().subscribe(result => {
        this.get_companies();

  });


}
  get_companies() {

    this.http.get<any>(this.configService.resourceApiURI + '/get_company/', this.httpOptions).subscribe(result => {

      this.gridData = result;
      this.loadItems();
    })
  }
}


@Component({
  selector: 'edit-company-dialog',
  templateUrl: 'edit-company-dialog.html',
  styleUrls: ['./company.component.sass']

})
export class EditMyCompanyDialog {

  selectedCompany: any = {};

  companyName = '';

  isActive: boolean = false;

  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<EditMyCompanyDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

      this.isActive = data.company_IsEnabled;
    this.companyName = data.company_Name;

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };


      
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onEditClick(): void {
  
    if(this.companyName != ''){
      this.http.post<any>(this.configService.resourceApiURI + '/update_company/',
        {
          "Company_Id": this.data.company_Id,
          "Company_Name": this.companyName,
          "Company_Type_Id": this.data.company_Type_Id,
          "Company_IsEnabled": this.isActive,

        },
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Saving changes.", "Close", {
            duration: 2000,
          });
        })

    }
    this.dialogRef.close();
  }

  select_Location() {
    const dialogRef = this.dialog.open(MyCompanyLoactionsDialog, {
      disableClose: true,
      width: '800px',
      data: this.data,
      panelClass: 'custom-location-dialog-container'

    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }
  
  access_to_company() {
    const dialogRef = this.dialog.open(AccessToMyCompanyDialog, {
      disableClose: true,
      width: '800px',
      data: this.data,
      panelClass: 'custom-access-to-company-dialog-container'

    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }


}

@Component({
  selector: 'access-to-company-dialog',
  templateUrl: 'access-to-company-dialog.html',
  styleUrls: ['./company.component.sass']

})
export class AccessToMyCompanyDialog {
  companies: any[] = [];
  selectedCompany: any[] = [];


  constructor(
    public dialogRef: MatDialogRef<AccessToMyCompanyDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private _snackBar: MatSnackBar, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
    let httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        company_Id: this.data.company_Id,
        company_Type_Id: this.data.company_Type_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_Company_Access_To_Company/', httpOptionsTwo).subscribe(result => {
      this.companies = result;
      result.forEach(selCom => {
        if (selCom.selected == "1") {
          this.selectedCompany.push(selCom)
        }
      });

    });

  }
  onchange(comp) {

/*    console.log(comp);
*/

  }
  save() {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_company_access_to_company/',
      {
        "Company_Id": this.data.company_Id,
        "Access_To_Companies": this.selectedCompany

      },
      httpOptions).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 2000,
        });
      })

  }
  Close() {
    this.dialogRef.close();
  }

}
@Component({
  selector: 'company-locations-dialog',
  templateUrl: 'company-locations-dialog.html',
  styleUrls: ['./company.component.sass']

})
export class MyCompanyLoactionsDialog {
  locations: any[] = [];
  selectedLocations: any[] = [];
  httpOptions: { headers: any; params:any;};
  //selectedCompany: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<MyCompanyLoactionsDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private _snackBar: MatSnackBar, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
      , params: {
        Company_Id: this.data.company_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_locations_by_companyId/', this.httpOptions).subscribe(result => {
      this.locations = result;

      this.data.locations.forEach(comLoc => {
        result.forEach(loc => {
          if (comLoc.location_Id.toLowerCase() == loc.location_Id.toLowerCase()) {
            this.selectedLocations.push(loc);
         }
        });
      });

    })
  }


  save() {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_company_locations/',
      {
        "Company_Id": this.data.company_Id,
        "Locations": this.selectedLocations

      },
      httpOptions).subscribe(result => {
        this.data.locations = this.selectedLocations;
        this._snackBar.open("Saving changes.", "Close", {
          duration: 2000,
        });
      })

  }

}
