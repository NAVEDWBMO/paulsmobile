import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, NgZone, ElementRef } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, SelectableSettings, RowArgs} from '@progress/kendo-angular-grid';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router'
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { FormGroup, FormControl, Validators, Form, FormBuilder } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import {  orderBy, SortDescriptor } from '@progress/kendo-data-query';

@Component({
  selector: 'app-pictures',
  templateUrl: './pictures.component.html',
  styleUrls: ['./pictures.component.sass']
})
export class PicturesComponent implements OnInit {

  public gridView: GridDataResult;
  public pageSize = 6;
  public skip = 0;
  private data: Object[];
  public gridData: any[] = [];
  public Drivers: any[] = [];
  public mySelection: any[] = [];
  public selectableSettings: SelectableSettings;
  public searchValue: string;
  public selectedCompanyId: string;
  public selectedDriver: any=[];
  public selectedFolder: string = '';
  public selectImages: boolean = false;
  public companyType: string = '';
  public sort: SortDescriptor[] = [
    {
      field: "fileCreatedDate",
      dir: "desc",
    },
    

  ];
  constructor(public http: HttpClient, private spinner: NgxSpinnerService, @Inject(DOCUMENT) private _document: HTMLDocument, private router: Router, private zone: NgZone, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {

      if (access?.company_Id) {
        this.selectedCompanyId = access.company_Id;
        this.companyType = access.company_Type_Name;
        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: this.selectedCompanyId
          }
        };
        this.Drivers = [];
        this.selectDriver();
        if (access.company_Id.toLowerCase() != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E'.toLowerCase()) {
          this.http.get<any>(this.configService.resourceApiURI + '/get_registered_drivers_info/', httpOptionsTwo)
            .subscribe(result => {
            this.Drivers =result.sort(sorter);
            })
        }
      }
    });
    const sorter = (a, b) => {
      return b.driver_IsEnabled - a.driver_IsEnabled
    }

    this.selectableSettings = {
      checkboxOnly: true,
      mode: 'multiple'
    };
   
   }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  ngOnInit(): void {

  }

/*  selectimage(e, filepath) {
    e.preventDefault()
    if (filepath.substring(filepath.length - 3) != "pdf") {
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          filepath: filepath
        }
      };
      //  this.spinner.show();

      this.http.get<any>(this.configService.resourceApiURI + '/get_driver_ftp_files_image/', httpOptionsTwo)
        .subscribe(result => {
          //  console.log(result);
          const dialogRef = this.dialog.open(ImageDialog, {
            data: result[0].image
          });
        })
    }

  }*/

  selectimage(e, filepath) {
    e.preventDefault()
    //if (filepath.substring(filepath.length - 3) != "pdf") {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        filepath: filepath
      }
    };
    //  this.spinner.show();

    this.http.get<any>(this.configService.resourceApiURI + '/get_driver_ftp_files_image/', httpOptionsTwo)
      .subscribe(result => {
        // console.log(result);
        if (filepath.substring(filepath.length - 3) == "pdf") {
          const pdfData = result[0].image; // Assuming result[0].pdf contains the base64-encoded PDF data
          const pdfBlob = this.base64toBlob(pdfData, 'application/pdf');
          const pdfUrl = URL.createObjectURL(pdfBlob);
          window.open(pdfUrl, '_blank');
        } else {
          const dialogRef = this.dialog.open(ImageDialog, {
            data: result[0].image
          });

        }
      })
    //   }

  }
  private base64toBlob(base64Data: string, contentType: string): Blob {
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: contentType });
  }

  search(e) {
    this.router.navigateByUrl('/allpictures');
 


  }

  pageChange(event: PageChangeEvent): void
  {
    this.skip = event.skip;
    this.loadItems();
  }
  removeClass() {
    var myTag = this._document.querySelectorAll('.folder-btn');
    myTag.forEach((ele) => {
      ele.classList.remove('myClass');
    })
  }
  getFolderFiles(folder) {
    this.removeClass();
    this.mySelection = [];
    this.gridData = [];
    this.skip = 0;
    this.isImagesSelected();
    if (this.selectedDriver[0] != undefined && this.selectedDriver[0]?.driver_Id != '') {
      this.selectedFolder = folder;
      this._document.querySelector("#" + folder).classList.add('myClass');

      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Driver: this.selectedDriver[0].user_Id,
          Company: this.selectedDriver[0].company.company_Id,
          Folder: folder
        }
      };
      this.spinner.show();

      this.http.get<any>(this.configService.resourceApiURI + '/get_driver_ftp_files/', httpOptionsTwo)
        .subscribe(result => {
          this.gridData = result.map((elem) => {
            
            elem.fileCreatedDate = new Date(elem.fileCreatedDate);
            return elem

            } );
          this.loadItems();
    
            this.spinner.hide();
          
          
        })
    }
    else {
      const dialogRef = this.dialog.open(AlertDialog, {
        data: "Please select driver"

      });
    }
    
  }
  loadItems(): void
  {
    this.gridData = orderBy(this.gridData, this.sort);
    this.gridView = {
      data: this.gridData.slice(this.skip, this.skip + this.pageSize),
      total: this.gridData.length
    };
  }

  saveAFile() {

    var filepaths = [];
    this.mySelection.map((elem) => filepaths.push(elem.filePath));
    //console.log(filepaths);
    if (this.mySelection.length > 6) {
      const dialogRef = this.dialog.open(AlertDialog, {
        data: "You can download upto 6 images at a time!"
      });
    }
    else {
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),

      };
      //  this.spinner.show();

      this.http.post<any>(this.configService.resourceApiURI + '/get_driver_ftp_files_images/', {
        filepaths: filepaths
      }, httpOptionsTwo)
        .subscribe(result => {
          //console.log(result);
          result.map((elem) => {
            var a = document.createElement("a");
            a.href = "data:image/png;base64," + elem.image;
            a.download = elem.fileName;
            a.click();
          })
        })


    }
  }
  selectDriver()
  {
    this.mySelection = [];
    this.selectedFolder = '';
    this.gridData = [];
    this.loadItems();
    this.isImagesSelected();
    this.removeClass();

  }

  selectedKeysChange(rows: any[]) {
    this.isImagesSelected();

  }
  public onSelectedKey(context: RowArgs): any {
    return context.dataItem;
  }
  isImagesSelected() {
    if (!this.mySelection.length)
      this.selectImages = false;
    else
      this.selectImages = true;
  }

  form = new FormGroup({

    subject: new FormControl(""),
    message: new FormControl(""),
    request: new FormControl(""),
    email:   new FormControl({}),
    attachments: new FormControl({}),
    signature: new FormControl("")
  })


  sendMail() {

    var attachedfiles = [];
    if (this.mySelection.length > 6) {
      const dialogRef = this.dialog.open(AlertDialog, {
        data: "You can send upto 6 images at a time!"
      });
    }
    else
    {
      this.mySelection.map((ele) => {
        attachedfiles.push(ele.filePath);
      });
      this.form.patchValue({ attachments: attachedfiles });
      const dialogRef = this.dialog.open(EmailDialog, {
        data: this.form,
        disableClose: true

      });
      dialogRef.afterClosed().subscribe(result => {
      });
    }
    
  }
}
@Component({
  selector: 'image-dialog',
  templateUrl: 'image-dialog.html',
  styleUrls: ['./pictures.component.sass']
})

export class ImageDialog {

  constructor(
    public dialogRef: MatDialogRef<ImageDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;

  }

}

@Component({
  selector: 'email-dialog',
  templateUrl: 'email-dialog.html',
  styleUrls: ['./pictures.component.sass']
})

export class EmailDialog {
  public receivers:     string;
  public subject:       string;
  public message:       string;
  public resultFromApi: any;
  public httpOptions: any;
  public value: string = ``;
  constructor(
    public dialogRef: MatDialogRef<EmailDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, public dialog: MatDialog, private _snackBar: MatSnackBar, private configService: ConfigService) {
    dialogRef.disableClose = true;

  }
  url = '/sendMail';
  
  sendMail() {
    
    var emails = this.receivers?.trim().split(';');
    var isEmailValid = true;
    emails.map(ele => { if (!this.validateEmail(ele?.trim())) { isEmailValid = false; } });
    if (!isEmailValid) {
      const dialogRef = this.dialog.open(AlertDialog, {
        data: "Invalid Emails!"
      });
    }
    else {
      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.data.patchValue({ email: emails, message: this.message, subject: this.subject, signature: this.value });
      let headers = new HttpHeaders();
      headers = headers.set('Accept', 'application/json');
      if (this.data.valid) {
        this.http.post<any>(this.configService.resourceApiURI+this.url, JSON.stringify(this.data.value), this.httpOptions).subscribe(result => {
          this.resultFromApi = result;
        }, err => { console.log(err) }, () => {
          this._snackBar.open("Email Successfully Sent!!", "Close", {
            duration: 1000,
          });
        });
/*        this.data.reset();
*/        this.dialogRef.close();

      }
    }
 
  }
  public validateEmail(ele) {
    const regex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
    return regex.test(String(ele).toLowerCase());  }
}


@Component({
  selector: 'alert-dialog',
  templateUrl: 'alert-dialog.html',
  styleUrls: ['./pictures.component.sass']
})

export class AlertDialog {
  constructor(
    public dialogRef: MatDialogRef<AlertDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;

  }

}
