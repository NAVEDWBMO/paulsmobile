import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutsourceDriverSetupComponent } from './outsource-driver-setup.component';

describe('DriverSetupComponent', () => {
  let component: OutsourceDriverSetupComponent;
  let fixture: ComponentFixture<OutsourceDriverSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OutsourceDriverSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OutsourceDriverSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
