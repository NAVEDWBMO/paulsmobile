import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import {map, startWith} from 'rxjs/operators';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ConfigService } from '../shared/config.service';
import { AuthService } from '../core/authentication/auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DialogComplete } from '../dispatch-setup/dispatch-setup.component';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-outsource-driver-setup',
  templateUrl: './outsource-driver-setup.component.html',
  styleUrls: ['./outsource-driver-setup.component.css']
})
export class OutsourceDriverSetupComponent {

  driverCtrl = new FormControl();
  filteredDrivers: Observable<Driver[]>;

  drivers: Driver[];
  driverIdInput = new FormControl();


  fname = new FormControl();
  lname = new FormControl();
  email = new FormControl('', [Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]);
  password = new FormControl();

  lowerCharacters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  upperCharacters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  symbols = ['!', '?', '@', '+', '=', '-', '_'];

  httpOptions: { headers: any; };
  userInfoError: boolean = false;
  selectedDriver: any;
  selectedCompany = new FormControl();
  companies: any[] = [];
  userCompanyAccess: any[];
  userRole: string;
  selectedCompanyId: string = "";

  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {

    this.authService.userCompanyAccessSelectedStatus$
      .subscribe(access => {       
        this.selectedDriver = '';
        this.driverIdInput.setValue('');
      });
    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userCompanyAccessStatus$.subscribe(uCompany => this.userCompanyAccess = uCompany);

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

    this.http.get<any>(this.configService.resourceApiURI + '/get_drivers_info/', this.httpOptions).subscribe(result => {
      this.drivers = result;

    })

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.selectedCompanyId = access.company_Id;

      }

    });

    //this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions).subscribe(result => {
    //  if(this.userRole.toLowerCase() != '25942536-C57D-4E18-A82D-0CDCC77A74C5'.toLowerCase()){
    //    result.forEach(resultComp => {
    //      this.userCompanyAccess.forEach(accessComp => {
    //        if(resultComp.company_Type == "TRANSPORTATION" && resultComp.company_Id == accessComp.company_Id){
    //          this.companies.push(resultComp);
    //        }
    //      });
    //  })
    //  }else{
    //    result.forEach(resultComp => {
    //      this.userCompanyAccess.forEach(accessComp => {
    //        if(resultComp.company_Type == "TRANSPORTATION"){
    //          this.companies.push(resultComp);
    //        }
    //      });
    //  })
    //  }
      

    //})

    
   }

  ngOnInit(): void {
  
  }
  selectCompany($e){
    
  }


  getRandom(array){
    return array[Math.floor(Math.random() * array.length)];
  }

  generatePassword(){
    var finalCharacters = "";
    finalCharacters = finalCharacters.concat(this.getRandom(this.upperCharacters));
    finalCharacters = finalCharacters.concat(this.getRandom(this.numbers));
    finalCharacters = finalCharacters.concat(this.getRandom(this.symbols));

    for (var i = 1; i < 10 - 3; i++) {
      finalCharacters = finalCharacters.concat(this.getRandom(this.lowerCharacters));
    }

    let pass = finalCharacters.split('').sort(function () {
      return 0.5 - Math.random()
    }).join('');

    this.password.setValue(pass);

  }


  registerDriver(){

    //var idToSubmit = this.driverIdInput.value;
    
    
    this.http.post<any>(this.configService.resourceApiURI + '/register_driver/', 
    { "Driver_Email":  this.email.value,
     "Driver_Password":  this.password.value, 
     "Driver_FirstName": this.fname.value, 
     "Driver_LastName": this.lname.value, 
     "Driver_Id":  "O-"+this.driverIdInput.value,
      "Driver_Company": this.selectedCompanyId
    }, 
    this.httpOptions).subscribe(result => {
      
      this.email.setValue("");
      this.password.setValue("");
      this.fname.setValue("");
      this.lname.setValue("");
      this.selectedDriver = {};
      //this.selectedCompanyId.setValue("");
     // this.selectedCompany.setValue({company_Id: ""});
      this.driverIdInput.setValue('');
      const dialogRef = this.dialog.open(DialogComplete);

      dialogRef.afterClosed().subscribe(result => {

      });

      this.http.get<any>(this.configService.resourceApiURI + '/get_drivers_info/', this.httpOptions).subscribe(result => {
        this.drivers = result;
  
      })
    },
    error => {
      this._snackBar.open(error.error, "Close", {
        duration: 4000,
      });
  })
  }
  driverSelectedChange($e){
    var words = $e.value?.driver_Firstname.split(' ');
    this.fname.setValue(words[0]);
    this.lname.setValue(words[words.length-1]);
  }
  handleFName(){

    if(this.fname.value.length > 0){
      this.fname.setValue(this.fname.value[0].toUpperCase() + this.fname.value.substring(1))
    }
  }
  handleLName(){
    if(this.lname.value.length > 0){
      this.lname.setValue(this.lname.value[0].toUpperCase() + this.lname.value.substring(1))
    }
    
  }

  handleEmail(){
    if(this.email.value.length > 0){
      this.email.setValue(this.email.value.toLowerCase())
    }
  
  }
  clearForm(){
      this.email.setValue("");
      this.password.setValue("");
      this.fname.setValue("");
      this.lname.setValue("");
      this.selectedDriver = null;
     // this.selectedCompany.setValue({company_Id: ""});
      this.driverIdInput.setValue('');
  }

}
export interface Driver {
  driver_Id: string;
  driver_Name: string;
}

export interface RegisterDriverModel
{
    Driver_Email: string
    Driver_Password: string
    Driver_FirstName: string
    Driver_LastName: string
    Driver_Role: string
    Driver_Id: string
}
