import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, Pipe, PipeTransform } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent  } from '@progress/kendo-angular-grid';
import { orderBy, SortDescriptor } from '@progress/kendo-data-query';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { DeviceStatusDialog } from '../devices/devices.component';


@Component({
  selector: 'app-cell-companies',
  templateUrl: './cell-companies.component.html',
  styleUrls: ['./cell-companies.component.sass']
})
export class CellCompaniesComponent implements OnInit {
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;

  public gridData: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  access: any;
  selectedCompanyId: string = "";
  selectedCellCompanyId: string = "";
  CellCompanyImeis: any;

  public sort: SortDescriptor[] = [
    {
      field: "cell_Company_IsEnabled",
      dir: "desc",
    },
    {
      field: "company_Name",
      dir: "asc",
    }
  
  
  ];
  constructor(public http: HttpClient, private _router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {


    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {

      if(access?.company_Id){
        this.access = access;
        this.selectedCompanyId = access.company_Id.toUpperCase();
        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: access.company_Id
          }     
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_cell_companies_for_company/', httpOptionsTwo).subscribe(result => {
          this.gridData = result;
   
          this.loadItems();
        })
        this.http.get<any>(this.configService.resourceApiURI + '/get_imeis/', httpOptionsTwo).subscribe(result => {
          this.CellCompanyImeis = result;

        })

      }
      
    });

  }
 
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
}
  private loadItems(): void {
    this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
      total: this.gridData.length
    };
  }
 
  ngOnInit(): void {
    
  }

  openCreateCellCompanyDialog(){
    const dialogRef = this.dialog.open(AddCellCompanyDialog, {
      disableClose: true

    });
  
    dialogRef.afterClosed().subscribe(result => {
      this.refreshCellCompanies()
    });
  }
  openEditCompanyDialog(dataItem) {
    var imeiIds = [];
     this.CellCompanyImeis.filter(res => {
      if (res.cell_Company_Id == dataItem.cell_Company_Id.toUpperCase()) {
        if (imeiIds.indexOf(res.device_IMEI_Company_Id) < 0) { imeiIds.push(res.device_IMEI_Number); }
        return true;
      }
    });

    const dialogRef = this.dialog.open(EditCellCompanyDialog, {
      data: {
        dataItem: dataItem,
        imeiIds: imeiIds,
        disableClose: true

      }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshCellCompanies();
    });

  }


  openCellPlansDialog(dataItem) {
    var imies_cell_plan_Ids= [];
    this.CellCompanyImeis.filter(res => {
      if (res.cell_Company_Id == dataItem.cell_Company_Id.toUpperCase() && res.cell_Plan!="") {
        if (imies_cell_plan_Ids.indexOf(res.cell_Plan) < 0) { imies_cell_plan_Ids.push(res.cell_Plan); }
      }
    });
    const dialogRef = this.dialog.open(CellPlansDialog, {
      data: {
        dataItem: dataItem,
        imies_cell_plan_Ids: imies_cell_plan_Ids,
        disableClose: true

      }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshCellCompanies();
    });
  }
 
  refreshCellCompanies(){
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.access.company_Id
      }     
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_cell_companies_for_company/', httpOptionsTwo).subscribe(result => {
      this.gridData = result;
      this.loadItems();
    })
  }

}

// ADD-Cell_Companies dialog

@Component({
  selector: 'add-cell-company-dialog',
  templateUrl: 'add-cell-company-dialog.html',
  styleUrls: ['./cell-companies.component.sass']

})
export class AddCellCompanyDialog {

  cell_Company_Name: string = '';
  company_Name: string = '';
  company_Id: string = '';
  contact_Name: string;
  contact_Email: string;
  phone_Number: string;
  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<AddCellCompanyDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    
    var company_access_id = this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.company_Id = access.company_Id;
      this.company_Name = access.company_Name;
    })
  }
  onKey(event) {
    const input = event.target.value.replace(/\D/g, '').substring(0, 10);
    const areaCode = input.substring(0, 3);
    const middle = input.substring(3, 6);
    const last = input.substring(6, 10);

    if (input.length > 6) { event.target.value = `(${areaCode}) ${middle} - ${last}`; }
    else if (input.length > 3) { event.target.value = `(${areaCode}) ${middle}`; }
    else if (input.length > 0) { event.target.value = `(${areaCode}`; }
  }

  onNoClick(): void {
   
    if (this.cell_Company_Name != '') {
      this.phone_Number = this.phone_Number?.replace(/[^0-9]/g, '');

      this.http.post<any>(this.configService.resourceApiURI + '/create_cell_company/',
        {
          
          "Cell_Company_Name": this.cell_Company_Name ? this.cell_Company_Name :'',
          "Company_Id": this.company_Id,
          'contact_Name': this.contact_Name ? this.cell_Company_Name : '',
          'contact_email': this.contact_Email ? this.contact_Email : '',
          'cell_Company_Phone_Number': this.phone_Number ? this.phone_Number : '',
        },
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Cell Company created", "Close", {
            duration: 3000,
          });
        })
    }

    this.dialogRef.close();
  }

 
  close() {
    this.dialogRef.close();

  }

}



@Component({
  selector: 'edit-cell-company-dialog',
  templateUrl: 'edit-cell-company-dialog.html',
  styleUrls: ['./cell-companies.component.sass']

})

export class EditCellCompanyDialog {

  dataItem:any;
  prev_contact_Name: string;
  prev_contact_Email: string;
  prev_phone: string;
  Changed: boolean = false;
  httpOptions: { headers: any; };
  cell_Company_Phone_Number:string
  constructor(
    public dialogRef: MatDialogRef<EditCellCompanyDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.dataItem = data.dataItem;
    this.prev_contact_Name = this.dataItem.contact_Name.trim();
    this.prev_contact_Email = this.dataItem.contact_Email.trim();
    this.prev_phone = this.dataItem.cell_Company_Phone_Number;
    this.cell_Company_Phone_Number = this.dataItem.cell_Company_Phone_Number;

    if (this.dataItem.cell_Company_Phone_Number.length > 6) {
      const areaCode = this.dataItem.cell_Company_Phone_Number.substring(0, 3);
      const middle = this.dataItem.cell_Company_Phone_Number.substring(3, 6);
      const last = this.dataItem.cell_Company_Phone_Number.substring(6);
      this.cell_Company_Phone_Number = `(${areaCode}) ${middle} - ${last}`;
    }
   
  }
  check() {
    if (this.prev_contact_Name == this.dataItem.contact_Name.trim() &&
      this.prev_contact_Email.toLowerCase() == this.dataItem.contact_Email.trim().toLowerCase()) {
      this.Changed = false;
    }
    else {
      this.Changed = true;
    }
  }

  enable_disable_cell_company(status) {
    if (this.data.imeiIds.length > 0) {
      const dialogRef = this.dialog.open(DeviceStatusDialog, {
        data: { 'Id': '', 'message': 'Can\'t be deactivated, please go to imei\'s to deactivate Imei', 'title': 'This cell company currently has active imei:' }
      });

    }
    else {
      const dialogR = this.dialog.open(ConfirmActionDialog, {
        disableClose: true

      });
      dialogR.afterClosed().subscribe(result => {

        if (result == true) {
          this.dataItem.cell_Company_IsEnabled = status;


          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/enable_disable_cell_company/',
            {
              'cell_Company_Id': this.dataItem.cell_Company_Id,
              'cell_Company_IsEnabled': this.dataItem.cell_Company_IsEnabled

            },
            httpOptions).subscribe(result => {


            })
        }
      });
    }
   
 
  }

  onKey(event)
  {

    const phone_number = event.target.value.replace(/\D/g, '').substring(0, 10);
    if (this.prev_phone == phone_number) { this.Changed = false; }
    else {this.Changed = true;}
    const areaCode = phone_number.substring(0, 3);
    const middle = phone_number.substring(3, 6);
    const last = phone_number.substring(6, 10);

    if (phone_number.length > 6) { event.target.value = `(${areaCode}) ${middle} - ${last}`; }
    else if (phone_number.length > 3) { event.target.value = `(${areaCode}) ${middle}`; }
    else if (phone_number.length > 0) { event.target.value = `(${areaCode}`; }
  }
  onNoClick(): void {

      this.http.post<any>(this.configService.resourceApiURI + '/update_cell_company/',
        {
          'contact_Name': this.dataItem.contact_Name ? this.dataItem.contact_Name : '',
          'contact_email': this.dataItem.contact_Email ? this.dataItem.contact_Email : '',
          'cell_Company_Phone_Number': this.cell_Company_Phone_Number ? this.cell_Company_Phone_Number.replace(/[^0-9]/g, '') : '',
          'cell_Company_Id': this.dataItem.cell_Company_Id
        },
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Cell company updated", "Close", {
            duration: 3000,
          });
        })
    
    this.dialogRef.close();
  }
  
  close() {
    this.dialogRef.close();

  }

}


// Cell_Plans dialog


@Component({
  selector: 'cell-plans-dialog',
  templateUrl: 'cell-plans-dialog.html',
  styleUrls: ['./cell-companies.component.sass']

})
export class CellPlansDialog {

  public gridView: GridDataResult;
  public pageSize = 5;
  public skip = 0;

  public gridData: any[] = [];

  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  access: any;
  selectedCompanyId: string = "";
 
  public selectedCellCompanyId: string = "";
  public cell_company_data: any[] = [];
  CompanyId: string = "";
  cell_Company_Name: string = "";
  public sort: SortDescriptor[] = [
    {
      field: "cell_Plan_IsEnabled",
      dir: "desc",
    },
  ];

  constructor(
    public dialogRef: MatDialogRef<CellPlansDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.selectedCellCompanyId = data.dataItem.cell_Company_Id;
    this.cell_Company_Name = data.dataItem.cell_Company_Name;
    this.cell_company_data = data.dataItem;
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {

      if (access?.company_Id) {
        this.access = access;
        this.selectedCompanyId = access.company_Id.toUpperCase();
      }
      });

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Cell_Company_Id: this.selectedCellCompanyId
      }
    };
    if (this.selectedCellCompanyId != '' && this.selectedCellCompanyId != 'null') {
      this.http.get<any>(this.configService.resourceApiURI + '/get_cell_plans_for_cell_company/', httpOptionsTwo).subscribe(result => {
        this.gridData = result;
        this.loadItems();
      })
    }
  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  private loadItems(): void {
    this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
      total: this.gridData.length
    };
  }


  openCreateCellPlanDialog() {
    const dialogRef = this.dialog.open(AddCellPlansDialog, {
      data: {
        'cell_Company_Name': this.cell_Company_Name,
        'cell_Company_Id': this.selectedCellCompanyId,
    
      }

    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshCellPlans()
    });
  }
  openEditPlanDialog(dataItem) {
    const dialogRef = this.dialog.open(EditCellPlanDialog, {
      data: { dataItem: dataItem, imies_cell_plan_Ids: this.data.imies_cell_plan_Ids },
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshCellPlans();
    });

  }
  close() {
    this.dialogRef.close();

  }
  refreshCellPlans() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Cell_Company_Id: this.selectedCellCompanyId
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_cell_plans_for_cell_company/', httpOptionsTwo).subscribe(result => {
      this.gridData = result;
      this.loadItems();
    })
  }
}

// ADD-Cell_Plans dialog

@Component({
  selector: 'add-cell-plans-dialog',
  templateUrl: 'add-cell-plans-dialog.html',
  styleUrls: ['./cell-companies.component.sass']

})
export class AddCellPlansDialog {

  cell_Company_Name: string = '';
  company_Name: string = '';
  cell_Company_Id: string = '';
  httpOptions: { headers: any; };
  Plan_Price: number = 0;
  Plan_Name: string = '';
  Plan_Data: string = '';
  selectedPlan: any;

  constructor(
    public dialogRef: MatDialogRef<AddCellPlansDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.cell_Company_Name = data.cell_Company_Name;
    this.cell_Company_Id = data.cell_Company_Id;
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

  
  }

  onNoClick(): void {

    if (this.cell_Company_Name != '') {
      this.http.post<any>(this.configService.resourceApiURI + '/create_cell_plan/',
        {

          "Cell_Plan_Name": this.Plan_Name,
          "Cell_Plan_Company_Id": this.cell_Company_Id.toUpperCase(),
          "Cell_Plan_Data": this.Plan_Data,
          "Cell_Plan_Has_Voice": this.selectedPlan,
          "Cell_Plan_Price": '$'+(this.Plan_Price).toString()
        },
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Cell Plan created", "Close", {
            duration: 3000,
          });
        })
    }

    this.dialogRef.close();
  }


  close() {
    this.dialogRef.close();

  }

}


@Component({
  selector: 'edit-cell-plan-dialog',
  templateUrl: 'edit-cell-plan-dialog.html',
  styleUrls: ['./cell-companies.component.sass']

})

export class EditCellPlanDialog {

  dataItem: any;
  prev_cell_Plan_Name: string;
  prev_cell_Plan_Data: string;
  prev_cell_Plan_Price: any;
  prev_cell_Plan_Has_Voice: string;
  Changed: boolean = false;
  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<EditCellPlanDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;


    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.dataItem = data.dataItem;
    this.prev_cell_Plan_Name = this.dataItem.cell_Plan_Name.trim();
    this.prev_cell_Plan_Data = this.dataItem.cell_Plan_Data.trim();
    this.prev_cell_Plan_Price = parseInt(this.dataItem.cell_Plan_Price.substring(1));
    this.prev_cell_Plan_Has_Voice = this.dataItem.cell_Plan_Has_Voice;
    this.dataItem.cell_Plan_Price = parseInt(this.dataItem.cell_Plan_Price.substring(1));

    if (this.dataItem.cell_Plan_Has_Voice == true) {
      this.dataItem.cell_Plan_Has_Voice = 1;
    }
    else {
      this.dataItem.cell_Plan_Has_Voice = 0;

    }
  }
  check() {
 

    if (this.prev_cell_Plan_Name.toLowerCase() == this.dataItem.cell_Plan_Name.trim().toLowerCase() &&
      this.prev_cell_Plan_Data.toLowerCase() == this.dataItem.cell_Plan_Data.trim().toLowerCase() &&
      this.prev_cell_Plan_Price == this.dataItem.cell_Plan_Price &&
      this.prev_cell_Plan_Has_Voice == this.dataItem.cell_Plan_Has_Voice) {
      this.Changed = false;
    }
    else if (!this.dataItem.cell_Plan_Name.trim() || !this.dataItem.cell_Plan_Data.trim() || !this.dataItem.cell_Plan_Price) {
      this.Changed = false;
    }
    else {
      this.Changed = true;
    }
  }
  enable_disable_cell_plan(status) {
    if (this.data.imies_cell_plan_Ids.indexOf(this.dataItem.cell_Plan_Id) > -1) {
      const dialogRef = this.dialog.open(DeviceStatusDialog, {
        data: { 'Id': '', 'message': 'Can\'t be deactivated, please go to imei\'s to deactivate Imei', 'title': 'This cell plan currently has active imei:' }
  
      });

    } else {
      const dialogR = this.dialog.open(ConfirmActionDialog, {
        disableClose: true

      });
      dialogR.afterClosed().subscribe(result => {

        if (result == true) {
          this.dataItem.cell_Plan_IsEnabled = status;

          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/enable_disable_cell_plan/',
            {
              'cell_Plan_Id': this.dataItem.cell_Plan_Id,
              'cell_Plan_IsEnabled': this.dataItem.cell_Plan_IsEnabled

            },
            httpOptions).subscribe(result => {


            })
        }
      });

    }
   
  }


  onNoClick(): void {
    this.http.post<any>(this.configService.resourceApiURI + '/update_cell_plan/',
      {
        'cell_Plan_Id': this.dataItem.cell_Plan_Id,
        "Cell_Plan_Name": this.dataItem.cell_Plan_Name,
        "Cell_Plan_Data": this.dataItem.cell_Plan_Data,
        "Cell_Plan_Has_Voice": this.dataItem.cell_Plan_Has_Voice,
        "Cell_Plan_Price": '$' + (this.dataItem.cell_Plan_Price).toString()
      },
      this.httpOptions).subscribe(result => {
        this._snackBar.open("Cell plan updated", "Close", {
          duration: 3000,
        });
      })

    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();

  }

}
@Pipe({
  name: "phone"
})
export class PhonePipe implements PipeTransform{
  transform(phone_number: string) {

    var phone = phone_number?.replace(/\D/g, '').substring(0, 10);

    const areaCode = phone.slice(0, 3);
    const middle = phone.slice(3, 6);
    const last = phone.slice(6, 10);

    if (phone.length > 6) { phone = `(${areaCode}) ${middle} - ${last}`; }
    else if (phone.length > 3) { phone = `(${areaCode}) ${middle}`; }
    else if (phone.length > 0) { phone = `(${areaCode}`; }
    return phone;
  }
}
