import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Component, ElementRef, Inject, OnInit, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';


@Component({
  selector: 'app-chat-settings',
  templateUrl: './chat-settings.component.html',
  styleUrls: ['./chat-settings.component.sass']
})
export class ChatSettingsComponent implements OnInit {

  nameValue: string = '';
  companyID = "";
  companyName = "";
  chats: any[] = [];
  public gridView: GridDataResult;
  public skip = 0;
  public pageSize = 10;  

  rolesLst: any[] = [];

  selRoles: any[] = [];

  selectedChat: any = [];

  chatRolesSelected: any[] = [];
  public gridData: any[] = [];

  chatCreation: boolean = false;
  selectedCompany = new FormControl();
  companies: any[] = [];
  newChatName = new FormControl();

  httpOptions: any
  chatsLst: any;



  constructor(
    public http: HttpClient, private authService: AuthService, private configService: ConfigService, public dialog: MatDialog, private _snackBar: MatSnackBar
    ) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
/*
    this.http.get<any>(this.configService.resourceApiURI + '/get_roles/', httpOptions).subscribe(result => {
      let notDisplayed = [];
      notDisplayed.push("Driver");
      notDisplayed.push("Admin");
      this.rolesLst = result.filter((elem) => {
        return !notDisplayed.includes(elem.role_Name)
      });
    })*/

    this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', httpOptions).subscribe(result => {
      this.companies = result;
    });          
  }  
  ngOnInit() {
    
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.companyID = access?.company_Id;
        this.companyName = access?.company_Name;
        this.selectedCompany.setValue(access);
        let httpOptions2 = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            company_Id: this.companyID
          }
        };

        this.http.get<any>(this.configService.resourceApiURI + '/get_chats_for_chat_control/', httpOptions2).subscribe(result => {

          let chatsLst = [];
          let chatLstsortbyChatName = [];
          result.forEach(element => {
            if (element.chat_Type != 'STATUS' && element.chat_Type != 'DRIVER') {
              chatsLst.push(element);
              //this.gridData.push(element);
            }
          });

          chatLstsortbyChatName = chatsLst.sort((a, b) => {
            if (a.chat_Name > b.chat_Name) {
              return -1
            } else {
              return 1
            }
          });

          this.gridData = chatLstsortbyChatName.sort((a, b) => {
            if (a.chat_Status == true) {
              return -1
            } else {
              return 1
            }
          });

          this.loadItems();
        })

      }
    });
  };

  openEditDialog(dataItem): void {
    const dialogRef = this.dialog.open(EditChatDialog, {
      data: dataItem,
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshchatNames();
    });
  }


  openCreateChat() {
    const dialogRef = this.dialog.open(AddChatDialog, {
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshchatNames();
    });
  }


  refreshchatNames() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.companyID
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_chats_for_chat_control/', httpOptionsTwo).subscribe(result => {
      let chatsLst = [];
      let chatLstsortbyChatName = [];
      result.forEach(element => {
        if (element.chat_Type != 'STATUS' && element.chat_Type != 'DRIVER') {
          chatsLst.push(element);
          //this.gridData.push(element);
        }
      });

      chatLstsortbyChatName = chatsLst.sort((a, b) => {
        if (a.chat_Name > b.chat_Name) {
          return -1
        } else {
          return 1
        }
      });

      this.gridData = chatLstsortbyChatName.sort((a, b) => {
        if (a.chat_Status == true) {
          return -1
        } else {
          return 1
        }
      });

      this.loadItems();
    })
  }

  private loadItems(): void {
    this.gridView = {
      data: this.gridData.slice(this.skip, this.skip + this.pageSize),
      total: this.gridData.length
    };
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  
}


@Component({
  selector: 'confirm-action-dialog',
  templateUrl: 'confirm-action-dialog.html',
  styleUrls: ['./chat-settings.component.sass']
})

export class ConfirmActionDialog {
  constructor(
    public dialogRef: MatDialogRef<ConfirmActionDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
  }

}

@Component({
  selector: 'add-chat-dialog',
  templateUrl: 'add-chat-dialog.html',
  styleUrls: ['./chat-settings.component.sass']

})
export class AddChatDialog {
  public skip = 0;
  public pageSize = 10;
  companyID = "";
  companyName = "";
  rolesLst: any[] = [];
  httpOptions: { headers: any; };
  selRoles: any[] = [];
  companies: any[] = [];
  selectedCompany = new FormControl();
  newChatName = new FormControl();
  public gridView: GridDataResult;
  public gridData: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<AddChatDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.companyID = access?.company_Id;
        this.companyName = access?.company_Name;
        this.selectedCompany.setValue(access);
      }
        
    });

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.companyID
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_roles_based_on_user/', httpOptionsTwo).subscribe(result => {
      this.rolesLst = result;
     
    });
    

  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }

  private loadItems(): void {
    this.gridView = {
      data: this.gridData.slice(this.skip, this.skip + this.pageSize),
      total: this.gridData.length
    };
  }

  createChat() {
    var chatRoles = new Array;
    this.selRoles.forEach(elem => {
      chatRoles.push(elem.role_Id);
    })
    chatRoles.push(('25942536-C57D-4E18-A82D-0CDCC77A74C5').toLowerCase());

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/create_custom_chat/',
      {
        "Chat_Name": this.newChatName.value,
        "Chat_Company": this.companyID,
        "Chat_Roles": chatRoles
      },
      httpOptions).subscribe(result => {
        this.newChatName.setValue("");
        this.selRoles = [];

      },
        (error) => {
          this._snackBar.open(error.error.text, "Close", {
            duration: 4000,
          });
        })
    
    this.dialogRef.close();



  }

  
  close() {
    this.dialogRef.close();

  }

}


@Component({
  selector: 'edit-chat-dialog',
  templateUrl: 'edit-chat-dialog.html',
  styleUrls: ['./chat-settings.component.sass']

})
export class EditChatDialog {
  public skip = 0;
  public pageSize = 10;
  companyID = "";
  companyName = "";
  rolesLst: any[] = [];
  httpOptions: { headers: any; };
  selRoles: any[] = [];
  companies: any[] = [];
  selectedCompany = new FormControl();
  newChatName = new FormControl();
  public gridView: GridDataResult;
  public gridData: any[] = [];
  chatRolesSelected: any[] = [];
  selectedChat: any = [];
  userDefaultCompanyId: string = "";
  prev_roles = [];
  Changed: boolean = false;
  constructor(
    public dialogRef: MatDialogRef<EditChatDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.companyID = access?.company_Id;
        this.companyName = access?.company_Name;
        this.selectedCompany.setValue(access);
      }

    });

    
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.companyID
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_roles_based_on_user/', httpOptionsTwo).subscribe(result => {
      this.rolesLst = result;
      let selectedRoles = [];
      this.data.roles.forEach(chR => {
        this.rolesLst.forEach(rol => {
          if (chR.toLowerCase() == rol.role_Id.toLowerCase()) {
            selectedRoles.push(rol);
            this.prev_roles.push(rol.role_Id);
          }
        });
      });
      this.chatRolesSelected = selectedRoles;
    });
 
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }

  private loadItems(): void {
    this.gridView = {
      data: this.gridData.slice(this.skip, this.skip + this.pageSize),
      total: this.gridData.length
    };
  }

  editChatRoles(): void {
    let rolesSelected = [];
    this.chatRolesSelected.forEach(elem => {
      rolesSelected.push(elem.role_Id);
    })
    rolesSelected.push(('25942536-C57D-4E18-A82D-0CDCC77A74C5').toLowerCase());

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/edit_chat_roles/',
      {
        "Chat_Id": this.data.chat_Id,
        "Roles": rolesSelected
      },
      httpOptions).subscribe(result => {
        this._snackBar.open("Roles Updated", "Close", {
          duration: 3000,
        });

      })
    this.dialogRef.close();
  }

  disableChatClick() {
    const dialogRef = this.dialog.open(ConfirmActionDialog, {

    });
    dialogRef.afterClosed().subscribe(result => {

      if (result == true) {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.post<any>(this.configService.resourceApiURI + '/disable_chat/',
          {
            "Chat_Id": this.data.chat_Id,
            "Chat_Type": this.data.chat_Type,

          },
          httpOptions).subscribe(result => {
            this.data.chat_Status = false;

          })
        this.gridData = this.gridData.sort((a, b) => {
          if (a.chat_Status == true) {
            return -1
          } else {
            return 1
          }
        });
      }
    });
  }
  check() {
    var roleLst = [];
    this.chatRolesSelected.forEach(rol => {
      roleLst.push(rol.role_Id);
    })
    if (this.prev_roles.length == roleLst.length && JSON.stringify(this.prev_roles.sort()) === JSON.stringify(roleLst.sort())) {
      this.Changed = false;     }
    else
    { this.Changed = true; }
   
  }
  changerole() {
    this.check();
  }

  enableChatClick() {
    const dialogRef = this.dialog.open(ConfirmActionDialog, {

    });
    dialogRef.afterClosed().subscribe(result => {

      if (result == true) {
        const httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.post<any>(this.configService.resourceApiURI + '/enable_chat/',
          {
            "Chat_Id": this.data.chat_Id,
            "Chat_Type": this.data.chat_Type,

          },
          httpOptions).subscribe(result => {
            this.data.chat_Status = true;


          })

      }
    });
  }

    // this.chatCreation = false;
    /* let httpOptionsTwo = {
       headers: new HttpHeaders({
         'Content-Type': 'application/json',
         'Authorization': this.authService.authorizationHeaderValue
       }),
       params: {
         company_Id: this.selectedCompany.value.company_Id
       }
     };
     this.http.get<any>(this.configService.resourceApiURI + '/get_chats_for_chat_control/', httpOptionsTwo).subscribe(result => {
       let chatsLst = [];
       result.forEach(element => {
         if (element.chat_Type != 'STATUS' && element.chat_Type != 'DRIVER') {
           chatsLst.push(element);
         }
       });
       setTimeout(() => {
         //this.chats = chatsLst;
         //this.createordisablechat = "Create a Chat";
       }, 300)
     })*/

  


  close() {
    this.dialogRef.close();

  }

}
