import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, ElementRef, Input, Inject, OnInit, ViewChild } from '@angular/core';
import { MessageModel } from '../chat-level1/chat-level1.component';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { SignalRService } from '../core/chat/signalr';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-chat-container',
  templateUrl: './chat-container.component.html',
  styleUrls: ['./chat-container.component.sass']
})
export class ChatContainerComponent implements OnInit {

  @ViewChild('messageContainer') container: ElementRef<HTMLElement>;
  msgContainer: HTMLElement;
  @Input() openedChat: any;

  loadingChat: any;
  inHistory: boolean;
  endOfHistory: any;
  loadingMessages: boolean;
  userId: string;
  isInEnd: any = true;
  newMessageIncoming: boolean;
  chats: any = [];

  constructor(public http: HttpClient, private signalRService: SignalRService, private authService: AuthService, private configService: ConfigService, public dialog: MatDialog) {
    this.authService.userIdStatus$.subscribe(uId => this.userId = uId);

   }

  ngOnInit(): void {
    this.isInEnd = false;
    this.scrollChat()
  }

  

  ngAfterViewChecked(): void{
    //this.scrollChat()
    if(this.newMessageIncoming){
      this.scrollChat()
    }

    this.signalRService.onHideMessage(
      (message: any) => {
        this.chats.find(chat => chat.chat_Id == message.chat_Id).messages.find(mes => mes.message_Id == message.message_Id).message_Is_Visible = message.message_Is_Visible;
      }
    );
  }

  scrollChat(){
    try{
      if(this.openedChat.messages?.length > 0){
        requestAnimationFrame(() => {
          
          this.container?.nativeElement.scrollBy({
            top: 99999999
          });
          
        });
      }

    }catch{

    }
    
  }

/*  openDialog(event, message): void {

    const dialogRef = this.dialog.open(ChatContainerDialog, {
      data: { latitude: message.message_Latitude, longitude: message.message_Longitude }
    });

    dialogRef.afterClosed().subscribe(result => {
    });

  }

  openImagesDialog(): void {
    const dialogRef = this.dialog.open(ImagesContainerDialog, {
      data: { test: 1 }
    });
  }
*/


  

  trackChatMessage(index: number, chatMessage: MessageModel) {
    return chatMessage.message_Text;
  }
  newMessage() {
    //console.log('inside new message');
    this.newMessageIncoming = true;
    setTimeout (() => {
      this.newMessageIncoming = false;
   }, 1000);
  }

  loadingNewChat(){
    this.inHistory = false;
    this.endOfHistory = false;
    this.loadingChat = true;
    setTimeout (() => {
      this.loadingChat = false;
   }, 500);
    this.scrollChat();
  }

  //Hide message
  hideMessage(mes) {
    //console.log(mes);
    mes.message_Is_Visible = !mes.message_Is_Visible;
   // console.log('checking visibility');
    this.signalRService.sendToServer("HideMessage", mes);

  }



   onScroll(event){

     if(!this.loadingChat){
       if(this.container?.nativeElement.scrollHeight > this.container?.nativeElement.scrollTop + 800){
         this.inHistory = true;
       }else{
         this.inHistory = false;
       }
       if(!this.endOfHistory && this.openedChat.chat_Type != "STATUS"){
         if(this.container?.nativeElement.scrollTop < 30){
          
           if(!this.loadingMessages){
  
             this.loadingMessages = true;
            
             let httpOptions = {
               headers: new HttpHeaders({
                 'Content-Type':  'application/json',
                 'Authorization': this.authService.authorizationHeaderValue
               }),
               params: {
                 Chat_Table: this.openedChat.chat_Table,
                 Last_Message_Id: this.openedChat.messages[0]?.message_Id
               }       
             };
  
             this.http.get<any>(this.configService.resourceApiURI + '/get_messages_from_history/', httpOptions).subscribe(result => {
              
               this.container.nativeElement.scrollTo({
                 top: 2
               })
               result.forEach(element => {
                 this.openedChat.messages = [element, ...this.openedChat.messages];
               });
              
    
               if(result.length < 10){
                 this.endOfHistory = true;
               }
  
                 setTimeout (() => {
                   this.loadingMessages = false;
                }, 500);
  
             })
           }
         }
       }
      
     }
  
   }

}

/*@Component({
  selector: 'map-dialog',
  templateUrl: 'map-dialog.html',
})
export class ChatContainerDialog {

  zoom = 15;
  center = {
    lat: 43.643455,
    lng: -79.628178,
  }
  constructor(
    public dialogRef: MatDialogRef<ChatContainerDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.center = {
      lat: parseFloat(data.latitude),
      lng: parseFloat(data.longitude)
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}



  @Component({
    selector: 'images-dialog',
    templateUrl: 'images-dialog.html',
  })
  export class ImagesContainerDialog {

  imgs: any = []

  constructor(
    public dialogRef: MatDialogRef < ChatContainerDialog >,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    let todayDate = Date.now();
    let startDate = Date.parse('12-01-2020');
    for (let i = 0; i < 30; i++) {
      this.imgs.push({ date: this.randomDate(startDate, todayDate) })
    }

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  randomDate(start, end) {
    var date = new Date(+start + Math.random() * (end - start));
    return date;
  }

}
*/
