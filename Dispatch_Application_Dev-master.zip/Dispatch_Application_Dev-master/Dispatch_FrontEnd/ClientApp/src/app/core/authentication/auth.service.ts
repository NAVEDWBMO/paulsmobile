import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { UserManager, UserManagerSettings, User } from 'oidc-client';
import { BehaviorSubject } from 'rxjs'; 
import { BaseService } from "../../shared/base.service";
import { ConfigService } from '../../shared/config.service';
import { access } from 'fs';

@Injectable({
  providedIn: 'root'
})
export class AuthService extends BaseService  {

  // Observable navItem source
  private _authNavStatusSource = new BehaviorSubject<boolean>(false);
  // Observable navItem stream
  authNavStatus$ = this._authNavStatusSource.asObservable();


// Observable navItem source
private _userRole = new BehaviorSubject<string>("");
// Observable navItem stream
userRoleStatus$ = this._userRole.asObservable();

// Observable navItem source
private _userCompany = new BehaviorSubject<string>("");
// Observable navItem stream
userCompanyStatus$ = this._userCompany.asObservable();


_userName = new BehaviorSubject<string>("");
// Observable navItem stream
userNameStatus$ = this._userName.asObservable();

private _userId = new BehaviorSubject<string>("");
// Observable navItem stream
userIdStatus$ = this._userId.asObservable();

public _userCompanyAccess = new BehaviorSubject<any[]>([{}]);
// Observable navItem stream
userCompanyAccessStatus$ = this._userCompanyAccess.asObservable();

public _userCompanyAccessSelected = new BehaviorSubject<any>({});
// Observable navItem stream
userCompanyAccessSelectedStatus$ = this._userCompanyAccessSelected.asObservable();

//public _userCompanyId = new BehaviorSubject<any>({});
//userCompanyId$ = this._userCompanyId.asObservable();

  private _userPermissions = new BehaviorSubject<any[]>([{}]);
  // Observable navItem stream
  _userPermissionsStatus$ = this._userPermissions.asObservable();


  private _userCompanyId = new BehaviorSubject<string>("");

  userCompanyId$ = this._userCompanyId.asObservable();
  public _userInfo = new BehaviorSubject<any>({});
  // Observable navItem stream
  userInfoStatus$ = this._userInfo.asObservable();

  private manager;
  private user: User | null;

  constructor(private http: HttpClient, public configService: ConfigService) {
    super();

    this.manager = new UserManager({
      authority: configService.readConfig().Auth,
      client_id: 'angular_spa',
      redirect_uri: configService.readConfig().Frontend + '/auth-callback',
      post_logout_redirect_uri: configService.readConfig().Frontend,
      response_type: "code",
      scope: "dispatchapp",
      filterProtocolClaims: true,
      loadUserInfo: true
    });
     this.manager.getUser().then(user => { 
      this.user = user;      
      this._authNavStatusSource.next(this.isAuthenticated());
   });
  }

  login() { 
    return this.manager.signinRedirect();   
  }

  async completeAuthentication() {
      this.user = await this.manager.signinRedirectCallback();
      this._authNavStatusSource.next(this.isAuthenticated()); 
      
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': `${this.user.token_type} ${this.user.access_token}`
        })
    };
    //  get permission list here put them in global array appl
  await   this.http.get<any>(this.configService.resourceApiURI + '/get_current_user_info/', httpOptions).subscribe(result => {
        if (result.isEnabled == 'False'){
            this.signout();
        }else{
          this._userName.next(result.user_First_Name + ' ' + result.user_Last_Name);
          this._userRole.next(result.user_Role);
          this._userId.next(result.user_Id);
          this._userCompany.next(result.user_Company);
          this._userCompanyId.next(result.user_Company);
          this._userInfo.next(result);
          this.http.get<any>(this.configService.resourceApiURI + '/get_current_user_access/?userid=' + result.user_Id, httpOptions).subscribe(res => {
            this._userCompanyAccess.next(res);
          })

       }
     })
 

    //this.http.get<any>(this.configService.resourceApiURI + '/get_userdefaultcompany/', httpOptions).subscribe(result => {
    //  this._userCompanyId.next(result);
    //})
 

  }  
  get_Role_Permissions(user_id, company_id) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `${this.user.token_type} ${this.user.access_token}`
      }),
      params: {
        User_Id: user_id,
        Company_Id: company_id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_current_user_company_role_permisions/', httpOptions).subscribe(result => {
      this._userPermissions.next(result);
      this.updateUserCurrentCompany(user_id, company_id)
      })
    //_userPerissions

  }
  updateUserCurrentCompany(user_id, company_id) {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `${this.user.token_type} ${this.user.access_token}`
      })
    };
    var permission_Id: string;
    var user_Identity_Id: string;
    this._userPermissionsStatus$.subscribe(permissions => {
      var chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });
    this.userInfoStatus$.subscribe(user => { user_Identity_Id = user.user_Identity_Id });
    this.http.post<any>(this.configService.resourceApiURI + '/update_user_current_company/',
      {
        "User_Id": user_id,
        "User_Identity_Id": user_Identity_Id,
        "Permission_Id": permission_Id,
        "Company_Id": company_id
      },
      httpOptions).subscribe(result => {

      })
  }

  /*getcompanies() {
       const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': `${this.user.token_type} ${this.user.access_token}`
        })
      };
      this.http.get<any>(this.configService.resourceApiURI + '/get_user_info/', httpOptions).subscribe(result => {
        if(result.isEnabled == 'False'){
            this.signout();
        }else{
          this._userName.next(result.username);
          this._userRole.next(result.role);
          this._userId.next(result.id);
          this._userCompany.next(result.user_Company);
        }
      })
      this.http.get<any>(this.configService.resourceApiURI + '/get_userdefaultcompany/', httpOptions).subscribe(result => {
        this._userCompanyId.next(result);
      })

      this.http.get<any>(this.configService.resourceApiURI + '/get_user_access/', httpOptions).subscribe(result => {
        this._userCompanyAccess.next(result);
      })

  }*/

  isAuthenticated(): boolean {
    return this.user != null && !this.user.expired;
  }


  get authorizationHeaderValue(): string {
    return `${this.user.token_type} ${this.user.access_token}`;
  }

  get name(): string {
    return this.user != null ? this.user.profile.name : '';
  }
  

  async signout() {
    await this.manager.signoutRedirect();
  }
}
