import { Injectable, EventEmitter } from "@angular/core";
import * as signalR from "@microsoft/signalr";
import { IHttpConnectionOptions } from '@microsoft/signalr';
import { BehaviorSubject } from 'rxjs';
import { ConfigService } from 'src/app/shared/config.service';
import { AuthService } from '../authentication/auth.service';

@Injectable({
  providedIn: "root"
})
export class SignalRService {

  connection: signalR.HubConnection;

  private _connection = new BehaviorSubject<string>("");
  // Observable navItem stream
  connectionStatus$ = this._connection.asObservable();


  constructor(configService: ConfigService, private authService: AuthService) {
    const options: IHttpConnectionOptions = {
      accessTokenFactory: () => {
        return this.authService.authorizationHeaderValue.substr(7)
      }
    };


    this.connection = new signalR.HubConnectionBuilder()
       .configureLogging(signalR.LogLevel.None)
       .withUrl( configService.resourceUrl + "/MainChatHub", options)
       //.withAutomaticReconnect()
      .build();
    this.connection.serverTimeoutInMilliseconds = 120000;
    this.connection.keepAliveIntervalInMilliseconds = 60000;
   // console.log(this.connection);
    if (this.connection.state === signalR.HubConnectionState.Disconnected) {
        this.connection.start().catch(err => console.log(err));
      }

      

  }


  public onClosedConnection(next){
    this.connection.onclose(() => {
      next("disconnected");
    })
  }

  public change_signalr_connection(command, data) {
    this.connection.invoke(command, data);

  }

  public timeoutUser(){
    this.connection.stop();
  }
  

  public getMessage(next) {
         this.connection.on('SendToDispatch', (message) => {

           next(message);
         });
     }

  public RefreshDispacthers(next) {
    this.connection.on('RefreshOnlineDispacthers', (message) => {

      next(message);
    });
  }
  public offChatMessages() {
    this.connection.off('SendToDispatch');
    this.connection.off('StartedTyping');
    this.connection.off('StoppedTyping');
    this.connection.off('DriverTyping');
    this.connection.off('SetChatLevel');
    this.connection.off('AssignChatToDispatch');
    this.connection.off('ReleaseAssignedChat');
    this.connection.off('HideMessage');
    this.connection.off('BroadcastMessage');
    this.connection.off('UpdatedUserStatus');
    this.connection.off('UpdateChats');
    this.connection.off('CurrentUsersOnlineList');
    this.connection.off('SendBroadcastMessageToRooms');
    this.connection.off('SendBroadcastMessageToDrivers');
    this.connection.off('CurrentUsersOnlineList');

    
  }
    
    public onStartedTyping(next) {
           this.connection.on('StartedTyping', (typing) => {
             next(typing);
           });
       }
    public onStoppedTyping(next) {
         this.connection.on('StoppedTyping', (typing) => {
            next(typing);
         });
    }
    public onDriverTyping(next) {
      /* this.connection.on('DriverTyping', (typing) => {
          next(typing);
       });*/
  }

    public onSetChatLevel(next){
      this.connection.on('SetChatLevel', (chat_Id, level, user_Name, last_Time) => {
        next(chat_Id, level, user_Name, last_Time);
         });
    }

    public onAssignChatToDispatch(next){
      this.connection.on('AssignChatToDispatch', (am) => {
            next(am);
         });
    }
    public onReleaseAssignedChat(next){
      this.connection.on('ReleaseAssignedChat', (chat_Id) => {
            next(chat_Id);
         });
    }
    public onHideMessage(next){
      this.connection.on('HideMessage', (am) => {
            next(am);
         });
    }
    public onBroadcastMessage(next){
      this.connection.on('BroadcastMessage', (md) => {
            next(md);
         });
  }
  public onBroadcastRoomsMessageRecevied(next) {
    this.connection.on('SendBroadcastMessageToRooms', (md) => {
      next(md);
    });
  }
  public onBroadcastDriversMessageRecevied(next) {
    this.connection.on('SendBroadcastMessageToDrivers', (md) => {
      next(md);
    });
  }
    public onUserStatusUpdate(next){
      this.connection.on('UpdatedUserStatus', (md) => {
            next(md);
         });
    }
    public onUpdateChats(next) {
       this.connection.on('UpdateChats', (md) => {
         next(md)
       });
  }

  public onCurrentUsersOnlineList(next) {
     this.connection.on('CurrentUsersOnlineList', (list) => {
      next(list)
     });
}
  public getUserList(command, data) {
    this.connection.invoke(command, data);

  }

     public sendToServer(command, data) {
      this.connection.invoke(command, data);

    }

    public handleLostConnection(next){
      
        

    }


  public disconnect() {
    this.connection.stop();
  }


}
