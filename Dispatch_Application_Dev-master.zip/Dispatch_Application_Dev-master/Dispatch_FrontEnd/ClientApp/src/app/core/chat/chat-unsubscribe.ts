import { Injectable, EventEmitter } from "@angular/core";
import { IHttpConnectionOptions } from '@microsoft/signalr';
import { BehaviorSubject, EMPTY, Subject, Subscription } from 'rxjs';
import { ConfigService } from 'src/app/shared/config.service';
import { AuthService } from '../authentication/auth.service';
import { SignalRService } from './signalr';
import * as signalR from "@microsoft/signalr";
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: "root"
})
export class ChatUnsubscribeService {
  private chatTypingSubscription: Subscription;
  term$ = new Subject<string>();
  private driverTypingSubscription: Subscription;
  driverTyping$ = new Subject<string>();

  subscribe_Status = new BehaviorSubject<number>(0);
  subscribeStatusStatus$ = this.subscribe_Status.asObservable();
  constructor(private signalRService: SignalRService, private authService: AuthService) { }

  Unsubscribe_All() {
    this.signalRService.offChatMessages();
    

  }
  change_User_Signalr_Connection(User_Id, Company_Id) {
    this.signalRService.change_signalr_connection("ChangeUserSignalrConnection", { User_Id: User_Id, Company_Id: Company_Id })

  }

 
  }

  

