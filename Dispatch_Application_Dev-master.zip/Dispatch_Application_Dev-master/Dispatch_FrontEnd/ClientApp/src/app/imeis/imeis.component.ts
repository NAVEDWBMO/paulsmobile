import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, Pipe} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { AuthService } from '../core/authentication/auth.service';
import { AddImeiDialog } from '../devices/devices.component';
import { ConfigService } from '../shared/config.service';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { DeviceStatusDialog } from '../devices/devices.component';
import { PhonePipe } from '../cell-companies/cell-companies.component';


@Component({
  selector: 'app-imeis',
  templateUrl: './imeis.component.html',
  styleUrls: ['./imeis.component.sass'],
  providers: [PhonePipe]
})
export class ImeisComponent implements OnInit {
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: object[];


  public gridData: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  access: any;
  selectedCompanyId: string = "";
  
  public sort: SortDescriptor[] = [
    {
      field: "device_IMEI_IsEnabled",
      dir: "desc",
    }, {
      field: "device_IMEI_Company_Name",
      dir: "asc",
    },
  ]; public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  constructor(public http: HttpClient, private phone: PhonePipe, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
  

    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {

      if(access?.company_Id){
        this.access = access;
        this.selectedCompanyId = access.company_Id.toUpperCase();
        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: access.company_Id
          }     
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_imeis/', httpOptionsTwo).subscribe(result => {
          this.gridData = result;
          this.loadItems();
        })
      }
      
    });

    

  }

  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();
     
  }

  private loadItems(): void {
  /*  this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
      total: this.gridData.length
    };*/
    this.gridData = orderBy(this.gridData, this.sort);
    var filterdat = this.gridData;
    filterdat = filterBy(this.gridData, this.state.filter)
    this.gridView = {
      data: filterdat.slice(this.skip, this.skip + this.pageSize),
      total: filterdat.length
    };
  }

  ngOnInit(): void {
 
  }

  openCreateImeiDialog(){
    const dialogRef = this.dialog.open(AddImeiDialog, {
      disableClose: true

    });
  
    dialogRef.afterClosed().subscribe(result => {
      this.refreshImeis()
    });
  }
  openEditDialog(dataItem){
    const dialogRef = this.dialog.open(EditImeiDialog, {
      data: dataItem,
      disableClose: true

    });
  
    dialogRef.afterClosed().subscribe(result => {
      this.refreshImeis()
    });
  }

  refreshImeis(){
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.access.company_Id
      }     
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_imeis/', httpOptionsTwo).subscribe(result => {
      this.gridData = result;
      this.loadItems();
    })
  }

}



@Component({
  selector: 'edit-imei-dialog',
  templateUrl: 'edit-imei-dialog.html',
  styleUrls: ['./imeis.component.sass'],
  providers: [PhonePipe]

})
export class EditImeiDialog {

  Imei_Number: string = '';
  Phone_Number: string = '';
  selectedComp: any;
  selectedPlan: any;
  cellCompanies: any[] = [];
  cellPlans: any[] = [];
  changed: boolean = false;
  prev_selectedComp: any;
  prev_selectedPlan: any;

  filteredPlans: any[] = [];

  
  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<EditImeiDialog>, @Inject(MAT_DIALOG_DATA) public data: any, private phone: PhonePipe, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar, public dialog: MatDialog) {
    dialogRef.disableClose = true;

    this.Imei_Number = data.device_IMEI_Number;
    this.Phone_Number = phone.transform(data.phone_Number);


      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
    };
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: data.device_IMEI_Company_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_cell_companies_for_company/', httpOptionsTwo).subscribe(result => {
      this.cellCompanies = result;
      var cell_companies_Ids = [];

      this.cellCompanies = this.cellCompanies.filter(element => {
        if (element.cell_Company_IsEnabled == true) {
          cell_companies_Ids.push(element.cell_Company_Id);
          return true;
        } else { return false; }
      });
  
      if (this.data.cell_Company_Id != '') {
        var comp = this.cellCompanies.filter(element => {
          if (element.cell_Company_Id.toUpperCase() == this.data.cell_Company_Id) {
            return true;
          } else { return false; }
        });
        if (comp.length > 0) {
          this.selectedComp = comp[0];
          this.prev_selectedComp = comp[0];
        }
      }
    
      
      this.http.get<any>(this.configService.resourceApiURI + '/get_cell_plans/', this.httpOptions).subscribe(result => {

        this.cellPlans = result;
        var companies_Ids = [];

        this.cellPlans = this.cellPlans.filter(element => {
          if (element.cell_Plan_IsEnabled == true) {
            if (cell_companies_Ids.indexOf(element.cell_Plan_Company_Id) > -1) {
              if (companies_Ids.indexOf(element.cell_Plan_Company_Id) < 0) {
                companies_Ids.push(element.cell_Plan_Company_Id);
              }
            }
            return true;
          } else {
            return false;
          }
        })

        this.cellCompanies = this.cellCompanies.filter(element => {
          if (companies_Ids.indexOf(element.cell_Company_Id) > -1) {
            return true;
          } else { return false; }
        })
        if (this.data.cell_Company_Id != '') {
          this.filteredPlans = this.cellPlans.filter(element => {
            if (element.cell_Plan_Company_Id == this.selectedComp.cell_Company_Id) {
              return true;
            } else { return false; }
          })
          var plan = this.cellPlans.filter(element => {
            if (element.cell_Plan_Id == this.data.cPlan.cell_Plan_Id) {
              return true;
            } else { return false; }
          })
          if (plan.length > 0) { this.selectedPlan = plan[0]; this.prev_selectedPlan = plan[0]; }
        }
         
          
        })
      })

    }
  check() {

    if (
      this.prev_selectedComp == this.selectedComp &&
      this.prev_selectedPlan == this.selectedPlan && 
      this.Imei_Number.trim().toLowerCase() == this.data.device_IMEI_Number.trim().toLowerCase() &&
      this.Phone_Number.replace(/\D/g, '').trim() == this.data.phone_Number.trim()
    ) {

      this.changed = false;
    }
    else if (this.Phone_Number.replace(/\D/g, '').trim() == "" || this.Imei_Number.trim()=="" ) {
      this.changed = false;
    }
    else {
      this.changed = true;
    }
  } onKey(event) {

    const phone_number = event.target.value.replace(/\D/g, '').substring(0, 10);
    this.Phone_Number = this.phone.transform(phone_number);
    this.check();
  }
  onNoClick(): void {
    if (this.Imei_Number != '') {
      if (!this.data.device_IMEI_IsEnabled) {
        const dialogR = this.dialog.open(DeviceStatusDialog, {
          data: {
            'Id': '',
            'message': 'Please activate it before updating it',
            'title': 'This Imei is deactivated '
          }

        });
      }
      else {
        this.http.post<any>(this.configService.resourceApiURI + '/update_imei/',
          {
            "Device_IMEI_Id": this.data.device_IMEI_Id,
            "Device_IMEI_Number": this.Imei_Number,
            "Phone_Number": this.Phone_Number.replace(/[^0-9]/g, ''),
            "Cell_Company": this.selectedComp?.cell_Company_Id,
            "Cell_Plan": this.selectedPlan?.cell_Plan_Id
          },
          this.httpOptions).subscribe(result => {
            this._snackBar.open("Imei updated", "Close", {
              duration: 3000,
            });
          })
        this.dialogRef.close();
      }
     
    }
  
 
  }

  enable_disable_Imei(status) {

    if (this.data.assigned_to_Device.device_Serial_Number != '') {
      const dialogRef = this.dialog.open(DeviceStatusDialog, {
        data: {
          'Id': this.data.assigned_to_Device.device_Serial_Number,
          'message': 'Can\'t be deactivated, please go to driver device\'s to deactivate device',
          'title': 'This imei device is currently assigned to device(Serial Number):'
        }

      });

    }
    else {
      
      const dialogR = this.dialog.open(ConfirmActionDialog, {

      });
      dialogR.afterClosed().subscribe(result => {

        if (result == true) {
          this.data.device_IMEI_IsEnabled = status;
          
          
          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/enable_disable_device_imei/',
            {
              'device_IMEI_Id': this.data.device_IMEI_Id,
              'device_IMEI_IsEnabled': this.data.device_IMEI_IsEnabled

            },
            httpOptions).subscribe(result => {


            })
/*          this.dialogRef.close();
*/        }
      });
    }



  }

  selChange($e){
    this.filteredPlans = this.cellPlans.filter(element => {
      if (element.cell_Plan_Company_Id == $e.value.cell_Company_Id) {
        return true;}else{return false; }});
    this.selectedPlan = null;
   
    

  }
  planChange() {
    this.check();

  }
  close(){
    this.dialogRef.close();

  }

}
