import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router';
import { orderBy, SortDescriptor } from '@progress/kendo-data-query';
import { config } from 'rxjs';


@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.sass']
})
export class AccountComponent implements OnInit {

  lowerCharacters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
  upperCharacters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  symbols = ['!', '?', '@', '+', '=', '-', '_'];

  fname : string;
  lname: string;
  email:string;
  password = new FormControl("");
  location :string;
  Role :string;



  httpOptions: { headers: any; };

  UserInfo: any;

  companyName: string = "";



  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private _snackBar: MatSnackBar, private authService: AuthService, public dialog: MatDialog) {
/*    this.authService.userCompanyAccessStatus$.subscribe(uCompany => this.userCompanyAccess = uCompany);
*//*    this.authService.userRoleStatus$.subscribe(uCompany => this.userRole = uCompany);
*/


    this.authService._userInfo.subscribe(Info => {
      this.fname= Info.user_First_Name;
      this.lname= Info.user_Last_Name;
      this.email= Info.user_Email;
      this.location = Info.location_Name;
      this.Role = Info.role_Name;
      this.companyName = Info.company_Name;
      this.UserInfo = Info;
    });
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

  }


  updateUser() {

    let pass;
    if (this.password.value) {
      pass = this.password.value;
    } else {
      pass = ""
    }

    this.http.post<any>(this.configService.resourceApiURI + '/update_account/',
      {
        
        "User_Email": this.UserInfo.user_Email,
        "User_Password": pass,
      },
      this.httpOptions).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 2000,
        });
       
      })

  }



  getRandom(array) {
    return array[Math.floor(Math.random() * array.length)];
  }

  generatePassword() {
    var finalCharacters = "";
    finalCharacters = finalCharacters.concat(this.getRandom(this.upperCharacters));
    finalCharacters = finalCharacters.concat(this.getRandom(this.numbers));
    finalCharacters = finalCharacters.concat(this.getRandom(this.symbols));

    for (var i = 1; i < 10 - 3; i++) {
      finalCharacters = finalCharacters.concat(this.getRandom(this.lowerCharacters));
    }
    let pass = finalCharacters.split('').sort(function () {
      return 0.5 - Math.random()
    }).join('');

    this.password.setValue(pass);
  }

  ngOnInit(): void {
   
  }




}


