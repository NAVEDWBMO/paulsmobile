import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.sass']
})
export class CompaniesComponent implements OnInit {

  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  private selectedCompanyId: string;

  public gridData: any[] = [];
  httpOptions: { headers: any; };
  public sort: SortDescriptor[] = [
    {
      field: "company_IsEnabled",
      dir: "desc",
    },

  ]; public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {


    this.authService.userCompanyAccessSelectedStatus$
      .subscribe(access => {
        this.selectedCompanyId = access.company_Id;
        if (this.router.url === '/companies') {
          if (this.selectedCompanyId.toUpperCase() != '96AA4673-C3CD-40A9-9F69-DF2290E20C8E') {
            this.router.navigateByUrl('/home');
          }
        }

      });
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

    this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions).subscribe(result => {

      this.gridData = result;
      this.loadItems();
    })
 
  }
  ngOnInit(): void {
    //throw new Error('Method not implemented.');
   
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
}
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();

  }
private loadItems(): void {
    /*this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
        total: this.gridData.length
  };*/
  this.gridData = orderBy(this.gridData, this.sort);
  var filterdat = this.gridData;
  filterdat = filterBy(this.gridData, this.state.filter)
  this.gridView = {
    data: filterdat.slice(this.skip, this.skip + this.pageSize),
    total: filterdat.length
  };
}

openCreateDialog(){
  const dialogRef = this.dialog.open(CreateCompanyDialog, {
    disableClose: true

  });

  dialogRef.afterClosed().subscribe(result => {
    this.get_companies();
  });


}
openEditDialog(dataitem){
  const dialogRef = this.dialog.open(EditCompanyDialog, {
    data: dataitem,
    disableClose: true

  });

  dialogRef.afterClosed().subscribe(result => {
        this.get_companies();

  });


}
  get_companies() {

    this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions).subscribe(result => {

      this.gridData = result;
      this.loadItems();
    })
  }
}

@Component({
  selector: 'create-company-dialog',
  templateUrl: 'create-company-dialog.html',
})
export class CreateCompanyDialog {

  companyName = '';
  companyTypes = [];
  selectedType: any = "";
/*  Administartor_Email = "";
  Administrator_Password = "";*/

  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<CreateCompanyDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService, 
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_company_types/', this.httpOptions).subscribe(result => {
      //result.forEach(comptype => {

      //  this.companyTypes = comptype.Company_Type_Id
        
      //});
      this.companyTypes = result;
      //this.loadItems();
    });
      //this.companyTypes.push('YARD');
      //this.companyTypes.push('TRANSPORTATION');
      //this.companyTypes.push('OUTSOURCE');

      
    }
   
  onNoClick(): void {
    this.dialogRef.close();
  }
  onCreateClick(){
    
    if('' != this.companyName || this.companyName != ''){
      this.http.post<any>(this.configService.resourceApiURI + '/create_company/', 
        { 
          "Company_Name":  this.companyName,
          "Company_Type_Id": this.selectedType.company_Type_Id
        }, 
        this.httpOptions).subscribe(result => {

          this.authService.userIdStatus$.subscribe(user_Id => {
            this.http.get<any>(this.configService.resourceApiURI + '/get_current_user_access/?userid=' + user_Id, this.httpOptions).subscribe(res => {
              this.authService._userCompanyAccess.next(res);
            })

          });
          this.dialogRef.close();
          this._snackBar.open("Committing changes.", "Close", {
            duration: 2000,
          });
        })
    }
    

  }
}


@Component({
  selector: 'edit-company-dialog',
  templateUrl: 'edit-company-dialog.html',
  styleUrls: ['./companies.component.sass']

})
export class EditCompanyDialog {

  selectedCompany: any = {};
  //selectedCompanies: any = [];

  companyName = '';
//  companyTypes = [];
//  selectedType: any;
//  selectedCompanyType: any;
//  selectedlocation: any[];
  isActive: boolean = false;

//  locations: any[] = [];
  //selectedLocations: any[] = [];
 // locationFormControl = new FormControl();


  //transportCompanies: any[] = [];
 // selectedTComp: any[] = [];
  //tCompFormControl = new FormControl();
  
  httpOptions: { headers: any; };
/*  changed: boolean = false;
  prev_selectedTComp=[];
  prev_selectedlocation= [];*/
  constructor(
    public dialogRef: MatDialogRef<EditCompanyDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

      this.isActive = data.company_IsEnabled;
 //     this.selectedCompany = data;
    this.companyName = data.company_Name;

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };

  /*  this.http.get<any>(this.configService.resourceApiURI + '/get_company_types/', this.httpOptions).subscribe(result => {
        this.companyTypes = result;

        this.selectedType = result.filter((elem) => {
          if (elem.company_Type_Name == data.company_Type_Name) {
            return true
          } else {
            return false
          }
        })[0];
        this.selectedCompanyType = this.selectedCompany.company_Type_Name;
      });*/
      
      
      

/*      this.http.get<any>(this.configService.resourceApiURI + '/get_locations/', this.httpOptions).subscribe(result => {
        this.locations = result;     

        this.data.locations.forEach(comLoc => {
          result.forEach(loc => {
            if(comLoc.location_Id == loc.location_Id){
              this.selectedLocations.push(loc);
              this.prev_selectedlocation.push(loc.location_Id);
            }
          });
        });
       
        this.locationFormControl.setValue(this.selectedLocations);
        this.selectedlocation = this.selectedLocations;
      })*/
/*    let httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        company_Id: this.selectedCompany.company_Id,
        company_Type_Id: this.selectedCompany.company_Type_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_Company_Access_To_Company/', httpOptionsTwo).subscribe(result => {
      this.transportCompanies = result;
      result.forEach(selCom => {
        if (selCom.selected == "1") {
          this.prev_selectedTComp.push(selCom.access_Company_Id)
        }
      });
      this.selectedTComp = result.filter((elem) => { if (elem.selected == 1) { return elem; } })
      *//*  if(this.selectedCompany.company_Type_Name == 'OUTSOURCE'){
      
          this.http.get<any>(this.configService.resourceApiURI + '/get_outsource_access/', httpOptionsTwo).subscribe(result => {
            let selectedAccess = [];
    
            result.forEach(selCom => {
              this.transportCompanies.forEach(comp => {
                if(selCom.company_Id == comp.company_Id){
                  selectedAccess.push(comp);
                  this.prev_selectedTComp.push(comp.company_Id)
                }
              });
            });
            this.tCompFormControl.setValue(selectedAccess);
            this.selectedTComp = selectedAccess;
          })
        }
        *//*

      })*/
    // this one is run the api because here code need company access
/*    let httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        company_Id: this.data.company_Id,
        company_Type_Id: this.data.company_Type_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_Company_Access_To_Company/', httpOptionsTwo).subscribe(result => {
      result.forEach(selCom => {
        if (selCom.selected == "1") {
          this.selectedCompanies.push(selCom)
        }
      });

    });*/
      
    }

  onNoClick(): void {
    this.dialogRef.close();
  }
/*  check()
  {
    var accessLst = [];

    this.selectedTComp.forEach(comp => {
      accessLst.push(comp.access_Company_Id);
    })

    var check_access = false;

    if (this.prev_selectedTComp.length == accessLst.length && JSON.stringify(this.prev_selectedTComp.sort()) === JSON.stringify(accessLst.sort()))
    {
      check_access = true;
    }
    else
    {
      check_access = false;
    }

    var locLst = []
    var check_loc = false;
    this.selectedlocation.forEach(loc => {
      locLst.push(loc.location_Id);
    })
    if (this.prev_selectedlocation.length == locLst.length && JSON.stringify(this.prev_selectedlocation.sort()) === JSON.stringify(locLst.sort()))
    {
      check_loc = true;
    }
    else
    {
      check_loc = false;
    }


    if (check_loc && check_access && this.companyName?.trim() == this.selectedCompany.company_Name?.trim()) {
      this.changed= false;
    }
    else
    {
      this.changed= true;
    }


  }*/
  onEditClick(): void {
  
    if(this.companyName != ''){
      this.http.post<any>(this.configService.resourceApiURI + '/update_company/',
        {
          "Company_Id": this.data.company_Id,
          "Company_Name": this.companyName,
          "Company_Type_Id": this.data.company_Type_Id,
          "Company_IsEnabled": this.isActive,
      /*    "Access_To_Companies": this.selectedCompanies,
          "Locations": this.data.locations*/

        },
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Saving changes.", "Close", {
            duration: 2000,
          });
        })

    }
    this.dialogRef.close();
  }
/*  changeValue() {
    this.check();
  }*/

  select_Location() {
    const dialogRef = this.dialog.open(CompanyLoactionsDialog, {
      disableClose: true,
      width: '800px',
      data: this.data,
      panelClass: 'custom-location-dialog-container'

    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }
  
  access_to_company() {
    const dialogRef = this.dialog.open(AccessToCompanyDialog, {
      disableClose: true,
      width: '800px',
      data: this.data,
      panelClass: 'custom-access-to-company-dialog-container'

    });

    dialogRef.afterClosed().subscribe(result => {

    });
  }


}

@Component({
  selector: 'access-to-company-dialog',
  templateUrl: 'access-to-company-dialog.html',
  styleUrls: ['./companies.component.sass']

})
export class AccessToCompanyDialog {
  companies: any[] = [];
  selectedCompany: any[] = [];


  constructor(
    public dialogRef: MatDialogRef<AccessToCompanyDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private _snackBar: MatSnackBar, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
    let httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        company_Id: this.data.company_Id,
        company_Type_Id: this.data.company_Type_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_Company_Access_To_Company/', httpOptionsTwo).subscribe(result => {
      this.companies = result;
      result.forEach(selCom => {
        if (selCom.selected == "1") {
          this.selectedCompany.push(selCom)
        }
      });

    });

  }
  onchange(comp) {

/*    console.log(comp);
*/

  }
  save() {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_company_access_to_company/',
      {
        "Company_Id": this.data.company_Id,
        "Access_To_Companies": this.selectedCompany

      },
      httpOptions).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 2000,
        });
      })

  }
  Close() {
    this.dialogRef.close();
  }

}
@Component({
  selector: 'company-locations-dialog',
  templateUrl: 'company-locations-dialog.html',
  styleUrls: ['./companies.component.sass']

})
export class CompanyLoactionsDialog {
  locations: any[] = [];
  selectedLocations: any[] = [];
  httpOptions: { headers: any; params: any; };
  //selectedCompany: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<CompanyLoactionsDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private _snackBar: MatSnackBar, private router: Router, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
      , params: {
        Company_Id: this.data.company_Id
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_locations_by_companyId/', this.httpOptions).subscribe(result => {
      this.locations = result;

      this.data.locations.forEach(comLoc => {
        result.forEach(loc => {
          if (comLoc.location_Id.toLowerCase() == loc.location_Id.toLowerCase()) {
            this.selectedLocations.push(loc);
         }
        });
      });

    })
  }


  save() {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_company_locations/',
      {
        "Company_Id": this.data.company_Id,
        "Locations": this.selectedLocations

      },
      httpOptions).subscribe(result => {
        this.data.locations = this.selectedLocations;
        this._snackBar.open("Saving changes.", "Close", {
          duration: 2000,
        });
      })

  }

}
