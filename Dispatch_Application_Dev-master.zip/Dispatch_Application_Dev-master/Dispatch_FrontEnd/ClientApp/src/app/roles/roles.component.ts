import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { Router } from '@angular/router'
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.sass']
})
export class RolesComponent implements OnInit {
  locations: any;
  httpOptions: { headers: any; };

  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  public gridData: any[] = [];
  public companies: any[] = [];
  public companyTyperoles: any[] = [];
  public All_users: any[] = [];
  selectedCompanyId: string;
  access: string;
  public selectedCompanyType: any = [];
  constructor(public http: HttpClient, private router: Router, private configService: ConfigService, private authService: AuthService, private _snackBar: MatSnackBar, public dialog: MatDialog) {

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })

    };
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.selectedCompanyType = [];
      if (access?.company_Id) {
        this.access = access;
        this.selectedCompanyId = access.company_Id;
        this.httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions)
          .subscribe(result => {
            if (access.company_Id.toUpperCase() == "96AA4673-C3CD-40A9-9F69-DF2290E20C8E") {
              this.companies = result.sort(function (a, b) {
                if (a.company_Type_Name < b.company_Type_Name) { return -1; }
                if (a.company_Type_Name > b.company_Type_Name) { return 1; }
                return 0;
              });
              this.selectedCompanyType.push(this.companies[0]);

            } else {
              this.companies = result.filter(ele => { if (ele.company_Id == access.company_Id) { return ele; } });
              this.selectedCompanyType.push(this.companies[0]);

            }

            this.http.get<any>(this.configService.resourceApiURI + '/get_company_roles/', this.httpOptions)
              .subscribe(result => {
                this.companyTyperoles = result;
                this.gridData = result.filter(ele => {
                  if (ele.company_Id.toLowerCase() == this.selectedCompanyType[0].company_Id.toLowerCase()) {
                    return true;
                  }
                  else {
                    return false;
                  }
                });
                this.loadItems();
              })

          })

      }

    });

  

   }

  ngOnInit(): void {
   
 
/*    this.http.get<any>(this.configService.resourceApiURI + '/get_company_types/', this.httpOptions)
        .subscribe(result => {
        this.companyTypes = result;
        function sorter(a, b) {
          if (a.sort_Order < b.sort_Order) {
            return -1;
          }
          if (a.sort_Order > b.sort_Order) {
            return 1;
          }
          return 0;
       }
       this.companyTypes.sort(sorter);*/

   

  
    this.http.get<any>(this.configService.resourceApiURI + '/get_dispatch_users/', this.httpOptions)
      .subscribe(result => {
      this.All_users = result;
    })

  }
  pageChange(event: PageChangeEvent): void
  {
    this.skip = event.skip;
    this.loadItems();
  }
  sorter(a, b)
  {
    if (a.sort_Order < b.sort_Order) {
      return -1;
    }
    if (a.sort_Order > b.sort_Order) {
      return 1;
    }
    return 0;
  }
  loadItems(): void
  {
  this.gridData.sort(this.sorter);
  this.gridView = {
      data: this.gridData.slice(this.skip, this.skip + this.pageSize),
      total: this.gridData.length
  };
}

  selecttype(e)
  {
    this.selectedCompanyType = e;
    this.gridData=this.companyTyperoles.filter(ele => {
      if (ele.company_Id.toLowerCase() == this.selectedCompanyType[0].company_Id.toLowerCase()) {
        return true;
      }
      else {
        return false;
      }

    });
    this.loadItems();
  }
  openDialog(dataItem)
  {
    const dialogRef = this.dialog.open(RoleEditDialog, {
      width: '1100px',
      data: dataItem,
      disableClose: true,
      panelClass: 'custom-edit-role-dialog-container'

    });

    dialogRef.afterClosed().subscribe(result => {
      this.refreshRoles();
      this.loadItems();

    });
  }
  OpenAccessDialog(dataItem) {
    const dialogRef = this.dialog.open(RolesCompanyAccessDialog, {
      width: '800px',
      data: dataItem,
      disableClose: true,
      panelClass: 'custom-Access-dialog-container'

    });

    dialogRef.afterClosed().subscribe(result => {


    });
  }
  refreshRoles() {
    this.http.get<any>(this.configService.resourceApiURI + '/get_company_roles/', this.httpOptions)
        .subscribe(result => {
        this.companyTyperoles = result;
        this.gridData = result.filter(ele => {
          if (ele.company_Id.toLowerCase() == this.selectedCompanyType[0].company_Id.toLowerCase()) {
            return true;
          }
          else
          {
            return false;
          }
        });
        this.loadItems();
      })
  }

  openAddDialog(){
  const dialogRef = this.dialog.open(AddRoleDialog, {
    width: '400px',
    data: this.selectedCompanyType[0],
    disableClose: true,
    panelClass: 'custom-add-role-dialog-container'

  });

  dialogRef.afterClosed().subscribe(result => {
    this.refreshRoles();
    this.loadItems();
   
  });

  }
  delete(data) {
 

    const role_index = this.All_users.map(ele => ele.user_Role.toUpperCase()).indexOf(data.role_Id.toUpperCase());
    if (role_index > -1) {
      this.dialog.open(DialogAlert, { data: { 'msg': 'This role is currently assigned to user(s)' } });

    }
    else {
      const dialogR = this.dialog.open(ConfirmActionDialog, {

      });
      dialogR.afterClosed().subscribe(result => {

        if (result == true) {
          var httpOptionsTwo = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            }),

          };
          this.http.post<any>(this.configService.resourceApiURI + '/delete_role/', {

            'role_Id': data.role_Id,
            "company_Id": data.company_Id,
            "sort_Order": data.sort_Order

          }, httpOptionsTwo).subscribe(result => {

            this.refreshRoles();
            this.loadItems();

          })
        }
      })
    
    }
   
  }


}

@Component({
  selector: 'edit-role-dialog',
  templateUrl: 'edit-role-dialog.html',
  styleUrls: ['./roles.component.sass']

})
export class RoleEditDialog {



 // public selectedCompanies = new FormControl();
  public httpOptions: { headers: any; };
 // public All_roles: any[] = [];
  public prev_role: string;
  public prev_sort_order: string;

  public selectedPermissionType: any[] = [];
  public permissionTypes: any[] = [];
  public permissions: any[] = [];

  public filteredPermissions: any[] = [];
  public Allpermissions: any[] = [];

  //public Role_Permissions: any[] = [];
  public Updated_Permissions: any[] = [];
  public selectedPermissionFunction: any[] = [];
  public access_level: any[] = [];
  public filteredAccess_level: any[] = [];

  public selected_level: any[] = [];
  public ischanged: boolean =true;
  constructor(
    public dialogRef: MatDialogRef<RoleEditDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar)
    {
      dialogRef.disableClose = true;
      this.httpOptions = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_permission_types/', this.httpOptions)
      .subscribe(result => {
        this.permissionTypes = result.sort(function (a, b) {
          if (a.permission_Type_Name < b.permission_Type_Name) { return -1; }
          if (a.permission_Type_Name > b.permission_Type_Name) { return 1; }
          return 0;
        });

       // this.selectedPermissionType[0] = this.permissionTypes[0];
        var role_Id = "";
        this.authService.userRoleStatus$.subscribe(role => {
          role_Id = role;
          //console.log(role)
        });
        let httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Role_Id: this.data.role_Id,
          Current_User_Role_Id:role_Id
         // permission_Type_Id: this.selectedPermissionType[0]['permission_Type_Id']
        }
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_user_role_permissions', httpOptionsTwo).subscribe(result => {
 /*         var list = [];
          console.log(result);*/
          this.Allpermissions = result.Permissions;
          this.access_level = result.Permission_Access_Level;
          
          /*this.permissions = result.filter(ele => {
            if (list.indexOf(ele.permission_Id) == -1) {
              list.push(ele.permission_Id)
              return ele;
            }
          });*/
/*          list = [];
*/            /*.sort(function (a, b) {
            if (a.permission_Function < b.permission_Function) { return -1; }
            if (a.permission_Function > b.permission_Function) { return 1; }
            return 0;
          })*/;
          this.Updated_Permissions = [];
          this.ischanged = false;
        })
     /*   this.http.get<any>(this.configService.resourceApiURI + '/get_permissions/', this.httpOptions)
          .subscribe(result => {
            this.Allpermissions = result;
            this.permissions = result.filter(ele => {
              if (ele.permission_Type_Id.toLowerCase() == this.selectedPermissionType['permission_Type_Id'].toLowerCase()) {
                return true;
              }
              else {
                return false;
              }
            });
        
          })*/

      })

    
    this.prev_role = this.data.role_Name;
    this.prev_sort_order = this.data.sort_Order;

    }
  selectchange(e) {
    //this.selectedPermissionType = e.value;
    this.Updated_Permissions  = [];
    this.filteredAccess_level = [];
    this.filteredPermissions = this.Allpermissions.filter(ele => { if (ele.permission_Type_Id == this.selectedPermissionType[0]['permission_Type_Id']) return ele; }).sort();
    this.selectedPermissionFunction[0] = this.filteredPermissions[0];

    if (this.selectedPermissionFunction[0] != undefined ) {
      this.filteredAccess_level = this.access_level[this.selectedPermissionFunction[0].permission_Id];
    }

/*
    let httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Role_Id: this.data.role_Id,
     //   permission_Type_Id: this.selectedPermissionType[0]['permission_Type_Id']
      }
    };
/*    this.http.get<any>(this.configService.resourceApiURI + '/get_user_role_permissions', httpOptionsTwo).subscribe(result => {
      this.permissions = result.sort( function(a, b) {
        if (a.permission_Function < b.permission_Function) { return -1; }
        if (a.permission_Function > b.permission_Function) { return 1; }
        return 0;
      });
    })*/
  /*  this.permissions = this.Allpermissions.filter(ele => {
      if (ele.permission_Type_Id.toLowerCase() == this.selectedPermissionType['permission_Type_Id'].toLowerCase()) {
        return true;
      }
      else {
        return false;
      }

    });*/
  }
  checkValue(access) {
    access.selected == 1 ? access.selected = 0 : access.selected = 1;
    this.filteredAccess_level.map(x => { if (x.access_Level_Id != access.access_Level_Id) { x.selected = 0;}})
    this.http.post<any>(this.configService.resourceApiURI + '/update_user_role_permissions/',
      {
        "Role_Id": this.data.role_Id,
        "Permission_Type_Id": this.selectedPermissionType[0].permission_Type_Id,
        "Permission_Id": this.selectedPermissionFunction[0].permission_Id,
        "Access_Level_Id": access.access_Level_Id,
        "Selected": access.selected
      },
      this.httpOptions).subscribe(result => {

        this._snackBar.open("Committing changes.", "Close", {
          duration: 2000,
        });
      })
  }
  selectFunction(e) {
    this.filteredAccess_level= this.access_level[this.selectedPermissionFunction[0].permission_Id];
  } 

  onChange(permission_Id: string) {
    var up_index = this.Updated_Permissions.indexOf(permission_Id);
    if (up_index > -1) {
      this.Updated_Permissions.splice(up_index, 1);
    } else {
      this.Updated_Permissions.push(permission_Id)

    }
    this.permissions = this.permissions.map(element => {
      if (permission_Id.toLowerCase() == element.permission_Id.toLowerCase()) {
        element.access_Type == "0" ? element.access_Type = "1" : element.access_Type = "0";

      }

      return element;
    });
     

  }
  onEditClick(): void {


    if (this.Updated_Permissions.length > 0) {
      var Updated_Permissions = this.permissions.filter(ele => {
              if (this.Updated_Permissions.indexOf(ele.permission_Id.toLowerCase())>-1) {
                return true;
              }
              else {
                return false;
              }
      });
      this.Updated_Permissions = [];
      this.http.post<any>(this.configService.resourceApiURI + '/update_user_role_permissions/',
        {
          "Role_Id": this.data.role_Id,
          "Permission_Type_Id": this.selectedPermissionType['permission_Type_Id'],
          "User_Role_Permissions": Updated_Permissions
        },
        this.httpOptions).subscribe(result => {

          this._snackBar.open("Committing changes.", "Close", {
            duration: 2000,
          });
        })

    }
    if (this.prev_role?.trim().toLowerCase() != this.data.role_Name?.trim().toLowerCase() || this.prev_sort_order != this.data.sort_Order) {
    
      this.http.get<any>(this.configService.resourceApiURI + '/get_company_roles/', this.httpOptions).subscribe(result => {

        var index = result.map(ele => { if (ele.company_Id === this.data.company_Id) { return ele.role_Name.toUpperCase() } }).indexOf(this.data.role_Name.trim().toUpperCase());
        if (this.prev_role != this.data.role_Name && index > -1) {
          this.dialog.open(DialogAlert, { data: { 'msg': 'This role already exists!' } });
        } else {
          if (this.data.role_Id != "" && this.data.role_Name != "") {
            this.http.post<any>(this.configService.resourceApiURI + '/update_role/',
              {
                "company_Id": this.data.company_Id,
                "role_Id": this.data.role_Id,
                "role_Name": this.data.role_Name.trim().toUpperCase(),
                "sort_Order": this.data.sort_Order,

              },
              this.httpOptions).subscribe(result => {
                this.data.role_Name = this.data.role_Name.trim().toUpperCase();
                this.prev_role = this.data.role_Name.trim();
                this.prev_sort_order = this.data.sort_Order;
                this._snackBar.open("Committing changes.", "Close", {
                  duration: 2000,
                });
              })
          }
          //this.dialogRef.close();
        }
      })

     
    }
   
   
  }
  onNoClick(){
    this.dialogRef.close();
  }

}


@Component({
  selector: 'add-role-dialog',
  templateUrl: 'add-role-dialog.html',
  styleUrls: ['./roles.component.sass']

})
export class AddRoleDialog {

  Role: string = '';
  Sort_Order: number = 1;
  All_roles: any[] = [];
  httpOptions: { headers: any; };
  role_Access_Level = 1;
  constructor(
    public dialogRef: MatDialogRef<AddRoleDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar, public dialog: MatDialog) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    dialogRef.disableClose = true;
    this.http.get<any>(this.configService.resourceApiURI + '/get_company_roles/', this.httpOptions).subscribe(result => {
      this.All_roles = result;
      result.map(ele => { if (ele.company_Id === this.data.company_Id) { if (ele.sort_Order >= this.Sort_Order) { this.Sort_Order = ele.sort_Order + 1 } } })
    })

  }

  ngOnInit() {
 
  }
  save(): void {
    const index = this.All_roles.map(ele => { if (ele.company_Id === this.data.company_Id) { return ele.role_Name.toUpperCase() }}).indexOf(this.Role.trim().toUpperCase());

    if (index > -1)
    {
      this.dialog.open(DialogAlert, { data: { 'msg':'This role already exists!'}});
    }
    else
    {
      if ('' != this.Role || this.Sort_Order != null)
      {
        this.http.post<any>(this.configService.resourceApiURI + '/create_role/',
          {
            "role_Name": this.Role.toUpperCase(),
            "sort_Order": this.Sort_Order,
            "company_Id": this.data.company_Id,
            "role_Access_Level": this.role_Access_Level
          },
          this.httpOptions).subscribe(result => {
            this._snackBar.open("Committing changes.", "Close", {
              duration: 2000,
            });
          })
        this.dialogRef.close();

      }
    }

  }

  close(){
    this.dialogRef.close();
  }
}
@Component({
  selector: 'dialog-alert-dialog',
  templateUrl: 'dialog-alert.html',
})
export class DialogAlert {

  constructor(
    public dialogRe: MatDialogRef<DialogAlert>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  finish(): void {
    this.dialogRe.close();
  }

}
@Component({
  selector: 'roles-company-access-dialog',
  templateUrl: 'roles-company-access-dialog.html',
})
export class RolesCompanyAccessDialog {
  public role_company_access: any[] = [];
 // public seleced_access: any[] = [];

  constructor(
    public dialogRe: MatDialogRef<RolesCompanyAccessDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar, public dialog: MatDialog) {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
      , params: {
        Role_Id: this.data.role_Id,
        Company_Id: this.data.company_Id,
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_role_company_access/', httpOptions).subscribe(result => {
      this.role_company_access = result;

    //  this.seleced_access = result.filter(ele => { if (ele.access_Type == 1) { return ele } });
    })
  

  }
  selectChange(e) {
   
    this.role_company_access = this.role_company_access.map(element => {
      if (e.option.value.access_Company_Id.toLowerCase() == element.access_Company_Id.toLowerCase()) {
        element.access_Type == "0" ? element.access_Type = "1" : element.access_Type = "0";

      }
      return element;
    })


  }
  save() {
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_role_company_access/',
      {
        "Role_Id": this.data.role_Id,
        "Role_Company_Access": this.role_company_access
      },
      httpOptions).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 2000,
        });
      })

  }

  finish(): void {
    this.dialogRe.close();
  }
}
