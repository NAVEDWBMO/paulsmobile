import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { access } from 'fs';
import { AuthService } from '../core/authentication/auth.service';
/*import { SignalRService } from '../core/chat/signalr';
import * as signalR from "@microsoft/signalr";*/

@Component({
  selector: 'app-chats',
  templateUrl: './chats.component.html',
  styleUrls: ['./chats.component.sass']
})
export class ChatsComponent implements OnInit {

  constructor(private router: Router, private authService: AuthService) {
   /* if (this.signalRService.connection.state === signalR.HubConnectionState.Disconnected) {
      this.signalRService.offChatMessages();

      this.signalRService.connection.start();
    }
*/

    var chat_Permissions: any;
    var Company_Id = "";
    var Company_Type_Id = "";
    var User_Id = "";
    var User_Name = "";
    var Permission_Id = "";
    this.authService.userInfoStatus$.subscribe(userinfo => { User_Id = userinfo.user_Id; User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name })
    this.authService._userCompanyAccessSelected.subscribe(access => { Company_Id = access?.company_Id; Company_Type_Id = access?.company_Type_Id; });
    this.authService._userPermissionsStatus$.subscribe(permissions => {
        chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });
    let navigationExtras: NavigationExtras = {
      state: {
        UserInfo: {
          Company_Id: Company_Id,
          User_Id: User_Id,
          User_Name: User_Name,
          Permission_Id: Permission_Id,
          Company_Type_Id: Company_Type_Id
        }
      }
    };
    this.router.navigate([chat_Permissions[chat_Permissions.length - 1].router_Link], navigationExtras );
  }

  ngOnInit(): void {
    

    }
    



  


}
