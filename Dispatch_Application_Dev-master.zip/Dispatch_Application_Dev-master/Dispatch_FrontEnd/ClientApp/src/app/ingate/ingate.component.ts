import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { isFilterable } from '@progress/kendo-angular-grid/dist/es2015/filtering/filterable';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { Console } from 'console';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { SignalRService } from '../core/chat/signalr';
import * as signalR from "@microsoft/signalr";
import { PickupRequestDialog, PickupNumberDialog, AddPickupDialog, LineupRemoveReasonDialog, ContainerNumberDialog } from '../gate/gate.component'

@Component({
  selector: 'app-InGate',
  templateUrl: './ingate.component.html',
  styleUrls: ['./ingate.component.sass']
})
export class InGateComponent implements OnInit {
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  private access: any;
  public gridData: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  selectedCompanyId: string = "";
  public sort: SortDescriptor[] = [
    {
      field: 'driver_Number',
      dir: 'desc'
    }
  ];
  public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  selectedCompany: any;
  userCompaniesAccess: any;

  constructor(public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {


    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.gridData = [];
      if (access?.company_Id) {
        this.access = access;
        this.selectedCompanyId = access.company_Id;
      }
    });

  //  this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
 //   this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);
    this.getListInfo();
  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.loadItems();

  }
  private loadItems(): void {

    this.gridData = orderBy(this.gridData, this.sort);
    var filterdat = this.gridData;
    filterdat = filterBy(this.gridData, this.state.filter)
    this.gridView = {
      data: filterdat.slice(this.skip, this.skip + this.pageSize),
      total: filterdat.length
    };

  }

  refresh() {
    this.getListInfo();
  }
  getListInfo() {

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }), params: {

        "Company_Id": this.selectedCompanyId
      }


    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_ingate_list/', httpOptionsTwo).subscribe(result => {
      this.gridData = result;
      this.loadItems();
    });


  }
  openYardDialog(dataItem): void {
    const dialogRef = this.dialog.open(ChangeIngateDialog, {
      data: dataItem,
      disableClose: true,
      width:"66vw",
      panelClass: 'custom-fb-dialog',
      autoFocus: false,
    });

    dialogRef.afterClosed().subscribe(result => {

      this.refresh()

    });
  }

  ngOnInit(): void {

  }


}




@Component({
  selector: 'yard-location-dialog',
  templateUrl: 'yard-location-dialog.html',
  styleUrls: ['./ingate.component.sass']
})
export class YardLocationDialog {

  lanePositions: any[] = [];
  yardlocation = "";
  Company_Id = "";
  httpOptions: { headers: any;params:any };
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  public ditPerson = [];
  public dotPerson = [];
  constructor(
    public dialogRef: MatDialogRef<YardLocationDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar, public dialog: MatDialog, public http: HttpClient, private signalRService: SignalRService, private configService: ConfigService, private authService: AuthService,) {
    dialogRef.disableClose = true;
    this.authService.userInfoStatus$.subscribe(userinfo => {
      this.user_id = userinfo.user_Id;
      this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name;

    })
    this.authService._userCompanyAccessSelected.subscribe(access => {this.Company_Id = access?.company_Id; });

    var chat_Permissions: any;
    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }), params: {

        "Company_Id": this.Company_Id
      }

    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_gate_driver_info/', this.httpOptions).subscribe(result => {
      //  this.ditPerson = result;
      result.map(ele => {
        if (ele.role_Id.toUpperCase() == 'DD17B764-5D41-4774-91CD-73117E59B65A') {
          this.ditPerson.push(ele);

        } else if (ele.role_Id.toUpperCase() == '89342125-00EE-4A78-9807-B1ABC6C68478') {
          this.dotPerson.push(ele);

         
        }

      })
      //console.log(result);

    });


  }

  updateLocation() {

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/assign_yard_location/',
      {
        "Driver": this.data.driver_Number,
        "Driver_Job_Status": this.data.driver_Job_Status,
        "Carrier": this.data.carrier_Name,
        "Location": this.yardlocation
      },
      httpOptionsTwo).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 3000,
        });
        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
          let message = "Send Driver " + this.data.driver_Number + " to Location " + this.yardlocation;

          if (this.ditPerson.length != 0) {
            this.ditPerson.map(ele => {

              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);
            })
          }
          message = "Driver " + this.data.driver_Number + " Is Going at Location " + this.yardlocation + " , Will Leave Soon. Refresh List";
          if (this.dotPerson.length != 0) {
            this.dotPerson.map(ele => {

              let mes1: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes1);
            })
          }
        }
      })
    this.dialogRef.close();

  }
}

@Component({
  selector: 'change-ingate-dialog',
  templateUrl: 'change-ingate-dialog.html',
  styleUrls: ['./ingate.component.sass']
})

export class ChangeIngateDialog {

  dataItem: any;
  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog,
    public dialogRef: MatDialogRef<ChangeIngateDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.dataItem = this.data;

  }
  openYardDialog(): void {
    const dialogRef = this.dialog.open(YardLocationDialog, {
      data: this.data,
      disableClose: true,
      width: "500px"

    });

    dialogRef.afterClosed().subscribe(result => {


    });
  }
  
  openAddPickupDialog(): void {
    const dialogRef = this.dialog.open(AddPickupDialog, {
      data: this.data,
      disableClose: true,
      width: "500px"

    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != "close") {

        this.dialogRef.close();
      }

    });
  }
  openContainerNumberDialog(): void {
    const dialogRef = this.dialog.open(ContainerNumberDialog, {
      data: this.data,
      disableClose: true

    });
    dialogRef.afterClosed().subscribe(result => {
      //  this.dialogRef.close();
      if (result != "close") {

        this.dialogRef.close();
      }
    });

  }
  openPickupRequest(): void {

    const dialogRef = this.dialog.open(PickupRequestDialog, {
      data: this.data,
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      //  this.dialogRef.close();
      if (result != "close") {

        this.dialogRef.close();
      }
    });

  }
  openPickupDialog(): void {

    const dialogRef = this.dialog.open(PickupNumberDialog, {
      data: this.data,
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      // this.dialogRef.close();
      if (result != "close") {

        this.dialogRef.close();
      }
    });

  }
  openDeleteDialog(): void {
    const dialogRef = this.dialog.open(LineupRemoveReasonDialog, {
      data: this.data,
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      //  this.dialogRef.close();
      if (result != "close") {

        this.dialogRef.close();
      }
    });

  }
}
export interface MessageModel {
  message_Id?: any;
  from_User_Id: string;
  message_From_User_Role?: string;
  message_From_User_Name?: string;
  message_Text: string;
  chat_Id: string;
  message_Date?: any;
  message_Latitude?: string;
  message_Longitude?: string;
  chat_Table: string;
  message_Is_Visible: boolean;
  message_To_Group: string;
}
