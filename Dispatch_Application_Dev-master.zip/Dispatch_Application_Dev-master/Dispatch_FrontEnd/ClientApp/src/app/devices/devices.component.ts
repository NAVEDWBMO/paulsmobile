import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { element } from 'protractor';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { PhonePipe } from '../cell-companies/cell-companies.component';


@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.sass']
})
export class DevicesComponent implements OnInit {

  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  selectedCompanyId: string = "";

  public gridData: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  access: any;
  public sort: SortDescriptor[] = [
    {
      field: "driver_Device_IsEnabled",
      dir: "desc",
    },
    {
      field: "company_Name",
      dir: "asc",
    },
  ]; public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  constructor(public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {


    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {

      if(access?.company_Id){
        this.access = access;
        this.selectedCompanyId = access.company_Id;
        this.httpOptions = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_devices/?Company_Id=' + this.access.company_Id, this.httpOptions).subscribe(result => {
          this.gridData = result;
          this.loadItems();
        })

      }
      
    });


  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.skip = 0;
    this.state = state;
    this.loadItems();

  }

private loadItems(): void {
  /*this.gridView = {
    data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
    total: this.gridData.length
  };*/
  this.gridData = orderBy(this.gridData, this.sort);
  var filterdat = this.gridData;
  filterdat = filterBy(this.gridData, this.state.filter)
  this.gridView = {
    data: filterdat.slice(this.skip, this.skip + this.pageSize),
    total: filterdat.length
  };
}

openCreateDevice(){
  const dialogRef = this.dialog.open(AddDeviceDialog, {
    disableClose: true

  });

  dialogRef.afterClosed().subscribe(result => {
    this.refreshDevices();
  });
}

refreshDevices(){
  var httpOptionsTwo = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': this.authService.authorizationHeaderValue
    }),
    params: {
      Company_Id: this.access.company_Id
    }     
  };
  this.http.get<any>(this.configService.resourceApiURI + '/get_devices/', httpOptionsTwo).subscribe(result => {
    this.gridData = result;
    this.loadItems();
  })
}

  ngOnInit(): void {
  
  }

  openEditDialog(dataItem): void {
    const dialogRef = this.dialog.open(EditDeviceDialog, {
      data: dataItem,
      disableClose: true

    });
  
    dialogRef.afterClosed().subscribe(result => {
    this.refreshDevices();
    });
  }
}



@Component({
  selector: 'add-device-dialog',
  templateUrl: 'add-device-dialog.html',
  styleUrls: ['./devices.component.sass']

})
export class AddDeviceDialog {

  Device_Model: string = '';
  Device_Model_Year: number = new Date().getFullYear();
  Device_Company: string = '';
  Device_Serial_Number: string = '';

  lstImei: any[] = [];
  selectedImei = new FormControl();
  
  httpOptions: { headers: any; };
  userCompanyAccess: any[];
  userRole: string;
  companies: any[] = [];
  selectedCompany = new FormControl();


  constructor(
    public dialogRef: MatDialogRef<AddDeviceDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService, 
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;
    this.authService.userCompanyAccessStatus$.subscribe(uCompany => this.userCompanyAccess = uCompany);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userRole = uCompany);

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.selectedCompany = access?.company_Id;
      }
    });
      
     this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

   /*  this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', this.httpOptions).subscribe(result => {
        if(this.userRole.toLowerCase() != '25942536-C57D-4E18-A82D-0CDCC77A74C5'.toLowerCase()){
          result.forEach(resultComp => {
            this.userCompanyAccess.forEach(accessComp => {
              if(resultComp.company_Id == accessComp.company_Id && resultComp.company_Type == "TRANSPORTATION"){
                this.companies.push(resultComp);
              }
            });
        })
        }else{
          this.companies = result.filter((elem) => {
            if(elem.company_Type == 'TRANSPORTATION'){
              return true;
            }
          }
        )
        }
        
        
  
      })*/
      
    }

  onNoClick(): void {

    if( this.Device_Serial_Number != ''){
      this.http.post<any>(this.configService.resourceApiURI + '/create_device/', 
        { 

          "Device_Model": this.Device_Model?.trim(),
          "Device_Model_Year": this.Device_Model_Year,
         "Device_Company":  this.Device_Company,
         "Device_Serial_Number":  this.Device_Serial_Number?.trim(),
          "Company_Id": this.selectedCompany
        }, 
        this.httpOptions).subscribe(result => {
          
        },
          error => {
           
            if (error.error.text == "Not-Existed") {
              this._snackBar.open("Device created", "Close", {
                duration: 3000,
              });
            }
            else if (error.error.text == "Existed") {
              this._snackBar.open("Device Already Exist", "Close", {
                duration: 4000,
              });
            }
          })
        this.dialogRef.close();
      }
    
  }
  close(){
    this.dialogRef.close();

  }

}



@Component({
  selector: 'edit-device-dialog',
  templateUrl: 'edit-device-dialog.html',
  styleUrls: ['./devices.component.sass']

})
export class EditDeviceDialog {

  Device_Make: string = '';
  Device_Model: string = '';
  Device_Model_Year: number ;
  Device_Company: string = '';
  Device_Serial_Number: string = '';
  access: any;
  lstImei: any[] = [];
  selectedImei_new:any;
  selectedImei = new FormControl();
  selectedCompany = new FormControl();
  Device_Id: string = '';
  httpOptions: { headers: any; };
  changed: boolean = false;
  prev_selectedImei: any;

  constructor(
    public dialogRef: MatDialogRef<EditDeviceDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

      this.Device_Make = data.device_Make;
      this.Device_Model = data.device_Model;
      this.Device_Model_Year = Number(data.device_Model_Year);
      this.Device_Company = data.device_Company;
      this.Device_Serial_Number = data.device_Serial_Number;
      this.Device_Id = data.device_Id;
      this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.access = access;      
      if (access?.company_Id) {
        this.selectedCompany = access.company_Id;               
      }

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),

      };
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Company_Id: data.company_Id
        }
      };
     
      this.http.get<any>(this.configService.resourceApiURI + '/get_imeis/', httpOptionsTwo).subscribe(result => {
      
        this.lstImei = result;

        if (data.device_IMEI_Id.trim() != '') {
     
          var selectedImei = this.lstImei.filter(element => {
            if (element.device_IMEI_Id == data.device_IMEI_Id) {
              return true;
            } else {
              return false;
            }
          })
           
        }

     
        this.lstImei = this.lstImei.filter(element => {
          if (element.device_IMEI_IsEnabled == true &&
            (element.assigned_to_Device.device_Serial_Number == null || element.assigned_to_Device.device_Serial_Number == '')) {
            return true;
          } else {
            return false;
          }
        })
        if (data.device_IMEI_Id.trim() != '') {
          if (selectedImei.length > 0) {
            this.lstImei.push(selectedImei[0]);
            this.selectedImei.setValue(selectedImei[0]);
            this.prev_selectedImei = selectedImei[0];
            this.selectedImei_new = selectedImei[0]
          }
        }
      })
    });  
  }
  selectchange(e) {
    this.check();
  }
  onChange(e) {
    this.check();

  }
  check() {
   

    if (this.prev_selectedImei == this.selectedImei_new &&
      this.Device_Model.trim() == this.data.device_Model.trim() &&
      this.Device_Model_Year == Number(this.data.device_Model_Year) &&
      this.Device_Company.trim() == this.data.device_Company.trim() &&
      this.Device_Serial_Number.trim().toLowerCase() == this.data.device_Serial_Number.trim().toLowerCase()
    ) {

      this.changed = false;
    }
    else if (this.Device_Model.trim() == "" ||
      this.Device_Model_Year == 0 ||
      this.Device_Company.trim() == "" ||
      this.Device_Serial_Number.trim() == ""
      ) {
      this.changed = false;
    }
    else {
      this.changed = true;
    }
  }
  enable_disable_device(status) {

    if (this.data.device_Driver_User_Id != '' && this.data.device_Driver_User_Id != null) {
      const dialogRef = this.dialog.open(DeviceStatusDialog, {
        data: {
          'Id': this.data.device_Driver_Id, 'message': 'Can\'t be deactivated, please unassign driver to deactivate', 'title': 'This device is currently assigned to driver:', 'driver_Id': this.data.device_Driver_User_Id }
           
      });
      dialogRef.afterClosed().subscribe(result => {

        if (result == true) {
          this.http.post<any>(this.configService.resourceApiURI + '/update_driver_truck_device/',
            {
              "User_Id": this.data.device_Driver_User_Id,
              "Driver_Truck_Id": this.data.device_Driver_Truck_Id,
           
            },
            this.httpOptions).subscribe(result => {
              this.data.device_Driver_User_Id = '';
              this.data.device_Driver_Firstname = '';
              this.data.device_Driver_Lastname = '';
              this.data.device_Driver_Id = '';
              this._snackBar.open("Device updated", "Close", {
                duration: 3000,
              });
            })
       }
      });
    }
    else {
      const dialogR = this.dialog.open(ConfirmActionDialog, {

      });
      dialogR.afterClosed().subscribe(result => {

        if (result == true) {
          this.data.driver_Device_IsEnabled = status;


          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/enable_disable_device/',
            {
              'Device_Id': this.Device_Id,
              'driver_Device_IsEnabled': this.data.driver_Device_IsEnabled

            },
            httpOptions).subscribe(result => {
              if (status == 0) {
                this._snackBar.open("Device Deactivated", "Close", {
                  duration: 3000,
                });
                this.data.device_IMEI_Number = '';
              }
              else {
                this._snackBar.open("Device Activated", "Close", {
                  duration: 3000,
                });
              }
             

            })
    }
      });
    }
   


  }
    openCreateImeiDialog(){
      const dialogRef = this.dialog.open(AddImeiDialog, {
      
      });
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Company_Id: this.access.company_Id
        }
      };
      dialogRef.afterClosed().subscribe(result => {
        this.http.get<any>(this.configService.resourceApiURI + '/get_imeis/', httpOptionsTwo).subscribe(result => {
          this.lstImei = result;
        })
      });
  }
  clearImeis() {
    if (this.data.device_Driver_User_Id == '' || this.data.device_Driver_User_Id == null) {
      this.selectedImei_new = null;
      this.check();
    }
    else {
      const dialogRef = this.dialog.open(DeviceStatusDialog, {
        data: { 'Id': this.data.device_Driver_Name, 'message': 'Can\'t remove imei, please unassign driver to change imei', 'title': 'This device is currently assigned to driver:' }

      });
    }
  }
  onNoClick(): void {
    if (!this.data.driver_Device_IsEnabled) {
      const dialogRef = this.dialog.open(DeviceStatusDialog, {
        data: {
          'Id': '',
          'message': 'Please activate it before updating it',
          'title': 'This device is deactivated '
        }

      });
    }
    else {
      this.http.post<any>(this.configService.resourceApiURI + '/update_device/',
        {
          "Device_Id": this.data.device_Id,
          "Device_IMEI_Id": this.selectedImei_new?.device_IMEI_Id,
          "Device_Model": this.Device_Model,
          "Device_Model_Year": this.Device_Model_Year,
          "Device_Company": this.Device_Company,
          "Device_Serial_Number": this.Device_Serial_Number,
        },
        this.httpOptions).subscribe(result => {
          this._snackBar.open("Device updated", "Close", {
            duration: 3000,
          });
        })
      this.dialogRef.close();

    }
 
    //}
  }
  close(){
    this.dialogRef.close();

  }

}

@Component({
  selector: 'device-status-dialog',
  templateUrl: 'device-status-dialog.html',
  styleUrls: ['./devices.component.sass']
})

export class DeviceStatusDialog {
  constructor(
    public dialogRef: MatDialogRef<DeviceStatusDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;

  }

}

@Component({
  selector: 'add-imei-dialog',
  templateUrl: 'add-imei-dialog.html',
  styleUrls: ['./devices.component.sass'],
  providers: [PhonePipe]
})
export class AddImeiDialog {

  Imei_Number: string = '';
  Phone_Number: string = '';


  selectedComp: any;
  selectedPlan: any;
  cellCompanies: any[] = [];
  cellPlans: any[] = [];

  filteredPlans: any[] = [];
  access: any;
  
  httpOptions: { headers: any; };
  constructor(
    public dialogRef: MatDialogRef<AddDeviceDialog>, @Inject(MAT_DIALOG_DATA) public data: any, private phone: PhonePipe, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;


    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.access = access;
     
    })
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
      var httpOptionsTwo = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Company_Id: this.access.company_Id
        }
      };

    this.http.get<any>(this.configService.resourceApiURI + '/get_cell_companies_for_company/', httpOptionsTwo).subscribe(result => {

      this.cellCompanies = result;
      var cell_companies_Ids = [];

      this.cellCompanies = this.cellCompanies.filter(element => {
        if (element.cell_Company_IsEnabled == true) {
          cell_companies_Ids.push(element.cell_Company_Id);
          return true;
        } else { return false; } });

     
      this.http.get<any>(this.configService.resourceApiURI + '/get_cell_plans/', this.httpOptions).subscribe(result => {

        this.cellPlans = result;
        var companies_Ids = [];

          this.cellPlans = this.cellPlans.filter(element => {
            if (element.cell_Plan_IsEnabled == true) {
              if (cell_companies_Ids.indexOf(element.cell_Plan_Company_Id) > -1) {
                if (companies_Ids.indexOf(element.cell_Plan_Company_Id) < 0) {
                  companies_Ids.push(element.cell_Plan_Company_Id);
                }
              }   
              return true;
            } else {
              return false;
            }
          })

         this.cellCompanies = this.cellCompanies.filter(element => {
            if (companies_Ids.indexOf(element.cell_Company_Id)>-1) {
              return true;} else {return false; }
         })
         
        })
      })
  }
  onKey(event) {

    const phone_number = event.target.value.replace(/\D/g, '').substring(0, 10);
    this.Phone_Number = this.phone.transform(phone_number);
  }
  onNoClick(): void {
    var company_Id = '';
    var company_access_id = this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      company_Id = access.company_Id
    })
    if( this.Imei_Number != ''){
      this.http.post<any>(this.configService.resourceApiURI + '/create_imei/', 
        { 
         "Device_IMEI_Number":  this.Imei_Number,
          "Phone_Number": this.Phone_Number.replace(/[^0-9]/g, ''),
         "Cell_Company":  this.selectedComp?.cell_Company_Id,
          "Cell_Plan": this.selectedPlan?.cell_Plan_Id,
          "Device_IMEI_Company_Id": company_Id
        }, 
        this.httpOptions).subscribe(result => {
        /*  this._snackBar.open("Imei created", "Close", {
            duration: 3000,
          });*/
        }, error => {
          if (error.error.text == "Not-Existed") {
            this._snackBar.open("Imei created", "Close", {
              duration: 3000,
            });
          }
          else if (error.error.text == "Existed") {
            this._snackBar.open("Imei Already Exist", "Close", {
              duration: 4000,
            });
          }
        })
    }
    this.dialogRef.close();
  }

  selChange($e){

    this.filteredPlans = this.cellPlans.filter(element => {
      if(element.cell_Plan_Company_Id == $e.value.cell_Company_Id){
        return true;
      }else{
        return false;
      }
    })
    this.selectedPlan = null;

  }
  close(){
    this.dialogRef.close();

  }

}
