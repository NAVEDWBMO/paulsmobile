import { animate, state, style, transition, trigger } from '@angular/animations';
import { CdkVirtualScrollViewport } from '@angular/cdk/scrolling';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, ElementRef, Inject, OnInit, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BehaviorSubject, EMPTY, Subject, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { AuthService } from '../core/authentication/auth.service';
import { SignalRService } from '../core/chat/signalr';
import { ConfigService } from '../shared/config.service';
import { Router, NavigationExtras } from '@angular/router';
import * as signalR from "@microsoft/signalr";
import { ChatUnsubscribeService } from '../core/chat/chat-unsubscribe';
import { Console } from 'console';

@Component({
  selector: 'app-chat-level3',
  templateUrl: './chat-level3.component.html',
  styleUrls: ['./chat-level3.component.sass', './chat-level3css.component.css'],
  animations: [
    trigger('openClose', [

      state('open', style({

        opacity: 1,
        backgroundColor: 'yellow'
      })),
      state('closed', style({

        opacity: 0.5,
        backgroundColor: 'green'
      })),
      transition('open => closed', [
        animate('1s')
      ]),
      transition('closed => open', [
        animate('0.5s')
      ]),
    ]),
  ],
})
export class ChatLevel3Component implements OnInit {

  @ViewChild('messageContainer') container: ElementRef<HTMLElement>;
  msgContainer: HTMLElement;

  @ViewChild(CdkVirtualScrollViewport)
  viewport: CdkVirtualScrollViewport;
  @ViewChild("messageinput") messageinputField: ElementRef;

  //Important info fields
  connection: string = "";
  userName = "";
  userRole = "";
  userId = "";
  company_Id: string;
  Company_Type_Id: string;
  yellowFilter: boolean = true;
  blueFilter: boolean = true;
  greenFilter: boolean = true;

  chats: any = [];
  chats_Status: any = [];
  filteredChats: any = [];
  selectedChat: any = [];
  openedChat: any = {
    messages: []
  };

  //Search
  searchValue: string = '';
  selectedTab: string = 'Rooms';

  searchMessagesContainer: boolean = false;
  foundMessages: any;

  statusChatOpened: boolean = false;
  lastStatusMessage: string = "";
  lastStatusTimeout: any;

  unreadMessagesInRooms: boolean = false;
  unreadMessagesInDrivers: boolean = false;
  unreadMessagesInOutsourced: boolean = false;


  loadingChat: boolean = false;
  loadingMessages: boolean = false;

  inHistory: boolean = false;
  endOfHistory: boolean = false;

  httpOptions: any;
  value: string = '';

  //Typing handlers
  typing: string = '';
  typingArray: string[];
  isTyping = false;
  private chatTypingSubscription: Subscription;
  term$ = new Subject<string>();
  private driverTypingSubscription: Subscription;
  driverTyping$ = new Subject<string>();
  isInEnd: any = true;
  newMessageIncoming: boolean;


  messageScope: string = "All";

  //Users handlers
  allDispatchUsers: any = [];

  //Breaks
  breakTime: number = 107;
  breakType: string = "Short";
  breakTimeSelected: number = 900;
  breakVisible: boolean = false;
  breakTimer: any;

  //TESTING


  driverInfoOpened: boolean = false;
  onlineStatusInfoOpened: boolean = true;
  driverInfo: any = {
    driver_Id: "",
    d_Id: "",
    driver_Email: "",
    driver_Firstname: "",
    driver_Lastname: "",
    driver_Phone: ""
  };

  //Critical error
  applicationCrashed: boolean = false;
  errorMessage: string = "";
  public onlineinterval1: any;
  public onlineinterval2: any;
    refreshChatsBtn: boolean = true;

  constructor(public http: HttpClient, private elementRef: ElementRef, private router: Router, private signalRService: SignalRService, private authService: AuthService, private configService: ConfigService, public dialog: MatDialog, private _snackBar: MatSnackBar,
    private chatUnsubscribeService: ChatUnsubscribeService ) {
    if (this.router.getCurrentNavigation().extras.state) {
      const UserInfo = this.router.getCurrentNavigation().extras.state.UserInfo;

      this.company_Id = UserInfo.Company_Id;
      this.userRole = UserInfo.Permission_Id;
      this.userId = UserInfo.User_Id;
      this.userName = UserInfo.User_Name;
      this.Company_Type_Id = UserInfo.Company_Type_Id;
    }
    this.authService._userCompanyAccessSelected.subscribe(access => {
      this.killTask();
    });


    this.typingArray = new Array<string>();
    this.chatTypingSubscription = this.term$.pipe(
      debounceTime(1500),
      distinctUntilChanged(),
      switchMap(term => {
        this.isTyping = false;
        this.signalRService.sendToServer("UserStoppedTyping", { userName: this.userName, user_Id: this.userId, chat_Id: this.openedChat.chat_Id });
        return EMPTY;
      })
    ).subscribe();

    this.driverTypingSubscription = this.driverTyping$.pipe(
      debounceTime(1500),
      switchMap(term => {

        this.typingArray = this.typingArray.filter(str => str != "Driver");
        this.handleTypingDisplay();

        return EMPTY;
      })
    ).subscribe();
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
  }
  ngAfterViewChecked(): void {
    if (this.newMessageIncoming) {
      this.scrollChat()
    }

    this.signalRService.onHideMessage(
      (message: any) => {
        this.chats.find(chat => chat.chat_Id == message.chat_Id).messages.find(mes => mes.message_Id == message.message_Id).message_Is_Visible = message.message_Is_Visible;
      }
    );
    //console.log("FIRED");
  }
  killTask() {

      clearInterval(this.onlineinterval1);
      this.onlineinterval1 = undefined;

      clearInterval(this.onlineinterval2);
      this.onlineinterval2 = undefined;

  }
  ngOnInit() {

    this.getChats();
    if (this.chatUnsubscribeService.subscribe_Status.value == 1) {
      this.chatUnsubscribeService.Unsubscribe_All();
    }
    this.chatUnsubscribeService.change_User_Signalr_Connection(this.userId, this.company_Id);
    this.subscribe_all();
    this.signalRService.sendToServer("GetUserList", this.company_Id);
   // this.refreshOnlinelist();

    //Task for online list
    this.onlineinterval1 = setInterval(() => {
      this.refreshOnlinelist();
     
    }, 60000);

    //Task for new chat list
    this.onlineinterval2 = setInterval(() => {
      this.getChats();

    }, 60 * 60 * 1000);



  }
  ngOnDestroy() {
    this.killTask();
  }
  refreshOnlinelist() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.company_Id
      }
    };
    this.signalRService.sendToServer("GetUserList", this.company_Id);
    if (this.searchValue?.trim() == "") {
      this.http.get<any>(this.configService.resourceApiURI + '/get_online_status/', httpOptionsTwo).subscribe(result2 => {
        this.chats = this.chats.map(chat => {
          if (chat.chat_Type == 'DRIVER' || chat.chat_Type == 'OUTSOURCEDRIVER') {
            var res = result2.find(os => { return os.chat_Id.toLowerCase() == chat.chat_Id.toLowerCase() });
            if (res != undefined) {
              chat.online_Status = res.online_Status;
            }
            //   console.log(res);

          }
          return chat;
        })
        this.organiseChatList();
      });
    }

  }
  loadChats() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.company_Id,
        User_Id: this.userId

      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_chats/', httpOptionsTwo).subscribe(result => {
      this.chats = result;

      
      //this.openedChat = {};
      this.organiseChatList();
      this.openedChat = this.chats.filter(elem => {
        if (elem.chat_Type == 'GENERAL') {
          return true
        } else {
          return false
        }
      })[0];
      setTimeout(() => {
        this.closeStatusChat();
      }, 30)

    })

  }
  getChats() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        Company_Id: this.company_Id,
        User_Id: this.userId

      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_chats/', httpOptionsTwo).subscribe(result => {
      this.chats = result;
      this.http.get<any>(this.configService.resourceApiURI + '/get_online_status/', httpOptionsTwo).subscribe(result2 => {
        this.chats = this.chats.map(chat => {
          if (chat.chat_Type == 'DRIVER' || chat.chat_Type == 'OUTSOURCEDRIVER') {
            var res = result2.find(os => { return os.chat_Id == chat.chat_Id });
            if (res != undefined) {
              chat.online_Status = res.online_Status;
            }
            //   console.log(res);

          }

          return { ...chat, new_message: false };
        })
        this.organiseChatList();

      });


    })

  }

  refreshChats() {
    this.refreshChatsBtn = false;
    this.getChats();
    setTimeout(() => {
      this.refreshChatsBtn = true;
    }, 5000)
  }
  // Properly display who is typing

  handleTypingDisplay() {
    if (this.typingArray.length == 1) {
      this.typing = this.typingArray[0] + " is typing..."
    } else if (this.typingArray.length >= 2) {
      this.typing = this.typingArray[0] + " and " + (this.typingArray.length - 1) + " other are typing..."
    } else {
      this.typing = "";
    }
  }

  //Sending notification to the server that the user is typing

  handleTypingNotification($event) {
    if (this.isTyping == false) {
      this.isTyping = true;
      this.signalRService.sendToServer("UserStartedTyping", { userName: this.userName, user_Id: this.userId, chat_Id: this.openedChat.chat_Id });
    }
    this.term$.next($event.target.value);
  }

  //Search
  search() {
  /*  if (event.key === "Enter") {*/
     /* this.searchMessagesContainer = true;
      let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        }),
        params: {
          Search_Value: this.searchValue,
          Company_Id: this.company_Id
        }
      };
      this.http.get<any>(this.configService.resourceApiURI + '/search_messages_in_chats/', httpOptions).subscribe(result => {
        this.foundMessages = result;

      })*/
      let navigationExtras: NavigationExtras = {
        state: {
          searchInfo: {
            Selected_Tab: this.selectedTab,
            Company_Id: this.company_Id,
            User_Id: this.userId


          }
        }
      };
      this.router.navigate(['chat_search'], navigationExtras);
   // }
    //this.organiseChatList();
  }

  closeSearch() {
    this.searchMessagesContainer = false;
    this.searchValue = "";
    this.organiseChatList();
  }

  //Filter by color
  toggleFilter(str) {
    if (str == "yellow") {
      this.yellowFilter = !this.yellowFilter;
    } else if (str == "blue") {
      this.blueFilter = !this.blueFilter;
    } else if (str == "green") {
      this.greenFilter = !this.greenFilter;
    }

    this.organiseChatList();
  }

  search_In_List() {

    this.filteredChats = this.chats.filter(chat => {
        if (chat.chat_Name.toLowerCase().includes(this.searchValue?.trim().toLowerCase())) {
          return true
        } else {
          return false
        }
    })
    var offlineFiletered: any[] = [];
    var onlineFiletered: any[] = this.filteredChats.filter(chat => { if (chat.online_Status == '1' || chat.online_Status == '2') { return chat; } else { offlineFiletered.push(chat) } })

    offlineFiletered = this.SortChatlist(offlineFiletered);
    onlineFiletered = this.SortChatlist(onlineFiletered);

    this.filteredChats = [...onlineFiletered, ...offlineFiletered]
      this.selectedChat = [];
      this.openedChat = {
        messages: []
      };

  }
  clearSearchField() {
    this.searchValue = "";
    this.organiseChatList();

  }
  //Sort
  organiseChatList() {
  /*  if (this.searchValue != '' && this.searchMessagesContainer != true) {
      this.filteredChats = this.chats.filter(chat => {
        if (chat.chat_Name.includes(this.searchValue)) {
          return true
        } else {
          return false
        }
      })
    } else*/
    if (this.searchValue?.trim() == '') {
      this.filteredChats = this.chats.filter(chat => {
        if (this.yellowFilter && chat.chat_Level == 2) {
          return true
        } else if (this.blueFilter && chat.chat_Level == 1) {
          return true
        } else if (this.greenFilter && chat.chat_Level == 0) {
          return true
        } else {
          return false
        }
      })

      if (this.filteredChats.length > 1) {

        var offlineFiletered: any[] = [];
        var onlineFiletered: any[] = this.filteredChats.filter(chat => { if (chat.online_Status == '1' || chat.online_Status == '2') { return chat; } else { offlineFiletered.push(chat) } })

        offlineFiletered = this.SortChatlist(offlineFiletered);
        onlineFiletered = this.SortChatlist(onlineFiletered);

        this.filteredChats = [...onlineFiletered, ...offlineFiletered]


        /*
              this.filteredChats.sort((a, b) => Date.parse(a.last_Time) < Date.parse(b.last_Time) ? 1 : -1);
              var chatlevel1 = [];
              var Chatlevels = this.filteredChats.reduce((acc, curr) => {
                if (curr.chat_Level === 1) {
                  chatlevel1.push(curr)
                } else {
                  acc.push(curr)
                }
                return acc;
              }, []).sort((a, b) => a.chat_Level < b.chat_Level ? 1 : -1);
        
              chatlevel1.forEach((item, index) => {
                Chatlevels.unshift(item)
              });
              this.filteredChats = Chatlevels.sort((a, b) => a.online_Status > b.online_Status ? 1 : 0);
        */

        //this.filteredChats.sort((a, b) => a.assignedId == this.userId || a.assignedId == "ME" ? -1 : 0);

      }

    }
  }
  SortChatlist(list: any[]) {

    list.sort((a, b) => Date.parse(a.last_Time) < Date.parse(b.last_Time) ? 1 : -1);
    var chatlevel1 = [];
    var Chatlevels = list.reduce((acc, curr) => {
      if (curr.chat_Level === 1) {
        chatlevel1.push(curr)
      } else {
        acc.push(curr)
      }
      return acc;
    }, []).sort((a, b) => a.chat_Level < b.chat_Level ? 1 : -1);

    chatlevel1.forEach((item, index) => {
      Chatlevels.unshift(item)
    });
   // this.filteredChats = Chatlevels.sort((a, b) => a.online_Status < b.online_Status ? 1 : 0);
    return Chatlevels;
  }
  onScroll(event) {

    if (!this.loadingChat) {
      if (this.container?.nativeElement.scrollHeight > this.container?.nativeElement.scrollTop + 800) {
        this.inHistory = true;
      } else {
        this.inHistory = false;
      }
      if (!this.endOfHistory && this.openedChat.chat_Type != "STATUS") {
        if (this.container?.nativeElement.scrollTop < 30) {

          if (!this.loadingMessages) {

            this.loadingMessages = true;

            let httpOptions = {
              headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': this.authService.authorizationHeaderValue
              }),
              params: {
                Chat_Table: this.openedChat.chat_Table,
                Last_Message_Id: this.openedChat.messages[0]?.message_Id
              }
            };

            this.http.get<any>(this.configService.resourceApiURI + '/get_messages_from_history/', httpOptions).subscribe(result => {

              this.container.nativeElement.scrollTo({
                top: 2
              })
              result.forEach(element => {
                this.openedChat.messages = [element, ...this.openedChat.messages];
              });


              if (result.length < 10) {
                this.endOfHistory = true;
              }

              setTimeout(() => {
                this.loadingMessages = false;
              }, 500);

            })
          }
        }
      }

    }

  }


  scrollToBottomBtnHandler() {
    this.inHistory = false;
    this.scrollChat();

  }

  //loading messages for the specific chat
  loadChat() {
    this.selectedChat[0] = this.openedChat;
    this.searchMessagesContainer = false;
    this.driverInfoOpened = false;
    this.onlineStatusInfoOpened = true;
    this.inHistory = false;
    this.endOfHistory = false;
    this.loadingChat = true;
    if (this.openedChat.messages.length > 30) {
      this.openedChat.messages = this.openedChat.messages.slice(this.openedChat.messages.length - 30)
    }

    this.openedChat.messages = this.chats.find(chat => chat.chat_Id === this.openedChat.chat_Id).messages;
    if (this.openedChat.messages.length < 20) {
      this.endOfHistory = true;
    }

    setTimeout(() => {
      this.loadingNewChat();
    }, 50)
    setTimeout(() => {
      this.loadingChat = false;
    }, 500);
  }
  loadingNewChat() {
    this.inHistory = false;
    this.endOfHistory = false;
    this.loadingChat = true;
    setTimeout(() => {
      this.loadingChat = false;
    }, 500);
    this.scrollChat();
  }
  //Sending a message
  check_send_message() {

    if (this.value != '' && (this.messageScope == "Broadcast" || this.messageScope == "TextToPhoneBroadcast")) {

      const dialogRef1 = this.dialog.open(BroadcastMsg3Dialog, {
        data: {
        text_message: "Do you want to send broadcast message ?" },
        disableClose: true,
        width: '435px',
        panelClass: 'custom-bm-dialog',
        autoFocus: false
      });
      dialogRef1.afterClosed().subscribe(result => {
        if (result == "confirmed") {
          this.sendMessage();
        }
      });
    } else {

      this.sendMessage();

    }

  }

  sendMessage() {

    if (this.value != '') {
      var isSendTophone = false;
      var isBroadcastTophone = false;
      let message = this.value.replace(/'/g, '"');
      if (this.messageScope == "AllTextToPhone") {
       // this.messageScope = "AllTextToPhone";
        isSendTophone = true;
      }
      if (this.messageScope == "TextToPhoneBroadcast") {
        // this.messageScope = "AllTextToPhone";
        isBroadcastTophone = true;
      }
      let mes: MessageModel = {
        from_User_Id: this.userId,
        message_Text: message,
        chat_Id: this.openedChat.chat_Id,
        message_Date: new Date().toISOString(),
        message_From_User_Role: this.userRole,
        chat_Table: this.openedChat.chat_Table,
        message_From_User_Name: this.userName,
        message_Is_Visible: true,
        message_To_Group: this.messageScope
      };

      this.value = '';
      if (this.messageScope == "Broadcast") {
        let chatIds = [];
        let chatTable = [];

        if (this.selectedTab == 'Rooms') {
          this.chats.forEach(element => {
            if (element.chat_Type != 'DRIVER' && element.chat_Type != 'OUTSOURCEDRIVER') {
              chatIds.push(element.chat_Id);
              chatTable.push(element.chat_Table)
            }
          });
          this.signalRService.sendToServer("BroadcastRoomsMessage", { 'Chat_Ids': chatIds, 'Chat_Tables': chatTable, 'Message': mes });

        }
        else if (this.selectedTab == 'Drivers') {
          this.chats.forEach(element => {
            if (element.chat_Type == 'DRIVER') {
              chatIds.push(element.chat_Id);
              chatTable.push(element.chat_Table)
            }
          });
          this.signalRService.sendToServer("BroadcastDriversMessage", { 'Chat_Ids': chatIds, 'Chat_Tables': chatTable, 'Message': mes });

        }
        else if (this.selectedTab == 'Outsourced') {
          this.chats.forEach(element => {
            if (element.chat_Type == 'OUTSOURCEDRIVER') {
              chatIds.push(element.chat_Id);
              chatTable.push(element.chat_Table)
            }
          });
          this.signalRService.sendToServer("BroadcastDriversMessage", { 'Chat_Ids': chatIds, 'Chat_Tables': chatTable, 'Message': mes });

        }
      } else if (isBroadcastTophone) {
        let chatIds = [];
        let chatTable = [];
        mes.message_To_Group = "TextToPhoneBroadcast";
        this.chats.forEach(element => {

          if (element.chat_Type == 'DRIVER') {

            chatIds.push(element.chat_Id);
            chatTable.push(element.chat_Table)
          }
        });
        this.signalRService.sendToServer("BroadcastDriversMessage", { 'Chat_Ids': chatIds, 'Chat_Tables': chatTable, 'Message': mes });

        this.BroadcastToPhone(message);
      } else {
        this.signalRService.sendToServer("MessageToServer", mes);
        this.openedChat.messages = [...this.openedChat.messages, mes]
      }
      this.messageScope = "All"
      this.signalRService.sendToServer("UserStoppedTyping", { userName: this.userName, user_Id: this.userId, chat_Id: this.openedChat.chat_Id });
      this.inHistory = false;
      this.scrollChat();
      if (isSendTophone) {
        this.sendToPhone(message);
      }
   
    }

  }

  sendToPhone(message) {
    this.http.post<any>(this.configService.resourceApiURI + '/textflow-send-sms/',
      {
        "Chat_Id": this.openedChat.chat_Id,
        "Company_Id": this.company_Id,
        "Message": message,

      },
      this.httpOptions).subscribe(result => {
        this._snackBar.open("Message Sent.", "Close", {
          duration: 2000,
        });
      }, (error) => {
        this._snackBar.open(error.error, "Close", {
          duration: 4000,
        })
      });
  }

  BroadcastToPhone(message) {
    this.http.post<any>(this.configService.resourceApiURI + '/textflow-broadcast-sms/',
      {
        "Company_Id": this.company_Id,
        "Message": message,
        "Chat_Type": this.selectedTab

      },
      this.httpOptions).subscribe(result => {
        this._snackBar.open("Message Sent.", "Close", {
          duration: 2000,
        });
      }, (error) => {
        this._snackBar.open(error.error, "Close", {
          duration: 4000,
        })
      });
  }


  scrollChat() {
    try {
      if (this.openedChat.messages?.length > 0) {
        requestAnimationFrame(() => {

          this.container?.nativeElement.scrollBy({
            top: 99999999
          });

        });
      }

    } catch {

    }

  }

  //Hide message
  hideMessage(mes) {
    mes.message_Is_Visible = !mes.message_Is_Visible;
    this.signalRService.sendToServer("HideMessage", mes);

  }
  /*
   readMessagesInRooms(){
     this.unreadMessagesInRooms = false;
   }
   readMessagesInDrivers(){
    this.unreadMessagesInRooms = false;
  }*/
  // Mark the task as closed (blue)

  markChatAsClosed(code) {
    if (this.selectedChat.length > 0) {
      this.signalRService.sendToServer("SetChatLevelAsClosed", { chat_Id: this.openedChat.chat_Id, chat_Level: code, User_Id: this.userId });
      this.openedChat.chat_Level = code;
    }

    /*  var chat = this.chats.find(chat => chat.chat_Id.toLowerCase() === this.openedChat.chat_Id.toLowerCase());
    */ // clearInterval(chat.interval);
  }

  // On click in list load new chat
  loadNewChat(event) {
    this.messageScope = "All";
    this.messageinputField.nativeElement.focus();
    this.statusChatOpened = false;
    if (event[0]) {
      this.openedChat = event[0];
      this.openedChat.new_message = false;
      //console.log(this.openedChat);
    }

    this.signalRService.sendToServer("UserStoppedTyping", { userName: this.userName, user_Id: this.userId, chat_Id: this.openedChat.chat_Id });
    this.loadChat();

  }

  //Opening general chat
  openStatusChat() {
    if (this.statusChatOpened == true) {
      this.closeStatusChat();
    } else {
      this.statusChatOpened = true;
      this.selectedChat = [];
      this.openedChat = this.chats.filter(chat => chat.chat_Type == "STATUS")[0];
      this.scrollChat();

    }
  }

  closeStatusChat() {
    this.onlineStatusInfoOpened = false;

    /*this.statusChatOpened = false;
    this.openedChat = this.chats.filter(chat => chat.chat_Type == "GENERAL")[0];
    setTimeout(() => {
      this.scrollChat();
    }, 10)*/


  }
  selectCompany($e) {
    this.chats = [];
    this.filteredChats = [];
    this.openedChat = {
      messages: []
    };


    this.loadChats();
  }
  // Open dialogs



  openCreateChatDialog(): void {
    /*  const dialogRef = this.dialog.open(ChatLevel2ControlDialog, {
        
      });
  
      dialogRef.afterClosed().subscribe(result => {
      });*/
  }
  openAssignDialog(): void {
    /*   let assignedToMe;
       if(this.openedChat.assignedId == this.userId){
         assignedToMe = true;
       }else{
         assignedToMe = false;
       }
   
       let users = this.allDispatchUsers;
   
       const dialogRef = this.dialog.open(ChatLevel2AssignDialog, {
         data: {chat_Id: this.openedChat.chat_Id, assignedToMe: assignedToMe, usersOnline: users, userId: this.userId}
       });
   
       dialogRef.afterClosed().subscribe(result => {
         this.organiseChatList();
       });*/
  }

  openDialog(event, message): void {

    const dialogRef = this.dialog.open(ChatContainer3Dialog, {
      data: { latitude: message.message_Latitude, longitude: message.message_Longitude }
    });

    dialogRef.afterClosed().subscribe(result => {
    });

  }

  openImagesDialog(): void {
    const dialogRef = this.dialog.open(ImagesContainer3Dialog, {
      data: { test: 1 }
    });
  }

  openDriverChatImagesDialog(imglink): void {
    const dialogRef = this.dialog.open(DriverChatImage3Dialog, {
      data: { imgLink: imglink, Chat_Id: this.openedChat.chat_Id, Company_Id: this.company_Id }
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }

  //Breaks

  startBreak(number) {
    //clearTimeout(this.idleTimeout);
    if (number == 5) {
      this.breakType = "Short";
      this.breakTimeSelected = 300;
    } else if (number == 30) {
      this.breakType = "Lunch";
      this.breakTimeSelected = 1800;
    } else if (number == 60) {
      this.breakType = "Meeting";
      this.breakTimeSelected = 3600;
    } else if (number == -1) {
      this.breakType = "Indefinite";
      this.breakTimeSelected = -1;
    }
    this.breakTime = 0;
    this.breakTimer = setInterval(() => {
      this.breakTime++;
    }, 1000)

    this.signalRService.sendToServer("StartBreak", { User_Id: this.userId, Role_Id: this.userRole, Company_Id: this.company_Id  });
    this.breakVisible = true;
  }

  finishBreak() {
    this.breakVisible = false;
    clearInterval(this.breakTimer);
    this.signalRService.sendToServer("EndBreak", { User_Id: this.userId, Role_Id: this.userRole, Company_Id: this.company_Id });
    // this.idleTimeout = setTimeout(() => {
    //   this.timeoutUser();
    // }, this.idleTime)
  }

  openDriverInfo(driverId) {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        User_Id: driverId,
      }
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_driver_info_for_chat/', httpOptions).subscribe(result => {
      this.driverInfo = result;
      this.driverInfoOpened = true;

    })

  }

  closeDriverInfo() {
    this.driverInfoOpened = false;
  }

  timeoutUser() {
    this.signalRService.timeoutUser();
    this.applicationCrashed = true;
    this.errorMessage = "You have been inactive for too long!"
    this.authService._userName.next("error");
  }

  refresh(): void {
    window.location.reload();
  }
  trackChatMessage(index: number, chatMessage: MessageModel) {
    return chatMessage.message_Text;
  }
  newMessage() {
    //console.log('inside new message');
    this.newMessageIncoming = true;
    setTimeout(() => {
      this.newMessageIncoming = false;
    }, 1000);
  }
  //loadChats
  onTabSelect(e) {

    this.selectedTab = e.title;
    this.selectedChat = [];
    this.openedChat = {
      messages: []
    };

    if (e.title == "Drivers") {
      this.unreadMessagesInDrivers = false;

    }
    else if (e.title == "Rooms") {
      this.unreadMessagesInRooms = false;

    } else if (e.title == "Outsourced") {
      this.unreadMessagesInOutsourced = false;

    }
    if (this.searchValue?.trim() != "") {
      this.searchValue = "";
      this.search_In_List();
    }
  }

  subscribe_all() {

    //Handler for receiving new messages
    this.signalRService.getMessage(
      (message: any) => {
        //console.log(message);
        //var chat_Id = "";

        if (message.from_User_Id != this.userId) {
          //  var msg = message.chat_Table.split('_');
          // chat_Id = msg[msg.length - 1].toLowerCase();
          // message.chat_Id = chat_Id;
          var chat = this.chats.filter(chat => { if (chat.chat_Id.toLowerCase() === message.chat_Id.toLowerCase()) { return chat; } });
          if (chat.length > 0) {
            chat[0].messages.push(message)
            chat[0].new_message = true;

            if (this.openedChat.chat_Id != undefined) {

              if (this.openedChat.chat_Id == message.chat_Id.toLowerCase()) {
                chat[0].new_message = false;

                setTimeout(() => {
                  this.newMessage();
                  this.loadChat();
                }, 400)

              }

            }
            if (chat[0].chat_Type == 'CUSTOM' || chat[0].chat_Type == 'GENERAL') {
              if (this.selectedTab != 'Rooms') {
                this.unreadMessagesInRooms = true;
              }
            }
            else if (chat[0].chat_Type == 'DRIVER') {
              if (this.selectedTab != 'Drivers') {
                this.unreadMessagesInDrivers = true;
              }
            } else {
              if (chat[0].chat_Type == 'OUTSOURCEDRIVER') {
                if (this.selectedTab != 'Outsourced') {
                  this.unreadMessagesInOutsourced = true;
                }
              }
            }

            if (message.message_From_User_Role.toLowerCase() == '352c54b4-cbdb-406a-b0d2-9e05544198e4' && chat[0].online_Status == "0") {
              this.refreshOnlinelist();
            } else {
              this.organiseChatList();
            }
          }


        } else {
        //  console.log(message);
          this.openedChat.messages.find(mess => mess.message_Text == message.message_Text && mess.message_Id == null).message_Id = message.message_Id;
          this.openedChat.messages = [...this.openedChat.messages];
        //   console.log(message);

        }

        if (message.chat_Id == this.openedChat.chat_Id) {
          if (!this.inHistory) {
            this.scrollChat();

          }
        }
      }
    );


    //Typing methods

    this.signalRService.onStartedTyping(
      (typing: any) => {
        if (typing.chat_Id == this.openedChat.chat_Id && typing.user_Id != this.userId) {
          this.typingArray.push(typing.username);
          this.handleTypingDisplay();
        }
      }
    );
    this.signalRService.onStoppedTyping(
      (typing: any) => {
        this.typingArray = this.typingArray.filter(str => str != typing.username);
        this.handleTypingDisplay();
      }
    );
    this.signalRService.onCurrentUsersOnlineList(
      (Users: any) => {
        this.allDispatchUsers = Users;
      }
    );
    this.signalRService.onSetChatLevel(
      (chat_Id: any, level: any, user_Name: any, last_Time: any) => {

        var chat = this.chats.find(chat => chat.chat_Id.toLowerCase() === chat_Id.toLowerCase());
        //console.log(chat)
        if (chat) {
          chat.chat_Level = level;
          chat.user_Name = user_Name;
          chat.last_Time = last_Time;
          this.organiseChatList();
          /*  if(level == 2){
              clearInterval(chat.interval);
              chat.timer = 30;
              chat.interval = setInterval(() => {
                chat.timer--;
              },1000)
            }else {
              chat.timer = "";
              clearInterval(chat.interval);
            }*/
        }
      }
    );

    this.signalRService.onDriverTyping(
      (typing: any) => {
        /*  if(typing.chat_Id == this.openedChat.chat_Id){
            if(!this.typingArray.includes("Driver")){
              this.typingArray.unshift("Driver")
            }
     
            this.driverTyping$.next();
            this.handleTypingDisplay();
          }*/

      }
    );

    this.signalRService.onBroadcastMessage(
      (broadcast: any) => {

        this.chats.forEach(chat => {
          if (broadcast.chat_Ids.includes(chat.chat_Table)) {
            chat.messages = [...chat.messages, broadcast.message]
          }
        });
        this.openedChat.messages = [...this.openedChat.messages];

      }
    );
    this.signalRService.onBroadcastRoomsMessageRecevied(
      (broadcast: any) => {
        this.chats.forEach(chat => {
          if (broadcast.chat_Ids.includes(chat.chat_Id)) {
            chat.messages = [...chat.messages, broadcast.message]
          }
        });
        this.openedChat.messages = [...this.openedChat.messages];

      }
    );

    this.signalRService.onBroadcastDriversMessageRecevied(
      (broadcast: any) => {
        this.chats.forEach(chat => {
          if (broadcast.chat_Ids.includes(chat.chat_Id)) {
            chat.messages = [...chat.messages, broadcast.message]
          }
        });
        this.openedChat.messages = [...this.openedChat.messages];
        //console.log(this.openedChat.messages);
      }
    );

    this.signalRService.onClosedConnection(
      (mes) => {
        if (!this.applicationCrashed) {
          this.applicationCrashed = true;
          this.errorMessage = "You lost connection to the server";
          this.authService._userName.next("error");

        }
      }
    )



   /* this.signalRService.onCurrentUsersOnlineList(
      (list) => {
        this.allDispatchUsers.forEach(user => {
          user.status = "Offline";
        })

        list.forEach(onlineUser => {
          this.allDispatchUsers.forEach(user => {
            if (user.user_Id == onlineUser.user_Id) {
              user.status = onlineUser.status
            }
          });
        });
      }
    );*/
    this.signalRService.onUserStatusUpdate(
      (md) => {

        if (this.company_Id == md.company_Id) {

          var chat = this.chats.find(chat => chat.chat_Type == "STATUS");
          if (chat) {
            chat.messages = [...chat.messages, {
              from_User_Id: md.message.from_User_Id,
              message_From_User_Role: md.message.message_From_User_Role,
              message_From_User_Name: md.message.message_From_User_Name,
              message_Text: md.message.message_Text,
              chat_Id: md.message.chat_Id,
              message_Date: md.message.message_Date
            }];

          }
          this.scrollChat();

        }


      }

    );
    this.signalRService.onUpdateChats(
      (typing: any) => {
        setTimeout(() => {

          this.loadChats();
        }, 1000)


      }
    );
    this.signalRService.RefreshDispacthers(
      (typing: any) => {

        this.signalRService.sendToServer("GetUserList", this.company_Id);

      }
    );
    // Buttons functionality

    this.signalRService.onHideMessage(
      (message: any) => {
        this.chats.find(chat => chat.chat_Id == message.chat_Id).messages.find(mes => mes.message_Id == message.message_Id).message_Is_Visible = message.message_Is_Visible;
      }
    );
    this.signalRService.onAssignChatToDispatch(
      (am: any) => {
        let check = false;
        am.user_Ids.forEach(element => {
          if (element == this.userId) {
            check = true;
          }
        });
        if (check) {
          let chat = this.chats.find(chat => chat.chat_Id === am.chat_Id);
          if (chat) {
            chat.assignedId = this.userId;
          }
        }

      }
    );
    this.signalRService.onReleaseAssignedChat(
      (chat_Id: any) => {
        let chat = this.chats.find(chat => chat.chat_Id === chat_Id);
        chat.assignedId = null;

      }
    );
    this.chatUnsubscribeService.subscribe_Status.next(1);
  }




}





@Component({
  selector: 'chat-level3-control',
  templateUrl: 'chat-level3-control.html',
  styleUrls: ['./chat-level3.component.sass']
})
export class ChatLevel3ControlDialog {

  /*nameValue: string = '';
  
  chats: any[] = [];
  
  
  rolesLst: any[] = [];
  
  selRoles: any[] = [];
  
  selectedChat: any = [];
  
  chatRolesSelected : any[] = [];
  
  
  chatCreation: boolean = false;
  selectedCompany = new FormControl();
  companies: any[] = [];
  newChatName = new FormControl();
  
  httpOptions: any
    chatsLst: any;*/

  constructor(
    public dialogRef: MatDialogRef<ChatLevel3ControlDialog>, public http: HttpClient, private authService: AuthService, private configService: ConfigService, public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    /*  const  httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
      };

    this.http.get<any>(this.configService.resourceApiURI + '/get_roles/', httpOptions).subscribe(result => {
      let notDisplayed = [];
      notDisplayed.push("Driver");
      notDisplayed.push("Admin");
      this.rolesLst = result.filter((elem) => {
        return !notDisplayed.includes(elem.role_Name)
      } );
    })
    
    this.http.get<any>(this.configService.resourceApiURI + '/get_companies/', httpOptions).subscribe(result => {
      this.companies = result;
    })*/

  }

  /*   selectCompany($e){
       
       let httpOptions = {
         headers: new HttpHeaders({
           'Content-Type':  'application/json',
           'Authorization': this.authService.authorizationHeaderValue
         }),
         params: {
           company_Id: $e.company_Id
         }       
       };
       this.http.get<any>(this.configService.resourceApiURI + '/get_chats_for_chat_control/', httpOptions).subscribe(result => {
         
         let chatsLst = [];
         result.forEach(element => {
           if(element.chat_Type != 'STATUS' && element.chat_Type != 'DRIVER' ){
             chatsLst.push(element);
           }
         });
         this.chats = chatsLst.sort((a, b) => {
           if(a.chat_Status == true){
             return -1
           }else{
             return 1
           }
         } );
       })
     }
 
 
     selectChat($e){
 
       if(this.selectedChat[0]?.chat_Type == 'CUSTOM'){
         let selectedRoles = [];
         this.selectedChat[0].roles.forEach(chR => {
           this.rolesLst.forEach(rol => {
             if(chR.toLowerCase() == rol.role_Id.toLowerCase()){
               selectedRoles.push(rol);
             }
           });
         });
         this.chatRolesSelected = selectedRoles;
       }
       
 
     }*/

  /*disableChatClick(){
    const dialogRef = this.dialog.open(ConfirmActionDialog, {
      
    });
    dialogRef.afterClosed().subscribe(result => {

      if(result == true){
        const  httpOptions = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.post<any>(this.configService.resourceApiURI + '/disable_chat/', 
        { 
            "Chat_Id": this.selectedChat[0].chat_Id,
            "Chat_Type": this.selectedChat[0].chat_Type,
            
        }, 
        httpOptions).subscribe(result => {
          this.selectedChat[0].chat_Status = false;
          
        })
        this.chats = this.chats.sort((a, b) => {
          if(a.chat_Status == true){
            return -1
          }else{
            return 1
          }
        } );
      }
    });
  }

  enableChatClick(){
    const dialogRef = this.dialog.open(ConfirmActionDialog, {
      
    });
    dialogRef.afterClosed().subscribe(result => {

      if(result == true){
        const  httpOptions = {
          headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          })
        };
        this.http.post<any>(this.configService.resourceApiURI + '/enable_chat/', 
        { 
            "Chat_Id": this.selectedChat[0].chat_Id,
            "Chat_Type": this.selectedChat[0].chat_Type,
            
        }, 
        httpOptions).subscribe(result => {
          this.selectedChat[0].chat_Status = true;

    
        })
  
      }
    });
  }*/

  /* editChatRoles(){
     let rolesSelected = [];
     this.chatRolesSelected.forEach(elem => {
       rolesSelected.push(elem.role_Id);
     })

     const  httpOptions = {
       headers: new HttpHeaders({
         'Content-Type':  'application/json',
         'Authorization': this.authService.authorizationHeaderValue
       })
     };
     this.http.post<any>(this.configService.resourceApiURI + '/edit_chat_roles/', 
     { 
         "Chat_Id": this.selectedChat[0].chat_Id,
         "Roles": rolesSelected
     }, 
     httpOptions).subscribe(result => {
       this.newChatName.setValue("");
       this.selRoles = [];
 
     })

   }
*/
  onNoClick(): void {
    this.dialogRef.close();
  }

  /*createNewChat(){
    this.chatCreation = true;
  }
  backToChatList(){
    this.chatCreation = false;

  }

  createChat(){

    var chatRoles = new Array;
    this.selRoles.forEach(elem => {
      chatRoles.push(elem.role_Id);
    })

    const  httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/create_custom_chat/', 
    { 
        "Chat_Name": this.newChatName.value,
        "Chat_Company": this.selectedCompany.value.company_Id,
        "Chat_Roles": chatRoles
    }, 
    httpOptions).subscribe(result => {
      this.newChatName.setValue("");
      this.selRoles = [];

    })
    this.chatCreation = false;
    let httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {
        company_Id: this.selectedCompany.value.company_Id
      }       
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_chats_for_chat_control/', httpOptionsTwo).subscribe(result => {
      let chatsLst = [];
        result.forEach(element => {
          if(element.chat_Type != 'STATUS' && element.chat_Type != 'DRIVER' ){
            chatsLst.push(element);
          }
        });
        this.chats = chatsLst;
    })
    
  }*/

}




@Component({
  selector: 'chat-level3-assign-dialog',
  templateUrl: 'chat-level3-assign-dialog.html',
  styleUrls: ['./chat-level3.component.sass']
})
export class ChatLevel3AssignDialog {


  userLst: any[] = [];
  rolesLst: any[] = [];

  selUsers: any[] = [];
  selRoles: any[] = [];



  public chat_Id: string;

  public assignedToMe;
  userId: any;

  constructor(
    public dialogRef: MatDialogRef<ChatLevel3ControlDialog>, public http: HttpClient, private signalRService: SignalRService, private authService: AuthService, private configService: ConfigService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.chat_Id = data.chat_Id;
    this.assignedToMe = data.assignedToMe;
    this.userLst = data.usersOnline;
    this.userId = data.userId;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

    //On load receive the available chats
    this.http.get<any>(this.configService.resourceApiURI + '/get_roles/', httpOptions).subscribe(result => {
      let notDisplayed = [];
      notDisplayed.push("Driver");
      this.rolesLst = result.filter((elem) => {
        return !notDisplayed.includes(elem.role_Name)
      });
    })
  }

  selectRole(role) {
    let selUsersOld = this.selUsers;

    if (this.selRoles.includes(role)) {
      this.selUsers = this.userLst.filter(user => {
        if (selUsersOld.includes(user)) {
          return true;
        }
        if (user.user_Role == role.role_Id) {
          return true;
        } else {
          return false;
        }
      });

    } else {
      this.selUsers = this.userLst.filter(user => {
        if (selUsersOld.includes(user)) {
          if (user.user_Role == role.role_Id) {
            return false;
          } else {
            return true
          }
        } else {
          return false
        }
      });
    }

    this.userLst.sort((a, b) => {
      if (this.selUsers.includes(a)) {
        return -1
      }
      if (this.selUsers.includes(b)) {
        return 1
      } else {
        return 0
      }

    })



  }

  assignToDispatch() {

    let selIds = [];

    this.selUsers.forEach(element => {
      selIds.push(element.user_Id)
    });

    this.signalRService.sendToServer("AssignChatToDispatch", { Chat_Id: this.chat_Id, User_Ids: selIds });

  }

  releaseAssign() {

    this.signalRService.sendToServer("ReleaseAssignedChat", { Chat_Id: this.chat_Id, User_Ids: [this.userId] });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}


@Component({
  selector: 'map-dialog',
  templateUrl: 'map-dialog.html',
})
export class ChatContainer3Dialog {

  zoom = 15;
  center = {
    lat: 43.643455,
    lng: -79.628178,
  }
  constructor(
    public dialogRef: MatDialogRef<ChatContainer3Dialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.center = {
      lat: parseFloat(data.latitude),
      lng: parseFloat(data.longitude)
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}



@Component({
  selector: 'images-dialog',
  templateUrl: 'images-dialog.html',
})
export class ImagesContainer3Dialog {

  imgs: any = []

  constructor(
    public dialogRef: MatDialogRef<ChatContainer3Dialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    let todayDate = Date.now();
    let startDate = Date.parse('12-01-2020');
    for (let i = 0; i < 30; i++) {
      this.imgs.push({ date: this.randomDate(startDate, todayDate) })
    }

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  randomDate(start, end) {
    var date = new Date(+start + Math.random() * (end - start));
    return date;
  }

}

@Component({
  selector: 'driver-chat-image-dialog',
  templateUrl: 'driver-chat-image-dialog.html',
})
export class DriverChatImage3Dialog {

   User_Id = "";
  constructor(public dialogRef: MatDialogRef<DriverChatImage3Dialog>, @Inject(MAT_DIALOG_DATA) public data: any, private http: HttpClient, private authService: AuthService, private configService: ConfigService) {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),
      params: {

        Chat_Id: this.data.Chat_Id

      }
    };

    this.http.get<any>(this.configService.resourceApiURI + '/get_driver_by_chat_Id/', httpOptions).subscribe(result => {
      this.User_Id = result.User_Id;
      
    })
  }
  downloadImage(): void {

    var filepaths = [];
    const lastIndex = this.data.imgLink.lastIndexOf('/');
    const secondLastIndex = this.data.imgLink.lastIndexOf('/', lastIndex - 1);

    filepaths.push(this.data.Company_Id + '/' + this.User_Id + '/' + this.data.imgLink.substr(secondLastIndex + 1))
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }),

    };
    //  this.spinner.show();

    this.http.post<any>(this.configService.resourceApiURI + '/get_driver_ftp_files_images/', {
      filepaths: filepaths
    }, httpOptionsTwo)
      .subscribe(result => {
        //  console.log(result);
        result.map((elem) => {
          var a = document.createElement("a");
          a.href = "data:image/png;base64," + elem.image;
          a.download = elem.fileName;
          a.click();
        })
      })


  /*  this.http.get(this.data.imgLink, { responseType: 'blob' }).subscribe(
      (data) => this.downloadBlob(data),
      (error) => console.error('Error downloading image:', error)
    );*/
  }
 /* private downloadBlob(blob: Blob): void {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = this.data.imgLink.substr(this.data.imgLink.lastIndexOf("/") + 1);
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  }*/

}


@Component({
  selector: 'broadcast-message-dialog',
  templateUrl: 'broadcast-message-dialog.html',
  styleUrls: ['./chat-level3.component.sass', './chat-level3css.component.css'],
})

export class BroadcastMsg3Dialog {
  public dataItem: any;


  constructor(private _snackBar: MatSnackBar, public http: HttpClient, private dialog: MatDialog, 
    public dialogRef: MatDialogRef<BroadcastMsg3Dialog>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
    this.dataItem = data;
  }


  SendBroadcast(): void {
    this.dialogRef.close("confirmed");

  }


}








export interface Chat {
  chat_Id: string;
  chat_Name: string;
  chat_Level: string;
}

export interface MessageModel {
  message_Id?: any;
  from_User_Id: string;
  message_From_User_Role?: string;
  message_From_User_Name?: string;
  message_Text: string;
  chat_Id: string;
  message_Date?: any;
  message_Latitude?: string;
  message_Longitude?: string;
  chat_Table: string;
  message_Is_Visible: boolean;
  message_To_Group: string;
}

