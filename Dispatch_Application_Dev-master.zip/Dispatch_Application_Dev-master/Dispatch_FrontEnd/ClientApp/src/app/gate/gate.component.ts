import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output, OnChanges, ViewChild, Inject } from '@angular/core';

import { FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { isFilterable } from '@progress/kendo-angular-grid/dist/es2015/filtering/filterable';
import { Console } from 'console';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { AuthService } from '../core/authentication/auth.service';
import { ConfigService } from '../shared/config.service';
import { LineupComponent } from '../lineup/lineup.component';
import { InGateComponent } from '../ingate/ingate.component';
import { OutGateComponent } from '../outgate/outgate.component';
import { SignalRService } from '../core/chat/signalr';
import * as signalR from "@microsoft/signalr";
@Component({
  selector: 'app-Gate',
  templateUrl: './gate.component.html',
  styleUrls: ['./gate.component.sass']
})
export class GateComponent implements OnInit {
  

  httpOptions: { headers: any; };
  @ViewChild('lineup') child: LineupComponent;
  @ViewChild('ingate') child1: InGateComponent;
  @ViewChild('outgate') child2: OutGateComponent;


  constructor(public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {

  }
  
  ngOnInit(): void {
   
  }
  refreshAllList() {
    this.child.refresh();
    this.child1.refresh();
    this.child2.refresh();
  }

}


@Component({
  selector: 'pickup-request-dialog',
  templateUrl: 'pickup-request-dialog.html',
  styleUrls: ['./gate.component.sass']
})
export class PickupRequestDialog {
  pickup_Number = "";
  lanePositions: any[] = [];
  selectedPosition = [];
  httpOptions: { headers: any; params: any };
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  public datPerson = [];
  public ditPerson = [];
  public dotPerson = [];

  Company_Id = "";

  constructor(
    public dialogRef: MatDialogRef<PickupRequestDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar, public dialog: MatDialog, private signalRService: SignalRService, public http: HttpClient, private configService: ConfigService, private authService: AuthService,) {
    dialogRef.disableClose = true;
    this.authService.userInfoStatus$.subscribe(userinfo => { this.user_id = userinfo.user_Id; this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name })
    var chat_Permissions: any;
    this.authService._userCompanyAccessSelected.subscribe(access => { this.Company_Id = access?.company_Id; });

    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });

    this.sendmessage();

  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  sendmessage() {
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }), params: {

        "Company_Id": this.Company_Id
      }

    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_gate_driver_info/', this.httpOptions).subscribe(result => {
      result.map(ele => {
        if (ele.role_Id.toUpperCase() == 'DD17B764-5D41-4774-91CD-73117E59B65A') {
          this.ditPerson.push(ele);

        } else if (ele.role_Id.toUpperCase() == '389FF47B-5057-466A-AD97-6489832C2444') {
          this.datPerson.push(ele);
        }
        else if (ele.role_Id.toUpperCase() == '89342125-00EE-4A78-9807-B1ABC6C68478') {
          this.dotPerson.push(ele);
        }
      })
      if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
        let message = "Send Pickup Number For Driver " + this.data.driver_Number + ", Refresh List";

        if (this.data.gate_Status == 'LINEUP' && this.datPerson.length != 0) {
          this.datPerson.map(ele => {
            let mes: MessageModel = {
              from_User_Id: this.user_id,
              message_Text: message,
              chat_Id: ele["chat_Id"],
              message_Date: new Date().toISOString(),
              message_From_User_Role: this.Permission_Id,
              chat_Table: ele["chat_Table"],
              message_From_User_Name: this.User_Name,
              message_Is_Visible: true,
              message_To_Group: "All"
            };
            this.signalRService.sendToServer("MessageToServer", mes);


          })
        }
        else if (this.data.gate_Status == 'INGATE' && this.ditPerson.length != 0) {
          this.ditPerson.map(ele => {
            let mes: MessageModel = {
              from_User_Id: this.user_id,
              message_Text: message,
              chat_Id: ele["chat_Id"],
              message_Date: new Date().toISOString(),
              message_From_User_Role: this.Permission_Id,
              chat_Table: ele["chat_Table"],
              message_From_User_Name: this.User_Name,
              message_Is_Visible: true,
              message_To_Group: "All"
            };
            this.signalRService.sendToServer("MessageToServer", mes);


          })
        }
        else if (this.data.gate_Status == 'OUTGATE' && this.dotPerson.length != 0) {
          this.dotPerson.map(ele => {
            let mes: MessageModel = {
              from_User_Id: this.user_id,
              message_Text: message,
              chat_Id: ele["chat_Id"],
              message_Date: new Date().toISOString(),
              message_From_User_Role: this.Permission_Id,
              chat_Table: ele["chat_Table"],
              message_From_User_Name: this.User_Name,
              message_Is_Visible: true,
              message_To_Group: "All"
            };
            this.signalRService.sendToServer("MessageToServer", mes);


          })
        }
      }
    });


  }
}

@Component({
  selector: 'pickup-number-dialog',
  templateUrl: 'pickup-number-dialog.html',
  styleUrls: ['./gate.component.sass']
})
export class PickupNumberDialog {
  pickup_Number = "";
  lanePositions: any[] = [];
  selectedPosition = [];
  httpOptions: { headers: any; params: any };
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  public datPerson = [];
  public ditPerson = [];
  public dotPerson = [];
  Company_Id = "";

  constructor(
    public dialogRef: MatDialogRef<PickupNumberDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar, public dialog: MatDialog, private signalRService: SignalRService, public http: HttpClient, private configService: ConfigService, private authService: AuthService,) {
    dialogRef.disableClose = true;
    this.authService.userInfoStatus$.subscribe(userinfo => { this.user_id = userinfo.user_Id; this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name })
    var chat_Permissions: any;
    this.authService._userCompanyAccessSelected.subscribe(access => { this.Company_Id = access?.company_Id; });

    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }), params: {

        "Company_Id": this.Company_Id
      }

    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_lane_position/', this.httpOptions).subscribe(result => {
      this.lanePositions = result;

    })
    this.http.get<any>(this.configService.resourceApiURI + '/get_gate_driver_info/', this.httpOptions).subscribe(result => {
      result.map(ele => {
        if (ele.role_Id.toUpperCase() == 'DD17B764-5D41-4774-91CD-73117E59B65A') {
          this.ditPerson.push(ele);

        } else if (ele.role_Id.toUpperCase() == '389FF47B-5057-466A-AD97-6489832C2444') {
          this.datPerson.push(ele);
        }
        else if (ele.role_Id.toUpperCase() == '89342125-00EE-4A78-9807-B1ABC6C68478') {
          this.dotPerson.push(ele);
        }

      })

    });


  }

  updatePickupNumber() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_pickup_number/',
      {
        "Gate_Id": this.data.gate_Id,
        "Container_Status": this.data.container_Status,
        "Container_Number": this.data.container_Number,
        "Pickup_Number": this.pickup_Number
      },
      httpOptionsTwo).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 3000,
        });
        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
          let message = "Pickup number updated for Driver " + this.data.driver_Number + ", Refresh List";

          if (this.data.gate_Status == 'LINEUP' && this.datPerson.length != 0) {
            this.datPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          } else if (this.data.gate_Status == 'INGATE' && this.ditPerson.length != 0) {
            this.ditPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }
          else if (this.data.gate_Status == 'OUTGATE' && this.dotPerson.length != 0) {
            this.dotPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }

        }

      })
    this.dialogRef.close();

  }
  onNoClick(): void {
    this.dialogRef.close();
  }

}

@Component({
  selector: 'add-pickup-dialog',
  templateUrl: 'add-pickup-dialog.html',
  styleUrls: ['./gate.component.sass']
})
export class AddPickupDialog {

  lanePositions: any[] = [];
  container_Number = "";
  pickup_Number = "";
  container_Size = "";
  Company_Id = "";
  httpOptions: { headers: any; params: any };
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  public datPerson = [];
  public ditPerson = [];
  public dotPerson = [];
  constructor(
    public dialogRef: MatDialogRef<AddPickupDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar, public dialog: MatDialog, public http: HttpClient, private signalRService: SignalRService, private configService: ConfigService, private authService: AuthService,) {
    dialogRef.disableClose = true;
    this.authService.userInfoStatus$.subscribe(userinfo => {
      this.user_id = userinfo.user_Id;
      this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name;

    })
    this.authService._userCompanyAccessSelected.subscribe(access => { this.Company_Id = access?.company_Id; });

    var chat_Permissions: any;
    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }), params: {

        "Company_Id": this.Company_Id
      }

    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_gate_driver_info/', this.httpOptions).subscribe(result => {
      //  this.ditPerson = result;
      result.map(ele => {
        if (ele.role_Id.toUpperCase() == 'DD17B764-5D41-4774-91CD-73117E59B65A') {
          this.ditPerson.push(ele);

        } else if (ele.role_Id.toUpperCase() == '389FF47B-5057-466A-AD97-6489832C2444') {
          this.datPerson.push(ele);
        }
        else if (ele.role_Id.toUpperCase() == '89342125-00EE-4A78-9807-B1ABC6C68478') {
          this.dotPerson.push(ele);
        }
      })
      //console.log(result);

    });


  }

  addPickup() {

    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/add_pickup_container/',
      {
        "Gate_Id": this.data.gate_Id,
        "Container_Number": this.container_Number,
        "Container_Size": this.container_Size,
        "Pickup_Number": this.pickup_Number,
        "Carrier_Name": this.data.carrier_Name,
        "Driver_Number": this.data.driver_Number,
        "Company_Id": this.Company_Id,
        //   "Location": this.yardlocation
      },
      httpOptionsTwo).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 3000,
        });
        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
          let message = "Added Pickup Container For Driver " + this.data.driver_Number + ", Refresh List ";

          if (this.data.gate_Status == 'LINEUP' && this.datPerson.length != 0) {
            this.datPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          } else if (this.data.gate_Status == 'INGATE' && this.ditPerson.length != 0) {
            this.ditPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }
          else if (this.data.gate_Status == 'OUTGATE' && this.dotPerson.length != 0) {
            this.dotPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }

        }
      })
    this.dialogRef.close();

  }
}

@Component({
  selector: 'lineup-remove-reason-dialog',
  templateUrl: 'lineup-remove-reason-dialog.html',
  styleUrls: ['./gate.component.sass']
})
export class LineupRemoveReasonDialog {


  reason: string = "";
  lanePositions: any[] = [];
  selectedPosition = [];
  httpOptions: { headers: any; params: any };
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  public datPerson = [];
  public ditPerson = [];
  public dotPerson = [];
  Company_Id = "";

  constructor(
    public dialogRef: MatDialogRef<LineupRemoveReasonDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar, public dialog: MatDialog, private signalRService: SignalRService, public http: HttpClient, private configService: ConfigService, private authService: AuthService,) {
    dialogRef.disableClose = true;
    this.authService.userInfoStatus$.subscribe(userinfo => { this.user_id = userinfo.user_Id; this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name })
    var chat_Permissions: any;
    this.authService._userCompanyAccessSelected.subscribe(access => { this.Company_Id = access?.company_Id; });
    //console.log(this.data);
    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }), params: {

        "Company_Id": this.Company_Id
      }

    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_lane_position/', this.httpOptions).subscribe(result => {
      this.lanePositions = result;

    })
    this.http.get<any>(this.configService.resourceApiURI + '/get_gate_driver_info/', this.httpOptions).subscribe(result => {
      result.map(ele => {
        if (ele.role_Id.toUpperCase() == 'DD17B764-5D41-4774-91CD-73117E59B65A') {
          this.ditPerson.push(ele);

        } else if (ele.role_Id.toUpperCase() == '389FF47B-5057-466A-AD97-6489832C2444') {
          this.datPerson.push(ele);
        }
        else if (ele.role_Id.toUpperCase() == '89342125-00EE-4A78-9807-B1ABC6C68478') {
          this.dotPerson.push(ele);
        }

      })

    });
  }
  removeLineup() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/delete_lineup_driver/',
      {
        "Gate_Id": this.data.gate_Id,
        "Removed_By": this.user_id,
        "Reason": this.reason,
        "Gate_Status": this.data.gate_Status,
        "Container_Status": this.data.container_Status,
        "Container_Number": this.data.container_Number
      },
      httpOptionsTwo).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 3000,
        });
        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
          let message = this.reason + ", Please Refresh List";

          if (this.data.gate_Status == 'LINEUP' && this.datPerson.length != 0) {
            this.datPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          } else if (this.data.gate_Status == 'INGATE' && this.ditPerson.length != 0) {
            this.ditPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }
          else if (this.data.gate_Status == 'OUTGATE' && this.dotPerson.length != 0) {
            this.dotPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }

        }

      })
    this.dialogRef.close();

  }
  onNoClick(): void {
    this.dialogRef.close();
  }

}


@Component({
  selector: 'container-number-dialog',
  templateUrl: 'container-number-dialog.html',
  styleUrls: ['./gate.component.sass']
})
export class ContainerNumberDialog {
  container_Number = "";
  lanePositions: any[] = [];
  selectedPosition = [];
  httpOptions: { headers: any; params: any };
  public user_id: any;
  public User_Name = "";
  public Permission_Id = "";
  public datPerson = [];
  public ditPerson = [];
  public dotPerson = [];
  Company_Id = "";

  constructor(
    public dialogRef: MatDialogRef<ContainerNumberDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar, public dialog: MatDialog, private signalRService: SignalRService, public http: HttpClient, private configService: ConfigService, private authService: AuthService,) {
    dialogRef.disableClose = true;
    this.authService.userInfoStatus$.subscribe(userinfo => { this.user_id = userinfo.user_Id; this.User_Name = userinfo.user_First_Name + ' ' + userinfo.user_Last_Name })
    var chat_Permissions: any;
    this.authService._userCompanyAccessSelected.subscribe(access => { this.Company_Id = access?.company_Id; });

    this.authService._userPermissionsStatus$.subscribe(permissions => {
      chat_Permissions = permissions["Chat_Function"];
      if (chat_Permissions.length > 0) {
        this.Permission_Id = chat_Permissions[chat_Permissions.length - 1].permission_Id;
      }
    });
    this.container_Number = this.data.container_Number;
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      }), params: {

        "Company_Id": this.Company_Id
      }

    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_lane_position/', this.httpOptions).subscribe(result => {
      this.lanePositions = result;

    })
    this.http.get<any>(this.configService.resourceApiURI + '/get_gate_driver_info/', this.httpOptions).subscribe(result => {
      result.map(ele => {
        if (ele.role_Id.toUpperCase() == 'DD17B764-5D41-4774-91CD-73117E59B65A') {
          this.ditPerson.push(ele);

        } else if (ele.role_Id.toUpperCase() == '389FF47B-5057-466A-AD97-6489832C2444') {
          this.datPerson.push(ele);
        }
        else if (ele.role_Id.toUpperCase() == '89342125-00EE-4A78-9807-B1ABC6C68478') {
          this.dotPerson.push(ele);
        }

      })

    });


  }

  updatePickupNumber() {
    var httpOptionsTwo = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
    this.http.post<any>(this.configService.resourceApiURI + '/update_container_number/',
      {
        "Gate_Id": this.data.gate_Id,
        "Container_Status": this.data.container_Status,
        "Old_Container_Number": this.data.container_Number,
        "Container_Number": this.container_Number
      },
      httpOptionsTwo).subscribe(result => {
        this._snackBar.open("Saving changes.", "Close", {
          duration: 3000,
        });
        if (this.signalRService.connection.state === signalR.HubConnectionState.Connected) {
          let message = "Container number updated for Driver " + this.data.driver_Number + ", Refresh List";

          if (this.data.gate_Status == 'LINEUP' && this.datPerson.length != 0) {
            this.datPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          } else if (this.data.gate_Status == 'INGATE' && this.ditPerson.length != 0) {
            this.ditPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }
          else if (this.data.gate_Status == 'OUTGATE' && this.dotPerson.length != 0) {
            this.dotPerson.map(ele => {
              let mes: MessageModel = {
                from_User_Id: this.user_id,
                message_Text: message,
                chat_Id: ele["chat_Id"],
                message_Date: new Date().toISOString(),
                message_From_User_Role: this.Permission_Id,
                chat_Table: ele["chat_Table"],
                message_From_User_Name: this.User_Name,
                message_Is_Visible: true,
                message_To_Group: "All"
              };
              this.signalRService.sendToServer("MessageToServer", mes);


            })
          }

        }

      })
    this.dialogRef.close();

  }
  onNoClick(): void {
    this.dialogRef.close();
  }

}

export interface MessageModel {
  message_Id?: any;
  from_User_Id: string;
  message_From_User_Role?: string;
  message_From_User_Name?: string;
  message_Text: string;
  chat_Id: string;
  message_Date?: any;
  message_Latitude?: string;
  message_Longitude?: string;
  chat_Table: string;
  message_Is_Visible: boolean;
  message_To_Group: string;
}
