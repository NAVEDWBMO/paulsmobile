import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { GridDataResult, PageChangeEvent, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { GroupDescriptor, orderBy, SortDescriptor, process, State, filterBy, FilterDescriptor } from '@progress/kendo-data-query';
import { AuthService } from '../core/authentication/auth.service';
import { SetupDialog } from '../drivers/drivers.component';
import { ConfigService } from '../shared/config.service';
import { DeviceStatusDialog } from '../devices/devices.component';
import { ConfirmActionDialog } from '../chat-settings/chat-settings.component';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-trucks',
  templateUrl: './trucks.component.html',
  styleUrls: ['./trucks.component.sass']
})
export class TrucksComponent implements OnInit {
  public gridView: GridDataResult;
  public pageSize = 10;
  public skip = 0;
  private data: Object[];
  private access: any;

  public gridData: any[] = [];
  httpOptions: { headers: any; };
  userRole: string;
  userCompany: string;
  selectedCompany: any;
  selectedCompanyId: string = "";
  lstTruckname: any[] = [];
  public sort: SortDescriptor[] = [
    {
      field: 'truck_IsEnabled',
      dir: 'desc'
    },
    {
      field: 'company_Name',
      dir: 'asc'
    }
  ]; public state: State = {

    filter: {
      logic: 'and',
      filters: []
    }
  };
  constructor(public http: HttpClient, private configService: ConfigService, private authService: AuthService, public dialog: MatDialog) {

    this.authService.userRoleStatus$.subscribe(uRole => this.userRole = uRole);
    this.authService.userRoleStatus$.subscribe(uCompany => this.userCompany = uCompany);

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      this.gridData = [];
      if (access?.company_Id) {
        this.access = access;
        this.selectedCompanyId = access.company_Id;

        var httpOptionsTwo = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': this.authService.authorizationHeaderValue
          }),
          params: {
            Company_Id: access.company_Id
          }
        };
        this.http.get<any>(this.configService.resourceApiURI + '/get_trucks/', httpOptionsTwo).subscribe(result => {
          this.gridData = result;
          this.loadItems();
          this.lstTruckname = result.map
            (res => {
              return res.truck_Name.trim();
            })
        })
      }
    });

    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };

  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadItems();
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.skip = 0;
    this.loadItems();

  }

private loadItems(): void {
  /*  this.gridView = {
      data: orderBy(this.gridData.slice(this.skip, this.skip + this.pageSize), this.sort),
        total: this.gridData.length
    };*/
  this.gridData = orderBy(this.gridData, this.sort);
  var filterdat = this.gridData;
  filterdat = filterBy(this.gridData, this.state.filter)
  this.gridView = {
    data: filterdat.slice(this.skip, this.skip + this.pageSize),
    total: filterdat.length
  };
}


  ngOnInit(): void {

  }
  createOutsourceTruck(): void {
    const dialogRef = this.dialog.open(AddOutsourceTruckDialog, {
      data: this.lstTruckname,
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
        this.gridData = [];
        if (access?.company_Id) {
          this.access = access;
          this.selectedCompanyId = access.company_Id;

          var httpOptionsTwo = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            }),
            params: {
              Company_Id: access.company_Id
            }
          };
          this.http.get<any>(this.configService.resourceApiURI + '/get_trucks/', httpOptionsTwo).subscribe(result => {
            this.gridData = result;
            this.loadItems();
            this.lstTruckname = result.map
              (res => {
                return res.truck_Name.trim();
              })
          })
        }

      });
    });
  }
  createNewTruck(): void {
    const dialogRef = this.dialog.open(AddTruckDialog, {
      data: this.lstTruckname,
      disableClose: true

    });

    dialogRef.afterClosed().subscribe(result => {
      this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
        this.gridData = [];
        if (access?.company_Id) {
          this.access = access;
          this.selectedCompanyId = access.company_Id;

          var httpOptionsTwo = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            }),
            params: {
              Company_Id: access.company_Id
            }
          };
          this.http.get<any>(this.configService.resourceApiURI + '/get_trucks/', httpOptionsTwo).subscribe(result => {
            this.gridData = result;
            this.loadItems();
            this.lstTruckname = result.map
              (res => {
                return res.truck_Name.trim();
              })
          })
        }

      });
    });
  }
  openEditDialog(dataItem): void {
    this.lstTruckname = this.lstTruckname.filter
      (res => {
        if (dataItem.truck_Name.trim() != res.trim()) { return true; }
      })

    const dialogRef = this.dialog.open(EditTruckDialog, {
      data: {
        'dataItem': dataItem,
        'lsTruck': this.lstTruckname,
        disableClose: true

      }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
        this.gridData = [];
        if (access?.company_Id) {
          this.access = access;
          this.selectedCompanyId = access.company_Id;

          var httpOptionsTwo = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            }),
            params: {
              Company_Id: access.company_Id
            }
          };
          this.http.get<any>(this.configService.resourceApiURI + '/get_trucks/', httpOptionsTwo).subscribe(result => {
            this.gridData = result;
            this.loadItems();
            this.lstTruckname = result.map
              (res => {
                return res.truck_Name.trim();
              })
          })
        }

      });
    });
  }

}




@Component({
  selector: 'add-truck-dialog',
  templateUrl: 'add-truck-dialog.html',
  styleUrls: ['./trucks.component.sass']

})
export class AddTruckDialog {

  tName: string = '';
  tMake: string = '';
  tModel: string = '';
  tYear: string = '';
  tSerial_Number: string = '';
  tLicense_Plate: string = '';
  private access: any;
  selectedCompany: any;
  selectedCompanyId: string = "";
  lstTruck: any[] = [];
  selectedTruck = new FormControl();
  
  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<AddTruckDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog,public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {      
      if (access?.company_Id) {
        this.access = access;
        this.selectedCompanyId = access.company_Id;                
      }

    });

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
    };
    this.http.get<any>(this.configService.resourceApiURI + '/get_trucks_list/', this.httpOptions).subscribe(resAv => {

      this.lstTruck = resAv.filter((res) => { if (this.data.indexOf(res.truck_Name) < 0) { return true; } else { return false; } });
      
    })

    }
  TruckSelectedChange($e) {
    this.tName = $e.value?.truck_Name;
    this.tMake = $e.value?.truck_Make;
    this.tModel = $e.value?.truck_Model;
    this.tYear = $e.value?.truck_Year;
    this.tSerial_Number = $e.value?.truck_Serial_Number;
    this.tLicense_Plate = $e.value?.truck_License_Plate;

  }
  onNoClick(): void {
    if (this.tName != '') {
      if (this.data.indexOf(this.tName) > -1) {
      
        const dialogR = this.dialog.open(DeviceStatusDialog, {
          data: {
            'message': this.tName+' already exists',
    
          },
          disableClose: true


        });
      }
      else {
        this.http.post<any>(this.configService.resourceApiURI + '/create_truck/',
          {
            "Truck_Name": this.tName,
            "Truck_Make": this.tMake,
            "Truck_Model": this.tModel,
            "Truck_Year": this.tYear,
            "Truck_Serial_Number": this.tSerial_Number,
            "Truck_License_Plate": this.tLicense_Plate,
            "Company_Id": this.selectedCompanyId
          },
          this.httpOptions).subscribe(result => {
            this._snackBar.open("Truck created.", "Close", {
              duration: 3000,
            });
          })
      }
      
    }
    this.dialogRef.close();
  }
  
  close(){
    this.dialogRef.close();

  }

}


@Component({
  selector: 'add-truck-dialog',
  templateUrl: 'add-outsource-truck-dialog.html',
  styleUrls: ['./trucks.component.sass']

})
export class AddOutsourceTruckDialog {

  tName: string = '';
  tMake: string = '';
  tModel: string = '';
  tYear: string = '';
  tSerial_Number: string = '';
  tLicense_Plate: string = '';
  private access: any;
  selectedCompany: any;
  selectedCompanyId: string = "";
  lstTruck: any[] = [];
  selectedTruck = new FormControl();

  httpOptions: { headers: any; };

  constructor(
    public dialogRef: MatDialogRef<AddTruckDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.access = access;
        this.selectedCompanyId = access.company_Id;
      }

    });

   this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': this.authService.authorizationHeaderValue
      })
    };
  /*  this.http.get<any>(this.configService.resourceApiURI + '/get_trucks_list/', this.httpOptions).subscribe(resAv => {

      this.lstTruck = resAv.filter((res) => { if (this.data.indexOf(res.truck_Name) < 0) { return true; } else { return false; } });

    })*/

  }
/*  TruckSelectedChange($e) {
    this.tName = $e.value?.truck_Name;
    this.tMake = $e.value?.truck_Make;
    this.tModel = $e.value?.truck_Model;
    this.tYear = $e.value?.truck_Year;
    this.tSerial_Number = $e.value?.truck_Serial_Number;
    this.tLicense_Plate = $e.value?.truck_License_Plate;

  }*/
  onNoClick(): void {
    if (this.tName != '') {
      if (this.data.indexOf(this.tName) > -1) {

        const dialogR = this.dialog.open(DeviceStatusDialog, {
          data: {
            'message': this.tName + ' already exists',

          },
          disableClose: true


        });
      }
      else {
        this.http.post<any>(this.configService.resourceApiURI + '/create_truck/',
          {
            "Truck_Name": "O-"+this.tName,
            "Truck_Make": this.tMake,
            "Truck_Model": this.tModel,
            "Truck_Year": this.tYear,
            "Truck_Serial_Number": this.tSerial_Number,
            "Truck_License_Plate": this.tLicense_Plate,
            "Company_Id": this.selectedCompanyId
          },
          this.httpOptions).subscribe(result => {
            this._snackBar.open("Truck created.", "Close", {
              duration: 3000,
            });
          })
      }

    }
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();

  }

}


@Component({
  selector: 'edit-truck-dialog',
  templateUrl: 'edit-truck-dialog.html',
  styleUrls: ['./trucks.component.sass']

})
export class EditTruckDialog {

  tName: string = '';
  tMake: string = '';
  tModel: string = '';
  tYear: string = '';
  tSerial_Number: string = '';
  tLicense_Plate: string = '';
  lstTruck: any[] = [];
  selectedTruck = new FormControl();
  selectedCompany: any;
  selectedCompanyId: string = "";
  httpOptions: { headers: any; };
  private access: any;
  changed: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<EditTruckDialog>, @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog,public http: HttpClient, private configService: ConfigService, private authService: AuthService,
    private _snackBar: MatSnackBar) {
    dialogRef.disableClose = true;

    this.tName = data.dataItem.truck_Name?.trim();
    this.tMake = data.dataItem.truck_Make?.trim();
    this.tModel = data.dataItem.truck_Model?.trim();
    this.tYear = data.dataItem.truck_Year?.trim();
    this.tSerial_Number = data.dataItem.truck_Serial_Number?.trim();
    this.tLicense_Plate = data.dataItem.truck_License_Plate?.trim();
 

      this.httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.authService.authorizationHeaderValue
        })
    };
    this.authService.userCompanyAccessSelectedStatus$.subscribe(access => {
      if (access?.company_Id) {
        this.access = access;
        this.selectedCompanyId = access.company_Id;
      }

    });

  }
  check() {
    if (
      this.tName?.trim() == this.data.dataItem.truck_Name &&
      this.tMake?.trim() == this.data.dataItem.truck_Make &&
      this.tModel?.trim() == this.data.dataItem.truck_Model &&
      this.tYear?.trim() == this.data.dataItem.truck_Year &&
      this.tSerial_Number?.trim() == this.data.dataItem.truck_Serial_Number &&
      this.tLicense_Plate?.trim() == this.data.dataItem.truck_License_Plate
    ) {

        this.changed = false;
    }
    else if (this.tName?.trim() == "") {
      this.changed = false;
    }
    else {
      this.changed = true;
    }
  }
  enable_disable_truck(status) {

    if (this.data.dataItem.truck_Driver_User_Id != '' && this.data.dataItem.truck_Driver_User_Id != null ) {
      const dialogRef = this.dialog.open(DeviceStatusDialog, {
        data: {
          'Id': this.data.dataItem.truck_Driver_Id,
          'message': 'Can\'t be deactivated, please unassign driver to deactivate',
          'title': 'This truck is currently assigned to driver:',
          'driver_Id': this.data.dataItem.truck_Driver_User_Id
        },
              disableClose: true

      });
      dialogRef.afterClosed().subscribe(result => {

        if (result == true) {
          this.http.post<any>(this.configService.resourceApiURI + '/update_driver_truck_device/',
            {
              "User_Id": this.data.dataItem.truck_Driver_User_Id,
              "Driver_Device_Id": this.data.dataItem.truck_Driver_Device_Id,

            },
            this.httpOptions).subscribe(result => {
              this.data.dataItem.truck_Driver_User_Id = '';
              this.data.dataItem.truck_Driver_Firstname = '';
              this.data.dataItem.truck_Driver_Lastname = '';
              this.data.dataItem.truck_Driver_Id = '';

              this._snackBar.open("Truck updated", "Close", {
                duration: 3000,
              });
            })
        }
      });
    }
    else {
      const dialogR = this.dialog.open(ConfirmActionDialog, {
        disableClose: true

      });
      dialogR.afterClosed().subscribe(result => {

        if (result == true) {
          this.data.dataItem.truck_IsEnabled = status;


          const httpOptions = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'Authorization': this.authService.authorizationHeaderValue
            })
          };
          this.http.post<any>(this.configService.resourceApiURI + '/enable_disable_truck/',
            {
              'Truck_Id': this.data.dataItem.truck_Id,
              'Truck_IsEnabled': this.data.dataItem.truck_IsEnabled

            },
            httpOptions).subscribe(result => {
              if (status == 0) {
                this._snackBar.open("Truck " + this.data.dataItem.truck_Name+" Deactivated", "Close", {
                  duration: 3000,
                });
              
              }
              else {
                this._snackBar.open("Truck " + this.data.dataItem.truck_Name + " Activated", "Close", {
                  duration: 3000,
                });
              }

            })
        }
      });
    }



  }
  onNoClick(): void {
    if (this.tName != '') {
      if (this.data.lsTruck.indexOf(this.tName) > -1) {

        const dialogRef = this.dialog.open(DeviceStatusDialog, {
          data: {
            'message': this.tName + ' already exists',

          },
           disableClose: true


        });
      }
      else {
        this.http.post<any>(this.configService.resourceApiURI + '/update_truck/',
          {
            "Truck_Id": this.data.dataItem.truck_Id,
            "Truck_Name": this.tName,
            "Truck_Make": this.tMake,
            "Truck_Model": this.tModel,
            "Truck_Year": this.tYear,
            "Truck_Serial_Number": this.tSerial_Number,
            "Truck_License_Plate": this.tLicense_Plate
          },
          this.httpOptions).subscribe(result => {
            this._snackBar.open("Truck updated.", "Close", {
              duration: 3000,
            });
          })
        this.dialogRef.close();

      }
    }
      
  }
  
  close(){
    this.dialogRef.close();

  }

}
