﻿namespace Api.Constants
{
    internal class HttpContentMediaTypes
    {
        public const string JSON = "application/json";
    }
}
