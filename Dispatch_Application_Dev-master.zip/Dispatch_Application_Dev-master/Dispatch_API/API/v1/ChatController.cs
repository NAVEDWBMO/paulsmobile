﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Api;
using Dispatch_Application_Debug_API.Data.Entity;
using Dispatch_Application_Debug_API.Data.Hubs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using Newtonsoft.Json;
using System.IO;
using System.Web;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;

namespace Dispatch_Application_Debug_API.API.v1
{
    [ApiController]
    [Authorize]
    public class ChatController : Controller
    {

        private  IHubContext<SignalHub> _hubContext { get; set; }
        private readonly ILogger<ChatController> _logger;
        private readonly ILogger<SignalHub> _logger2;

        public ChatController(IHubContext<SignalHub> hubContext, ILogger<ChatController> logger, ILogger<SignalHub> logger2)
        {
            _hubContext = hubContext;
            _logger = logger;
            _logger2 = logger2;

        }

        public List<Chat> chtLst = new List<Chat>();


        [HttpGet]
        [Route("api/get_chats")]
        public List<Chat> GetChats(string Company_Id, string User_Id)
        {
            //1. Check the role of the user;
            //2. If the user is admin, just get all chats.
            //3. If the user is NOT admin, then:
            //4. Get access to the companies this user's company has;
            //5. Get status and general chats for this users company;
            //6. Get the rest of the chats based on the company;
            //7. Chech assignment for this user;

            try
            {
            var claims = User.Claims.ToList();

            var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {

           

                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
             
                    cmd.CommandText = "p_Get_All_Chats";
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);

                    con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                                int chatlevel = 0;
                                if (rdr["Chat_Level"].ToString() != null && rdr["Chat_Level"].ToString() != "")
                                {
                                    chatlevel = Int32.Parse(rdr["Chat_Level"].ToString());
                                };
                                Chat cht = new Chat()
                            {
                                Chat_Id = rdr["Chat_Id"].ToString(),
                                Chat_Name = rdr["Chat_Name"].ToString(),
                                Chat_Table = rdr["Chat_Table"].ToString(),
                                Chat_Level = chatlevel,
                                Chat_Type = rdr["Chat_Type"].ToString(),
                                User_Name = rdr["User_Name"].ToString(),
                                Last_Time = DateTime.Parse(rdr["Last_Time"].ToString()),
                                Online_Status = "0"
                                };
                            chtLst.Add(cht);
                        }
                    }
                    rdr.Close();
            

                cmd.Parameters.Clear();
                cmd.CommandText = "p_Check_Chat_Assignment_For_User";
                cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                List<string> assignedChatsToMe = new List<string>();
                SqlDataReader rdrTwo = cmd.ExecuteReader();
                if (rdrTwo.HasRows)
                {
                    while (rdrTwo.Read())
                    {
                        assignedChatsToMe.Add(rdrTwo["Chat_Id"].ToString());
                    }
                }
                rdrTwo.Close();

                foreach (Chat chat in chtLst)
                {
                    if (assignedChatsToMe.Contains(chat.Chat_Id))
                    {
                        chat.AssignedId = "ME";
                       
                    } 

                    chat.Messages = new List<MessageModel>();

                  /*  if(chat.Chat_Type != "STATUS")
                    {*/
                        cmd.Parameters.Clear();
                        cmd.CommandText = "p_Get_Chat_Messages";
                        
                        cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = chat.Chat_Table;
                        rdrTwo = cmd.ExecuteReader();
                        if (rdrTwo.HasRows)
                        {
                            while (rdrTwo.Read())
                            {
                                

                                MessageModel msg = new MessageModel()
                                {
                                    Message_Id   = rdrTwo["Message_Id"].ToString(),
                                    Message_Text = rdrTwo["Message_Text"].ToString(),
                                    Message_Date = DateTime.Parse(rdrTwo["Message_Date"].ToString()),
                                    Message_From_User_Role = rdrTwo["Message_From_User_Role"].ToString(),
                                    From_User_Id       = rdrTwo["From_User_Id"].ToString(),
                                    Message_Is_Visible = bool.Parse(rdrTwo["Message_Is_Visible"].ToString()),
                                    Message_Latitude   = rdrTwo["Message_Latitude"].ToString(),
                                    Message_Longitude  = rdrTwo["Message_Longitude"].ToString(),
                                    Message_To_Group   = rdrTwo["Message_To_Group"].ToString(),
                                    Message_From_User_Name = rdrTwo["Message_From_User_Name"].ToString().Trim(),

                                };
                                msg.Chat_Table = chat.Chat_Table;
                                msg.Chat_Id    = chat.Chat_Id;
                                chat.Messages.Insert(0, msg);

                            }
                        }
                        rdrTwo.Close();
                  
                    
                }

                con.Close();

            }
        }
            catch(Exception e)
            {
                throw new Exception("Error getting chats");
            }

            return chtLst;
        }

        [HttpGet]
        [Route("api/get_disabled_chats")]
        public List<Chat> GetDisabledChats()
        {
            try
            {
            var claims = User.Claims.ToList();
            var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Get_Disabled_Chats_List"
                };
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        Chat cht = new Chat()
                        {
                            Chat_Id = rdr["Chat_Id"].ToString(),
                            Chat_Name = rdr["Chat_Name"].ToString(),
                            Chat_Table = rdr["Chat_Table"].ToString(),
                            Chat_Type = rdr["Chat_Type"].ToString(),
                        };
                        chtLst.Add(cht);
                    }
                }
                rdr.Close();
                foreach (Chat chat in chtLst)
                {
                    chat.Messages = new List<MessageModel>();
                    cmd.Parameters.Clear();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "p_Get_Chat_Messages";
                    cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = chat.Chat_Table;
                    rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                                MessageModel msg = new MessageModel()
                                {
                                    Message_Id = rdr["Message_Id"].ToString(),
                                    Message_Text = rdr["Message_Text"].ToString(),
                                    Message_Date = DateTime.Parse(rdr["Message_Date"].ToString()),
                                    Message_From_User_Role = rdr["Message_From_User_Role"].ToString(),
                                    From_User_Id = rdr["From_User_Id"].ToString(),
                                    Message_Is_Visible = bool.Parse(rdr["Message_Is_Visible"].ToString()),
                                    Message_Latitude = rdr["Message_Latitude"].ToString(),
                                    Message_Longitude = rdr["Message_Longitude"].ToString(),
                                    Message_To_Group = rdr["Message_To_Group"].ToString(),
                                    Message_From_User_Name = rdr["Message_From_User_Name"].ToString().Trim(),

                                };
                                msg.Chat_Table = chat.Chat_Table;
                                msg.Chat_Id = chat.Chat_Id;
                                chat.Messages.Insert(0, msg);

                            }
                        }
                    rdr.Close();
                }
                con.Close();
            }
            }
            catch
            {
                throw new Exception("Error getting disabled chats");
            }
            
            return chtLst;
        }



        [HttpGet]
        [Route("api/get_driver_chat")]
        public Chat LoadChatForDriver()
        {
            Chat chat = new Chat();

            try
            {
            var claims = User.Claims.ToList();

            var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier);
                cmd.Parameters["@Chat_Id"].Direction = ParameterDirection.Output;
                cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70);
                cmd.Parameters["@Chat_Table"].Direction = ParameterDirection.Output;
                cmd.CommandText = "p_Get_Driver_Chat";
                con.Open();
                

                SqlDataReader rdr = cmd.ExecuteReader();

                if (rdr.HasRows)
                {
                    
                    chat.Messages = new List<MessageModel>();
                    while (rdr.Read())
                    {

                        MessageModel msg = new MessageModel()
                        {
                            Message_Id = rdr["Message_Id"].ToString(),
                            Message_Text = rdr["Message_Text"].ToString(),
                            From_User_Id = rdr["Message_From_User_Id"].ToString(),
                            Message_Date = DateTime.Parse(rdr["Message_Date"].ToString()),
                            Message_From_User_Role = rdr["Message_From_User_Role"].ToString(),
                            Message_From_User_Name = rdr["User_First_Name"].ToString().Trim(),
                            Message_Is_Visible = bool.Parse(rdr["Message_Is_Visible"].ToString()),
                            Message_To_Group = rdr["Message_To_Group"].ToString(),


                        };


                        chat.Messages.Insert(0, msg);
                    }
                }
                rdr.Close();
                chat.Chat_Id = cmd.Parameters["@Chat_Id"].Value.ToString();
                chat.Chat_Table = cmd.Parameters["@Chat_Table"].Value.ToString(); 
                con.Close();

            }
            }
            catch
            {
                throw new Exception("Error loading chat");

            }

            
            return chat;
        }


        [HttpGet]
        [Route("api/get_chat")]
        public Chat LoadChat()
        {
            Chat chat = new Chat();

            try
            {
                    var claims = User.Claims.ToList();
                    var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure
                        };
                      
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                        cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier);
                        cmd.Parameters["@Chat_Id"].Direction = ParameterDirection.Output;
                        cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70);
                        cmd.Parameters["@Chat_Table"].Direction = ParameterDirection.Output;
                        cmd.CommandText = "p_Get_Driver_Chat";

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {

                        chat.Messages = new List<MessageModel>();
                        while (rdr.Read())
                        {

                            MessageModel msg = new MessageModel()
                            {
                                Message_Id = rdr["Message_Id"].ToString(),
                                Message_Text = rdr["Message_Text"].ToString(),
                                From_User_Id = rdr["Message_From_User_Id"].ToString(),
                                Message_Date = DateTime.Parse(rdr["Message_Date"].ToString()),
                                Message_From_User_Role = rdr["Message_From_User_Role"].ToString(),
                                Message_From_User_Name = rdr["User_First_Name"].ToString().Trim(),
                                Message_Is_Visible = bool.Parse(rdr["Message_Is_Visible"].ToString()),
                                Message_To_Group = rdr["Message_To_Group"].ToString(),
                            };
                            chat.Messages.Insert(0, msg);
                        }
                    }
                    rdr.Close();
                    chat.Chat_Id = cmd.Parameters["@Chat_Id"].Value.ToString();
                    chat.Chat_Table = cmd.Parameters["@Chat_Table"].Value.ToString();
                    con.Close();
              
                    }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return chat;
        }


       
        [HttpGet]
        [Route("api/get_messages_from_history")]
        public List<MessageModel> SearchMessages(string Chat_Table, string Last_Message_Id)
        {
            List<MessageModel> searchedMessages = new List<MessageModel>();

            try
            {
             using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
             {
                
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Get_Chat_Messages_From_History"
                };
                cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = Chat_Table;
                cmd.Parameters.Add("@Last_Message_Id", SqlDbType.NVarChar, -1).Value = Last_Message_Id;
                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        MessageModel mes = new MessageModel()
                        {
                            Message_Id = rdr["Message_Id"].ToString(),
                            Message_Text = rdr["Message_Text"].ToString(),
                            From_User_Id = rdr["Message_From_User_Id"].ToString(),
                            Message_Date = DateTime.Parse(rdr["Message_Date"].ToString()),
                            Message_From_User_Role = rdr["Message_From_User_Role"].ToString(),
                            Message_Latitude = rdr["Message_Latitude"].ToString(),
                            Message_Longitude = rdr["Message_Longitude"].ToString(),
                            Message_From_User_Name = rdr["Message_Firstname"].ToString().Trim(),
                            Message_Is_Visible = bool.Parse(rdr["Message_Is_Visible"].ToString()),
                            Chat_Table = Chat_Table,
                            Message_To_Group = rdr["Message_To_Group"].ToString(),
                        };
                        searchedMessages.Add(mes);
                    }
                }
                rdr.Close();


                con.Close();
 
             }
            }
            catch
            {
                throw new Exception("Error getting messages from history");

            }
           

            return searchedMessages;
        }

        [HttpGet]
        [Route("api/get_online_status")]
        public List<OnlineStatus>  GetOnlineStatus(string Company_Id)
        {
            List<OnlineStatus> olstatus = new List<OnlineStatus>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {

                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Online_Status"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.NVarChar, 70).Value = Company_Id;
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            OnlineStatus ostatus = new OnlineStatus()
                            {
                                Chat_Id = rdr["Chat_Id"].ToString(),
                                Online_Status = rdr["Online_Status"].ToString()
                            };
                            olstatus.Add(ostatus);
                        }
                    }
                    rdr.Close();


                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting online status");

            }


            return olstatus;
        }
        [HttpPost]
        [Route("api/search_messages_in_chats")]
        public List<Chat>  SearchMessagesInChats(Dictionary<string,string> chats)
        {
            try
            {

                var Search_Value = chats.GetValueOrDefault("Search_Value");
                var Search_For_Chats = chats.GetValueOrDefault("Search_For_Chats");
                var Days = chats.GetValueOrDefault("Days");

            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {

            
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };

                con.Open();
                string[] chat_Ids = Search_For_Chats.Split(',');

                foreach (var chat_Id in chat_Ids)
                {

                        Chat cht = new Chat()
                        {
                            Chat_Id = chat_Id.ToString(),
                        };

                        cmd.Parameters.Clear();
                        cht.Messages = new List<MessageModel>();

                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "p_Search_Chat_Messages";
                        cmd.Parameters.Add("@Search_Value", SqlDbType.NVarChar, -1).Value = Search_Value.ToString();
                        cmd.Parameters.Add("@Days", SqlDbType.NVarChar).Value = Days.ToString();
                        cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(chat_Id);

                        SqlDataReader rdr2 = cmd.ExecuteReader();
                        if (rdr2.HasRows)
                        {
                            while (rdr2.Read())
                            {
                                //cht.Chat_Name = rdr2["Chat_Name"].ToString();
                                MessageModel msg = new MessageModel()
                                {
                                    Message_Id = rdr2["Message_Id"].ToString(),
                                    Message_Text = rdr2["Message_Text"].ToString(),
                                    From_User_Id = rdr2["Message_From_User_Id"].ToString(),
                                    Message_Date = DateTime.Parse(rdr2["Message_Date"].ToString()),
                                    Message_From_User_Role = rdr2["Message_From_User_Role"].ToString(),
                                    Message_Latitude = rdr2["Message_Latitude"].ToString(),
                                    Message_Longitude = rdr2["Message_Longitude"].ToString(),
                                    Message_From_User_Name = rdr2["Message_Firstname"].ToString().Trim(),
                                    Message_Is_Visible = bool.Parse(rdr2["Message_Is_Visible"].ToString()),
                                    Chat_Table = cht.Chat_Table,
                                    Message_To_Group = rdr2["Message_To_Group"].ToString(),
                                    Chat_Id = cht.Chat_Id
                                };
                                cht.Messages.Insert(0, msg);


                            }
                        }
                        chtLst.Add(cht);

                        rdr2.Close();
                    

                }
            }
            }
            catch
            {
                throw new Exception("Error searching for messages");

            }
            
                return chtLst;

        }
        [HttpGet]
        [Route("api/get_last_user_chat_message")]
        public object GetLastUserChatMessage(string Chat_Id)
        {
            var User_Name = "";
            try
            {
                
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Chat_Id);
                    cmd.CommandText = "p_Get_Last_User_Chat_Message";
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            User_Name = rdr["UserName"].ToString();

                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch
            {
                throw new Exception("Error while getting user name");
            }
            List<string> username = new List<string> () { User_Name };
          return username;


        }
        [HttpGet]
        [Route("api/get_assigned_dispatcher_drivers")]
        public object GetAssignedDispatcherDrivers(string User_Id, string Company_Id)
        {
            List<AssignedDispactherDriver> DriversChats = new List<AssignedDispactherDriver>();
            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);
                    cmd.CommandText = "p_Get_Assigned_Dispatcher_Drivers";
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            AssignedDispactherDriver ostatus = new AssignedDispactherDriver()
                            {
                                Chat_Id = rdr["Chat_Id"].ToString(),
                                Chat_Name = rdr["Chat_Name"].ToString(),
                                IsSelected = rdr["Selected"].ToString()
                            };
                            DriversChats.Add(ostatus);

                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch(Exception Ex)
            {
                throw new Exception(Ex.Message);
            }
            return DriversChats;


        }

        [HttpPost]
        [Route("api/edit_chat_roles")]
        public void EditChatRoles(Chat cm)
        {

            using SqlConnection con = new SqlConnection(Startup.DatabaseString);
            try
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Clear_Chat_Roles"
                };
                cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(cm.Chat_Id);
                con.Open();


                cmd.ExecuteNonQuery();


                cmd.CommandText = "p_Assign_Role_To_Chat";
                foreach (string role_Id in cm.Roles)
                {
                    
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(role_Id);
                    cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(cm.Chat_Id);

                    cmd.ExecuteNonQuery();
                }


                con.Close();
            }
            catch
            {
                throw new Exception("Error managing chat roles");

            }


        }


        [HttpPost]
        [Route("api/create_custom_chat")]
        public async Task<IActionResult> CreateCustomChatAsync(CreateCustomChatModel cm)
        {

            string Chat_Name_Adjusted = cm.Chat_Name.Trim().Replace(" ", "_");
            DateTime currDate = DateTime.Now;
            using SqlConnection con = new SqlConnection(Startup.DatabaseString);
            try
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Create_Custom_Chat"
                };
                cmd.Parameters.Add("@Chat_Name", SqlDbType.NVarChar, 50).Value = cm.Chat_Name.Trim();
             /*   cmd.Parameters.Add("@Chat_Table_Name", SqlDbType.NVarChar, 50).Value = Chat_Name_Adjusted;*/
                cmd.Parameters.Add("@Chat_Company", SqlDbType.UniqueIdentifier).Value = Guid.Parse(cm.Chat_Company);
                cmd.Parameters.Add("@Chat_Date_Created", SqlDbType.DateTime2).Value = currDate;
                con.Open();

                var Chat_Status = "";
                SqlDataReader rdr1 = cmd.ExecuteReader();
                if (rdr1.HasRows)
                {
                    while (rdr1.Read())
                    {
                        Chat_Status = rdr1["Chat_Status"].ToString();
                    }
                }
                rdr1.Close();
                if (Chat_Status == "Inserted")
                {
                    var newChatId = "";
                    cmd.Parameters.Clear();
                    cmd.CommandText = "p_Get_Chat_Id";
                    cmd.Parameters.Add("@Chat_Name", SqlDbType.NVarChar, 50).Value = cm.Chat_Name.Trim();
                    cmd.Parameters.Add("@Chat_Date_Created", SqlDbType.DateTime2).Value = currDate;
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            newChatId = rdr["Chat_Id"].ToString();
                        }
                    }
                    rdr.Close();


                    cmd.CommandText = "p_Assign_Role_To_Chat";
                    foreach (string role_Id in cm.Chat_Roles)
                    {

                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(role_Id);
                        cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(newChatId);

                        cmd.ExecuteNonQuery();
                    }
                }
                else if (Chat_Status == "Existed") 
                {
                    return Ok("Chat name " + cm.Chat_Name + " is already taken");
                }
                con.Close();
            }
            catch(Exception Ex)
            {
                //throw new Exception("Error creating chat");
                return BadRequest(Ex.Message);

            }

            await _hubContext.Clients.All.SendAsync("UpdateChats", "");
            return Ok();
        }

        [HttpPost]
        [Route("api/disable_chat")]
        public async Task DisableChatAsync(Chat cm)
        {
            try
            {
                using SqlConnection con = new SqlConnection(Startup.DatabaseString);
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };

                cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(cm.Chat_Id);
                cmd.Parameters.Add("@Date_Disabled", SqlDbType.DateTime2).Value = DateTime.Now;
                con.Open();
                if (cm.Chat_Type == "CUSTOM")
                {
                    cmd.CommandText = "p_Disable_Custom_Chat";
                    cmd.ExecuteNonQuery();
                }else if( cm.Chat_Type == "GENERAL")
                {
                    cmd.CommandText = "p_Disable_General_Chat";
                    cmd.ExecuteNonQuery();
                }
                con.Close();
            }
            catch
            {
                throw new Exception("Error disabling chat");
            }

            await _hubContext.Clients.All.SendAsync("UpdateChats", "");

        }
        [HttpPost]
        [Route("api/enable_chat")]
        public async Task EnableChatAsync(Chat cm)
        {
            try
            {
                using SqlConnection con = new SqlConnection(Startup.DatabaseString);
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };

                cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(cm.Chat_Id);
                con.Open();

                cmd.CommandText = "p_Enable_Custom_Chat";
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch
            {
                throw new Exception("Error enabling chat");
            }

            await _hubContext.Clients.All.SendAsync("UpdateChats", "");

        }

        /* public static MessageModel SaveMessage(MessageModel md)
         {
             try
             {
                 md.Message_Text = md.Message_Text.Replace("'", "''");
             using SqlConnection con = new SqlConnection(Startup.DatabaseString);
                 SqlCommand cmd = new SqlCommand
                 {
                     Connection = con,
                     CommandType = System.Data.CommandType.StoredProcedure
                 };
                 cmd.Parameters.Add("@From_User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.From_User_Id);
                 cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = md.Chat_Table;
                 cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = md.Message_Text;
                 cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = md.Message_Date;
                 cmd.Parameters.Add("@Message_From_User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message_From_User_Role);
                 cmd.Parameters.Add("@Message_Latitude", SqlDbType.NVarChar, 12).Value = md.Message_Latitude;
                 cmd.Parameters.Add("@Message_Longitude", SqlDbType.NVarChar, 12).Value = md.Message_Longitude;
                 cmd.Parameters.Add("@Message_Is_Visible", SqlDbType.Bit).Value = md.Message_Is_Visible;
                 cmd.Parameters.Add("@Message_To_Group", SqlDbType.NVarChar, 20).Value = md.Message_To_Group;


                 cmd.CommandText = "p_Save_Message";

                 con.Open();
                 cmd.ExecuteNonQuery();
                 cmd.Parameters.Clear();

                 cmd.CommandText = "p_Get_Message_Id";
                 cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = md.Chat_Table;
                 cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = md.Message_Text;

                 SqlDataReader idReader = cmd.ExecuteReader();
                 if (idReader.HasRows)
                 {
                     while (idReader.Read())
                     {
                         md.Message_Id = idReader["Message_Id"].ToString();
                     }
                 }
                 idReader.Close();

                 con.Close();


             }
             catch
             {
                 throw new Exception("Saving message unsuccessful");
             }

             return md;
         }*/

        public static Dictionary<string,object> SaveMessage(MessageModel md,int chatlevel, ILogger<SignalHub> _logger)
        {
            Updated_Chat_Level_Info chat_Level_Info = new Updated_Chat_Level_Info();
            try
            {
                using SqlConnection con = new SqlConnection(Startup.DatabaseString);
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                _logger.Log(LogLevel.Warning, "save message Chat_Id " + md.Chat_Id);
                _logger.Log(LogLevel.Warning, "save message From_User_Id "+ md.From_User_Id);
                _logger.Log(LogLevel.Warning, "save message Message_From_User_Role "+ md.Message_From_User_Role);

                cmd.Parameters.Add("@From_User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.From_User_Id);
                cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = md.Chat_Table;
                cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = md.Message_Text;
                cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = md.Message_Date;
                cmd.Parameters.Add("@Message_From_User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message_From_User_Role);
                cmd.Parameters.Add("@Message_Latitude", SqlDbType.NVarChar, 12).Value = md.Message_Latitude;
                cmd.Parameters.Add("@Message_Longitude", SqlDbType.NVarChar, 12).Value = md.Message_Longitude;
                cmd.Parameters.Add("@Message_Is_Visible", SqlDbType.Bit).Value = md.Message_Is_Visible;
                cmd.Parameters.Add("@Message_To_Group", SqlDbType.NVarChar, 20).Value = md.Message_To_Group;
                cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Chat_Id);
                cmd.Parameters.Add("@Chat_Level", SqlDbType.Int, 50).Value = chatlevel;

                cmd.CommandText = "p_Save_Message";

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {

                        chat_Level_Info.User_Name = rdr["User_Name"].ToString();
                        chat_Level_Info.Last_Time = rdr["Last_Time"].ToString();
                    }
                }
                rdr.Close();
                cmd.Parameters.Clear();

                cmd.CommandText = "p_Get_Message_Id";
                cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = md.Chat_Table;
                cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = md.Message_Text;

                SqlDataReader idReader = cmd.ExecuteReader();
                if (idReader.HasRows)
                {
                    while (idReader.Read())
                    {
                        md.Message_Id = idReader["Message_Id"].ToString();
                    }
                }
                idReader.Close();

                con.Close();


            }
            catch(Exception Ex)
            {
                throw new Exception(md.From_User_Id + "message is  "+ md.Message_Text + "message id "+ md.Message_Id +   Ex.Message);
            }
            var msg_chat_level_info = new Dictionary<string,object>();
            msg_chat_level_info.Add("message", md);
            msg_chat_level_info.Add("chat_level_info", chat_Level_Info);
            return msg_chat_level_info;
        }

        public static Updated_Chat_Level_Info SetChatLevel(string ChatId, string NewLevel,string User_Id)
        {
            Updated_Chat_Level_Info chat_Level_Info = new Updated_Chat_Level_Info();
            try
            {
                using SqlConnection con2 = new SqlConnection(Startup.DatabaseString);
                con2.Open();

                SqlCommand cmd2 = new SqlCommand
                {
                    Connection = con2,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmd2.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ChatId);
                cmd2.Parameters.Add("@Chat_Level", SqlDbType.NVarChar, 50).Value = NewLevel;
                cmd2.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);

                cmd2.CommandText = "p_Set_Chat_Level";

                SqlDataReader idReader = cmd2.ExecuteReader();
                if (idReader.HasRows)
                {
                    while (idReader.Read())
                    {


                        chat_Level_Info.User_Name = idReader["User_Name"].ToString();
                        chat_Level_Info.Last_Time = idReader["Last_Time"].ToString();
                         
                    
                     }
                }
                idReader.Close();

                con2.Close();
            }
            catch
            {
                throw new Exception("Error changing chat level");
            }

            return chat_Level_Info;
        }

        [HttpPost]
        [Route("api/send_text_to_phone")]
        public void SendTextToPhone(Dictionary<string,string> driver_info)
        {

            using SqlConnection con = new SqlConnection(Startup.DatabaseString);
            try
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Get_Driver_Carrier_Info"
                };
                cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(driver_info["Chat_Id"]);
                con.Open();


               SqlDataReader rdr = cmd.ExecuteReader();
                var Carrier = "";
                var Phone_Number = "";
                if (rdr.HasRows) {

                    while (rdr.Read())
                    {
                        Carrier = rdr["Carrier_Domain_Name"].ToString();
                    
                    }

                
                }

                rdr.Close();

                con.Close();

                string apiKey = "AIzaSyC-HQF3AReyTtbCVxsJC6wtipJnBV4O1SU";
                string username = "amit.amit@pauls.ca";
                //string receiver = "4373268773@txt.bellmobility.ca";
                //string receiver = "4164736373@pcs.rogers.com";
                //string receiver = "2267002846@txt.freedommobile.ca";
                //string receiver = "6475055033@fido.ca";
                //string receiver = "4165731310@msg.koodomobile.com";
                //string receiver = "6475710181@text.telus.com";
                string receiver = "3657775810@vmobile.ca";
                string smtpserver = "smtp.office365.com";
                //string smtpassword = "+5pERz2zSG";
                string smtpassword = "wGc8amk-m";
                try {

                    var mimeMessage = new MimeMessage();
                    mimeMessage.From.Add(new MailboxAddress(username, username));
                    mimeMessage.To.Add(new MailboxAddress(receiver, receiver));
                    mimeMessage.Subject = "Dispatch Message";
                    mimeMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html)
                    { Text = "<p>" + "<b></b>" + "<br/>" + "<b></b>" + driver_info["Message"].ToString() + "</p><br/><p>Note* Don't Reply</p>" };

                    using (SmtpClient smtpClient = new SmtpClient())
                    {
                        smtpClient.Connect(smtpserver, 587, SecureSocketOptions.StartTls);
                        smtpClient.Authenticate(username,
                        smtpassword);

                        smtpClient.Send(mimeMessage);
                        smtpClient.Disconnect(true);

                    }


                }
                catch(Exception Ex) {
                    Console.WriteLine(Ex.Message);
                
                }



            }
            catch
            {
                throw new Exception("Error managing chat roles");

            }


        }

        [HttpPost]
        [Route("api/update_assigned_dispatcher_drivers")]
        public void UpdateAssignedDispatcherDrivers(Dictionary<string, object> user_info)
        {

            using SqlConnection con = new SqlConnection(Startup.DatabaseString);
            try
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Update_Assigned_Dispatcher_Drivers"
                };
                cmd.Parameters.Add("@Assigned_Drivers", SqlDbType.NVarChar, -1).Value = JsonConvert.SerializeObject(user_info["Assigned_Drivers"]);
                cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_info["User_Id"].ToString());
                cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_info["Company_Id"].ToString());
                con.Open();

                cmd.ExecuteNonQuery();
                con.Close();

              
            }
            catch(Exception Ex)
            {
                throw new Exception(Ex.Message);

            }
        }

        [Route("api/textflow-webhooks")]
        [HttpPost]
        [AllowAnonymous]

        public async Task<IActionResult> TextFlowWebhooks([FromBody] Text_Info text_info)
        {

            var User_Id = "";
            var Chat_Id = "";
            var Chat_Table = "";
            var Driver_Name = "";
            var Company_Id = "";
            var phone_number = String.Format("{0:###-###-####}", Convert.ToInt64(text_info.phone_number.Substring(2)));
            try
            {
                using SqlConnection con2 = new SqlConnection(Startup.DatabaseString);
                con2.Open();

                SqlCommand cmd2 = new SqlCommand
                {
                    Connection = con2,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmd2.Parameters.Add("@Phone_Number", SqlDbType.NVarChar).Value = phone_number;


                cmd2.CommandText = "p_Get_Driver_By_Phone_Number";

                SqlDataReader idReader = cmd2.ExecuteReader();
                if (idReader.HasRows)
                {
                    while (idReader.Read())
                    {
                        User_Id      = idReader["User_Id"].ToString();
                        Chat_Id      = idReader["Chat_Id"].ToString();
                        Chat_Table   = idReader["Chat_Table"].ToString();
                        Driver_Name  = idReader["Driver_Name"].ToString();
                        Company_Id   = idReader["Company_Id"].ToString();

                    }
                }
                idReader.Close();

                con2.Close();
                if (!String.IsNullOrWhiteSpace(User_Id))
                {
                    var message = new MessageModel
                    {

                        From_User_Id = User_Id,
                        Message_Text = text_info.text,
                        Chat_Id = Chat_Id,
                        Message_Date = new DateTime(),
                        Message_From_User_Role = "352C54B4-CBDB-406A-B0D2-9E05544198E4",
                        Chat_Table = Chat_Table,
                        Message_From_User_Name = Driver_Name,
                        Message_Is_Visible = true,
                        Message_To_Group = "AllTextToPhone",

                    };

                    message.Message_Date = DateTime.Now;
                    message.Message_Text = Regex.Replace(message.Message_Text, @"[\']", "\"", RegexOptions.None);

                    Dictionary<string, object> msg_chat_info = ChatController.SaveMessage(message, 2, _logger2);
                    MessageModel updMessage = (MessageModel)msg_chat_info["message"];
                    Updated_Chat_Level_Info chat_Level_Info = (Updated_Chat_Level_Info)msg_chat_info["chat_level_info"];
                    await _hubContext.Clients.All.SendAsync("SetChatLevel", message.Chat_Id, 2, chat_Level_Info.User_Name, chat_Level_Info.Last_Time);

                    await _hubContext.Clients.Client(message.From_User_Id).SendAsync("SendToDriver", message);

                    await _hubContext.Clients.Group(Company_Id.ToUpper()).SendAsync("SendToDispatch", message);
                }
            }
            catch(Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }        
          
            return Ok(text_info.phone_number);
        }

        [HttpPost]
        [Route("api/textflow-send-sms")]
        public async Task<IActionResult> TextFlowSendSms(Dictionary<string, string> driver_info)
        {
            try
            {
                var Phone_Number = "";
                using SqlConnection con2 = new SqlConnection(Startup.DatabaseString);
                con2.Open();

                SqlCommand cmd2 = new SqlCommand
                {
                    Connection = con2,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmd2.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(driver_info["Chat_Id"]);
                cmd2.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(driver_info["Company_Id"]);



                cmd2.CommandText = "p_Get_Driver_Phone_Number";

                SqlDataReader idReader = cmd2.ExecuteReader();
                if (idReader.HasRows)
                {
                    while (idReader.Read())
                    {
                        Phone_Number = idReader["CELL_PHONE"].ToString();
                    }
                }
                idReader.Close();

                con2.Close();


                var Message_Text = driver_info["Message"];
                if (Message_Text != "" && !String.IsNullOrWhiteSpace(Phone_Number))
                {
                    //string[] words = Message_Text.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                  /*  StringBuilder result = new StringBuilder();

                    foreach (string word in words)
                    {
                        if (IsAlphanumeric(word) && word.Length > 4)
                        {
                            string formattedWord = Regex.Replace(word, @"(\d+)|([a-zA-Z]+)", "$1 $2 ").Trim();

                            if (formattedWord.Length > 4)
                            {
                                formattedWord = Regex.Replace(formattedWord, @"\d{3}", "$0 ").Trim();
                            }

                            result.Append(formattedWord).Append(", ");
                        }
                        else
                        {
                            result.Append(word).Append(" ");
                        }
                    }*/

                  //  Message_Text = Regex.Replace(result.ToString().Trim(), @"\.", ". ", RegexOptions.None);
                    Message_Text = Regex.Replace(Message_Text, @"\s+", " ");
                    HttpClient client = new HttpClient();

                    // Set headers
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    string bearerToken = "lCaRAYirONrHaf03PrkOsdDqnyZB4w6j9Efcivwn0AwvN97jRXKPdx4qVxvWdCC9";
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);

                    var requestBody = new
                    {
                        phone_number = "+1" + Phone_Number.Replace("-", ""),
                        text = Message_Text

                    };
                   // Console.WriteLine(requestBody);
                    // Create the content to be sent in the request body
                    var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(requestBody), System.Text.Encoding.UTF8, "application/json");

                    // Send the POST request
                    HttpResponseMessage response = await client.PostAsync("https://textflow.me/api/send-sms", content);

                    // Check the response status
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the response content
                        string responseContent = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("Response: " + responseContent);

                    }
                    else
                    {
                        throw new Exception("Request failed with status code: " + response.StatusCode);
                    }
                }
                else {

                    return BadRequest("Invalid Phone Number!!");
                }
            }
            catch (Exception Ex)
            {
               Console.WriteLine(Ex.Message);
               return BadRequest(Ex.Message);
            }
            return Ok();
        }

/*        public static bool IsAlphanumeric(string input)
        {
            return Regex.IsMatch(input, @"[a-zA-Z0-9!-]*$");
        }*/

        [HttpPost]
        [Route("api/textflow-broadcast-sms")]
        public async Task<IActionResult> TextFlowBroadcastSms(BroadcastTextToPhoneModel driver_info)
        {
            try
            {
                var Phone_Number = "";
                var Driver_Id = "";
                var Message_Text = driver_info.Message.Trim();
                if (Message_Text != "")
                {
                    //Message_Text = Regex.Replace(Message_Text.ToString().Trim(), @"\.", ". ", RegexOptions.None);
                    Message_Text = Regex.Replace(Message_Text, @"\s+", " ");
                    Console.WriteLine(Message_Text);
                    using SqlConnection con = new SqlConnection(Startup.DatabaseString);

                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Driver_For_Broadcast_SMS"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Chat_Type", SqlDbType.NVarChar).Value = driver_info.Chat_Type.Trim();
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(driver_info.Company_Id);
                    SqlDataReader idReader = cmd.ExecuteReader();
                    if (idReader.HasRows)
                    {
                        while (idReader.Read())
                        {
                            Phone_Number = idReader["CELL_PHONE"].ToString();
                            Driver_Id = idReader["Driver_Id"].ToString();
                            if (!String.IsNullOrWhiteSpace(Phone_Number))
                            {
                                HttpClient client = new HttpClient();

                                // Set headers
                                client.DefaultRequestHeaders.Accept.Clear();
                                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                string bearerToken = "lCaRAYirONrHaf03PrkOsdDqnyZB4w6j9Efcivwn0AwvN97jRXKPdx4qVxvWdCC9";
                                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);


                                /*    string[] words = Message_Text.Split(new[] { '', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                    StringBuilder result = new StringBuilder();

                                    foreach (string word in words)
                                    {
                                        if (IsAlphanumeric(word) && word.Length > 4)
                                        {
                                            string formattedWord = Regex.Replace(word, @"(\d+)|([a-zA-Z]+)", "$1 $2 ").Trim();

                                            if (formattedWord.Length > 4)
                                            {
                                                formattedWord = Regex.Replace(formattedWord, @"\d{3}", "$0 ").Trim();
                                            }

                                            result.Append(formattedWord).Append(", ");
                                        }
                                        else
                                        {
                                            result.Append(word).Append(" ");
                                        }
                                    }*/

                                
                                var requestBody = new
                                {
                                    phone_number = "+1" + Phone_Number.Replace("-", ""),
                                    text = Message_Text
                                };
                                // Console.WriteLine(requestBody);
                                // Create the content to be sent in the request body
                                var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(requestBody), System.Text.Encoding.UTF8, "application/json");

                                // Send the POST request
                                HttpResponseMessage response = await client.PostAsync("https://textflow.me/api/send-sms", content);

                                // Check the response status
                                if (response.IsSuccessStatusCode)
                                {
                                    // Read the response content
                                    string responseContent = await response.Content.ReadAsStringAsync();
                                    Console.WriteLine("Response: " + responseContent);

                                }
                                else
                                {
                                    throw new Exception("Request failed with status code: " + response.StatusCode);
                                }
                            }

                        }
                    }
                    idReader.Close();

                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
                return BadRequest(Ex.Message);
            }
            return Ok();
        }
        public class Text_Info
        {
            public string phone_number { get; set; }
            public string text { get; set; }
            public string secret { get; set; }
        }
        public class BroadcastTextToPhoneModel
        {
            public string Company_Id { get; set; }
            public string Message { get; set; }
            public string Chat_Type { get; set; }

        }


    }
}
