﻿using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.API.v1
{
    public interface ISignalService
    {
        Task<bool> SaveSignalAsync();
    }
}