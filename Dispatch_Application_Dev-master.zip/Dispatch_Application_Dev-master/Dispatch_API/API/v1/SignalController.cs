﻿using Dispatch_Application_Debug_API.API.v1;
using Dispatch_Application_Debug_API.Data.Hubs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Threading.Tasks;

namespace SignalMonitoring.API.Controllers
{
    [Route("api/signals")]
    [ApiController]
    public class SignalController : ControllerBase
    {

        private readonly IHubContext<SignalHub> _hubContext;
        public SignalController( IHubContext<SignalHub> hubContext)
        {
            _hubContext = hubContext;
        }


        [HttpPost]
        [Route("send_message")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = typeof(bool))]

        public async Task<IActionResult> MessageReceived(MessageModel mes)
        {
            mes.Message_Date = DateTime.Now;


            await _hubContext.Clients.All.SendAsync("MessageReceived", mes);
            //Console.WriteLine(mes.Message_Date);
            return StatusCode(200, mes.Message_Date);

        }



        [HttpPost]
        [Route("deliverypoint")]
        [ProducesResponseType(404)]
        [ProducesResponseType(200, Type = typeof(bool))]

        public async Task<IActionResult> SignalArrived()
        {


            await _hubContext.Clients.All.SendAsync("SignalMessageReceived", "Test from API");
            return StatusCode(200, "");

        }

    }
}
