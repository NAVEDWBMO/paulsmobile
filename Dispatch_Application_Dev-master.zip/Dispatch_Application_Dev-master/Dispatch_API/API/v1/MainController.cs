﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;
using Api;
using Api.Data.Entity;
using Driver_Api.API.v1;
using Driver_Api.Data.Entity;
using Driver_Api.Data.Entity.ActionModels;
using Dispatch_Application_Debug_API.API.v1;
using Dispatch_Api.Data.Entity;
using Dispatch_Application_Debug_API.Data.Entity;
using Dispatch_Application_Debug_API.Data.Hubs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Drawing;
using Renci.SshNet;

namespace Resource.Api.Controllers
{

    [ApiController]
    [Authorize]
    public class MainController : Controller
    {



        private readonly StatusHandler _statusHandler = new StatusHandler();
        private static readonly HttpClient client = new HttpClient();
        public IConfiguration _config;
        private readonly IHubContext<SignalHub> _hubContext;


        public MainController(IConfiguration config, IHubContext<SignalHub> hubContext)
        {
            _hubContext = hubContext;
            _config = config;
        }
        [HttpGet]
        [Route("api/get_driver_ftp_files")]
        public List<DriverFtpFiles> GetDriverFtp_Files(string driver, string company, string folder)
        {

            var images = new List<DriverFtpFiles>();

            using (var client = new SftpClient("mobilestorage.pauls.ca", port: 22, "dispatch_user", "_)$a8gF3TC"))
            {
                try
                {
                    client.Connect();

                    var remoteDirectory = "/" + company.ToUpper() + "/" + driver.ToUpper() + '/' + folder;


                    client.ChangeDirectory(remoteDirectory);
                    /*client.BufferSize = 4 * 1024;*/

                    var files = client.ListDirectory(remoteDirectory);

                    Console.WriteLine($"Files in {remoteDirectory}:");

                    foreach (var fi in files)
                    {
                        if (fi.IsRegularFile)
                        {
                            var image = new DriverFtpFiles()
                            {
                                FileName = fi.Name,
                                Image = fi.FullName,
                                FilePath = fi.FullName,
                                Driver_u_id = driver.ToUpper(),
                                Folder_type = folder,
                                fileCreatedDate = fi.LastWriteTime
                            };
                            images.Add(image);
                            Console.WriteLine(fi.Name);
                        }
                    }


                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                finally
                {
                    if (client.IsConnected)
                    {
                        client.Disconnect();
                    }
                }


            }

                // Create a DirectoryInfo object
                /* DirectoryInfo directoryInfo = new DirectoryInfo(@"\\mobilestorage.pauls.ca\Data\");


                 bool company_exists = Directory.Exists(@"\\mobilestorage.pauls.ca\Data\" + company.ToUpper() + @"\");
                 bool driver_exists = Directory.Exists(@"\\mobilestorage.pauls.ca\Data\" + company.ToUpper() + @"\" + driver.ToUpper() + @"\");
                 if (company_exists && driver_exists)
                 {
                     string getExtensions = "*.jpg,*.png,*.pdf";

                     string[] filePaths = Directory.GetFiles(@"\\mobilestorage.pauls.ca\Data\" + company.ToUpper() + @"\" + driver.ToUpper() + @"\" + folder + @"\", "*.*", SearchOption.TopDirectoryOnly).Where(s => getExtensions.Contains(Path.GetExtension(s).ToLower())).ToArray();

                     foreach (var fi in filePaths)
                     {
                         //byte[] imageArray = System.IO.File.ReadAllBytes(fi);
                         //string base64ImageRepresentation = Convert.ToBase64String(imageArray);
                         var image = new DriverFtpFiles()
                         {
                             FileName = Path.GetFileName(fi),
                             Image = Path.GetFileName(fi),
                             FilePath = fi,
                             Driver_u_id = Path.GetFileName(Path.GetDirectoryName(Path.GetDirectoryName(fi))),
                             Folder_type = Path.GetFileName(Path.GetDirectoryName(fi)),
                             fileCreatedDate = (new FileInfo(fi).CreationTime.Date)
                         };
                         images.Add(image);

                     }
                 }*/


                return images;

        }
        [HttpGet]
        [Route("api/get_driver_ftp_files_by_search")]
        public List<DriverFtpFiles> GetDriverFtp_Files_By_Search(string Company_Id, string User_Id, string Folder,int Month, int Year, string Search)
        {

            var images = new List<DriverFtpFiles>();
            var search_str = Search.ToLower();

            using (var client = new SftpClient("mobilestorage.pauls.ca", port: 22, "dispatch_user", "_)$a8gF3TC"))
            {
                try
                {
                    client.Connect();

                    var remoteDirectory = "/" + Company_Id.ToUpper() + "/"+ User_Id.ToUpper() + "/" + Folder;

                  
                    client.ChangeDirectory(remoteDirectory);



                    /*client.BufferSize = 4 * 1024;*/
                    // List to store file information
                    // Get the list of files in each subdirectory
                    var files = client.ListDirectory(remoteDirectory)
                        .Where(f => f.LastWriteTime.Month == Month && f.LastWriteTime.Year ==Year && f.FullName.ToLower().Contains(search_str) )
                        .ToList();

                    foreach (var fi in files)
                    {
                        var image = new DriverFtpFiles()
                        {

                            FileName = fi.Name,
                            Image = fi.FullName,
                            FilePath = fi.FullName,
                            Driver_u_id = "",
                            Folder_type = Folder,
                            fileCreatedDate = fi.LastWriteTime
                        };

                        images.Add(image);

                    }
                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                finally
                {
                    if (client.IsConnected)
                    {
                        client.Disconnect();
                    }
                }
            }

                /*        bool exists = Directory.Exists(@"\\mobilestorage.pauls.ca\Data\" + Company_Id.ToUpper() + @"\");
                        if (exists)
                        {
                            try
                            {

                                string getExtensions = "*.jpg,*.png,*.pdf";
                                var directoryInfo = new DirectoryInfo(@"\\mobilestorage.pauls.ca\Data\" + Company_Id.ToUpper());

                                var filteredFiles = Directory.GetFiles(@"\\mobilestorage.pauls.ca\Data\" + Company_Id.ToUpper(), "*.*", SearchOption.AllDirectories)
                                .Where(file =>
                                {
                                var fileInfo = new FileInfo(file);
                                return fileInfo.CreationTime.Month == month &&
                                        fileInfo.CreationTime.Year == year ;
                                })
                                .ToArray();


                                foreach (var fi in filteredFiles)
                                {

                                    //byte[] imageArray = System.IO.File.ReadAllBytes(fi);
                                    //string base64ImageRepresentation = Convert.ToBase64String(imageArray);
                                    var image = new DriverFtpFiles()
                                    {
                                        FileName = Path.GetFileName(fi),
                                        Image = Path.GetFileName(fi),
                                        FilePath = fi,
                                        Driver_u_id = Path.GetFileName(Path.GetDirectoryName(Path.GetDirectoryName(fi))),
                                        Folder_type = Path.GetFileName(Path.GetDirectoryName(fi)),
                                        fileCreatedDate = (new FileInfo(fi).CreationTime.Date)
                                    }; 
                                    images.Add(image);

                                }
                            }
                            catch (Exception Ex)
                            {

                                Console.WriteLine(Ex.Message);
                            }
                        }

            */
                return images;

        }
        [HttpGet]
        [Route("api/get_driver_ftp_files_image")]
        public List<DriverFtpFiles> GetDriverFtp_Files_Image(string filepath)
        {
            var images = new List<DriverFtpFiles>();

            try
            {
                using (var client = new SftpClient("mobilestorage.pauls.ca", port: 22, "dispatch_user", "_)$a8gF3TC"))
                {
                    client.Connect();
                    if (client.IsConnected)
                    {
                        Console.WriteLine("Connected to SFTP server.");
                        using (var memoryStream = new MemoryStream())
                        {
                            client.DownloadFile(filepath, memoryStream);

                            string base64String = Convert.ToBase64String(memoryStream.ToArray());
                            var image = new DriverFtpFiles()
                            {
                                Image = base64String

                            };
                            images.Add(image);
                        }

                        client.Disconnect();
                    }
                    else
                    {
                        Console.WriteLine("Failed to connect to SFTP server.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            /*   var images = new List<DriverFtpFiles>();
               //string[] filePaths = Directory.GetFiles(@"\\mobilestorage.pauls.ca\Data\" + filepath);
               byte[] imageArray = System.IO.File.ReadAllBytes(filepath);
               string base64ImageRepresentation = Convert.ToBase64String(imageArray);
               var image = new DriverFtpFiles()
               {
                   Image = base64ImageRepresentation

               };
               images.Add(image);*/
            return images;

        }
        public class Filpaths
        {
            public List<string> filepaths { get; set; }

        }
        [HttpPost]
        [Route("api/get_driver_ftp_files_images")]
        public List<DriverFtpFiles> GetDriverFtp_Files_Images(Filpaths filepaths)
        {
            var images = new List<DriverFtpFiles>();

            try
            {
                using (var client = new SftpClient("mobilestorage.pauls.ca", port: 22, "dispatch_user", "_)$a8gF3TC"))
                {
                    client.Connect();
                    if (client.IsConnected)
                    {
                        Console.WriteLine("Connected to SFTP server.");
                        foreach (var filepath in filepaths.filepaths)
                        {
                            using (var memoryStream = new MemoryStream())
                            {
                                client.DownloadFile(filepath, memoryStream);

                                string base64String = Convert.ToBase64String(memoryStream.ToArray());
                                var image = new DriverFtpFiles()
                                {
                                    FileName = Path.GetFileName(filepath),
                                    Image = base64String

                                };
                                images.Add(image);
                            }
                           
                        }
                        client.Disconnect();
                    }
                    else
                    {
                        Console.WriteLine("Failed to connect to SFTP server.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }



            /* foreach (var filepath in filepaths.filepaths)
             {
                 //string[] filePaths = Directory.GetFiles(@"\\mobilestorage.pauls.ca\Data\" + filepath);
                 byte[] imageArray = System.IO.File.ReadAllBytes(filepath);
                 string base64ImageRepresentation = Convert.ToBase64String(imageArray);
                 var image = new DriverFtpFiles()
                 {
                     FileName = Path.GetFileName(filepath),
                     Image = base64ImageRepresentation

                 };
                 images.Add(image);
             }*/
            return images;
        }
        [HttpGet]
        [Route("api/get_website_mobile_version")]
        public Website_Mobile_Version Get_Website_Mobile_Version()
        {
            var web_mob_version = new Website_Mobile_Version();
            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.CommandText = "p_Get_Website_Mobile_Version";
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            web_mob_version.Web_Version = rdr["Web_Version"].ToString();
                            web_mob_version.Web_Version_Date = DateTime.Parse(rdr["Web_Version_Date"].ToString());
                            web_mob_version.Mobile_Version = rdr["Mobile_Version"].ToString();
                            web_mob_version.Mobile_Version_Date = DateTime.Parse(rdr["Mobile_Version_Date"].ToString());

                        }
                    }
                    rdr.Close();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error retrieving version info.");

            }


            return web_mob_version;
        }

        [HttpGet]
        [Route("api/get_user_info")]
        public UserInfoModel GetUsername()
        {
            UserInfoModel um = new UserInfoModel();

            try
            {
                var claims = User.Claims.ToList();

                var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                    cmd.CommandText = "p_Get_User_Info";
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            um.Email = rdr["User_Email"].ToString().Trim();
                            um.Role = rdr["User_Role"].ToString();
                            um.Id = rdr["User_Id"].ToString();
                            um.Username = rdr["User_First_Name"].ToString();
                            um.IsEnabled = rdr["User_IsEnabled"].ToString();
                            um.User_Company = rdr["User_Company"].ToString();

                        }
                    }
                    rdr.Close();
                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error retrieving user info.");

            }

            return um;
        }
        [HttpGet]
        [Route("api/get_current_user_info")]
        public CurrentUser_Info GetCurrentUsername()
        {
            CurrentUser_Info um = new CurrentUser_Info();

            try
            {
                var claims = User.Claims.ToList();

                var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                    cmd.CommandText = "p_Get_Current_User_Info";
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            um.User_Id = rdr["User_Id"].ToString();
                            um.User_Email = rdr["User_Email"].ToString().Trim();
                            um.User_First_Name = rdr["User_First_Name"].ToString();
                            um.User_Last_Name = rdr["User_Last_Name"].ToString();
                            um.User_Role = rdr["User_Role"].ToString();
                            um.User_IsEnabled = rdr["User_IsEnabled"].ToString();
                            um.User_Company = rdr["User_Company"].ToString();
                            um.User_Location = rdr["User_Location"].ToString();
                            um.User_Initials = rdr["User_Initials"].ToString();
                            um.User_Colour = rdr["User_Colour"].ToString();
                            um.Company_Name = rdr["Company_Name"].ToString();
                            um.Role_Name = rdr["Role_Name"].ToString();
                            um.Location_Name = rdr["Location_Full_Name"].ToString();
                            um.User_Identity_Id = userIdClaim.Value.ToString();
                        }
                    }
                    rdr.Close();
                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error retrieving user info.");

            }

            return um;
        }

   
        [HttpGet]
        [Route("api/get_current_user_access")]
        public List<CurrentUser_CompanyAccess> GetCurrentUserAccess(string userid)
        {
            List<CurrentUser_CompanyAccess> comps = new List<CurrentUser_CompanyAccess>();

            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {

                   

                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userid);
                    cmd.CommandText = "p_Get_Current_User_Access";
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            CurrentUser_CompanyAccess comp = new CurrentUser_CompanyAccess();
                            comp.Company_Id = rdr["Company_Id"].ToString();
                            comp.Company_Name = rdr["Company_Name"].ToString();
                            comp.Company_Sort_Order = rdr["Sort_Order"].ToString();
                            comp.Company_Type_Name = rdr["Company_Type_Name"].ToString();
                            comp.Company_Type_Id = rdr["Company_Type_Id"].ToString();
                            comps.Add(comp);


                        }
                    }
                    rdr.Close();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error retrieving user info.");

            }


            return comps;
        }


        [HttpGet]
        [Route("api/get_dispatch_users")]
        public List<User> GetDispatchUsers()
        {
            List<User> userLst = new List<User>();
            try
            {
                var claims = User.Claims.ToList();

                var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {

                    string role = "";

                    SqlCommand cmdCheckRole = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmdCheckRole.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                    cmdCheckRole.CommandText = "p_Get_User_Info";
                    con.Open();

                    SqlDataReader rdrRole = cmdCheckRole.ExecuteReader();
                    if (rdrRole.HasRows)
                    {
                        while (rdrRole.Read())
                        {
                            role = rdrRole["User_Role"].ToString();

                        }
                    }
                    rdrRole.Close();
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,

                    };
                    //if admin then
                    if (role.ToLower() == "25942536-C57D-4E18-A82D-0CDCC77A74C5".ToLower()) {
                        cmd.CommandText = "p_Get_Dispatch_Users_List";
                        SqlDataReader rdr2 = cmd.ExecuteReader();
                        if (rdr2.HasRows)
                        {
                            while (rdr2.Read())
                            {
                                User disp = new User()
                                {
                                    User_Email = rdr2["User_Email"].ToString().Trim(),
                                    User_Id = Guid.Parse(rdr2["User_Id"].ToString()),
                                    User_First_Name = rdr2["User_First_Name"].ToString(),
                                    User_Last_Name = rdr2["User_Last_Name"].ToString(),
                                    User_Role = rdr2["User_Role"].ToString(),
                                    User_Company = rdr2["User_Company"].ToString(),
                                    User_Company_Name = rdr2["Company_Name"].ToString(),
                                    User_Location = rdr2["User_Location"].ToString(),
                                    User_IsEnabled = bool.Parse(rdr2["User_IsEnabled"].ToString()),
                                    Sort_Order = Convert.ToInt32(rdr2["Sort_Order"]),
                                    Role_Name = rdr2["Role_Name"].ToString()
                                };
                                userLst.Add(disp);
                            }
                        }
                        rdr2.Close();

                    }
                    else
                    {
                        List<string> compAccess = new List<string>();
                        cmd.CommandText = "p_Get_My_Access_To_Companies";
                        cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);

                        SqlDataReader rdr = cmd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                compAccess.Add(rdr["Company_Id"].ToString());
                            }
                        }
                        rdr.Close();

                        cmd.CommandText = "p_Get_Users_List_For_Company";
                        foreach (string comp in compAccess)
                        {
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp);

                            rdr = cmd.ExecuteReader();
                            if (rdr.HasRows)
                            {
                                while (rdr.Read())
                                {
                                    User disp = new User()
                                    {
                                        User_Email = rdr["User_Email"].ToString().Trim(),
                                        User_Id = Guid.Parse(rdr["User_Id"].ToString()),
                                        User_First_Name = rdr["User_First_Name"].ToString(),
                                        User_Last_Name = rdr["User_Last_Name"].ToString(),
                                        User_Role = rdr["User_Role"].ToString(),
                                        User_Company = rdr["User_Company"].ToString(),
                                        User_Company_Name = rdr["Company_Name"].ToString(),
                                        User_Location = rdr["User_Location"].ToString(),
                                        User_IsEnabled = bool.Parse(rdr["User_IsEnabled"].ToString()),
                                        Sort_Order = Convert.ToInt32(rdr["Sort_Order"]),
                                        Role_Name = rdr["Role_Name"].ToString()

                                    };
                                    userLst.Add(disp);
                                }
                            }
                            rdr.Close();
                        }

                        rdr.Close();
                    }

                    foreach (User us in userLst)
                    {
                        us.User_Company_Access = new List<string>();

                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = us.User_Id;
                        cmd.CommandText = "p_Get_User_Access_To_Companies";

                        SqlDataReader rdr2 = cmd.ExecuteReader();
                        if (rdr2.HasRows)
                        {
                            while (rdr2.Read())
                            {
                                us.User_Company_Access.Add(rdr2["Company_Id"].ToString());

                            }
                        }
                        rdr2.Close();
                    }

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error retrieving user info.");

            }


            return userLst;
        }

        [HttpGet]
        [Route("api/get_companies")]
        public List<Company> GetCompanies()
        {
            List<Company> lstCompanies = new List<Company>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Companies"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Company comp = new Company()
                            {
                                Company_Id = rdr["Company_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString(),
                                Company_Type_Id = rdr["Company_Type_Id"].ToString(),
                                Company_IsEnabled = bool.Parse(rdr["Company_IsEnabled"].ToString()),
                            };
                            lstCompanies.Add(comp);


                        }
                    }
                    rdr.Close();

                    foreach (Company comp in lstCompanies)
                    {
                        cmd.Parameters.Clear();
                        cmd.CommandText = "p_Get_Company_Type_Name";
                        cmd.Parameters.Add("@Company_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp.Company_Type_Id);
                        rdr = cmd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                comp.Company_Type_Name = rdr["Company_Type_Name"].ToString();

                            }
                        }
                        rdr.Close();

                    }

     



                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting companies info.");

            }



            return lstCompanies;
        }

        [HttpGet]
        [Route("api/get_company")]
        public List<Company> GetCompany(string company_Id)
        {
            List<Company> lstCompanies = new List<Company>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Company"
                    };
                    con.Open();
                    cmd.Parameters.Add("@company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(company_Id);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Company comp = new Company()
                            {
                                Company_Id = rdr["Company_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString(),
                                Company_Type_Id = rdr["Company_Type_Id"].ToString(),
                                Company_IsEnabled = bool.Parse(rdr["Company_IsEnabled"].ToString()),
                                Company_Type_Name = rdr["Company_Type_Name"].ToString()
                            };
                            lstCompanies.Add(comp);


                        }
                    }
                    rdr.Close();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting companies info.");

            }



            return lstCompanies;
        }

        [HttpGet]
        [Route("api/get_Company_Access_To_Company")]
        public List<CompanyAccess> GetTCompanies(string company_id, string company_type_id)
        {
            List<CompanyAccess> lstCompanies = new List<CompanyAccess>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Company_Access_Other",


                    };
                    con.Open();
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(company_id);
                    cmd.Parameters.Add("@Company_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(company_type_id);
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            CompanyAccess comp = new CompanyAccess()
                            {
                                Access_Company_Id = rdr["Access_Company_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString(),
                                Company_Type_Id = rdr["Company_Type_Id"].ToString(),
                                Selected = rdr["Selected"].ToString()
                            };
                            lstCompanies.Add(comp);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting company type info.");

            }


            return lstCompanies;
        }

        [HttpGet]
        [Route("api/get_outsource_access")]
        public List<Company> GetOutsourceAccess(string Company_Id)
        {
            List<Company> lstCompanies = new List<Company>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Company_Access_Other"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);


                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Company comp = new Company()
                            {
                                Company_Id = rdr["Company_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString(),
                                Company_Type_Id = rdr["Company_Type_Id"].ToString(),
                            };
                            lstCompanies.Add(comp);


                        }
                    }
                    rdr.Close();
                    foreach (Company comp in lstCompanies)
                    {
                        cmd.Parameters.Clear();
                        cmd.CommandText = "p_Get_Company_Type_Name";
                        cmd.Parameters.Add("@Company_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp.Company_Type_Id);
                        rdr = cmd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                comp.Company_Type_Name = rdr["Company_Type_Name"].ToString();

                            }
                        }
                        rdr.Close();

                    }

                    con.Close();
                }
            }
            catch
            {
                throw new Exception("Error getting companies info.");

            }


            return lstCompanies;
        }



        [HttpGet]
        [Route("api/get_chats_for_chat_control")]
        public List<Chat> GetChatsForChatControl(string Company_Id)
        {
            List<Chat> lstChats = new List<Chat>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Chats_For_Control"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Chat chat = new Chat()
                            {
                                Chat_Id = rdr["Chat_Id"].ToString(),
                                Chat_Name = rdr["Chat_Name"].ToString(),
                                Chat_Type = rdr["Chat_Type"].ToString(),
                                Chat_Status = bool.Parse(rdr["Chat_Status"].ToString()),
                                Company_Id = rdr["Company_Id"].ToString(),
                                Roles = new List<string>()
                            };
                            lstChats.Add(chat);


                        }
                    }
                    rdr.Close();

                    cmd.CommandText = "p_Get_Roles_For_Chats";

                    foreach (Chat cht in lstChats)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(cht.Chat_Id);
                        SqlDataReader rdrTwo = cmd.ExecuteReader();


                        while (rdrTwo.Read())
                        {
                            cht.Roles.Add(rdrTwo["Role_Id"].ToString());
                        }
                        rdrTwo.Close();
                    }
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting chat info.");

            }


            return lstChats;
        }
        [HttpGet]
        [Route("api/get_permission_types")]
        public List<Permission_Types> GetPermissionTypes()
        {
            List<Permission_Types> lstPermissionsTypes = new List<Permission_Types>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Permission_Types"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Permission_Types pType = new Permission_Types()
                            {
                                Permission_Type_Id = rdr["Permission_Type_Id"].ToString(),
                                Permission_Type_Name = rdr["Permission_Type_Name"].ToString()
                            };
                            lstPermissionsTypes.Add(pType);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting roles info.");

            }

            return lstPermissionsTypes;
        }
        [HttpGet]
        [Route("api/get_permissions")]
        public List<Permissions> GetPermissions()
        {
            List<Permissions> lstPermissionsTypes = new List<Permissions>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Permissions"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Permissions pType = new Permissions()
                            {
                                Permission_Id = rdr["Permission_Id"].ToString(),
                                Permission_Type_Id = rdr["Permission_Type_Id"].ToString(),
                                Permission_Function = rdr["Permission_Function"].ToString(),
                                Sort_Order = Convert.ToInt32(rdr["Sort_Order"])
                            };
                            lstPermissionsTypes.Add(pType);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting permissions info.");

            }

            return lstPermissionsTypes;
        }

        [HttpGet]
        [Route("api/get_permission_access_level")]
        public List<Permission_Access_Level> GetPermissionAccessLevel(string permission_Id)
        {
            List<Permission_Access_Level> lstAccess = new List<Permission_Access_Level>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Permission_Access_Level"
                    };
                    cmd.Parameters.Add("@Permission_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(permission_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Permission_Access_Level pType = new Permission_Access_Level()
                            {
                                Access_Level_Id = rdr["Access_Level_Id"].ToString(),
                                Access_Level = Convert.ToInt32(rdr["Access_Level"]),
                                Image_Link = Convert.ToString(rdr["Image_Link"]),
                                Router_Link = Convert.ToString(rdr["Router_Link"]),
                                Permission_Status = bool.Parse(rdr["Permission_Status"].ToString()),

                            };
                            lstAccess.Add(pType);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting permissions info.");

            }

            return lstAccess;
        }
       
        [HttpGet]
        [Route("api/get_user_role_permissions")]
        public Dictionary<string, object> GetUserRolePermissions(string Role_Id, string Current_User_Role_Id)
        {
            List<User_Role_Permissions> lstPermissionsTypes = new List<User_Role_Permissions>();
            var listnew = new Dictionary<string, object>();
            var list = new Dictionary<string, List<Role_Permission_Access_Level>>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                    };
                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Role_Id);
                    cmd.Parameters.Add("@Current_User_Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Current_User_Role_Id);
                    cmd.CommandText = "p_Get_User_Role_Permissions";

                    con.Open();


                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {



                            Role_Permission_Access_Level rpal = new Role_Permission_Access_Level()
                            {
                                Access_Level_Id = rdr["Access_Level_Id"].ToString(),
                                Access_Level_Name = rdr["Access_Level_Name"].ToString(),
                                Selected = Convert.ToInt32(rdr["Selected"]),
                            };

                            if (list.ContainsKey(rdr["Permission_Id"].ToString()))
                            {
                                list[rdr["Permission_Id"].ToString()].Add(rpal);
                            }
                            else
                            {
                                list.Add(rdr["Permission_Id"].ToString(), new List<Role_Permission_Access_Level>() { rpal });
                            }

                            User_Role_Permissions urp = new User_Role_Permissions()
                            {
                                Permission_Id = rdr["Permission_Id"].ToString(),
                                Permission_Function = rdr["Permission_Function"].ToString(),
                                Permission_Type_Id = rdr["Permission_Type_Id"].ToString(),
                               
                            };
                            bool alreadyExists = lstPermissionsTypes.Any(x => x.Permission_Id.ToString().ToLower() == rdr["Permission_Id"].ToString().ToLower());

                            if (lstPermissionsTypes.Count == 0 || !alreadyExists)
                            {
                                lstPermissionsTypes.Add(urp);
                            }





                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting roles info.");

            }

            listnew.Add("Permission_Access_Level", list);
            listnew.Add("Permissions", lstPermissionsTypes);
            return listnew;
        }
        [HttpGet]
        [Route("api/get_current_user_company_role_permisions")]
        public Dictionary<string, List<Role_Permissions>> GetCurrentUserPermissions(string User_Id, string Company_Id)
        {
            var list = new Dictionary<string, List<Role_Permissions>>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Current_User_Company_Role_Permisions"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {

                        while (rdr.Read())
                        {
                            Role_Permissions pType = new Role_Permissions()
                            {
                                Permission_Type_Id = rdr["Permission_Type_Id"].ToString(),
                                Permission_Id = rdr["Permission_Id"].ToString(),
                                Permission_Function = rdr["Permission_Function"].ToString(),
                                Image_Link = rdr["Image_Link"].ToString(),
                                Router_Link = rdr["Router_Link"].ToString(),
                                Role_Id = rdr["User_Role"].ToString()



                            };
                            if (list.ContainsKey(rdr["Permission_Type_Name"].ToString()))
                            {
                                list[rdr["Permission_Type_Name"].ToString()].Add(pType);
                            }
                            else
                            {
                                list.Add(rdr["Permission_Type_Name"].ToString(), new List<Role_Permissions>() { pType });
                            }


                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting roles info.");

            }

            return list;
        }
        [HttpGet]
        [Route("api/get_roles")]
        public List<Role> GetRoles()
        {
            List<Role> lstRoles = new List<Role>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Roles"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Role role = new Role()
                            {
                                Role_Id = Guid.Parse(rdr["Role_Id"].ToString()),
                                Role_Name = rdr["Role_Name"].ToString()
                            };
                            lstRoles.Add(role);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting roles info.");

            }

            return lstRoles;
        }
        [HttpGet]
        [Route("api/get_current_company_roles")]
        public List<Role> GetCurrentCompanyRoles(string Company_Id)
        {
            List<Role> lstRoles = new List<Role>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Current_Company_Roles"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Role role = new Role()
                            {
                                Role_Id = Guid.Parse(rdr["Role_Id"].ToString()),
                                Role_Name = rdr["Role_Name"].ToString()
                            };
                            lstRoles.Add(role);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting roles info.");

            }

            return lstRoles;
        }
        [HttpGet]
        [Route("api/get_current_company_other_roles")]
        public List<User_Company_Roles> GetCurrentCompanyOtherRoles(string Current_Company_Id, string Access_Company_Id, string User_Id)
        {
            List<User_Company_Roles> lstRoles = new List<User_Company_Roles>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Current_Company_Other_Roles"
                    };
                    cmd.Parameters.Add("@Current_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Current_Company_Id);
                    cmd.Parameters.Add("@Access_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Access_Company_Id);
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            User_Company_Roles role = new User_Company_Roles()
                            {
                                Role_Id = rdr["Role_Id"].ToString(),
                                Role_Name = rdr["Role_Name"].ToString(),
                                Role_Access = Convert.ToInt32(rdr["Role_Access"])

                            };
                            lstRoles.Add(role);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }


            }
            catch
            {
                throw new Exception("Error getting roles info.");

            }

            return lstRoles;
        }
        [HttpGet]
        [Route("api/get_current_company_access")]
        public List<User_Company_Access> GetCurrentCompanyAccess(string Company_Id)
        {
            List<User_Company_Access> list_uca = new List<User_Company_Access>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Current_Company_Access"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            User_Company_Access uca = new User_Company_Access()
                            {

                                Company_Id = rdr["Company_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString()
                            };

                            list_uca.Add(uca);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting companies types.");

            }



            return list_uca;

        }


        [HttpGet]
        [Route("api/get_roles_based_on_user")]
        public List<Role> GetRolesBasedOnUser(string Company_id)
        {
            List<Role> lstRoles = new List<Role>();
            try
            {
                var claims = User.Claims.ToList();

                var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");


                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmdGetUserId = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmdGetUserId.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                    cmdGetUserId.CommandText = "p_Get_User_Info";
                    con.Open();

                    string user_id = "";
                    SqlDataReader rdrUserId = cmdGetUserId.ExecuteReader();
                    if (rdrUserId.HasRows)
                    {
                        while (rdrUserId.Read())
                        {
                            user_id = rdrUserId["User_Id"].ToString();

                        }
                    }
                    rdrUserId.Close();


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Roles_Based_On_User"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_id);
                    cmd.Parameters.Add("@Company_id", SqlDbType.NVarChar).Value = Company_id;

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Role role = new Role()
                            {
                                Role_Id = Guid.Parse(rdr["Role_Id"].ToString()),
                                Role_Name = rdr["Role_Name"].ToString()
                            };
                            lstRoles.Add(role);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting roles info.");

            }


            return lstRoles;
        }
        [HttpGet]
        [Route("api/get_role_company_access")]
        public List<Role_Company_Access> GetRoleCompanyAccess(string Role_Id, string Company_Id)
        {
            List<Role_Company_Access> lstrca = new List<Role_Company_Access>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Role_Company_Access"
                    };
                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Role_Id);
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Role_Company_Access rca = new Role_Company_Access()
                            {
                                Access_Company_Id = rdr["Access_Company_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString(),
                                Access_Type = Convert.ToInt32(rdr["Access_Type"]),
                                Default_Company = Convert.ToInt32(rdr["Default_Company"]),
                            };
                            lstrca.Add(rca);


                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting Role Company access info.");

            }

            return lstrca;
        }

        [HttpGet]
        [Route("api/get_locations")]
        public List<Location> GetLocations()
        {
            List<Location> lstLocs = new List<Location>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Locations"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Location loc = new Location()
                            {
                                Location_Id = rdr["Location_Id"].ToString(),
                                Location_Full_Name = rdr["Location_Full_Name"].ToString(),
                                Location_Short_Name = rdr["Location_Short_Name"].ToString(),
                                Location_IsEnabled = bool.Parse(rdr["Location_IsEnabled"].ToString()),
                            };
                            lstLocs.Add(loc);


                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting locations info.");

            }

            return lstLocs;
        }
        [HttpGet]
        [Route("api/get_company_types")]
        public List<CompanyTypes> GetCompanyTypes()
        {
            List<CompanyTypes> comptypes = new List<CompanyTypes>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Company_Types"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            CompanyTypes type = new CompanyTypes()
                            {
                                Company_Type_Id = rdr["Company_Type_Id"].ToString(),
                                Company_Type_Name = rdr["Company_Type_Name"].ToString(),
                                Sort_Order = Convert.ToInt32(rdr["Sort_Order"])
                            };
                            comptypes.Add(type);


                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting locations info.");

            }

            return comptypes;
        }

        [HttpGet]
        [Route("api/get_company_type_roles")]
        public List<CompanyTypeRoles> GetCompanyTypeRoles()
        {
            List<CompanyTypeRoles> lstCompanyroles = new List<CompanyTypeRoles>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Company_Type_Roles"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            CompanyTypeRoles role = new CompanyTypeRoles()
                            {
                                Company_Type_Id = rdr["Company_Type_Id"].ToString(),
                                Role_Id = rdr["Role_Id"].ToString(),
                                Role_Name = rdr["Role_Name"].ToString(),
                                Sort_Order = Convert.ToInt32(rdr["Sort_Order"]),
                            };

                            lstCompanyroles.Add(role);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting companies types.");

            }



            return lstCompanyroles;
        }

        [HttpGet]
        [Route("api/get_company_roles")]
        public List<Company_Roles> GetCompanyRoles()
        {
            List<Company_Roles> lstCompanyroles = new List<Company_Roles>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Company_Roles"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            Company_Roles role = new Company_Roles()
                            {

                                Role_Id = rdr["Role_Id"].ToString(),
                                Role_Name = rdr["Role_Name"].ToString(),
                                Sort_Order = Convert.ToInt32(rdr["Sort_Order"]),
                                Company_Id = rdr["Company_Id"].ToString(),
                                Role_Access_Level = Convert.ToInt32(rdr["Role_Access_Level"])
                            };

                            lstCompanyroles.Add(role);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting companies types.");

            }



            return lstCompanyroles;
        }
        [HttpGet]
        [Route("api/get_user_company_access")]
        public List<User_Company_Access> GetUserCompanyAccess(string CompanyId)
        {
            List<User_Company_Access> list_uca = new List<User_Company_Access>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_User_Company_Access"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(CompanyId);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            User_Company_Access uca = new User_Company_Access()
                            {

                                Company_Id = rdr["Company_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString()
                            };

                            list_uca.Add(uca);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting companies types.");

            }



            return list_uca;
        }
        [HttpGet]
        [Route("api/get_user_company_roles")]
        public List<User_Company_Roles> GetUserCompanyRoles(string User_Id, string CompanyId)
        {
            List<User_Company_Roles> list_ucr = new List<User_Company_Roles>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_User_Company_Roles"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(CompanyId);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            User_Company_Roles ucr = new User_Company_Roles()
                            {

                                Role_Id = rdr["Role_Id"].ToString(),
                                Role_Name = rdr["Role_Name"].ToString(),
                                Role_Access = Convert.ToInt32(rdr["Role_Access"])

                            };

                            list_ucr.Add(ucr);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting companies types.");

            }



            return list_ucr;
        }
        [HttpGet]
        [Route("api/get_locations_by_companyId")]
        public List<Location> GetLocationsbyCompanyId(string Company_Id)
        {
            List<Location> lstLocs = new List<Location>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Location_By_CompanyId"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Location loc = new Location()
                            {
                                Location_Id = rdr["Location_Id"].ToString(),
                                Location_Full_Name = rdr["Location_Full_Name"].ToString(),
                                Location_Short_Name = rdr["Location_Short_Name"].ToString(),
                                Location_IsEnabled = bool.Parse(rdr["Location_IsEnabled"].ToString()),
                            };
                            lstLocs.Add(loc);


                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting locations info.");

            }

            return lstLocs;
        }

        // TRUCK CONTROL

        [HttpPost]
        [Route("api/update_role_company_access")]
        public void UpdateRoleCompanyAccess(Updated_Role_Company_Access urca)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Role_Company_Access"
                    };

                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(urca.Role_Id);
                    cmd.Parameters.Add("@Role_Company_Access", SqlDbType.NVarChar).Value = JsonConvert.SerializeObject(urca.Role_Company_Access);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating Role Company Access.");

            }


        }


        [HttpPost]
        [Route("api/update_location")]
        public void UpdateLocation(Location loc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Location"
                    };

                    cmd.Parameters.Add("@Location_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loc.Location_Id);
                    cmd.Parameters.Add("@Location_Full_Name", SqlDbType.NVarChar, -1).Value = loc.Location_Full_Name;
                    cmd.Parameters.Add("@Location_Short_Name", SqlDbType.NVarChar, 15).Value = loc.Location_Short_Name;
                    cmd.Parameters.Add("@Location_IsEnabled", SqlDbType.Bit).Value = loc.Location_IsEnabled;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating location.");

            }


        }
        [HttpPost]
        [Route("api/create_location")]
        public void CreateLocation(Company_Location loc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_Location"
                    };

                    cmd.Parameters.Add("@Location_Full_Name", SqlDbType.NVarChar, -1).Value = loc.Location_Full_Name;
                    cmd.Parameters.Add("@Location_Short_Name", SqlDbType.NVarChar, 15).Value = loc.Location_Short_Name;
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loc.Company_Id);
                    cmd.Parameters.Add("@Location_IsEnabled", SqlDbType.Bit).Value = true;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error creating location.");

            }


        }
        [HttpPost]
        [Route("api/add_permission")]
        public void AddPermission(Permissions pr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Add_Permission"
                    };
                    cmd.Parameters.Add("@Permission_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Permission_Type_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Function", SqlDbType.NVarChar).Value = pr.Permission_Function.ToString();
                    cmd.Parameters.Add("@Sort_Order_New", SqlDbType.Int).Value = Convert.ToInt32(pr.Sort_Order.ToString());

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error Adding permission");

            }


        }
        [HttpPost]
        [Route("api/add_permission_type")]
        public void AddPermissionType(Permission_Types pt)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Add_Permission_Type"
                    };
                    cmd.Parameters.Add("@Permission_Type_Name", SqlDbType.NVarChar).Value = pt.Permission_Type_Name.ToString();

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error Adding permission");

            }


        }
        [HttpPost]
        [Route("api/update_permission_access_level")]
        public void UpdatePermission(Permission_Access_Level pr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Permission_Access_Level"
                    };
                    cmd.Parameters.Add("@Access_Level_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Access_Level_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Permission_Id.ToUpper());
                    cmd.Parameters.Add("@Access_Level", SqlDbType.Int).Value = Convert.ToInt32(pr.Access_Level);
                    cmd.Parameters.Add("@Image_Link", SqlDbType.NVarChar).Value = pr.Image_Link.ToString();
                    cmd.Parameters.Add("@Router_Link", SqlDbType.NVarChar).Value = pr.Router_Link.ToString();
                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating permission");

            }


        }
        [HttpPost]
        [Route("api/delete_permission")]
        public void DeletePermission(Permissions pr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Delete_Permission"
                    };
                    cmd.Parameters.Add("@Permission_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Permission_Type_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Permission_Id.ToUpper());
                    cmd.Parameters.Add("@Sort_Order_New", SqlDbType.Int).Value = Convert.ToInt32(pr.Sort_Order.ToString());

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error delteing permission");

            }


        }
        [HttpPost]
        [Route("api/update_permission")]
        public void UpdatePermission(Permissions pr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Permission"
                    };
                    cmd.Parameters.Add("@Permission_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Permission_Type_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Permission_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Function", SqlDbType.NVarChar).Value = pr.Permission_Function.ToString();
                    cmd.Parameters.Add("@Sort_Order_New", SqlDbType.Int).Value = Convert.ToInt32(pr.Sort_Order.ToString());


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error delteing permission");

            }


        }
        [HttpPost]
        [Route("api/update_permission_type")]
        public void UpdatePermissionType(Permission_Types pr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Permission_Type"
                    };
                    cmd.Parameters.Add("@Permission_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pr.Permission_Type_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Type_Name", SqlDbType.NVarChar).Value = pr.Permission_Type_Name.ToString();


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error delteing permission");

            }


        }
        [HttpPost]
        [Route("api/delete_permission_type")]
        public void DeletePermissionType(Permission_Types pt)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Delete_Permission_Type"
                    };
                    cmd.Parameters.Add("@Permission_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pt.Permission_Type_Id);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error delteing permission type");

            }


        }
        [HttpPost]
        [Route("api/update_user_role_permissions")]
        public void UpdateUserRolePermissions(Updated_User_Role_Permissions Urp)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_User_Role_Permissions"
                    };


                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Urp.Role_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Urp.Permission_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Urp.Permission_Type_Id.ToUpper());
                    cmd.Parameters.Add("@Access_Level_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Urp.Access_Level_Id.ToUpper());
                    cmd.Parameters.Add("@Selected", SqlDbType.Int).Value = Convert.ToInt32(Urp.Selected);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating permission");

            }


        }
        [HttpPost]
        [Route("api/create_role")]
        public void CreateRole(Company_Roles cr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_Role"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(cr.Company_Id.ToUpper());
                    cmd.Parameters.Add("@Role_Name_New", SqlDbType.NVarChar, 50).Value = cr.Role_Name;
                    cmd.Parameters.Add("@Sort_Order_New", SqlDbType.Int).Value = Convert.ToInt32(cr.Sort_Order);
                    cmd.Parameters.Add("@Role_Access_Level", SqlDbType.Int).Value = Convert.ToInt32(cr.Role_Access_Level);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error creating role.");

            }


        }
        [HttpPost]
        [Route("api/update_role")]
        public void UdateRole(Company_Roles ctr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Role"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ctr.Company_Id.ToUpper());
                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ctr.Role_Id);
                    cmd.Parameters.Add("@Role_Name_New", SqlDbType.NVarChar, -1).Value = ctr.Role_Name;
                    cmd.Parameters.Add("@Sort_Order_New", SqlDbType.Int).Value = Convert.ToInt32(ctr.Sort_Order);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating role.");

            }


        }
        [HttpPost]
        [Route("api/delete_role")]
        public void DeleteRole(Company_Roles ctr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Delete_Role"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ctr.Company_Id.ToUpper());
                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ctr.Role_Id);
                    cmd.Parameters.Add("@Sort_Order_New", SqlDbType.Int).Value = Convert.ToInt32(ctr.Sort_Order);


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error deleting role.");

            }


        }
        [HttpPost]
        [Route("api/update_user_company_roles")]
        public void UpdateUserCompanyRoles(Updated_User_Company_Roles uucr)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_User_Company_Roles"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(uucr.User_Id);
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(uucr.Company_Id);
                    cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(uucr.Role_Id);


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating user company access role.");

            }


        }
        [HttpPost]
        [Route("api/update_company")]
        public void UpdateCompanyAccessToCompany(Company com)
        {

            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Update_Company"
                };

                cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(com.Company_Id);
                cmd.Parameters.Add("@Company_Name", SqlDbType.NVarChar, -1).Value = com.Company_Name;
                cmd.Parameters.Add("@Company_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(com.Company_Type_Id.ToUpper());
                cmd.Parameters.Add("@Company_IsEnabled", SqlDbType.Bit).Value = com.Company_IsEnabled;


                con.Open();
                cmd.ExecuteNonQuery();

                con.Close();

            }

        }
        [HttpPost]
        [Route("api/update_company_access_to_company")]
        public void UpdateAccessToCompany(CompanyAccessToCompany com)
        {

            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Update_Company_Access_To_Company"
                };
                // Console.WriteLine(JsonConvert.SerializeObject(com.Access_To_Companies));
                cmd.Parameters.Add("@Current_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(com.Company_Id);
                cmd.Parameters.Add("@Access_To_Companies", SqlDbType.NVarChar).Value = JsonConvert.SerializeObject(com.Access_To_Companies);

                con.Open();
                cmd.ExecuteNonQuery();

                con.Close();

            }

        }
        [HttpPost]
        [Route("api/update_company_locations")]
        public void UpdatecCompanyLocations(CompanyAccessToCompany com)
        {

            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Update_Company_Locations"
                };
                Console.WriteLine(JsonConvert.SerializeObject(com.Access_To_Companies));
                cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(com.Company_Id);
                cmd.Parameters.Add("@Company_Locations", SqlDbType.NVarChar).Value = JsonConvert.SerializeObject(com.Locations);

                con.Open();
                cmd.ExecuteNonQuery();

                con.Close();

            }

        }
        [HttpPost]
        [Route("api/create_company")]
        public void CreateCompany(Company com)
        {
            try
            {


                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_Company"
                    };

                    cmd.Parameters.Add("@Company_Name", SqlDbType.NVarChar, -1).Value = com.Company_Name;
                    cmd.Parameters.Add("@Company_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(com.Company_Type_Id.ToUpper());
                    cmd.Parameters.Add("@Date_Created", SqlDbType.DateTime2).Value = DateTime.Now;


                    con.Open();
                    var Company_Id = "";
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {


                            Company_Id = rdr["Company_Id"].ToString();

                        }
                    }
                    rdr.Close(); con.Close();
                    if (Company_Id != "")
                    {
                        using (var client = new SftpClient("mobilestorage.pauls.ca", port: 22, "dispatch_user", "_)$a8gF3TC"))
                        {
                            try
                            {
                                client.Connect();

                                var remoteDirectory = "/" + Company_Id.ToUpper();
                                if (!client.Exists(remoteDirectory))
                                {
                                    client.CreateDirectory(remoteDirectory);
                                }


                            }
                            catch (Exception Ex)
                            {
                                Console.WriteLine(Ex.Message);

                            }
                            finally
                            {
                                if (client.IsConnected)
                                {
                                    client.Disconnect();
                                }
                            }
                        }

                    }

                }
            }
            catch
            {
                throw new Exception("Error creating company.");

            }

        }

        [HttpPost]
        [Route("api/disable_user")]
        public void DisableUser(User Us)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Disable_User"
                    };

                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar, -1).Value = Us.User_Email;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error disabling user.");

            }



        }
        [HttpPost]
        [Route("api/enable_user")]
        public void EnableUser(User Us)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_User"
                    };

                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar, -1).Value = Us.User_Email;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error enabling user.");

            }



        }
        [HttpPost]
        [Route("api/enable_disable_permission_access_level")]
        public void EnableDisablePermissionAccessLevel(Permission_Access_Level pal)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_Disable_Permission_Access_Level"
                    };

                    cmd.Parameters.Add("@Access_Level_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pal.Access_Level_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(pal.Permission_Id.ToUpper());
                    cmd.Parameters.Add("@Permission_Status", SqlDbType.Bit).Value = Convert.ToBoolean(pal.Permission_Status);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error enabling user.");

            }



        }

        [HttpPost]
        [Route("api/update_user_current_company")]
        public void UpdateUserCurrentCompany(User_Current_Company comp)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp.User_Id);
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp.User_Identity_Id);
                    cmd.Parameters.Add("@Permission_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp.Permission_Id);
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp.Company_Id);

                    cmd.CommandText = "p_Update_User_Current_Company";


                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);

            }
        }

      /*  [HttpPost]
        [Route("api/handle_login_logout")]
        public void HandleLoginLogout(LoginLLogoutCompanies comp)
        {
            try
            {
                var claims = User.Claims.ToList();
                var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
                string user_identity_id = userIdClaim.Value;

                string user_id = "";
                string uFName = "";
                string uRole = "";
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_identity_id);
                    cmd.CommandText = "p_Get_User_Info";


                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            user_id = rdr["User_Id"].ToString();
                            uFName = rdr["User_First_Name"].ToString();
                            uRole = rdr["User_Role"].ToString();
                        }
                    }
                    rdr.Close();
                    con.Close();
                }

                //Getting company name based on company id
              *//*  using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp.Company_Id);
                    cmd.CommandText = "p_Get_Company_Name";


                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            uCompanyName = rdr["Company_Name"].ToString();
                        }
                    }
                    rdr.Close();
                    con.Close();
                }*//*


                //_statusHandler.HandleLoginLogout(comp, user_Id);

                if (comp.Current_Company.Company_Id != "" || comp.Current_Company.Company_Id != null)
                {
                    string company_Id = comp.Current_Company.Company_Id;
                    bool exists = false;
                    StatusUpdateModel stUp = new StatusUpdateModel();

                    DateTime nw = DateTime.Now;


                    foreach (HubUser us in StatusHandler.userConnections)
                    {

                        if (us.User_Id == user_identity_id)
                        {
                            exists = true;
                            if (us.Company_Id.ToLower() != company_Id.ToLower())
                            {
                                MessageModel mm = new MessageModel();
                                //log out of old company
                                if (comp.Previous_Company.Company_Id.ToLower() != comp.Current_Company.Company_Id.ToLower())
                                {
                                    _statusHandler.UpdateUserStatus(user_identity_id, comp.Previous_Company.Company_Id, "has logged out from " + comp.Previous_Company.Company_Name);
                                    stUp.Company_Id = us.Company_Id;
                                    mm.Message_Date = nw;
                                    mm.Message_Text = "has logged out from " + comp.Previous_Company.Company_Name;
                                    mm.Message_From_User_Name = uFName;
                                    //mm.Message_Company_Name = uCompanyName;

                                    //SEND TO FE
                                    _hubContext.Clients.All.SendAsync("UpdatedUserStatus", stUp);
                                }

                                //log in to new company
                                _statusHandler.UpdateUserStatus(user_identity_id, comp.Current_Company.Company_Id, "has logged in " + comp.Current_Company.Company_Name);
                                us.Company_Id = company_Id;

                                stUp.Company_Id = us.Company_Id;
                                mm.Message_Text = "has logged in from " + comp.Current_Company.Company_Name;

                                _hubContext.Clients.All.SendAsync("UpdatedUserStatus", stUp);
                                break;

                            }

                        }
                    }
                    if (!exists)
                    {
                        Console.WriteLine(user_identity_id);
                        HubUser us = new HubUser();
                        us.User_Id = user_identity_id;
                        us.Company_Id = comp.Current_Company.Company_Id;
                        StatusHandler.userConnections.Add(us);
                        //handle user logged to company for the first time
                        _statusHandler.UpdateUserStatus(user_identity_id, company_Id, "has logged in " + comp.Current_Company.Company_Name);

                        stUp.Company_Id = comp.Current_Company.Company_Id;
                        MessageModel mm = new MessageModel();
                        mm.Message_Date = nw;
                        mm.Message_Text = "has logged in from " + comp.Current_Company.Company_Name; ;
                        mm.Message_From_User_Name = uFName;
                        stUp.Message = mm;
                        _hubContext.Clients.All.SendAsync("UpdatedUserStatus", stUp);


                    }
                }



            }
            catch (Exception e)
            {
                throw new Exception(e.Message);

            }


        }*/

        [Route("api/register_user")]
        [HttpPost]
        public async Task<IActionResult> RegisterUserAsync(RegisterUserModel mod)
        {
            if (mod.User_Location == "" || mod.User_Location == null)
            {
                mod.User_Location = Guid.Empty.ToString();
            }

            //return BadRequest("Invalid username or password");
            //setting the values for Identity server registration
            var values = new Dictionary<string, string>
                {
                    { "Username", mod.User_Email },
                    { "Password", mod.User_Password}
                };
            var jsstr = JsonConvert.SerializeObject(values);

            var requestBody = new StringContent(jsstr);
            requestBody.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var response = await client.PostAsync(Startup.IdentityString + "/Register", requestBody);
            var responseUserId = await response.Content.ReadAsStringAsync();
            Guid newId;

            try
            {
                newId = Guid.Parse(responseUserId);
            }
            catch
            {
                List<IdentityError> errLst = JsonConvert.DeserializeObject<List<IdentityError>>(responseUserId);
                string errorDesc = "";

                foreach (IdentityError err in errLst)
                {
                    errorDesc += err.description;
                    errorDesc += "\n";
                }

                return BadRequest(errorDesc);
            }

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_User"
                    };
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = newId;
                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar).Value = mod.User_Email;
                    cmd.Parameters.Add("@User_First_Name", SqlDbType.NVarChar).Value = mod.User_FirstName;
                    cmd.Parameters.Add("@User_Last_Name", SqlDbType.NVarChar).Value = mod.User_LastName;
                    cmd.Parameters.Add("@User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Role);
                    cmd.Parameters.Add("@User_Company", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Company);
                    cmd.Parameters.Add("@User_Location", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Location);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    //Get user ID
                    string userId = "";
                    cmd.CommandText = "p_Get_User_Info";
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = newId;
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            userId  = rdr["User_Id"].ToString();
                          
                        }
                    }
                    rdr.Close();


                    cmd.CommandText = "p_Assign_User_To_Company";
                    foreach (string str in mod.User_Company_Access)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userId);
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(str);
                        cmd.Parameters.Add("@Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Role);
                        cmd.ExecuteNonQuery();

                    }
                    con.Close();
                }
            }
            catch
            {
                return BadRequest("Error creating a user. Please contact system administrator.");

            }


            return Ok();
        }

        /* [Route("api/get_company_type")]
         [HttpPost]
         public string GetCompanyTypeAsync(string comp)
         {
             string uCompanyType = "";
             try
             {

                 using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                 {


                     SqlCommand cmd = new SqlCommand
                     {
                         Connection = con,
                         CommandType = System.Data.CommandType.StoredProcedure
                     };
                     cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(comp);
                     cmd.CommandText = "p_Get_Company_Name";


                     con.Open();
                     SqlDataReader rdr = cmd.ExecuteReader();
                     if (rdr.HasRows)
                     {
                         while (rdr.Read())
                         {
                             uCompanyType = rdr["Company_Name"].ToString();
                         }
                     }
                     rdr.Close();
                     con.Close();
                 }





             }
             catch
             {
                 //throw new Exception("Error editing user info.");
             }
             return uCompanyType;

         }*/
        [Route("api/update_account")]
        [HttpPost]
        public async Task<IActionResult> UpdateAccountAsync(EditUserModel mod)
        {
            try
            {

                if (mod.User_Password != "")
                {
                    var passValues = new Dictionary<string, string>
                    {
                        { "UserName", mod.User_Email},
                        { "Password", mod.User_Password }

                    };
                    var jsstrPass = JsonConvert.SerializeObject(passValues);
                    var requestBodyPass = new StringContent(jsstrPass);
                    requestBodyPass.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    var resp = await client.PostAsync(Startup.IdentityString + "/UpdatePassword", requestBodyPass);

                }
            }
            catch
            {
                throw new Exception("Error editing user info.");
            }
            return Ok();
        } 
    

        [Route("api/update_user")]
        [HttpPost]
        public async Task<IActionResult> UpdateUserAsync(EditUserModel mod)
        {
            try
            {

                if (mod.User_Password != "")
                {
                    var passValues = new Dictionary<string, string>
                    {
                        { "UserName", mod.User_Email_Old },
                        { "Password", mod.User_Password }

                    };
                    var jsstrPass = JsonConvert.SerializeObject(passValues);
                    var requestBodyPass = new StringContent(jsstrPass);
                    requestBodyPass.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    var resp = await client.PostAsync(Startup.IdentityString + "/UpdatePassword", requestBodyPass);

                }

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = CommandType.StoredProcedure,
                        CommandText = "p_Update_User"
                    };
                    if (mod.User_Location_Id == "" || mod.User_Location_Id == null)
                    {
                        mod.User_Location_Id = Guid.Empty.ToString();
                    }

                    if (mod.Company_Id == "" || mod.Company_Id == null)
                    {
                        mod.Company_Id = Guid.Empty.ToString();
                    }
                    con.Open();
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Id);
                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar).Value = mod.User_Email;
                    cmd.Parameters.Add("@User_First_Name", SqlDbType.NVarChar).Value = mod.User_FirstName;
                    cmd.Parameters.Add("@User_Last_Name", SqlDbType.NVarChar).Value = mod.User_LastName;
                    cmd.Parameters.Add("@User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Role_Id);
                    cmd.Parameters.Add("@User_Company", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.Company_Id);
                    cmd.Parameters.Add("@User_Location", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Location_Id);

                    cmd.ExecuteNonQuery();


                    con.Close();
                }
            }
            catch
            {
                throw new Exception("Error editing user info.");
            }
            return Ok();

        }



    }
   
    
}
