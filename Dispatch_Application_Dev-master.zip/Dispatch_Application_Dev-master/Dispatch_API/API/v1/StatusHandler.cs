﻿using Api;
using Driver_Api.Data.Entity;
using Dispatch_Application_Debug_API.Data.Hubs;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.API.v1
{
    public class StatusHandler
    {
        public static List<HubUser> userConnections = new List<HubUser>();

        public void HandleLoginLogout(Company comp, string user_Id)
        {
            try
            {

                if (comp.Company_Id != "" || comp.Company_Id != null)
                {
                    string company_Id = comp.Company_Id;
                    bool exists = false;


                    foreach (HubUser us in userConnections)
                    {
                        if (us.User_Id == user_Id)
                        {
                            exists = true;
                            if (us.Company_Id.ToLower() != company_Id.ToLower())
                            {
                                //log out of old company
                                UpdateUserStatus(user_Id, us.Company_Id, "has logged out");


                                //log in to new company
                                UpdateUserStatus(user_Id, company_Id, "has logged in");
                                us.Company_Id = company_Id;
                            }

                        }
                    }
                    if (!exists)
                    {
                        HubUser us = new HubUser();
                        us.User_Id = user_Id;
                        us.Company_Id = company_Id;
                        userConnections.Add(us);
                        //handle user logged to company for the first time
                        UpdateUserStatus(user_Id, company_Id, "has logged in");

                    }
                }

            }
            catch
            {
                throw new Exception("Error.");

            }


        }
        public void LogOutUserStatus(string user_Id)
        {
            HubUser userToDelete = new HubUser();
            string company_Id = "";
            foreach (HubUser us in userConnections)
            {
                if (us.User_Id == user_Id)
                {
                    userToDelete = us;
                    company_Id = us.Company_Id;
                }
            }
            if (userToDelete.User_Id == user_Id)
            {
                userConnections.Remove(userToDelete);

                //handle logout user from the company
                UpdateUserStatus(user_Id, company_Id, "has logged out");

            }
        }
        public void StartBreakStatus(string user_Id)
        {

            string company_Id = "";
            foreach (HubUser us in userConnections)
            {
                if (us.User_Id == user_Id)
                {
                    company_Id = us.Company_Id;
                }
            }

            UpdateUserStatus(user_Id, company_Id, "started a break");

        }

        public void EndBreakStatus(string user_Id)
        {

            string company_Id = "";
            foreach (HubUser us in userConnections)
            {
                if (us.User_Id == user_Id)
                {
                    company_Id = us.Company_Id;
                }
            }

            UpdateUserStatus(user_Id, company_Id, "finished a break");

        }

        public void UpdateUserStatus(string user_identity_id, string company_Id, string action)
        {
            try
            {
                string user_id = "";
                string uFName = "";
                string uRole = "";
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_identity_id);
                    cmd.CommandText = "p_Get_User_Info";


                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            user_id = rdr["User_Id"].ToString();
                            uFName = rdr["User_First_Name"].ToString();
                            uRole = rdr["User_Role"].ToString();
                        }
                    }
                    rdr.Close();
                    DateTime nw = DateTime.Now;
                    if (uRole.ToLower() != "25942536-C57D-4E18-A82D-0CDCC77A74C5".ToLower())
                    {
                        
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_id);
                        cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = nw;
                        cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = action;
                        cmd.Parameters.Add("@User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(uRole);
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(company_Id);
                        cmd.CommandText = "p_Save_User_Status";

                        cmd.ExecuteNonQuery();



                    }
                    con.Close();

                    MessageModel mes = new MessageModel()
                    {
                        Message_Date = nw,
                        Message_From_User_Name = uFName,
                        From_User_Id = user_identity_id.ToString(),
                        Message_Text = action
                    };

                   
                }
            }
            catch
            {
                throw new Exception("Error updating the status");
            }


        }

        public string GetCompId(string user_Id)
        {

            string company_Id = "";
            foreach (HubUser us in userConnections)
            {
                if (us.User_Id == user_Id)
                {
                    company_Id = us.Company_Id;
                }
            }

            return company_Id;

        }

        public StatusUpdateModel StatusUpdateModel(string user_Id)
        {
            string company_Id = "";
            string uFName = "";
            foreach (HubUser us in userConnections)
            {
                if (us.User_Id == user_Id)
                {
                    company_Id = us.Company_Id;
                }
            }
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_Id);
                cmd.CommandText = "p_Get_User_Info";

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        uFName = rdr["User_First_Name"].ToString();

                    }
                }
                rdr.Close();
                con.Close();
            }

            StatusUpdateModel stUp = new StatusUpdateModel();
            stUp.Company_Id = company_Id;
            MessageModel mm = new MessageModel();
            mm.Message_Date = DateTime.Now;
            mm.Message_From_User_Name = uFName;
            stUp.Message = mm;


            return stUp;
        }


    }
}
