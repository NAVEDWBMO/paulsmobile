﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Api.Data.Entity;
using Driver_Api.Data.Entity;
using Driver_Api.Data.Entity.ActionModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Dispatch_Api.Data.Entity;
using SoapHttpClient;
using System.Xml.Linq;
using SoapHttpClient.Enums;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;
using Renci.SshNet;

namespace Api.API.v1
{
    [ApiController]
    [Authorize]
    public class DriverController : Controller
    {
        private static readonly HttpClient client = new HttpClient();

        public List<Driver> lstOfDrivers = new List<Driver>();


        [HttpGet]
        [Route("api/get_drivers_info")]
        public List<Driver> GetDriversInfo()
        {
            try
            {
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Get_DriverList"
                };
                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        Driver drv = new Driver()
                        {
                            Driver_Id = rdr["Driver_Id"].ToString(),
                            D_Id = rdr["D_Id"].ToString(),
                            Driver_Firstname = rdr["D_Name"].ToString()
                        };
                        lstOfDrivers.Add(drv);
                    }
                }
                rdr.Close();
                con.Close();

            }

            return lstOfDrivers;
            }
            catch
            {
                throw new Exception("Error getting driver info");

            }
            
        }


        [HttpGet]
        [Route("api/get_registered_drivers_info")]
        public List<Driver> GetRegisteredDriversInfo(string Company_Id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                    var claims = User.Claims.ToList();

                    var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

                    string role = "";

                    SqlCommand cmdCheckRole = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmdCheckRole.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                    cmdCheckRole.CommandText = "p_Get_User_Info";
                    con.Open();

                    SqlDataReader rdrRole = cmdCheckRole.ExecuteReader();
                    if (rdrRole.HasRows)
                    {
                        while (rdrRole.Read())
                        {
                            role = rdrRole["User_Role"].ToString();

                        }
                    }
                    rdrRole.Close();

                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure,
                            CommandText = "p_Get_RegisteredDriverList_For_Company"
                        };

                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);


                        SqlDataReader rdr = cmd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                string isEn = rdr["IsEnabled"].ToString();
                                bool isEnabled = false;
                                if (isEn == null || isEn == "" || isEn == "0" || isEn == "False")
                                {
                                    isEnabled = false;
                                }
                                else
                                {
                                    isEnabled = true;
                                }
                                Driver drv = new Driver()
                                {
                                    User_Id = rdr["User_Id"].ToString(),
                                    Driver_Id = rdr["Driver_Id"].ToString(),
                                    D_Id = rdr["Driver_Id_Normalized"].ToString(),
                                    Driver_Firstname = rdr["Firstname"].ToString(),
                                    Driver_Lastname = rdr["Lastname"].ToString(),
                                    Driver_Device_Id = rdr["Driver_Device_Id"].ToString(),
                                    Driver_Email = rdr["Email_Id"].ToString(),
                                    Driver_Phone = rdr["Phone_Number"].ToString(),
                                    Driver_Truck_Id = rdr["Truck_Id"].ToString(),
                                    Driver_Role_Id = rdr["Driver_Role"].ToString(),
                                    Driver_Role_Name = rdr["Driver_Role_Name"].ToString(),
                                    Driver_IsEnabled = isEnabled

                                };
                                Company comp = new Company()
                                {
                               
                                    Company_Name = rdr["Company_Name"].ToString(),
                                    Company_Type_Name = rdr["Company_Type_Name"].ToString(),
                                    Company_Id = rdr["Company_Id"].ToString()

                                };
                                drv.Company = comp;

                                lstOfDrivers.Add(drv);
                            }
                        }
                        rdr.Close();
                  
                    con.Close();

                        

            }

            return lstOfDrivers;
            }
            catch
            {
                throw new Exception("Error getting driver info");

    }

}

        


        //Get driver info for xamarin client
        [HttpGet]
        [Route("api/get_mobile_driver_info")]
        public Driver GetMobileDriverInfo()
        {
            Driver drv = new Driver();

            try
            {
                var claims = User.Claims.ToList();

                var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandText = "Select * From [dbo].[t_Driver] Where [User_Identity_Id] Like '%" + userIdClaim.Value + "%'"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            drv.Driver_Id = rdr["Driver_Id"].ToString();
                            drv.D_Id = rdr["User_Id"].ToString();
                            drv.Driver_Firstname = rdr["Firstname"].ToString();
                            drv.Company = new Company() { Company_Id = rdr["Company_Id"].ToString()};
                            drv.Driver_Role_Id = rdr["Driver_Role"].ToString();
                            drv.Driver_Lastname = rdr["Lastname"].ToString();
                        }
                    }
                  
                  
                    rdr.Close();
                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error retrieving driver info.");

            }

            return drv;
        }
        [HttpGet]
        [Route("api/get_driver_roles")]
        public List<Driver_Roles> GetDriverRoles(string Company_Type_Id)
        {
            List<Driver_Roles> drv_roles = new List<Driver_Roles>();

            try
            {
                
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Driver_Roles"
                    };
                    cmd.Parameters.Add("@Company_Type_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Type_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Driver_Roles Dr = new Driver_Roles()
                            {
                                Driver_Role_Id = rdr["Driver_Role_Id"].ToString(),
                                Driver_Role_Name = rdr["Driver_Role_Name"].ToString(),

                            };
                            drv_roles.Add(Dr);

                        }
                    }


                    rdr.Close();
                    con.Close();

                }

            }
            catch(Exception Ex)
            {
                //throw new Exception("Error retrieving driver info.");
                Console.WriteLine(Ex.Message);
            }

            return drv_roles;
        }

        // Information for right panel in chat

        [HttpGet]
        [Route("api/get_driver_info_for_chat")]
        public Driver GetDriverInfoForChat(string User_Id)
        {
            Driver drv = new Driver();

            try
            {
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                    CommandText = "p_Get_Driver_Info"
                };
                cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);

                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        drv = new Driver()
                        {
                            Driver_Id = rdr["Driver_Id"].ToString(),
                            D_Id = rdr["Driver_Id_Normalized"].ToString(),
                            Driver_Firstname = rdr["Firstname"].ToString(),
                            Driver_Lastname = rdr["Lastname"].ToString(),
                            Driver_Email = rdr["Email_Id"].ToString(),
                            Driver_Phone = rdr["Phone_Number"].ToString(),
                        };
                    }
                }
                rdr.Close();
                con.Close();

            }
            }
            catch
            {
                throw new Exception("Error retrieving driver info.");

            }
            

            return drv;
        }

        [HttpGet]
        [Route("api/driver_getdrivershiftdetails")]
        public DriverShift Driver_GetDriverShiftDetails(String User_Id)
        {
            DriverShift drivershift_details = new DriverShift();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Driver_ShiftDetails"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            drivershift_details.Shift_Id   = (Guid)rdr["Shift_Id"];
                            drivershift_details.User_Id    = rdr["User_Id"].ToString();
                            drivershift_details.ShiftStart = (DateTime)rdr["Driver_ShiftStart"];
                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch
            {
                throw new Exception("Error getting driver shift details.");
            }
            return drivershift_details;
        }


        [HttpGet]
        [Route("api/driver_gettripstatus")]
        public List<TripStatus> Driver_GetTripStatus()
        {
            List<TripStatus> tripstatus_list = new List<TripStatus>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Trip_Status"
                    };
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            TripStatus ts = new TripStatus()
                            {
                                Trip_Status_ID = rdr["Trip_Status_ID"].ToString(),
                                Status_Name = rdr["Status_Name"].ToString()

                            };
                            tripstatus_list.Add(ts);
                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return tripstatus_list;
        }


        [HttpGet]
        [Route("api/driver_getdriverpaystatus")]
        public List<DriverPayStatus> Driver_GetDriverPayStatus()
        {
            List<DriverPayStatus> driverpaystatus_list = new List<DriverPayStatus>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Driver_Pay_Status"
                    };
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            DriverPayStatus dps = new DriverPayStatus()
                            {
                                status_Id = rdr["Status_Id"].ToString(),
                                status = rdr["Status"].ToString()

                            };
                            driverpaystatus_list.Add(dps);
                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return driverpaystatus_list;
        }
        [HttpGet]
        [Route("api/driver_gettabletdrivers")]
        public List<Driver> Driver_GetTabletDrivers(string Company_Id)
        {
            List<Driver> drivers = new List<Driver>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Tablet_Drivers"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Driver Dr = new Driver()
                            {
                                User_Id    = rdr["User_Id"].ToString(),
                                Driver_Id  = rdr["Driver_Id"].ToString(),
                                D_Id       = rdr["Driver_Id_Normalized"].ToString(),
                                Chat_Id    = rdr["Chat_Id"].ToString(),
                                Chat_Table = rdr["Chat_Table"].ToString(),
                                Chat_Type  = rdr["Chat_Type"].ToString(),
                            };
                            drivers.Add(Dr);
                        }

                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return drivers;
        }
        [HttpGet]
        [Route("api/driver_getdrivertabletstatus")]
        public List<DriverTabletStatus> Driver_GetDriverTabletStatus(string User_Id)
        {
            List<DriverTabletStatus> load_offers_list = new List<DriverTabletStatus>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Driver_Tablet_Status"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            DriverTabletStatus dts = new DriverTabletStatus()
                            {

                                LoadOffers_ID = rdr["LoadOffers_ID"].ToString(),

                                DriverID = rdr["DriverID"].ToString(),

                                DLD = rdr["DLD"].ToString(),

                                FreightBill = rdr["FreightBill"].ToString(),

                                Trip = rdr["Trip"].ToString(),

                                Container_Number = rdr["Container_Number"].ToString(),

                                Origin_Name = rdr["Origin_Name"].ToString(),

                                Destination_Name = rdr["Destination_Name"].ToString(),

                                LO_Status = rdr["LO_Status"].ToString(),

                                LO_Status_Name = rdr["LO_Status_Name"].ToString(),

                                Trip_Status_ID = rdr["Trip_Status_ID"].ToString(),

                                Trip_Status_Name = Regex.Replace(rdr["Trip_Status_Name"].ToString(), @"[\d-]", string.Empty),

                                Status_Flag = rdr["Status_Flag"].ToString()

                            };
                            load_offers_list.Add(dts);
                        }
                        
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return load_offers_list;
        }

        [HttpGet]
        [Route("api/driver_getdriverloadoffersid")]
        public LoadOffer Driver_GetLoadOffersId(string loadoffers_id)
        {
            LoadOffer lf = new LoadOffer();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Load_Offers_Id"
                    };
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);                    
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            
                            
                                lf.LoadOffers_ID = rdr["LoadOffers_ID"].ToString();

                                lf.MessageID = rdr["MessageID"].ToString();

                                lf.DLD = rdr["DLD"].ToString();

                                lf.DeviceID = rdr["DeviceID"].ToString();

                                lf.DriverID = rdr["DriverID"].ToString();

                                lf.DriverNotes = rdr["DriverNotes"].ToString();

                                lf.FreightBill = rdr["FreightBill"].ToString();

                                lf.Trip = rdr["Trip"].ToString();

                                lf.Destination_Address = rdr["Destination_Address"].ToString();

                                lf.Destination_Address2 = rdr["Destination_Address2"].ToString();

                                lf.Destination_Cell = rdr["Destination_Cell"].ToString();

                                lf.Destination_City = rdr["Destination_City"].ToString();

                                lf.Destination_CloseTime = rdr["Destination_CloseTime"].ToString();

                                lf.Destination_Contact = rdr["Destination_Contact"].ToString();

                                lf.Destination_Email = rdr["Destination_Email"].ToString();

                                lf.Destination_Extension = rdr["Destination_Extension"].ToString();

                                lf.Destination_Fax = rdr["Destination_Fax"].ToString();

                                lf.Destination_GPS_Description = rdr["Destination_GPS_Description"].ToString();

                                lf.Destination_GPS_IsValid = rdr["Destination_GPS_IsValid"].ToString();

                                lf.Destination_GPS_Lat = rdr["Destination_GPS_Lat"].ToString();

                                lf.Destination_GPS_Long = rdr["Destination_GPS_Long"].ToString();

                                lf.Destination_ID = rdr["Destination_ID"].ToString();

                                lf.Destination_Name = rdr["Destination_Name"].ToString();

                                lf.Destination_OpenTime = rdr["Destination_OpenTime"].ToString();

                                lf.Destination_Phone = rdr["Destination_Phone"].ToString();

                                lf.Destination_PostalCode = rdr["Destination_PostalCode"].ToString();

                                lf.Destination_Prov = rdr["Destination_Prov"].ToString();

                                lf.Destination_UnitNo = rdr["Destination_UnitNo"].ToString();

                                lf.Destination_Dock = rdr["Destination_Dock"].ToString();

                                lf.Destination_DockNum = rdr["Destination_DockNum"].ToString();

                                lf.Destination_ZoneID = rdr["Destination_ZoneID"].ToString();

                                lf.Destination_AppointmentRequired = rdr["Destination_AppointmentRequired"].ToString();

                                lf.Destination_AppointmentMade = rdr["Destination_AppointmentMade"].ToString();

                                lf.Destination_AppointmentSpot = rdr["Destination_AppointmentSpot"].ToString();

                                lf.Destination_Country = rdr["Destination_Country"].ToString();

                                lf.Origin_Address = rdr["Origin_Address"].ToString();

                                lf.Origin_Address2 = rdr["Origin_Address2"].ToString();

                                lf.Origin_Cell = rdr["Origin_Cell"].ToString();

                                lf.Origin_City = rdr["Origin_City"].ToString();

                                lf.Origin_CloseTime = rdr["Origin_CloseTime"].ToString();

                                lf.Origin_Contact = rdr["Origin_Contact"].ToString();

                                lf.Origin_Email = rdr["Origin_Email"].ToString();

                                lf.Origin_Extension = rdr["Origin_Extension"].ToString();

                                lf.Origin_Fax = rdr["Origin_Fax"].ToString();

                                lf.Origin_GPS_Description = rdr["Origin_GPS_Description"].ToString();

                                lf.Origin_GPS_IsValid = rdr["Origin_GPS_IsValid"].ToString();

                                lf.Origin_GPS_Lat = rdr["Origin_GPS_Lat"].ToString();

                                lf.Origin_GPS_Long = rdr["Origin_GPS_Long"].ToString();

                                lf.Origin_ID = rdr["Origin_ID"].ToString();

                                lf.Origin_Name = rdr["Origin_Name"].ToString();

                                lf.Origin_OpenTime = rdr["Origin_OpenTime"].ToString();

                                lf.Origin_Phone = rdr["Origin_Phone"].ToString();

                                lf.Origin_PostalCode = rdr["Origin_PostalCode"].ToString();

                                lf.Origin_Prov = rdr["Origin_Prov"].ToString();

                                lf.Origin_UnitNo = rdr["Origin_UnitNo"].ToString();

                                lf.Origin_Dock = rdr["Origin_Dock"].ToString();

                                lf.Origin_DockNum = rdr["Origin_DockNum"].ToString();

                                lf.Origin_ZoneID = rdr["Origin_ZoneID"].ToString();

                                lf.Origin_AppointmentRequired = rdr["Origin_AppointmentRequired"].ToString();

                                lf.Origin_AppointmentMade = rdr["Origin_AppointmentMade"].ToString();

                                lf.Origin_AppointmentSpot = rdr["Origin_AppointmentSpot"].ToString();

                                lf.Origin_Country = rdr["Origin_Country"].ToString();

                                lf.TrailerID = rdr["TrailerID"].ToString();

                                lf.UserFields_User01 = rdr["UserFields_User01"].ToString();

                                lf.UserFields_User02 = rdr["UserFields_User02"].ToString();

                                lf.UserFields_User03 = rdr["UserFields_User03"].ToString();

                                lf.UserFields_User04 = rdr["UserFields_User04"].ToString();

                                lf.UserFields_User05 = rdr["UserFields_User05"].ToString();

                                lf.UserFields_User06 = rdr["UserFields_User06"].ToString();

                                lf.UserFields_User07 = rdr["UserFields_User07"].ToString();

                                lf.Weight_Units = rdr["Weight_Units"].ToString();

                                lf.Weight_Value = rdr["Weight_Value"].ToString();

                                lf.StartZone = rdr["StartZone"].ToString();

                                lf.EndZone = rdr["EndZone"].ToString();

                                lf.IntermodalOrders_ChassisNumber = rdr["IntermodalOrders_ChassisNumber"].ToString();

                                lf.IntermodalOrders_ChassisSize = rdr["IntermodalOrders_ChassisSize"].ToString();

                                lf.IntermodalOrders_ChassisType = rdr["IntermodalOrders_ChassisType"].ToString();

                                lf.IntermodalOrders_ContainerCode = rdr["IntermodalOrders_ContainerCode"].ToString();

                                lf.IntermodalOrders_ContainerDigit = rdr["IntermodalOrders_ContainerDigit"].ToString();

                                lf.IntermodalOrders_ContainerNumber = rdr["IntermodalOrders_ContainerNumber"].ToString();

                                lf.IntermodalOrders_ContainerSize = rdr["IntermodalOrders_ContainerSize"].ToString();

                                lf.IntermodalOrders_ContainerType = rdr["IntermodalOrders_ContainerType"].ToString();

                                lf.IntermodalOrders_IntermodalType = rdr["IntermodalOrders_IntermodalType"].ToString();

                                lf.IntermodalOrders_Loaded = rdr["IntermodalOrders_Loaded"].ToString();

                                lf.IntermodalOrders_MovementType = rdr["IntermodalOrders_MovementType"].ToString();

                                lf.IntermodalOrders_Voyage = rdr["IntermodalOrders_Voyage"].ToString();

                                lf.Temperature_Units = rdr["Temperature_Units"].ToString();

                                lf.Temperature_Value = rdr["Temperature_Value"].ToString();

                                lf.TemperatureControlled = rdr["TemperatureControlled"].ToString();

                                lf.LO_Status = rdr["LO_Status"].ToString();

                                lf.DP_Status = rdr["DP_Status"].ToString();
                                                       
                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return lf;
        }

        [HttpGet]
        [Route("api/driver_getloadofferstatus")]
        public List<LoadOffer> Driver_GetLoadOffersStatus(string User_Id)
        {
            List<LoadOffer> load_offers_list = new List<LoadOffer>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Load_Offers_Status"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);                    
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            LoadOffer lf = new LoadOffer()
                            {
                                LoadOffers_ID = rdr["LoadOffers_ID"].ToString(),

                                MessageID = rdr["MessageID"].ToString(),

                                Booking = rdr["Booking"].ToString(),

                                Bill_Of_Lading = rdr["Bill_Of_Lading"].ToString(),

                                DLD = rdr["DLD"].ToString(),

                                DeviceID = rdr["DeviceID"].ToString(),

                                DriverID = rdr["DriverID"].ToString(),

                                DriverNotes = rdr["DriverNotes"].ToString(),

                                FreightBill = rdr["FreightBill"].ToString(),

                                Trip = rdr["Trip"].ToString(),

                                DeliverBy =  DateTime.Parse(rdr["DeliverBy"].ToString()),

                                DeliverByEnd = DateTime.Parse(rdr["DeliverByEnd"].ToString()),

                                Destination_Address = rdr["Destination_Address"].ToString(),

                                Destination_Address2 = rdr["Destination_Address2"].ToString(),

                                Destination_Cell = rdr["Destination_Cell"].ToString(),

                                Destination_City = rdr["Destination_City"].ToString(),

                                Destination_CloseTime = rdr["Destination_CloseTime"].ToString(),

                                Destination_Contact = rdr["Destination_Contact"].ToString(),

                                Destination_Email = rdr["Destination_Email"].ToString(),

                                Destination_Extension = rdr["Destination_Extension"].ToString(),

                                Destination_Fax = rdr["Destination_Fax"].ToString(),

                                Destination_GPS_Description = rdr["Destination_GPS_Description"].ToString(),

                                Destination_GPS_IsValid = rdr["Destination_GPS_IsValid"].ToString(),

                                Destination_GPS_Lat = rdr["Destination_GPS_Lat"].ToString(),

                                Destination_GPS_Long = rdr["Destination_GPS_Long"].ToString(),

                                Destination_ID = rdr["Destination_ID"].ToString(),

                                Destination_Name = rdr["Destination_Name"].ToString(),

                                Destination_OpenTime = rdr["Destination_OpenTime"].ToString(),

                                Destination_Phone = rdr["Destination_Phone"].ToString(),

                                Destination_PostalCode = rdr["Destination_PostalCode"].ToString(),

                                Destination_Prov = rdr["Destination_Prov"].ToString(),

                                Destination_UnitNo = rdr["Destination_UnitNo"].ToString(),

                                Destination_Dock = rdr["Destination_Dock"].ToString(),

                                Destination_DockNum = rdr["Destination_DockNum"].ToString(),

                                Destination_ZoneID = rdr["Destination_ZoneID"].ToString(),

                                Destination_AppointmentRequired = rdr["Destination_AppointmentRequired"].ToString(),

                                Destination_AppointmentMade = rdr["Destination_AppointmentMade"].ToString(),

                                Destination_AppointmentSpot = rdr["Destination_AppointmentSpot"].ToString(),

                                Destination_Country = rdr["Destination_Country"].ToString(),

                                DangerousGoods = rdr["DangerousGoods"].ToString(),

                                PickupBy = DateTime.Parse(rdr["PickupBy"].ToString()),

                                PickupByEnd = DateTime.Parse(rdr["PickupByEnd"].ToString()),

                                PickupAt_AppointmentMade  = rdr["PickupAt_AppointmentMade"].ToString(),

                                Origin_Address = rdr["Origin_Address"].ToString(),

                                Origin_Address2 = rdr["Origin_Address2"].ToString(),

                                Origin_Cell = rdr["Origin_Cell"].ToString(),

                                Origin_City = rdr["Origin_City"].ToString(),

                                Origin_CloseTime = rdr["Origin_CloseTime"].ToString(),

                                Origin_Contact = rdr["Origin_Contact"].ToString(),

                                Origin_Email = rdr["Origin_Email"].ToString(),

                                Origin_Extension = rdr["Origin_Extension"].ToString(),

                                Origin_Fax = rdr["Origin_Fax"].ToString(),

                                Origin_GPS_Description = rdr["Origin_GPS_Description"].ToString(),

                                Origin_GPS_IsValid = rdr["Origin_GPS_IsValid"].ToString(),

                                Origin_GPS_Lat = rdr["Origin_GPS_Lat"].ToString(),

                                Origin_GPS_Long = rdr["Origin_GPS_Long"].ToString(),

                                Origin_ID = rdr["Origin_ID"].ToString(),

                                Origin_Name = rdr["Origin_Name"].ToString(),

                                Origin_OpenTime = rdr["Origin_OpenTime"].ToString(),

                                Origin_Phone = rdr["Origin_Phone"].ToString(),

                                Origin_PostalCode = rdr["Origin_PostalCode"].ToString(),

                                Origin_Prov = rdr["Origin_Prov"].ToString(),

                                Origin_UnitNo = rdr["Origin_UnitNo"].ToString(),

                                Origin_Dock = rdr["Origin_Dock"].ToString(),

                                Origin_DockNum = rdr["Origin_DockNum"].ToString(),

                                Origin_ZoneID = rdr["Origin_ZoneID"].ToString(),

                                Origin_AppointmentRequired = rdr["Origin_AppointmentRequired"].ToString(),

                                Origin_AppointmentMade = rdr["Origin_AppointmentMade"].ToString(),

                                Origin_AppointmentSpot = rdr["Origin_AppointmentSpot"].ToString(),

                                Origin_Country = rdr["Origin_Country"].ToString(),

                                Seal_Number = rdr["Seal_Number"].ToString(),

                                ShipLine = rdr["ShipLine"].ToString(),

                                TrailerID = rdr["TrailerID"].ToString(),

                                UserFields_User01 = rdr["UserFields_User01"].ToString(),

                                UserFields_User02 = rdr["UserFields_User02"].ToString(),

                                UserFields_User03 = rdr["UserFields_User03"].ToString(),

                                UserFields_User04 = rdr["UserFields_User04"].ToString(),

                                UserFields_User05 = rdr["UserFields_User05"].ToString(),

                                UserFields_User06 = rdr["UserFields_User06"].ToString(),

                                UserFields_User07 = rdr["UserFields_User07"].ToString(),

                                Vessel_Name = rdr["Vessel_Name"].ToString(),

                                Weight_Units = rdr["Weight_Units"].ToString(),

                                Weight_Value = rdr["Weight_Value"].ToString(),

                                StartZone = rdr["StartZone"].ToString(),

                                EndZone = rdr["EndZone"].ToString(),

                                IntermodalOrders_ChassisNumber = rdr["IntermodalOrders_ChassisNumber"].ToString(),

                                IntermodalOrders_ChassisSize = rdr["IntermodalOrders_ChassisSize"].ToString(),

                                IntermodalOrders_ChassisType = rdr["IntermodalOrders_ChassisType"].ToString(),

                                IntermodalOrders_ContainerCode = rdr["IntermodalOrders_ContainerCode"].ToString(),

                                IntermodalOrders_ContainerDigit = rdr["IntermodalOrders_ContainerDigit"].ToString(),

                                IntermodalOrders_ContainerNumber = rdr["IntermodalOrders_ContainerNumber"].ToString(),

                                IntermodalOrders_ContainerSize = rdr["IntermodalOrders_ContainerSize"].ToString(),

                                IntermodalOrders_ContainerType = rdr["IntermodalOrders_ContainerType"].ToString(),

                                IntermodalOrders_IntermodalType = rdr["IntermodalOrders_IntermodalType"].ToString(),

                                IntermodalOrders_Loaded = rdr["IntermodalOrders_Loaded"].ToString(),

                                IntermodalOrders_MovementType = rdr["IntermodalOrders_MovementType"].ToString(),

                                IntermodalOrders_Voyage = rdr["IntermodalOrders_Voyage"].ToString(),

                                Temperature_Units = rdr["Temperature_Units"].ToString(),

                                Temperature_Value = rdr["Temperature_Value"].ToString(),

                                TemperatureControlled = rdr["TemperatureControlled"].ToString(),

                                LO_Status = rdr["LO_Status"].ToString(),

                                DP_Status = rdr["DP_Status"].ToString(),

                                Status_Flag= int.Parse(rdr["Status_Flag"].ToString()),
                            };
                            load_offers_list.Add(lf);
                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return load_offers_list;
        }
        [HttpGet]
        [Route("api/driver_getemptypickloadoffer")]
        public LoadOffer Driver_GetEmmptyPickLoadOffer(string User_Id,string trip)
        {
            LoadOffer load_offer = new LoadOffer();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_EmptyPick_LoadOffer"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(User_Id);
                    cmd.Parameters.Add("@Trip", SqlDbType.NVarChar).Value = trip;
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            LoadOffer lf = new LoadOffer()
                            {
                                LoadOffers_ID = rdr["LoadOffers_ID"].ToString(),

                                MessageID = rdr["MessageID"].ToString(),

                                Booking = rdr["Booking"].ToString(),

                                Bill_Of_Lading = rdr["Bill_Of_Lading"].ToString(),

                                DLD = rdr["DLD"].ToString(),

                                DeviceID = rdr["DeviceID"].ToString(),

                                DriverID = rdr["DriverID"].ToString(),

                                DriverNotes = rdr["DriverNotes"].ToString(),

                                FreightBill = rdr["FreightBill"].ToString(),

                                Trip = rdr["Trip"].ToString(),

                                DeliverBy = DateTime.Parse(rdr["DeliverBy"].ToString()),

                                DeliverByEnd = DateTime.Parse(rdr["DeliverByEnd"].ToString()),

                                Destination_Address = rdr["Destination_Address"].ToString(),

                                Destination_Address2 = rdr["Destination_Address2"].ToString(),

                                Destination_Cell = rdr["Destination_Cell"].ToString(),

                                Destination_City = rdr["Destination_City"].ToString(),

                                Destination_CloseTime = rdr["Destination_CloseTime"].ToString(),

                                Destination_Contact = rdr["Destination_Contact"].ToString(),

                                Destination_Email = rdr["Destination_Email"].ToString(),

                                Destination_Extension = rdr["Destination_Extension"].ToString(),

                                Destination_Fax = rdr["Destination_Fax"].ToString(),

                                Destination_GPS_Description = rdr["Destination_GPS_Description"].ToString(),

                                Destination_GPS_IsValid = rdr["Destination_GPS_IsValid"].ToString(),

                                Destination_GPS_Lat = rdr["Destination_GPS_Lat"].ToString(),

                                Destination_GPS_Long = rdr["Destination_GPS_Long"].ToString(),

                                Destination_ID = rdr["Destination_ID"].ToString(),

                                Destination_Name = rdr["Destination_Name"].ToString(),

                                Destination_OpenTime = rdr["Destination_OpenTime"].ToString(),

                                Destination_Phone = rdr["Destination_Phone"].ToString(),

                                Destination_PostalCode = rdr["Destination_PostalCode"].ToString(),

                                Destination_Prov = rdr["Destination_Prov"].ToString(),

                                Destination_UnitNo = rdr["Destination_UnitNo"].ToString(),

                                Destination_Dock = rdr["Destination_Dock"].ToString(),

                                Destination_DockNum = rdr["Destination_DockNum"].ToString(),

                                Destination_ZoneID = rdr["Destination_ZoneID"].ToString(),

                                Destination_AppointmentRequired = rdr["Destination_AppointmentRequired"].ToString(),

                                Destination_AppointmentMade = rdr["Destination_AppointmentMade"].ToString(),

                                Destination_AppointmentSpot = rdr["Destination_AppointmentSpot"].ToString(),

                                Destination_Country = rdr["Destination_Country"].ToString(),

                                DangerousGoods = rdr["DangerousGoods"].ToString(),

                                PickupBy = DateTime.Parse(rdr["PickupBy"].ToString()),

                                PickupByEnd = DateTime.Parse(rdr["PickupByEnd"].ToString()),

                                PickupAt_AppointmentMade = rdr["PickupAt_AppointmentMade"].ToString(),

                                Origin_Address = rdr["Origin_Address"].ToString(),

                                Origin_Address2 = rdr["Origin_Address2"].ToString(),

                                Origin_Cell = rdr["Origin_Cell"].ToString(),

                                Origin_City = rdr["Origin_City"].ToString(),

                                Origin_CloseTime = rdr["Origin_CloseTime"].ToString(),

                                Origin_Contact = rdr["Origin_Contact"].ToString(),

                                Origin_Email = rdr["Origin_Email"].ToString(),

                                Origin_Extension = rdr["Origin_Extension"].ToString(),

                                Origin_Fax = rdr["Origin_Fax"].ToString(),

                                Origin_GPS_Description = rdr["Origin_GPS_Description"].ToString(),

                                Origin_GPS_IsValid = rdr["Origin_GPS_IsValid"].ToString(),

                                Origin_GPS_Lat = rdr["Origin_GPS_Lat"].ToString(),

                                Origin_GPS_Long = rdr["Origin_GPS_Long"].ToString(),

                                Origin_ID = rdr["Origin_ID"].ToString(),

                                Origin_Name = rdr["Origin_Name"].ToString(),

                                Origin_OpenTime = rdr["Origin_OpenTime"].ToString(),

                                Origin_Phone = rdr["Origin_Phone"].ToString(),

                                Origin_PostalCode = rdr["Origin_PostalCode"].ToString(),

                                Origin_Prov = rdr["Origin_Prov"].ToString(),

                                Origin_UnitNo = rdr["Origin_UnitNo"].ToString(),

                                Origin_Dock = rdr["Origin_Dock"].ToString(),

                                Origin_DockNum = rdr["Origin_DockNum"].ToString(),

                                Origin_ZoneID = rdr["Origin_ZoneID"].ToString(),

                                Origin_AppointmentRequired = rdr["Origin_AppointmentRequired"].ToString(),

                                Origin_AppointmentMade = rdr["Origin_AppointmentMade"].ToString(),

                                Origin_AppointmentSpot = rdr["Origin_AppointmentSpot"].ToString(),

                                Origin_Country = rdr["Origin_Country"].ToString(),

                                Seal_Number = rdr["Seal_Number"].ToString(),

                                ShipLine = rdr["ShipLine"].ToString(),

                                TrailerID = rdr["TrailerID"].ToString(),

                                UserFields_User01 = rdr["UserFields_User01"].ToString(),

                                UserFields_User02 = rdr["UserFields_User02"].ToString(),

                                UserFields_User03 = rdr["UserFields_User03"].ToString(),

                                UserFields_User04 = rdr["UserFields_User04"].ToString(),

                                UserFields_User05 = rdr["UserFields_User05"].ToString(),

                                UserFields_User06 = rdr["UserFields_User06"].ToString(),

                                UserFields_User07 = rdr["UserFields_User07"].ToString(),


                                Vessel_Name = rdr["Vessel_Name"].ToString(),

                                Weight_Units = rdr["Weight_Units"].ToString(),

                                Weight_Value = rdr["Weight_Value"].ToString(),

                                StartZone = rdr["StartZone"].ToString(),

                                EndZone = rdr["EndZone"].ToString(),

                                IntermodalOrders_ChassisNumber = rdr["IntermodalOrders_ChassisNumber"].ToString(),

                                IntermodalOrders_ChassisSize = rdr["IntermodalOrders_ChassisSize"].ToString(),

                                IntermodalOrders_ChassisType = rdr["IntermodalOrders_ChassisType"].ToString(),

                                IntermodalOrders_ContainerCode = rdr["IntermodalOrders_ContainerCode"].ToString(),

                                IntermodalOrders_ContainerDigit = rdr["IntermodalOrders_ContainerDigit"].ToString(),

                                IntermodalOrders_ContainerNumber = rdr["IntermodalOrders_ContainerNumber"].ToString(),

                                IntermodalOrders_ContainerSize = rdr["IntermodalOrders_ContainerSize"].ToString(),

                                IntermodalOrders_ContainerType = rdr["IntermodalOrders_ContainerType"].ToString(),

                                IntermodalOrders_IntermodalType = rdr["IntermodalOrders_IntermodalType"].ToString(),

                                IntermodalOrders_Loaded = rdr["IntermodalOrders_Loaded"].ToString(),

                                IntermodalOrders_MovementType = rdr["IntermodalOrders_MovementType"].ToString(),

                                IntermodalOrders_Voyage = rdr["IntermodalOrders_Voyage"].ToString(),

                                Temperature_Units = rdr["Temperature_Units"].ToString(),

                                Temperature_Value = rdr["Temperature_Value"].ToString(),

                                TemperatureControlled = rdr["TemperatureControlled"].ToString(),

                                LO_Status = rdr["LO_Status"].ToString(),

                                DP_Status = rdr["DP_Status"].ToString(),

                                Status_Flag = int.Parse(rdr["Status_Flag"].ToString()),
                            };
                            load_offer = lf;
                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return load_offer;
        }
        [HttpGet]
        [Route("api/driver_getdriverbreakdetails")]
        public List<DriverBreak> Driver_GetDriverBreakDetails(String Shift_Id)
        {
            List<DriverBreak> driverbreak_details_list = new List<DriverBreak>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Driver_BreakDetails"
                    };
                    cmd.Parameters.Add("@Shift_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Shift_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {

                            driverbreak_details_list.Add(new DriverBreak { BreakStart = Convert.ToDateTime(rdr["Driver_BreakStart"]), BreakEnd = Convert.ToDateTime(rdr["Driver_BreakEnd"]), BreakNotes = (string)rdr["Driver_Notes"], Break_Id = (Guid)rdr["Break_Id"], Shift_Id = (Guid)rdr["Shift_Id"] });

                        }
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return driverbreak_details_list;
        }

        [HttpGet]
        [Route("api/driver_getloadoffersUpdatedaddress")]
        public List<LoadOfferConsigneeAddress> Driver_GetLoadOffersUpdatedAddress(string user_id)
        {
            var lca_list = new List<LoadOfferConsigneeAddress>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_LoadOffers_Updated_Address"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_id);

                    con.Open();
                    SqlDataReader rdr= cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            var lca = new LoadOfferConsigneeAddress()
                            {
                                LoadOffers_ID = rdr["LoadOffers_ID"].ToString(),

                                Address_Type = rdr["Address_Type"].ToString(),

                                Status =  rdr["Status"].ToString(),
                                
                                Trip_Status =  rdr["Trip_Status"].ToString(),

                                Trip_Status_Name = rdr["Trip_Status_Name"].ToString(),

                                Address = rdr["Consignee_Address"].ToString(),

                                Address2 = rdr["Consignee_Address2"].ToString(),

                                Cell = rdr["Consignee_Cell"].ToString(),

                                City = rdr["Consignee_City"].ToString(),

                                CloseTime = rdr["Consignee_CloseTime"].ToString(),

                                Contact = rdr["Consignee_Contact"].ToString(),

                                Email = rdr["Consignee_Email"].ToString(),

                                Extension = rdr["Consignee_Extension"].ToString(),

                                Fax = rdr["Consignee_Fax"].ToString(),

                                GPS_Description = rdr["Consignee_GPS_Description"].ToString(),

                                GPS_IsValid = rdr["Consignee_GPS_IsValid"].ToString(),

                                GPS_Lat = rdr["Consignee_GPS_Lat"].ToString(),

                                GPS_Long = rdr["Consignee_GPS_Long"].ToString(),

                                ID = rdr["Consignee_ID"].ToString(),

                                Name = rdr["Consignee_Name"].ToString(),

                                OpenTime = rdr["Consignee_OpenTime"].ToString(),

                                Phone = rdr["Consignee_Phone"].ToString(),

                                PostalCode = rdr["Consignee_PostalCode"].ToString(),

                                Prov = rdr["Consignee_Prov"].ToString(),

                                UnitNo = rdr["Consignee_UnitNo"].ToString(),

                                Dock = rdr["Consignee_Dock"].ToString(),

                                DockNum = rdr["Consignee_DockNum"].ToString(),

                                ZoneID = rdr["Consignee_ZoneID"].ToString(),

                                AppointmentRequired = rdr["Consignee_AppointmentRequired"].ToString(),

                                AppointmentMade = rdr["Consignee_AppointmentMade"].ToString(),

                                AppointmentSpot = rdr["Consignee_AppointmentSpot"].ToString(),

                                Country = rdr["Consignee_Country"].ToString(),

                                DeliverBy = DateTime.Parse(rdr["DeliverBy"].ToString()),

                                DeliverByEnd = DateTime.Parse(rdr["DeliverByEnd"].ToString()),

                                PickupBy = DateTime.Parse(rdr["PickupBy"].ToString()),

                                PickupByEnd = DateTime.Parse(rdr["PickupByEnd"].ToString()),
                            };

                            lca_list.Add(lca);
                        }
                    }
                    con.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return lca_list;


        }
        [HttpGet]
        [Route("api/driver_deleteupdatedaddressstatus")]
        public void Driver_DeleteUpdatedAddressStatus(string user_id)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Delete_Updated_Address_Status"
                    };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(user_id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }


            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
        [HttpGet]
        [Route("api/check_chat_name")]
        public Dictionary<string,string> ChekChatName(string Chat_Name, string Company_Id)
        {
            var Chat_Name_Status = "";

            try
            {
              
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Check_Chat_Name"
                    };
                    cmd.Parameters.Add("@Chat_Name", SqlDbType.NVarChar).Value = Convert.ToString(Chat_Name);
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Chat_Name_Status = rdr["Chat_Name_Status"].ToString();
                          
                        }
                    }


                    rdr.Close();
                    con.Close();

                }

            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);

            }
            var chat_status = new Dictionary<string, string>() { { "Chat_Name_Status", Chat_Name_Status } };
            return chat_status;
        }
        [HttpGet]
        [Route("api/get_driver_by_chat_Id")]
        public Dictionary<string, string> GetDriverByChatID(string Chat_Id)
        {
            var User_Id = "";

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {

                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Driver_By_Chat_ID"
                    };
                    cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Chat_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            User_Id = rdr["User_Id"].ToString();
                        }
                    }
                    rdr.Close();


                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error getting driver Id ");

            }
            var User_info = new Dictionary<string, string>() { { "User_Id", User_Id } };


            return User_info;
        }


        [HttpPost]
        [Route("api/driver_update_loadoffers_consignee_address")]
        public async Task Driver_UpdateLoadofferDestination(LoadOfferAddressStatus las)
        {

            var soapClient = new SoapClient();
            var ns = XNamespace.Get(Startup.TruckMateString);
            XNamespace TTMHeader = "urn:TruckMateTypes";
            XElement tm = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                new XElement("Password", "{NVpd{W3Qa:M"),
                new XElement("Schema", "TMWIN"),
                new XElement("Username", "PTMobile"));

            List<XElement> lst = new List<XElement>();
            lst.Add(tm);
            XElement bdy1 = new XElement(ns.GetName("GetFreightHeader"),
                                                 new XElement("DLD", las.DLD), new XElement("FBRateGUID", ""));

            var result =
                await soapClient.PostAsync(
                    new Uri(Startup.TruckMateString + "soap/IResManagement"),
                    SoapVersion.Soap11,
                    headers: lst,
                    body: bdy1);
            var response = await result.Content.ReadAsStringAsync();
            XmlDocument xml = new XmlDocument();
            xml.LoadXml(response);
            var nsmgr = new XmlNamespaceManager(xml.NameTable);
            nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
            XmlNodeList nodes1 = xml.GetElementsByTagName("return");
            if (nodes1.Count != 0)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure,
                            CommandText = "p_Update_Loadoffers_Consignee_Address"
                        };
                        cmd.Parameters.Add("@LoadOffers_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(las.LoadOffers_ID);
                        cmd.Parameters.Add("@Address", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[0].InnerText;
                        cmd.Parameters.Add("@Address2", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[1].InnerText;
                        cmd.Parameters.Add("@Cell", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[2].InnerText;
                        cmd.Parameters.Add("@City", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[3].InnerText;
                        cmd.Parameters.Add("@CloseTime", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[4].InnerText;
                        cmd.Parameters.Add("@Contact", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[5].InnerText;
                        cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[6].InnerText;
                        cmd.Parameters.Add("@Extension", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[7].InnerText;
                        cmd.Parameters.Add("@Fax", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[8].InnerText;
                        cmd.Parameters.Add("@GPS_Description", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[9].ChildNodes[0].InnerText;
                        cmd.Parameters.Add("@GPS_IsValid", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[9].ChildNodes[1].InnerText;
                        cmd.Parameters.Add("@GPS_Lat", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[9].ChildNodes[2].InnerText;
                        cmd.Parameters.Add("@GPS_Long", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[9].ChildNodes[3].InnerText;
                        cmd.Parameters.Add("@Consignee_ID", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[10].InnerText;
                        cmd.Parameters.Add("@Consignee_Name", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[11].InnerText;
                        cmd.Parameters.Add("@OpenTime", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[12].InnerText;
                        cmd.Parameters.Add("@Phone", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[13].InnerText;
                        cmd.Parameters.Add("@PostalCode", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[14].InnerText;
                        cmd.Parameters.Add("@Province", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[15].InnerText;
                        cmd.Parameters.Add("@UnitNo", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[16].InnerText;
                        cmd.Parameters.Add("@Dock", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[17].InnerText;
                        cmd.Parameters.Add("@DockNum", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[18].InnerText;
                        cmd.Parameters.Add("@ZoneID", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[19].InnerText;
                        if (nodes1[0].ChildNodes[0].ChildNodes[20].InnerText != "")
                        {
                            cmd.Parameters.Add("@AppointmentRequired", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[20].InnerText;
                        }
                        else
                        {
                            cmd.Parameters.Add("@AppointmentRequired", SqlDbType.NVarChar).Value = "false";

                        }
                        if (nodes1[0].ChildNodes[0].ChildNodes[21].InnerText != "")
                        {
                            cmd.Parameters.Add("@AppointmentMade", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[21].InnerText;
                        }
                        else
                        {
                            cmd.Parameters.Add("@AppointmentMade", SqlDbType.NVarChar).Value = "false";

                        }
                        if (nodes1[0].ChildNodes[0].ChildNodes[22].InnerText != "")
                        {
                            cmd.Parameters.Add("@AppointmentSpot", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[22].InnerText;
                        }
                        else
                        {
                            cmd.Parameters.Add("@AppointmentSpot", SqlDbType.NVarChar).Value = "false";

                        }
                        cmd.Parameters.Add("@Country", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].ChildNodes[23].InnerText;
                        cmd.Parameters.Add("@DeliverBy", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[3].InnerText;
                        cmd.Parameters.Add("@DeliverByEnd", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[4].InnerText;
                        cmd.Parameters.Add("@PickupBy", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[5].InnerText;
                        cmd.Parameters.Add("@PickupByEnd", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[6].InnerText;

                        con.Open();
                        cmd.ExecuteNonQuery();

                        SqlCommand cmd2 = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure,
                            CommandText = "p_Add_Loadoffers_Address_Status"
                        };
                        cmd2.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(las.LoadOffers_ID);
                        cmd2.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(las.User_Id);
                        cmd2.Parameters.Add("@Address_Type", SqlDbType.NVarChar).Value = las.Address_Type;
                        cmd2.ExecuteNonQuery();


                        con.Close();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }


            }






        }

        [HttpPost]
        [Route("api/driver_addloadoffergeo_origin")]
        public void Driver_AddLoadOfferOrigin(string loadOffers_Id, string latitude, string longitude)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Add_LoadOffers_Geo_Origin"
                    };
                    cmd.Parameters.Add("@LoadOffers_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadOffers_Id);
                    cmd.Parameters.Add("@Latitude", SqlDbType.NVarChar).Value = latitude;
                    cmd.Parameters.Add("@Longitude", SqlDbType.NVarChar).Value = longitude;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        [HttpPost]
        [Route("api/driver_addloadoffergeo_destination")]
        public void Driver_AddLoadOfferGeoDestination(string loadOffers_Id, string latitude, string longitude)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Add_LoadOffers_Geo_Destination"
                    };
                    cmd.Parameters.Add("@LoadOffers_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadOffers_Id);
                    cmd.Parameters.Add("@Latitude", SqlDbType.NVarChar).Value = latitude;
                    cmd.Parameters.Add("@Longitude", SqlDbType.NVarChar).Value = longitude;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        [HttpPost]
        [Route("api/create_loadoffer")]
        public async Task CreateLoadoffer(string loadoffer_id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_LoadOffers_Trip_Number"
                    };
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffer_id);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    var Trip = "";
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Trip = rdr["Trip"].ToString();
                        }
                    }
                    rdr.Close();
                    con.Close();
                    if (Trip != "" )
                    {
                        var soapClient = new SoapClient();
                        var ns = XNamespace.Get(Startup.TruckMateString);
                        XNamespace TMobileCommHeader = "urn:MobileCommImpl";
                        XNamespace TTMHeader = "urn:TruckMateTypes";
                        XElement tm1 = new XElement(TMobileCommHeader + "TMobileCommHeader", new XElement("NetworkID", "Q"));
                        XElement tm2 = new XElement(TTMHeader + "TTMHeader",
                            new XElement("DSN", "PTITST22"),
                            new XElement("Password", "{NVpd{W3Qa:M"),
                            new XElement("Schema", "TMWIN"),
                            new XElement("Username", "PTMobile"));

                        List<XElement> lst = new List<XElement>();
                        lst.Add(tm1);
                        lst.Add(tm2);

                        XElement bdy = new XElement(ns.GetName("SendLoadOffer"), new XElement("TripNumber", Trip));

                        var result =
                            await soapClient.PostAsync(
                                new Uri(Startup.TruckMateString + "soap/IMobileComm"),
                                SoapVersion.Soap11,
                                headers: lst,
                                body: bdy);
                        var response = await result.Content.ReadAsStringAsync();
                        XmlDocument xml = new XmlDocument();
                        xml.LoadXml(response);
                        var nsmgr = new XmlNamespaceManager(xml.NameTable);
                        nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                        XmlNodeList nodes = xml.GetElementsByTagName("return");

                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        [HttpPost]
        [Route("api/driver_addloadoffertripstatus")]
        public async Task Driver_AddLoadOfferTripStatus(string loadoffer_id, string Trip_Status_ID)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Add_LoadOffers_Trip_Status"
                    };
                    cmd.Parameters.Add("@LoadOffers_Trip_Status_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffer_id);
                    cmd.Parameters.Add("@Trip_Status_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Trip_Status_ID);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    SqlCommand cmd2 = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_LoadOffers_Trip_Status"
                    };
                    cmd2.Parameters.Add("@LoadOffers_Trip_Status_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffer_id);
                    cmd2.Parameters.Add("@Trip_Status_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Trip_Status_ID);
                    SqlDataReader rdr = cmd2.ExecuteReader();
                    var Status_Name = "";
                    var Trip = "";
                    var Status_Date = "";
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Status_Name = rdr["Status_Name"].ToString();
                            Trip = rdr["Trip"].ToString();
                            Status_Date = rdr["Status_Date"].ToString();
                        }
                    }
                    rdr.Close();
                    cmd2.ExecuteNonQuery();
                    con.Close();

                    if (Trip != "" && Status_Name != "")
                    {
                        Status_Name = Regex.Replace(Status_Name, @"[\d-]", string.Empty);
                        var soapClient = new SoapClient();
                        var ns = XNamespace.Get(Startup.TruckMateString);

                        XNamespace TTMHeader = "urn:TruckMateTypes";
                        XElement tm = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                            new XElement("Password", "{NVpd{W3Qa:M"),
                            new XElement("Schema", "TMWIN"),
                            new XElement("Username", "PTMobile"));

                        List<XElement> lst = new List<XElement>();
                        lst.Add(tm);
                        var children1 = new XElement("GPS");
                        children1.Add(new XElement("Description", " "),
                                    new XElement("IsValid", "FALSE"),
                                    new XElement("Lat", "0"),
                                    new XElement("Long", "0")
                                    );
                        XElement bdy = new XElement(ns.GetName("SetTripStatus"),
                            new XElement("Trip", Trip),
                            new XElement("Status", Status_Name.ToUpper()),
                            new XElement("Reason", " "),
                            children1,
                            new XElement("Comment", "CREATED BY MOBILE"),
                            new XElement("Effective", Status_Date),
                            new XElement("OverrideZone", " "));
                        var result =
                            await soapClient.PostAsync(
                                new Uri(Startup.TruckMateString + "soap/IResManagement"),
                                SoapVersion.Soap11,
                                headers: lst,
                                body: bdy);
                        var response = await result.Content.ReadAsStringAsync();
                        XmlDocument xml = new XmlDocument();
                        xml.LoadXml(response);
                        var nsmgr = new XmlNamespaceManager(xml.NameTable);
                        nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                        XmlNodeList nodes = xml.GetElementsByTagName("Success");
                        if (nodes.Count != 0)
                        {

                        }
                        else
                        {
                            Console.WriteLine("Trip Not Updated");
                        }

                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        [HttpPost]
        [Route("api/driver_repositionchassis")]
        public async Task Driver_RepositionChassisAsync(string chassis)
        {            
                try
                {
                    var soapClient = new SoapClient();
                    var ns = XNamespace.Get(Startup.TruckMateString);

                    // XNamespace TMobileCommHeader = "ResManIntf-IResManagement";
                    XNamespace TTMHeader = "urn:TruckMateTypes";
                    // XElement tm = new XElement("TMobileCommHeader", new XElement("NetworkID", "Q"));
                    XElement tm2 = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                        new XElement("Password", "{NVpd{W3Qa:M"),
                        new XElement("Schema", "TMWIN"),
                        new XElement("Username", "PTMobile"));

                    List<XElement> lst = new List<XElement>();
                    //lst.Add(tm);
                    lst.Add(tm2);
                    var children = new XElement("Resources");
                    children.Add(new XElement("item",
                              new XElement("ID", chassis),
                              new XElement("ResType", "RTCHASSIS")));                   
/*                              new XElement("ResType", "rtChassis")));                   
*/
                    XElement bdy = new XElement(ns.GetName("RepositionResources"),
                                   children, new XElement("ToZone", ""));
                    var result =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString+"soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst,
                            body: bdy);
                    var response = await result.Content.ReadAsStringAsync();
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(response);
                    var nsmgr = new XmlNamespaceManager(xml.NameTable);
                    nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                    XmlNodeList nodes = xml.GetElementsByTagName("Success");
                    if (nodes.Count != 0)
                    {
                        if (nodes[0].ChildNodes[0].InnerText == "true")
                        {
                            
                            
                        }

                    }
                    else
                    {
                        Console.WriteLine("Failed to reposition chassis");
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }


        }

        [HttpPost]
        [Route("api/driver_repositionpowerunit")]
        public async Task Driver_RepositionPowerUnitAsync(string powerUnit)
        {
       
            try
            {
                var soapClient = new SoapClient();
                var ns = XNamespace.Get(Startup.TruckMateString);

                XNamespace TTMHeader = "urn:TruckMateTypes";
               
                XElement tm2 = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                    new XElement("Password", "{NVpd{W3Qa:M"),
                    new XElement("Schema", "TMWIN"),
                    new XElement("Username", "PTMobile"));

                List<XElement> lst = new List<XElement>();
                lst.Add(tm2);
                var children = new XElement("Resources");
                children.Add(new XElement("item",
                          new XElement("ID", powerUnit.ToUpper()),
                          new XElement("ResType", "RTPOWERUNIT")));

                XElement bdy = new XElement(ns.GetName("RepositionResources"),
                               children, new XElement("ToZone", ""));
                var result =
                    await soapClient.PostAsync(
                        new Uri(Startup.TruckMateString+"soap/IResManagement"),
                        SoapVersion.Soap11,
                        headers: lst,
                        body: bdy);
                var response = await result.Content.ReadAsStringAsync();
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(response);
                var nsmgr = new XmlNamespaceManager(xml.NameTable);
                nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                XmlNodeList nodes = xml.GetElementsByTagName("Success");
                if (nodes.Count != 0)
                {
                    if (nodes[0].ChildNodes[0].InnerText == "true")
                    {


                    }

                }
                else
                {
                    Console.WriteLine("Failed to reposition power unit");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

         


        }

        [HttpPost]
        [Route("api/driver_repositiondriver")]
        public async Task Driver_RepositionDriverAsync(string driver)
        {
           
            try
            {
                var soapClient = new SoapClient();
                var ns = XNamespace.Get(Startup.TruckMateString);

                XNamespace TTMHeader = "urn:TruckMateTypes";
                XElement tm2 = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                    new XElement("Password", "{NVpd{W3Qa:M"),
                    new XElement("Schema", "TMWIN"),
                    new XElement("Username", "PTMobile"));

                List<XElement> lst = new List<XElement>();
                lst.Add(tm2);
                var children = new XElement("Resources");
                children.Add(new XElement("item",
                          new XElement("ID", driver.ToUpper()),
                          new XElement("ResType", "RTDRIVER")));

                XElement bdy = new XElement(ns.GetName("RepositionResources"),
                               children, new XElement("ToZone", ""));
                var result =
                    await soapClient.PostAsync(
                        new Uri(Startup.TruckMateString+"soap/IResManagement"),
                        SoapVersion.Soap11,
                        headers: lst,
                        body: bdy);
                var response = await result.Content.ReadAsStringAsync();
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(response);
                var nsmgr = new XmlNamespaceManager(xml.NameTable);
                nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                XmlNodeList nodes = xml.GetElementsByTagName("Success");
                if (nodes.Count != 0)
                {
                    if (nodes[0].ChildNodes[0].InnerText == "true")
                    {


                    }

                }
                else
                {
                    Console.WriteLine("Failed to reposition driver");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }
         [HttpPost]
        [Route("api/driver_payrecordstatus")]
        public async Task<Dictionary<string, string>> Driver_PayRecordStatusAsync(string loadoffers_id)
        {
            Dictionary<string, string> Pay_records = new Dictionary<string, string>();

            var Trip = "";
            var DLD = "";
            var DriverID = "";
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Load_Offers_Id"
                    };
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);                    
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                                Trip = rdr["Trip"].ToString();
                                DLD = rdr["DLD"].ToString();
                                DriverID = rdr["DriverID"].ToString();
                        }
                    rdr.Close();
                    con.Close();
                }

            }
            if(Trip!="" && DLD!="" && DriverID!="")
            {
                try
                {
                    var soapClient = new SoapClient();
                    var ns = XNamespace.Get(Startup.TruckMateString);
                    XNamespace TMobileCommHeader = "urn:MobileCommImpl";
                    XNamespace TTMHeader = "urn:TruckMateTypes";
                    XElement tm1 = new XElement(TMobileCommHeader + "TMobileCommHeader", new XElement("NetworkID", "Q"));
                    XElement tm2 = new XElement(TTMHeader + "TTMHeader",
                        new XElement("DSN", "PTITST22"),
                        new XElement("Password", "{NVpd{W3Qa:M"),
                        new XElement("Schema", "TMWIN"),
                        new XElement("Username", "PTMobile"));

                    List<XElement> lst = new List<XElement>();
                    lst.Add(tm1);
                    lst.Add(tm2);

                    XElement bdy = new XElement(ns.GetName("GetDriverPay"), new XElement("DriverID", DriverID.ToUpper()), new XElement("Trip", Trip), new XElement("DLD", DLD));

                    var result =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString+"soap/IMobileComm"),
                            SoapVersion.Soap11,
                            headers: lst,
                            body: bdy);
                    var response = await result.Content.ReadAsStringAsync();
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(response);
                    var nsmgr = new XmlNamespaceManager(xml.NameTable);
                    nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                    XmlNodeList nodes = xml.GetElementsByTagName("return");
                    if (nodes.Count != 0)
                    {
                        if (nodes[0].InnerXml.StartsWith("<item>"))
                        {
                            for (int i = 0; i < nodes.Count; i++)
                            {
                                XmlNodeList lstnodes1 = nodes[i].ChildNodes;
                                for (int j = 0; j < lstnodes1.Count; j++)
                                 {
                                    try
                                    {
                                        XNamespace TMobileCommHeader1 = "urn:MobileCommImpl";
                                        XNamespace TTMHeader1 = "urn:TruckMateTypes";
                                        XElement tm3 = new XElement(TMobileCommHeader1 + "TMobileCommHeader", new XElement("NetworkID", "Q"));
                                        XElement tm4 = new XElement(TTMHeader1 + "TTMHeader",
                                            new XElement("DSN", "PTITST22"),
                                            new XElement("Password", "{NVpd{W3Qa:M"),
                                            new XElement("Schema", "TMWIN"),
                                            new XElement("Username", "PTMobile"));

                                        List<XElement> lst1 = new List<XElement>();
                                        lst1.Add(tm3);
                                        lst1.Add(tm4);
                                        XElement bdy1 = new XElement(ns.GetName("GetDriverPayRecord"), new XElement("PayId", lstnodes1[j].ChildNodes[7].InnerText));

                                        var result1 =
                                            await soapClient.PostAsync(
                                                new Uri(Startup.TruckMateString+"soap/IMobileComm"),
                                                SoapVersion.Soap11,
                                                headers: lst1,
                                                body: bdy1);
                                        var response1 = await result1.Content.ReadAsStringAsync();
                                        XmlDocument xml1 = new XmlDocument();
                                        xml1.LoadXml(response1);
                                        var nsmgr1 = new XmlNamespaceManager(xml1.NameTable);
                                        nsmgr1.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                                        XmlNodeList nodes1 = xml1.GetElementsByTagName("return");
                                        if (nodes1.Count != 0)
                                        {
                                            if (nodes1[0].InnerText != "")
                                            {

                                                try
                                                {
                                                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                                                    {
                                                        SqlCommand cmd = new SqlCommand
                                                        {
                                                            Connection = con,
                                                            CommandType = System.Data.CommandType.StoredProcedure,
                                                            CommandText = "p_Add_Driver_Pay_Record"
                                                        };
                                                        con.Open();

                                                        if (nodes1.Count != 0)
                                                        {
                                                            cmd.Parameters.Clear();
                                                            cmd.Parameters.Add("@Trip", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[0].InnerText;
                                                            cmd.Parameters.Add("@FreightBill", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[1].InnerText;
                                                            cmd.Parameters.Add("@PayCode", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[2].InnerText;
                                                            cmd.Parameters.Add("@Pay_Description", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[3].InnerText;
                                                            cmd.Parameters.Add("@Amount", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[4].InnerText;
                                                            cmd.Parameters.Add("@PayDate", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[5].InnerText;
                                                            cmd.Parameters.Add("@Driver_Id", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[6].InnerText;
                                                            cmd.Parameters.Add("@Pay_Id", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[7].InnerText;
                                                            cmd.Parameters.Add("@Trip_status", SqlDbType.NVarChar).Value = nodes1[0].ChildNodes[8].InnerText;
                                                            cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                                                            cmd.ExecuteNonQuery();
                                                        }
                                                        con.Close();

                                                    

                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    Console.WriteLine(ex.Message);
                                                }
                                            }
                                           
                                        }
                                        else
                                        {
                                            Console.WriteLine("Could not find pay record");

                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine(ex.Message);
                                    }
                                }
                                }
                    
                        }


                        using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                        {
                            SqlCommand cmd = new SqlCommand
                            {
                                Connection = con,
                                CommandType = System.Data.CommandType.StoredProcedure,
                                CommandText = "p_Get_Pay_Record"
                            };
                            cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                            con.Open();

                            SqlDataReader rdr = cmd.ExecuteReader();
                            if (rdr.HasRows)
                            {
                                var amount = "";
                                while (rdr.Read())
                                {
                                    amount = rdr["Amount"].ToString();

                                }
                                Pay_records.Add("amount", amount);
                            }
                            rdr.Close();
                            con.Close();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Could not find pay id");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            
            }
         
            return Pay_records;
        }


            [HttpPost]
        [Route("api/driver_updateloadofferchassis")]
        public  async Task<Dictionary<string, string>> Driver_UpdateLoadOfferChassisAsync(string loadoffers_id,  string chassis, string trip)
        {

                var chassisStatus = new Dictionary<string, string>();

                var soapClient = new SoapClient();
                var ns = XNamespace.Get(Startup.TruckMateString);
                XNamespace TTMHeader = "urn:TruckMateTypes";
                XElement tm = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                    new XElement("Password", "{NVpd{W3Qa:M"),
                    new XElement("Schema", "TMWIN"),
                    new XElement("Username", "PTMobile"));

                List<XElement> lst = new List<XElement>();
                lst.Add(tm);
                XElement bdy1 = new XElement(ns.GetName("GetChassis"),
                                                     new XElement("ChassisId", chassis));

                var result =
                    await soapClient.PostAsync(
                        new Uri(Startup.TruckMateString + "soap/IResManagement"),
                        SoapVersion.Soap11,
                        headers: lst,
                        body: bdy1);
                var response = await result.Content.ReadAsStringAsync();
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(response);
                var nsmgr = new XmlNamespaceManager(xml.NameTable);
                nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                XmlNodeList nodes1 = xml.GetElementsByTagName("return");
            if (nodes1.Count != 0 && (nodes1[0].ChildNodes[3].InnerText == "AVAIL" || nodes1[0].ChildNodes[3].InnerText == "ASSIGN"))
            {
               

                string status_Date = "";
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmdd = new SqlCommand
                    {
                        Connection = con,
                        CommandText = "select Convert(varchar(50), getdate(), 127) + Datename(TZOFFSET , SYSDATETIMEOFFSET()) as Status_Date"
                    };
                    con.Open();

                    SqlDataReader rdr = cmdd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            status_Date = rdr["Status_Date"].ToString();

                        }
                    }
                    rdr.Close();
                    con.Close();

                }
                try
                {

                    List<XElement> lst1 = new List<XElement>();
                    lst1.Add(tm);
                    var childrench1 = new XElement("Resources");
                    childrench1.Add(new XElement("item",
                              new XElement("ID", chassis),
                              new XElement("ResType", "RTCHASSIS")));

                    var childrench2 = new XElement("GPS");
                    childrench2.Add(new XElement("Description", ""),
                              new XElement("IsValid", "FALSE"),
                              new XElement("Lat", "0"),
                              new XElement("Long", "0")
                              );

                    XElement bdyCh1 = new XElement(ns.GetName("MatchResource"), new XElement("Trip", trip),
                                   childrench1, childrench2, new XElement("Effective", status_Date));
                    var resultCh1 =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString + "soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst1,
                            body: bdyCh1);
                    var responseCh1 = await resultCh1.Content.ReadAsStringAsync();
                    XmlDocument xmlCh1 = new XmlDocument();
                    xmlCh1.LoadXml(responseCh1);
                    var nsmgrCh1 = new XmlNamespaceManager(xmlCh1.NameTable);
                    nsmgrCh1.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                    XmlNodeList nodes = xmlCh1.GetElementsByTagName("Success");
                    if (nodes.Count != 0)
                    { }
                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Intermodal_Chassis"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@LoadOffer_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                    cmd.Parameters.Add("@Chassis_Number", SqlDbType.NVarChar).Value = chassis;
                    cmd.ExecuteNonQuery();

                    con.Close();

                    }
               

                    chassisStatus.Add("Status", "UPDATED");

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
            else
            {
                chassisStatus.Add("Status", "NOTAVAIL");

            }

            return chassisStatus;
            
         


        }

        [HttpPost]
        [Route("api/driver_removeloadofferchassis")]
        public async Task<bool> Driver_RemoveLoadOfferChassisAsync(string loadoffers_id)
        {
            bool chassisExist = false;
            string trip =  "";
            string chassis = "";
            string status_Date = "";

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Check_LoadOffers_Chassis_Exist"
                    };
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            trip = rdr["Trip"].ToString();
                            chassis = rdr["IntermodalOrders_ChassisNumber"].ToString();
                            status_Date= rdr["Status_Date"].ToString();

                        }
                            chassisExist = true;                            
                    }
                    rdr.Close();
                    con.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            if (chassisExist)
                { 
                try
                {
                    var soapClient = new SoapClient();
                    var ns = XNamespace.Get(Startup.TruckMateString);
                    
                    XNamespace TTMHeader = "urn:TruckMateTypes";

                    XElement tm2 = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                        new XElement("Password", "{NVpd{W3Qa:M"),
                        new XElement("Schema", "TMWIN"),
                        new XElement("Username", "PTMobile"));

                    List<XElement> lst = new List<XElement>();                    
                    lst.Add(tm2);
                    var children = new XElement("Resources");
                    children.Add(new XElement("item",
                              new XElement("ID", chassis),
                              new XElement("ResType", "RTCHASSIS")));

                    var children1 = new XElement("GPS");
                    children1.Add(new XElement("Description", ""),
                              new XElement("IsValid", "FALSE"),
                              new XElement("Lat", "0"),
                              new XElement("Long", "0")
                              );

                    XElement bdy = new XElement(ns.GetName("UnmatchResource"), new XElement("Trip", trip),
                                   children, children1, new XElement("Effective", status_Date));
                    var result =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString+"soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst,
                            body: bdy);
                    var response = await result.Content.ReadAsStringAsync();
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(response);
                    var nsmgr = new XmlNamespaceManager(xml.NameTable);
                    nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                    XmlNodeList nodes = xml.GetElementsByTagName("return");
                    if (nodes.Count != 0)
                    {
                        if (nodes[0].ChildNodes[2].InnerText == "true")
                        {
                            try
                            {
                                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                                {
                                    SqlCommand cmd = new SqlCommand
                                    {
                                        Connection = con,
                                        CommandType = System.Data.CommandType.StoredProcedure,
                                        CommandText = "p_Remove_LoadOffers_Chassis"
                                    };
                                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                                    cmd.Parameters.Add("@IntermodalOrders_ChassisNumber", SqlDbType.NVarChar).Value = chassis;
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                    con.Close();
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }

                            chassisExist = true;
                        }
                        else if(nodes[0].ChildNodes[2].InnerText == "false" && nodes[0].ChildNodes[1].InnerText == "No Components for Unmatch Operation")
                        {

                            try
                            {
                                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                                {
                                    SqlCommand cmd = new SqlCommand
                                    {
                                        Connection = con,
                                        CommandType = System.Data.CommandType.StoredProcedure,
                                        CommandText = "p_Remove_LoadOffers_Chassis"
                                    };
                                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                                    cmd.Parameters.Add("@IntermodalOrders_ChassisNumber", SqlDbType.NVarChar).Value = chassis;
                                    con.Open();
                                    cmd.ExecuteNonQuery();
                                    con.Close();
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e.Message);
                            }

                            chassisExist = true;                            
                        }
                        

                    }
                    else
                    {
                        Console.WriteLine("Failed to remove chassis from a trip");
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            else
            {
                chassisExist = false;
            }

            return chassisExist;

        }

  

        [HttpPost]
        [Route("api/driver_updateloadofferstatus")]
        public void Driver_UpdateLoadOfferStatusAsync(LoadOfferUpdateStatus ls)
        {

            try
            {
                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure,
                            CommandText = "p_Update_Load_Offers_Status"
                        };

                        con.Open();
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ls.LoadOffers_ID);
                        cmd.Parameters.Add("@LO_Status", SqlDbType.UniqueIdentifier).Value = Guid.Parse(ls.LO_Status);
                        cmd.Parameters.Add("@Status_Flag", SqlDbType.Int).Value =Convert.ToInt32(ls.Status_Flag);
                        cmd.ExecuteNonQuery();
                            
                        con.Close();

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

           

        }
        [HttpPost]
        [Route("api/driver_reassignloadoffer")]
        public  async  Task Driver_ReassignLoadOfferAsync(Dictionary<string,string> lo_info)
        {

            try
            {   // unmatch and match resources for both accepted and declined if driver changed. 

                if (lo_info["Prev_Driver"] != lo_info["New_Driver"])
                {

                    string status_Date = "";
                    using (SqlConnection con1 = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmdd = new SqlCommand
                        {
                            Connection = con1,
                            CommandText = "select Convert(varchar(50), getdate(), 127) + Datename(TZOFFSET , SYSDATETIMEOFFSET()) as Status_Date"
                        };
                        con1.Open();

                        SqlDataReader rdr = cmdd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                status_Date = rdr["Status_Date"].ToString();

                            }
                        }
                        rdr.Close();
                        con1.Close();

                    }
                    // ------------- unmatch powerunit ------------------------------- //

                    var soapClient = new SoapClient();
                    var ns = XNamespace.Get(Startup.TruckMateString);

                    XNamespace TTMHeader = "urn:TruckMateTypes";

                    XElement tm2 = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                        new XElement("Password", "{NVpd{W3Qa:M"),
                        new XElement("Schema", "TMWIN"),
                        new XElement("Username", "PTMobile"));

                    List<XElement> lst = new List<XElement>();
                    lst.Add(tm2);
                    var children = new XElement("Resources");
                    children.Add(new XElement("item",
                              new XElement("ID", lo_info["Prev_Punit"]),
                              new XElement("ResType", "RTPOWERUNIT")));

                    var children1 = new XElement("GPS");
                    children1.Add(new XElement("Description", ""),
                              new XElement("IsValid", "FALSE"),
                              new XElement("Lat", "0"),
                              new XElement("Long", "0")
                              );

                    XElement bdy = new XElement(ns.GetName("UnmatchResource"), new XElement("Trip", lo_info["Trip"]),
                                   children, children1, new XElement("Effective", status_Date));
                    var result = await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString + "soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst,
                            body: bdy);
                    var response = await result.Content.ReadAsStringAsync();
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(response);
                    var nsmgr = new XmlNamespaceManager(xml.NameTable);
                    nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                    XmlNodeList nodes = xml.GetElementsByTagName("return");
                    if (nodes.Count != 0)
                    {


                    }
                    // ------------- unmatch driver ------------------------------- //


                    List<XElement> lst1 = new List<XElement>();
                    lst1.Add(tm2);
                    var childrenDU1 = new XElement("Resources");
                    childrenDU1.Add(new XElement("item",
                              new XElement("ID", lo_info["Prev_Driver"]),
                              new XElement("ResType", "RTDRIVER")));

                    var childrenDU2 = new XElement("GPS");
                    childrenDU2.Add(new XElement("Description", ""),
                              new XElement("IsValid", "FALSE"),
                              new XElement("Lat", "0"),
                              new XElement("Long", "0")
                              );

                    XElement bdy1 = new XElement(ns.GetName("UnmatchResource"), new XElement("Trip", lo_info["Trip"]),
                                   childrenDU1, childrenDU2, new XElement("Effective", status_Date));
                    var result1 =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString + "soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst1,
                            body: bdy1);
                    var response1 = await result1.Content.ReadAsStringAsync();
                    XmlDocument xml1 = new XmlDocument();
                    xml1.LoadXml(response1);
                    var nsmgr1 = new XmlNamespaceManager(xml1.NameTable);
                    nsmgr1.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");

                    // ------------- Match powerunit ------------------------------- //

                    List<XElement> lst2 = new List<XElement>();
                    lst2.Add(tm2);
                    var childrenPM1 = new XElement("Resources");
                    childrenPM1.Add(new XElement("item",
                              new XElement("ID", lo_info["New_Punit"]),
                              new XElement("ResType", "RTPOWERUNIT")));

                    var childrenPM2 = new XElement("GPS");
                    childrenPM2.Add(new XElement("Description", ""),
                              new XElement("IsValid", "FALSE"),
                              new XElement("Lat", "0"),
                              new XElement("Long", "0")
                              );

                    XElement bdy2 = new XElement(ns.GetName("MatchResource"), new XElement("Trip", lo_info["Trip"]),
                                   childrenPM1, childrenPM2, new XElement("Effective", status_Date));
                    var result2 = await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString + "soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst2,
                            body: bdy2);
                    var response2 = await result2.Content.ReadAsStringAsync();
                    XmlDocument xml2 = new XmlDocument();
                    xml2.LoadXml(response2);
                    var nsmgr2 = new XmlNamespaceManager(xml2.NameTable);
                    nsmgr2.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                    XmlNodeList nodes2 = xml2.GetElementsByTagName("return");

                    // ------------- Match driver ------------------------------- //

                    List<XElement> lst3 = new List<XElement>();
                    lst3.Add(tm2);
                    var childrenDM1 = new XElement("Resources");
                    childrenDM1.Add(new XElement("item",
                              new XElement("ID", lo_info["New_Driver"]),
                              new XElement("ResType", "RTDRIVER")));

                    var childrenDM2 = new XElement("GPS");
                    childrenDM2.Add(new XElement("Description", ""),
                              new XElement("IsValid", "FALSE"),
                              new XElement("Lat", "0"),
                              new XElement("Long", "0")
                              );

                    XElement bdy3 = new XElement(ns.GetName("MatchResource"), new XElement("Trip", lo_info["Trip"]),
                                   childrenDM1, childrenDM2, new XElement("Effective", status_Date));
                    var result3 =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString + "soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst3,
                            body: bdy3);
                    var response3 = await result1.Content.ReadAsStringAsync();
                    XmlDocument xml3 = new XmlDocument();
                    xml3.LoadXml(response3);
                    var nsmgr3 = new XmlNamespaceManager(xml3.NameTable);
                    nsmgr3.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");


                }

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Reassign_Loadoffer"
                    };

                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value   = Guid.Parse(lo_info["LoadOffers_ID"]);
                    cmd.Parameters.Add("@Prev_Driver_UID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lo_info["Prev_Driver_UID"]);
                    cmd.Parameters.Add("@New_Driver_UID", SqlDbType.UniqueIdentifier).Value  = Guid.Parse(lo_info["New_Driver_UID"]);
                    cmd.Parameters.Add("@Lo_Status", SqlDbType.UniqueIdentifier).Value       = Guid.Parse(lo_info["Lo_Status"]);
                    cmd.Parameters.Add("@Trip_Status", SqlDbType.UniqueIdentifier).Value     = Guid.Parse(lo_info["Trip_Status"]);
                    cmd.Parameters.Add("@Driver_Id", SqlDbType.NVarChar).Value               = lo_info["New_Driver"];
                    cmd.Parameters.Add("@Device_Id", SqlDbType.NVarChar).Value               = lo_info["New_Punit"];
                    cmd.Parameters.Add("@Status_Flag", SqlDbType.Int).Value                  = Convert.ToInt32( lo_info["Status_Flag"]);

                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



        }

        [HttpPost]
        [Route("api/driver_driverdeleteloadofferstablet")]
        public void Driver_DriverDeleteLoadOffersTablet(Dictionary<string,string>lo_info)
        {

            try
            {                
                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure,
                            CommandText = "p_Delete_Load_Offers_Tablet"
                        };

                        con.Open();
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lo_info["LoadOffers_ID"]);
                        cmd.Parameters.Add("@Status_Flag", SqlDbType.Int).Value = Convert.ToInt32(lo_info["Status_Flag"]);

                        cmd.ExecuteNonQuery();

                        con.Close();

                    }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

     

        [HttpPost]
        [Route("api/driver_updateloadoffer_driverpaystatus")]
        public void Driver_UpdateLoadOfferDriverPayStatus(string loadoffers_id, string dp_status)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Load_Offers_Driver_Pay_Status"
                    };

                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                    cmd.Parameters.Add("@DP_Status", SqlDbType.UniqueIdentifier).Value = Guid.Parse(dp_status);
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        

        [HttpPost]
        [Route("api/driver_setbreakinfo")]
        public void Driver_SetBreakInfo(List<DriverBreak> brk)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Set_Driver_Break"
                    };

                    con.Open();
                    foreach (DriverBreak item in brk)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(item.User_Id);
                        cmd.Parameters.Add("@Break_Id", SqlDbType.UniqueIdentifier).Value = item.Break_Id;
                        cmd.Parameters.Add("@Shift_Id", SqlDbType.UniqueIdentifier).Value = item.Shift_Id;
                        cmd.Parameters.Add("@Driver_BreakStart", SqlDbType.DateTime).Value = item.BreakStart;
                        cmd.Parameters.Add("@Driver_BreakEnd", SqlDbType.DateTime).Value = item.BreakEnd;
                        cmd.Parameters.Add("@Driver_Notes", SqlDbType.VarChar).Value = item.BreakNotes;
                        cmd.ExecuteNonQuery();

                    }



                    con.Close();


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [HttpPost]
        [Route("api/driver_setshiftinfo")]
        public void Driver_SetShiftInfo(DriverShift driver_shiftinfo)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Set_Driver_Shift"
                    };

                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(driver_shiftinfo.User_Id);
                    cmd.Parameters.Add("@Shift_Id", SqlDbType.UniqueIdentifier).Value = driver_shiftinfo.Shift_Id;
                    cmd.Parameters.Add("@Driver_ShiftStart", SqlDbType.DateTime).Value = driver_shiftinfo.ShiftStart;
                    cmd.Parameters.Add("@Driver_ShiftEnd", SqlDbType.DateTime).Value = driver_shiftinfo.ShiftEnd;
            
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [Route("api/register_driver")]
        [HttpPost]
        public async Task<IActionResult> RegisterDriverAsync(RegisterDriverModel mod)
        {

            //setting the values for Identity server registration
            var values = new Dictionary<string, string>
                  {
                      { "Username", mod.Driver_Email },
                      { "Password", mod.Driver_Password}
                  };
            var jsstr = JsonConvert.SerializeObject(values);

            var requestBody = new StringContent(jsstr);
            requestBody.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var response = await client.PostAsync(Startup.IdentityString + "/Register", requestBody);
            var responseUserId = await response.Content.ReadAsStringAsync();

            Guid newId;

            try
            {
                newId = Guid.Parse(responseUserId);
            }
            catch
            {

                List<IdentityError> errLst = JsonConvert.DeserializeObject<List<IdentityError>>(responseUserId);
                string errorDesc = "";

                foreach (IdentityError err in errLst)
                {
                    errorDesc += err.description;
                    errorDesc += "\n";
                }

                return BadRequest(errorDesc);
            }
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_Driver_User"
                    };
                    cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = newId;
                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar).Value = mod.Driver_Email;
                    cmd.Parameters.Add("@User_First_Name", SqlDbType.NVarChar).Value = mod.Driver_FirstName;
                    cmd.Parameters.Add("@User_Last_Name", SqlDbType.NVarChar).Value = mod.Driver_LastName;
                    cmd.Parameters.Add("@User_Driver_Id", SqlDbType.NVarChar).Value = mod.Driver_Id;
                    cmd.Parameters.Add("@User_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.Driver_Company);
                    cmd.Parameters.Add("@User_Role_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.Driver_Role);
                    cmd.Parameters.Add("@Date_Created", SqlDbType.DateTime2).Value = DateTime.Now;

                    con.Open();
                    var Driver_Id = "";
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {


                            Driver_Id = rdr["Driver_Id"].ToString();

                        }
                    }
                    rdr.Close(); 
                    con.Close();
                    using (var client = new SftpClient("mobilestorage.pauls.ca", port: 22, "dispatch_user", "_)$a8gF3TC"))
                    {
                        try
                        {
                            client.Connect();

                            var remoteDirectory = "/" + mod.Driver_Company.ToUpper() + "/" + Driver_Id.ToUpper();
                            if (client.Exists("/" + mod.Driver_Company.ToUpper()))
                            {
                                client.CreateDirectory(remoteDirectory);
                            }

                            if (client.Exists(remoteDirectory))
                            {
                                client.CreateDirectory(remoteDirectory + @"/CONTAINER");
                                client.CreateDirectory(remoteDirectory + @"/DOCUMENTS");
                                client.CreateDirectory(remoteDirectory + @"/FREIGHTBILLS");
                                client.CreateDirectory(remoteDirectory + @"/GENERIC");
                                client.CreateDirectory(remoteDirectory + @"/POD");
                                client.CreateDirectory(remoteDirectory + @"/LINEUP");
                                client.CreateDirectory(remoteDirectory + @"/SIGNATURES");
                                client.CreateDirectory(remoteDirectory + @"/TRUCK");

                            }
                        }
                        catch (Exception Ex)
                        {
                            Console.WriteLine(Ex.Message);

                        }
                        finally
                        {
                            if (client.IsConnected)
                            {
                                client.Disconnect();
                            }
                        }
                    }


                    //  var path = @"\\mobilestorage.pauls.ca\Data\" + mod.Driver_Company.ToUpper();
                    // bool company_exists = Directory.Exists(path + @"\");

                    /*  if (company_exists)
                      {
                          DirectoryInfo di = Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper());
                          bool driver_exists = Directory.Exists(path + @"\" + Driver_Id.ToUpper());
                          if (driver_exists)
                          {
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\CHASSIS");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\CONTAINER");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\DOCUMENTS");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\FREIGHTBILLS");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\GENERIC");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\LINEUP");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\POD");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\SIGNATURES");
                              Directory.CreateDirectory(path + @"\" + Driver_Id.ToUpper() + @"\TRUCK");
                          }

                      }
                      else
                      {
                          Console.WriteLine(" path doesn't exists .");

                      }*/

                }
            }
            catch
            {
                throw new Exception("Error registering driver.");

            }


            return Ok();
        }

        [HttpPost]
        [Route("api/update_driver_truck_device")]
        public void UpdateImeiTruck(Driver im)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Driver_Device_Truck"
                    };
                    if (im.Driver_Device_Id == "" || im.Driver_Device_Id == null)
                    {
                        im.Driver_Device_Id = Guid.Empty.ToString();
                    }
                    if (im.Driver_Truck_Id == "" || im.Driver_Truck_Id == null)
                    {
                        im.Driver_Truck_Id = Guid.Empty.ToString();

                    }
                    cmd.Parameters.Add("@Driver_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.User_Id);
                    cmd.Parameters.Add("@Device_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Driver_Device_Id);
                    cmd.Parameters.Add("@Truck_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Driver_Truck_Id);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating the driver.");

            }


        }
        [Route("api/update_driver_user")]
        [HttpPost]
        public async Task<IActionResult> UpdateUserAsync(EditUserModel mod)
        {
            try
            {
                if (mod.User_Password != "")
                {
                    var passValues = new Dictionary<string, string>
                    {
                        { "UserName", mod.User_Email_Old },
                        { "Password", mod.User_Password }

                    };
                    var jsstrPass = JsonConvert.SerializeObject(passValues);
                    var requestBodyPass = new StringContent(jsstrPass);
                    requestBodyPass.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                    var resp = await client.PostAsync(Startup.IdentityString + "/UpdatePassword", requestBodyPass);

                }

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = CommandType.StoredProcedure,
                        CommandText = "p_Update_Driver_User"
                    };


                    con.Open();
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(mod.User_Id);
                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar).Value = mod.User_Email;
                    cmd.Parameters.Add("@User_First_Name", SqlDbType.NVarChar).Value = mod.User_FirstName;
                    cmd.Parameters.Add("@User_Last_Name", SqlDbType.NVarChar).Value = mod.User_LastName;
                    cmd.Parameters.Add("@User_Role_Id", SqlDbType.NVarChar).Value = mod.User_Role_Id;

                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }
            catch
            {
                throw new Exception("Error editing driver info.");
            }
            return Ok();

        }


        [HttpPost]
        [Route("api/disable_driver")]
        public void DisableUser(Driver Us)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Disable_Driver"
                    };

                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar, -1).Value = Us.Driver_Email;
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Us.User_Id);
                    cmd.Parameters.Add("@Date_Disabled", SqlDbType.DateTime2).Value = DateTime.Now;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error disabling user.");
            }
        }

        [HttpPost]
        [Route("api/enable_driver")]
        public void EnableUser(Driver Us)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_Driver"
                    };

                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar, -1).Value = Us.Driver_Email;
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Us.User_Id);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error enabling user.");
            }



        }
        [HttpPost]
        [Route("api/activate_new_driver")]
        public void ActivateNewDriver(Driver Us)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Activate_New_Driver"
                    };

                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Us.User_Id);
                    cmd.Parameters.Add("@Driver_Firstname", SqlDbType.NVarChar).Value = Us.Driver_Firstname;
                    cmd.Parameters.Add("@Driver_Lastname", SqlDbType.NVarChar).Value = Us.Driver_Lastname;
                    cmd.Parameters.Add("@Driver_Id", SqlDbType.NVarChar).Value = Us.Driver_Id;
                    cmd.Parameters.Add("@User_Email", SqlDbType.NVarChar).Value = Us.Driver_Email;


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch(Exception Ex)
            {
                throw new Exception(Ex.Message);
            }



        }


        [HttpPost]
        [Route("api/driver_addloadOfferseals")]
        public async Task driver_AddLoadOfferSeals(List<SealModel>Seals)
        {


            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure,
                };
                con.Open();
                foreach (SealModel seal in Seals)
                {
                    cmd.Parameters.Clear();
                    cmd.CommandText = "p_Add_LoadOffer_Seals";
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(seal.LoadOffers_ID);
                    cmd.Parameters.Add("@DLD", SqlDbType.NVarChar).Value = seal.DLD;
                    cmd.Parameters.Add("@Seal_Number", SqlDbType.NVarChar).Value = seal.Seal_Number;
                    cmd.Parameters.Add("@Seal_Type", SqlDbType.NVarChar).Value = seal.Seal_Type;
                    cmd.Parameters.Add("@IsConfirmed", SqlDbType.Bit).Value =  seal.IsConfirmed;

                    cmd.ExecuteNonQuery();
                   

                }
                foreach (SealModel seal in Seals)
                {
                    if (seal.Seal_Type == "E")
                    {
                        var soapClient = new SoapClient();
                        var ns = XNamespace.Get(Startup.TruckMateString);

                        XNamespace TTMHeader = "urn:TruckMateTypes";
                        XElement tm = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                            new XElement("Password", "{NVpd{W3Qa:M"),
                            new XElement("Schema", "TMWIN"),
                            new XElement("Username", "PTMobile"));



                        List<XElement> lst = new List<XElement>();
                        //lst.Add(tm);
                        lst.Add(tm);
                        var children = new XElement("TraceNumbers");
                        children.Add(new XElement("item",
                                        new XElement("Index", 0),
                                        new XElement("TraceType", "tSeal"),
                                        new XElement("Value", seal.Seal_Number)));

                        XElement bdy = new XElement(ns.GetName("SendTraceNumbers"),
                                       children, new XElement("DLD", seal.DLD));

                        var result =
                            await soapClient.PostAsync(
                                new Uri(Startup.TruckMateString + "soap/IResManagement"),
                                SoapVersion.Soap11,
                                headers: lst,
                                body: bdy);
                        var response = await result.Content.ReadAsStringAsync();
                        XmlDocument xml = new XmlDocument();
                        xml.LoadXml(response);
                        var nsmgr = new XmlNamespaceManager(xml.NameTable);
                        nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                        XmlNodeList nodes = xml.GetElementsByTagName("Success");
                        if (nodes.Count != 0)
                        {

                        }
                        else
                        {
                            Console.WriteLine("Seal Not Updated");
                        }

                    }


                }
                con.Close();

            }
        
            
            
          


        }
        [HttpPost]
        [Route("api/driver_updateloadoffer_tare_weight")]
        public async Task Driver_UpdateLoadOfferTareWeight(string loadoffers_id, string weight_value,string dld)
        {

            try
            {

                var soapClient = new SoapClient();
                var ns = XNamespace.Get(Startup.TruckMateString);

                XNamespace TTMHeader = "urn:TruckMateTypes";
                XElement tm = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                    new XElement("Password", "{NVpd{W3Qa:M"),
                    new XElement("Schema", "TMWIN"),
                    new XElement("Username", "PTMobile"));



                List<XElement> lst = new List<XElement>();
                //lst.Add(tm);
                lst.Add(tm);
                var children = new XElement("TraceNumbers");
                children.Add(new XElement("item",
                                new XElement("Index", 0),
                                new XElement("TraceType", "tUserT"),
                                new XElement("Value", weight_value)));

                XElement bdy = new XElement(ns.GetName("SendTraceNumbers"),
                               children, new XElement("DLD", dld));

                var result =
                    await soapClient.PostAsync(
                        new Uri(Startup.TruckMateString + "soap/IResManagement"),
                        SoapVersion.Soap11,
                        headers: lst,
                        body: bdy);
                var response = await result.Content.ReadAsStringAsync();
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(response);
                var nsmgr = new XmlNamespaceManager(xml.NameTable);
                nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");
                XmlNodeList nodes = xml.GetElementsByTagName("Success");
                if (nodes.Count != 0)
                {

                }
                else
                {
                    Console.WriteLine("Tare Weight Not Updated");
                }

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_LoadOffers_Tare_Weight"
                    };

                    con.Open();
                    cmd.Parameters.Add("@LoadOffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                    cmd.Parameters.Add("@Weight_Value", SqlDbType.NVarChar).Value = weight_value.ToString();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }


        [HttpPost]
        [Route("api/driver_addloadOffers_wait_time")]
        public void Driver_AddLoadOffersWaitTime(string loadoffers_id, TimeSpan wait_time, string wait_time_status)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Add_Loadoffers_Wait_Time"
                    };

                    con.Open();
                    cmd.Parameters.Add("@Loadoffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                    cmd.Parameters.Add("@Wait_Time_Driver", SqlDbType.Time).Value = (TimeSpan)wait_time;
                    cmd.Parameters.Add("@Wait_Time_Status", SqlDbType.NVarChar).Value = wait_time_status.ToString();

                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        [HttpPost]
        [Route("api/driver_addloadOffers_loadunload_wait_time")]
        public void Driver_AddLoadOffersLoadUnloadWaitTime(string loadoffers_id, TimeSpan wait_time, string ewt_status)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Add_Loadoffers_LoadUnload_Wait_Time"
                    };

                    con.Open();
                    cmd.Parameters.Add("@Loadoffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffers_id);
                    cmd.Parameters.Add("@Estimated_Wait_Time", SqlDbType.Time).Value = (TimeSpan)wait_time;
                    cmd.Parameters.Add("@EWT_Status", SqlDbType.NVarChar).Value = ewt_status.ToString();

                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        [HttpPost]
        [Route("api/driver_update_export_container")]
        public async Task Driver_UpdateExportContainerAsync(string loadoffer_id, string container_code, string container_digit, string trip , string owner ,string container_type)
        {

            if (container_code != "" && container_digit != "")
            {
                try
                {
                    var soapClient = new SoapClient();
                    var ns = XNamespace.Get(Startup.TruckMateString);

                    XNamespace TTMHeader = "urn:TruckMateTypes";
                    XElement tm = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                        new XElement("Password", "{NVpd{W3Qa:M"),
                        new XElement("Schema", "TMWIN"),
                        new XElement("Username", "PTMobile"));

                    List<XElement> lst = new List<XElement>();
                    lst.Add(tm);
                    var children = new XElement("Container");
                    children.Add(
                                new XElement("Container_Id", container_code),
                                new XElement("Current_Trip", trip),
                                new XElement("Current_Zone", "TBA"),
                                new XElement("Status", "AVAIL"),
                                new XElement("Active_In_Disp", "TRUE"),
                                new XElement("Current_Loc_Client", "TBA"),
                                new XElement("Description", ""),
                                new XElement("Movement_Type", "Export"),
                                new XElement("Number", container_code + container_digit),
                                new XElement("Container_Digit", container_digit),
                                new XElement("Container_Type", container_type),
                                new XElement("Container_Size", container_type),
                                new XElement("Owner", owner),
                                new XElement("ISONumber", container_type)
                                );
                    XElement bdy = new XElement(ns.GetName("PutContainer"),
                        children
                    );
                    var result =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString + "soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst,
                            body: bdy);
                    var response = await result.Content.ReadAsStringAsync();
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(response);
                    var nsmgr = new XmlNamespaceManager(xml.NameTable);
                    nsmgr.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");



                    // Assigning container

                    string status_Date = "";
                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmdd = new SqlCommand
                        {
                            Connection = con,
                            CommandText = "select Convert(varchar(50), getdate(), 127) + Datename(TZOFFSET , SYSDATETIMEOFFSET()) as Status_Date"
                        };
                        con.Open();

                        SqlDataReader rdr = cmdd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                status_Date = rdr["Status_Date"].ToString();

                            }
                        }
                        rdr.Close();
                        con.Close();

                    }

                    XElement tm1 = new XElement(TTMHeader + "TTMHeader", new XElement("DSN", "PTITST22"),
                        new XElement("Password", "{NVpd{W3Qa:M"),
                        new XElement("Schema", "TMWIN"),
                        new XElement("Username", "PTMobile"));

                    List<XElement> lst1 = new List<XElement>();
                    lst1.Add(tm1);
                    var children1 = new XElement("Resources");
                    children1.Add(new XElement("item",
                              new XElement("ID", container_code),
                              new XElement("ResType", "RTCONTAINER")));

                    var children2 = new XElement("GPS");
                    children2.Add(new XElement("Description", ""),
                              new XElement("IsValid", "FALSE"),
                              new XElement("Lat", "0"),
                              new XElement("Long", "0")
                              );

                    XElement bdy1 = new XElement(ns.GetName("MatchResource"), new XElement("Trip", trip),
                                   children1, children2, new XElement("Effective", status_Date));
                    var result1 =
                        await soapClient.PostAsync(
                            new Uri(Startup.TruckMateString + "soap/IResManagement"),
                            SoapVersion.Soap11,
                            headers: lst1,
                            body: bdy1);
                    var response1 = await result1.Content.ReadAsStringAsync();
                    XmlDocument xml1 = new XmlDocument();
                    xml1.LoadXml(response1);
                    var nsmgr1 = new XmlNamespaceManager(xml1.NameTable);
                    nsmgr1.AddNamespace("NS1", "urn:MobileCommIntf-IMobileComm");



                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                        {
                            SqlCommand cmd = new SqlCommand
                            {
                                Connection = con,
                                CommandType = System.Data.CommandType.StoredProcedure,
                                CommandText = "p_Update_Intermodal_Container_Info"
                            };

                            con.Open();
                            cmd.Parameters.Add("@Loadoffers_ID", SqlDbType.UniqueIdentifier).Value = Guid.Parse(loadoffer_id);
                            cmd.Parameters.Add("@ContainerCode", SqlDbType.NVarChar).Value = container_code;
                            cmd.Parameters.Add("@ContainerDigit", SqlDbType.NVarChar).Value = container_digit;
                            cmd.Parameters.Add("@ContainerNumber", SqlDbType.NVarChar).Value = container_code + container_digit;
                            cmd.ExecuteNonQuery();

                            con.Close();

                        }

                      


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }

        }
    }
}
