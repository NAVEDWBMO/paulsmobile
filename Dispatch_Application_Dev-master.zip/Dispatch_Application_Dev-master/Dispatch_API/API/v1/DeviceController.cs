﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;
using Api;
using Api.Data.Entity;
using Driver_Api.API.v1;
using Driver_Api.Data.Entity;
using Driver_Api.Data.Entity.ActionModels;
using Dispatch_Application_Debug_API.API.v1;
using Dispatch_Api.Data.Entity;
using Dispatch_Application_Debug_API.Data.Entity;
using Dispatch_Application_Debug_API.Data.Hubs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
/*using Microsoft.Data.SqlClient;
*/
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;


namespace Dispatch_Api.API.v1
{
    [ApiController]
    [Authorize]
    public class DeviceController : Controller
    {
        [HttpGet]
        [Route("api/get_devices")]
        public List<Device> GetDevices(string Company_Id)
        {
            List<Device> lstDevices = new List<Device>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    var claims = User.Claims.ToList();

                    var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

                    string role = "";

                    SqlCommand cmdCheckRole = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    cmdCheckRole.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                    cmdCheckRole.CommandText = "p_Get_User_Info";
                    con.Open();

                    SqlDataReader rdrRole = cmdCheckRole.ExecuteReader();
                    if (rdrRole.HasRows)
                    {
                        while (rdrRole.Read())
                        {
                            role = rdrRole["User_Role"].ToString();

                        }
                    }
                    rdrRole.Close();
                    //if admin


                    // if (role.ToLower() == "25942536-C57D-4E18-A82D-0CDCC77A74C5".ToLower())
                    if (Company_Id.ToLower() == "96AA4673-C3CD-40A9-9F69-DF2290E20C8E".ToLower())
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure,
                            CommandText = "p_Get_All_Devices"
                        };


                        SqlDataReader rdr = cmd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                Device dev = new Device()
                                {
                                    Device_Id = rdr["Driver_Device_Id"].ToString(),
                                    Device_IMEI_Id = rdr["Device_IMEI_Id"].ToString(),
                                    Device_Model = rdr["Model"].ToString(),
                                    Device_Model_Year = rdr["Model_Year"].ToString(),
                                    Device_Company = rdr["Device_Company"].ToString(),
                                    Device_Serial_Number = rdr["Serial_Number"].ToString(),
                                    Phone_Number = rdr["Phone_Number"].ToString(),
                                    Driver_Device_IsEnabled = bool.Parse( rdr["Driver_Device_IsEnabled"].ToString()),
                                    Company_Name = rdr["Company_Name"].ToString(),
                                    Device_IMEI_Number= rdr["Device_IMEI_Number"].ToString(),
                                    Device_Driver_User_Id = rdr["User_Id"].ToString(),
                                    Device_Driver_Firstname = rdr["Firstname"].ToString(),
                                    Device_Driver_Lastname = rdr["Lastname"].ToString(),
                                    Device_Driver_Truck_Id = rdr["Truck_Id"].ToString(),
                                    Device_Driver_Id = rdr["Driver_Id"].ToString(),
                                    Company_Id = rdr["Company_Id"].ToString()
                                };

                                lstDevices.Add(dev);
                            }
                        }
                        rdr.Close();
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure,
                            CommandText = "p_Get_Devices_For_Company"
                        };
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);


                        SqlDataReader rdr = cmd.ExecuteReader();
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                Device dev = new Device()
                                {
                                    Device_Id = rdr["Driver_Device_Id"].ToString(),
                                    Device_IMEI_Id = rdr["Device_IMEI_Id"].ToString(),
                                    Device_Model = rdr["Model"].ToString(),
                                    Device_Model_Year = rdr["Model_Year"].ToString(),
                                    Device_Company = rdr["Device_Company"].ToString(),
                                    Device_Serial_Number = rdr["Serial_Number"].ToString(),
                                    Phone_Number = rdr["Phone_Number"].ToString(),
                                    Driver_Device_IsEnabled = bool.Parse(rdr["Driver_Device_IsEnabled"].ToString()),
                                    Company_Name = rdr["Company_Name"].ToString(),
                                    Device_IMEI_Number = rdr["Device_IMEI_Number"].ToString(),
                                    Device_Driver_User_Id = rdr["User_Id"].ToString(),
                                    Device_Driver_Firstname = rdr["Firstname"].ToString(),
                                    Device_Driver_Lastname = rdr["Lastname"].ToString(),
                                    Device_Driver_Truck_Id = rdr["Truck_Id"].ToString(),
                                    Device_Driver_Id = rdr["Driver_Id"].ToString(),
                                    Company_Id = rdr["Company_Id"].ToString()
                                };

                                lstDevices.Add(dev);
                            }
                        }
                        rdr.Close();
                    }



                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting device info.");

            }

            return lstDevices;
        }

        [HttpGet]
        [Route("api/get_available_devices")]
        public List<Device> GetAvailableDevices(string Company_Id)
        {
            List<Device> lstDevices = new List<Device>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Available_Devices"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Device dev = new Device()
                            {
                                Device_Id = rdr["Driver_Device_Id"].ToString(),
                                Device_IMEI_Id = rdr["Device_IMEI_Id"].ToString(),
                                Device_Model = rdr["Model"].ToString(),
                                Device_Model_Year = rdr["Model_Year"].ToString(),
                                Device_Company = rdr["Device_Company"].ToString(),
                                Device_Serial_Number = rdr["Serial_Number"].ToString(),
                                Phone_Number = rdr["Phone_Number"].ToString()

                            };

                            lstDevices.Add(dev);
                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting device info.");

            }

            return lstDevices;
        }

        [HttpGet]
        [Route("api/get_imeis")]
        public List<Imei> GetImeis(string Company_Id)
        {
            List<Imei> lstDevices = new List<Imei>();
            /* try
             {*/
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                var claims = User.Claims.ToList();

                var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

                string role = "";

                SqlCommand cmdCheckRole = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmdCheckRole.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                cmdCheckRole.CommandText = "p_Get_User_Info";
                con.Open();

                SqlDataReader rdrRole = cmdCheckRole.ExecuteReader();
                if (rdrRole.HasRows)
                {
                    while (rdrRole.Read())
                    {
                        role = rdrRole["User_Role"].ToString();
                    }
                }
                rdrRole.Close();
                //if admin


                //if (role.ToLower() == "25942536-C57D-4E18-A82D-0CDCC77A74C5".ToLower())
                if (Company_Id.ToLower() == "96AA4673-C3CD-40A9-9F69-DF2290E20C8E".ToLower())
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Imeis"
                    };

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            bool hasVoice = false;
                            string val = rdr["Cell_Plan_Has_Voice"].ToString();
                            if (val == null || val == "0" || val == "" || val == "False")
                            {
                                hasVoice = false;
                            }
                            else
                            {
                                hasVoice = true;
                            }
                            CellPlan cp = new CellPlan()
                            {
                                Cell_Plan_Id = rdr["Cell_Plan_Id"].ToString(),
                                Cell_Plan_Name = rdr["Cell_Plan_Name"].ToString(),
                                Cell_Plan_Data = rdr["Cell_Plan_Data"].ToString(),
                                Cell_Plan_Has_Voice = hasVoice,
                                Cell_Plan_Price = rdr["Cell_Plan_Price"].ToString(),
                            };
                            Device dv = new Device()
                            {
                                Device_Serial_Number = rdr["Serial_Number"].ToString(),
                            };

                            Imei im = new Imei()
                            {
                                Device_IMEI_Id = rdr["Device_IMEI_Id"].ToString(),
                                Device_IMEI_Number = rdr["Device_IMEI_Number"].ToString(),
                                Phone_Number = rdr["Phone_Number"].ToString(),
                                Cell_Company = rdr["Cell_Company_Name"].ToString(),
                                Cell_Company_Id = rdr["Cell_Company"].ToString(),
                                Cell_Plan = rdr["Cell_Plan"].ToString(),
                                Assigned_to_Device = dv,
                                CPlan = cp,
                                Device_IMEI_Company_Id = rdr["Company_Id"].ToString(),
                                Device_IMEI_Company_Name = rdr["Company_Name"].ToString(),
                                Device_IMEI_IsEnabled = bool.Parse(rdr["Device_IMEI_IsEnabled"].ToString())


                            };
                     
                            lstDevices.Add(im);
                           


                        }
                    }
                    rdr.Close();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Imeis_For_Company"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);


                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            bool hasVoice = false;
                            string val = rdr["Cell_Plan_Has_Voice"].ToString();
                            if (val == null || val == "0" || val == "" || val == "False")
                            {
                                hasVoice = false;
                            }
                            else
                            {
                                hasVoice = true;
                            }
                            CellPlan cp = new CellPlan()
                            {
                                Cell_Plan_Id = rdr["Cell_Plan_Id"].ToString(),
                                Cell_Plan_Name = rdr["Cell_Plan_Name"].ToString(),
                                Cell_Plan_Data = rdr["Cell_Plan_Data"].ToString(),
                                Cell_Plan_Has_Voice = hasVoice,
                                Cell_Plan_Price = rdr["Cell_Plan_Price"].ToString(),
                            };

                            Device dv = new Device()
                            {
                                Device_Serial_Number = rdr["Serial_Number"].ToString(),
                            };

                            Imei im = new Imei()
                            {
                                Device_IMEI_Id = rdr["Device_IMEI_Id"].ToString(),
                                Device_IMEI_Number = rdr["Device_IMEI_Number"].ToString(),
                                Phone_Number = rdr["Phone_Number"].ToString(),
                                Cell_Company = rdr["Cell_Company_Name"].ToString(),
                                Cell_Company_Id = rdr["Cell_Company"].ToString(),
                                Cell_Plan = rdr["Cell_Plan"].ToString(),
                                Assigned_to_Device = dv,
                                CPlan = cp,
                                Device_IMEI_Company_Id = rdr["Company_Id"].ToString(),
                                Device_IMEI_Company_Name = rdr["Company_Name"].ToString(),
                                Device_IMEI_IsEnabled = bool.Parse(rdr["Device_IMEI_IsEnabled"].ToString())


                            };
                         

                            lstDevices.Add(im);
                        }
                    }
                    rdr.Close();
                }





                con.Close();

            }
            /*
                        }
                        catch
                        {
                            throw new Exception("Error getting Imei info.");

                        }*/

            return lstDevices;
        }

        [HttpGet]
        [Route("api/get_cell_companies")]
        public List<CellCompany> GetCellCompanies()
        {
            List<CellCompany> lstDevices = new List<CellCompany>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Cell_Companies"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            CellCompany im = new CellCompany()
                            {
                                Cell_Company_Id = rdr["Cell_Company_Id"].ToString(),
                                Cell_Company_Name = rdr["Cell_Company_Name"].ToString(),
                            };

                            lstDevices.Add(im);
                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting cell company info.");

            }

            return lstDevices;
        }
        [HttpGet]
        [Route("api/get_cell_companies_for_company")]
        public List<CellCompany> GetCellCompaniesForCompany(string Company_Id)
        {
            List<CellCompany> lstDevices = new List<CellCompany>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Cell_Companies_For_Company"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            CellCompany im = new CellCompany()
                            {
                                Cell_Company_Id = rdr["Cell_Company_Id"].ToString(),
                                Cell_Company_Name = rdr["Cell_Company_Name"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString(),
                                Company_Id = rdr["Company_Id"].ToString(),
                                Contact_Name = rdr["Contact_Name"].ToString(),
                                Contact_Email = rdr["Contact_Email"].ToString(),
                                Cell_Company_Phone_Number = rdr["Cell_Company_Phone_Number"].ToString(),
                                Cell_Company_IsEnabled = bool.Parse(rdr["Cell_Company_IsEnabled"].ToString()),
                            };

                            lstDevices.Add(im);
                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting cell company info.");

            }

            return lstDevices;
        }

        [HttpGet]
        [Route("api/get_cell_plans")]
        public List<CellPlan> GetCellPlans()
        {
            List<CellPlan> lstDevices = new List<CellPlan>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_All_Cell_Plans"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            bool hasVoice = false;
                            string val = rdr["Cell_Plan_Has_Voice"].ToString();
                            if (val == null || val == "0" || val == "" || val == "False")
                            {
                                hasVoice = false;
                            }
                            else
                            {
                                hasVoice = true;
                            }

                            CellPlan im = new CellPlan()
                            {

                                Cell_Plan_Company_Id = rdr["Cell_Plan_Company_Id"].ToString(),
                                Cell_Plan_Data = rdr["Cell_Plan_Data"].ToString(),
                                Cell_Plan_Id = rdr["Cell_Plan_Id"].ToString(),
                                Cell_Plan_Name = rdr["Cell_Plan_Name"].ToString(),
                                Cell_Plan_Has_Voice = hasVoice,
                                Cell_Plan_Price = rdr["Cell_Plan_Price"].ToString(),
                                Cell_Plan_IsEnabled = bool.Parse(rdr["Cell_Plan_IsEnabled"].ToString())

                            };

                            lstDevices.Add(im);
                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting cell plans info.");

            }

            return lstDevices;
        }


        
        [HttpGet]
        [Route("api/get_cell_plans_for_cell_company")]
        public List<CellPlan> GetCellPlansForCompany(String Cell_Company_Id)
        {
            List<CellPlan> lstDevices = new List<CellPlan>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_get_cell_plans_for_cell_company"
                    };
                    cmd.Parameters.Add("@Cell_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Cell_Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            bool hasVoice = false;

                            string val = rdr["Cell_Plan_Has_Voice"].ToString();
                            if (val == null || val == "0" || val == "" || val == "False")
                            {
                                hasVoice = false;
                            }
                            else
                            {
                                hasVoice = true;
                            }

                            CellPlan im = new CellPlan()
                            {
                                Cell_Plan_Id = rdr["Cell_Plan_Id"].ToString(),
                                Cell_Plan_Name = rdr["Cell_Plan_Name"].ToString(),
                                Cell_Plan_Company_Id = rdr["Cell_Plan_Company_Id"].ToString(),
                                Cell_Plan_Data = rdr["Cell_Plan_Data"].ToString(),
                                Cell_Plan_Has_Voice = hasVoice,
                                Cell_Plan_Price = rdr["Cell_Plan_Price"].ToString(),
                                Cell_Plan_IsEnabled = bool.Parse(rdr["Cell_Plan_IsEnabled"].ToString())

                            };

                            lstDevices.Add(im);
                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting cell plans info.");

            }

            return lstDevices;
        }
        [HttpGet]
        [Route("api/get_trucks")]
        public List<Truck> GetTrucks(string Company_Id)
        {
            List<Truck> lstTruck = new List<Truck>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Trucks_For_Company"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Truck loc = new Truck()
                            {
                                Truck_Id = rdr["Truck_Id"].ToString(),
                                Truck_Name = rdr["Truck_Name"].ToString(),
                                Truck_Make = rdr["Make"].ToString(),
                                Truck_Model = rdr["Model"].ToString(),
                                Truck_Year = rdr["Year"].ToString(),
                                Truck_Vin_Number = rdr["Vin_Number"].ToString(),
                                Truck_Serial_Number = rdr["Serial_Number"].ToString(),
                                Truck_License_Plate = rdr["License_Plate"].ToString(),
                                Truck_Samsara_Serial = rdr["Samsara_Serial"].ToString(),
                                Truck_Samsara_Vin = rdr["Samsara_Vin"].ToString(),
                                Truck_TM_Name = rdr["TM_Name"].ToString(),
                                Truck_TM_Serial = rdr["TM_Serial"].ToString(),
                                Truck_TM_Vin = rdr["TM_Vin"].ToString(),
                                Truck_IsEnabled=bool.Parse(rdr["Truck_IsEnabled"].ToString()),
                                Truck_Driver_User_Id = rdr["User_Id"].ToString(),
                                Truck_Driver_Firstname = rdr["Firstname"].ToString(),
                                Truck_Driver_Lastname = rdr["Lastname"].ToString(),
                                Truck_Driver_Device_Id = rdr["Driver_Device_Id"].ToString(),
                                Truck_Driver_Id = rdr["Driver_Id"].ToString(),
                                Company_Name = rdr["Company_Name"].ToString(),

                            };

                            lstTruck.Add(loc);
                        }
                    }
                    rdr.Close();
                    con.Close();

                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }

            return lstTruck;
        }
        [HttpGet]
        [Route("api/get_available_trucks")]
        public List<Truck> GetAvailableTrucks(string Company_Id)
        {
            List<Truck> lstTruck = new List<Truck>();
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Available_Trucks"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Truck loc = new Truck()
                            {
                                Truck_Id = rdr["Truck_Id"].ToString(),
                                Truck_Name = rdr["Truck_Name"].ToString(),
                                Truck_Make = rdr["Make"].ToString(),
                                Truck_Model = rdr["Model"].ToString(),
                                Truck_Year = rdr["Year"].ToString(),
                                Truck_Vin_Number = rdr["Vin_Number"].ToString(),
                                Truck_Serial_Number = rdr["Serial_Number"].ToString(),
                                Truck_License_Plate = rdr["License_Plate"].ToString(),
                                Truck_Samsara_Serial = rdr["Samsara_Serial"].ToString(),
                                Truck_Samsara_Vin = rdr["Samsara_Vin"].ToString(),
                                Truck_TM_Name = rdr["TM_Name"].ToString(),
                                Truck_TM_Serial = rdr["TM_Serial"].ToString(),
                                Truck_TM_Vin = rdr["TM_Vin"].ToString(),
                            };

                            lstTruck.Add(loc);
                        }
                    }
                    rdr.Close();

                    con.Close();

                }

            }
            catch
            {
                throw new Exception("Error getting device info.");

            }

            return lstTruck;
        }
        [HttpGet]
        [Route("api/get_trucks_list")]
        public List<Truck> GetTrucksList()
        {
             List<Truck> lstOfTrucks = new List<Truck>();

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_TruckList"
                    };
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Truck drv = new Truck()
                            {
                                Truck_Name = rdr["UNIT_ID"].ToString(),
                                Truck_License_Plate = rdr["PLATE"].ToString(),
                                Truck_Make = rdr["Make"].ToString(),
                                Truck_Model = rdr["Model"].ToString(),
                                Truck_Year = rdr["Year"].ToString(),
                                Truck_Serial_Number = rdr["SERIALNUM"].ToString(),
                                Truck_Vin_Number = rdr["VIN"].ToString()
                            };
                            lstOfTrucks.Add(drv);


                        }
                    }
                    rdr.Close();
                    con.Close();

                }

                return lstOfTrucks;
            }
            catch
            {
                throw new Exception("Error getting driver info");

            }

        }

        [HttpPost]
        [Route("api/create_device")]
        public async Task<IActionResult> CreateDevice(Device dev)
        {
            var Device_Status = "";

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                    };
                    cmd.CommandText = "p_Check_Device_Exist";
                    cmd.Parameters.Add("@Serial_Number", SqlDbType.NVarChar, 50).Value = dev.Device_Serial_Number;
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(dev.Company_Id);

                    con.Open();
                    
                   
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                          Device_Status = rdr["Device_Status"].ToString();
                        }
                    }
                    rdr.Close();

                    if (Device_Status == "Not-Existed")
                    {

                        cmd.Parameters.Clear();
                        cmd.CommandText = "p_Create_Device";

                        cmd.Parameters.Add("@Device_Model", SqlDbType.NVarChar, 50).Value = dev.Device_Model;
                        cmd.Parameters.Add("@Device_Model_Year", SqlDbType.NVarChar, 50).Value = dev.Device_Model_Year;
                        cmd.Parameters.Add("@Device_Company", SqlDbType.NVarChar, 50).Value = dev.Device_Company;
                        cmd.Parameters.Add("@Device_Serial_Number", SqlDbType.NVarChar, 50).Value = dev.Device_Serial_Number;
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(dev.Company_Id);


                        //con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        return Ok(Device_Status);
                    }
                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error creating device.");

            }

            return Ok(Device_Status);

        }

        [HttpPost]
        [Route("api/update_device")]
        public void UpdateDevice(Device dev)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Device"
                    };
                    if (dev.Device_IMEI_Id == "" || dev.Device_IMEI_Id == null)
                    {
                        dev.Device_IMEI_Id = Guid.Empty.ToString();
                    }

                    cmd.Parameters.Add("@Device_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(dev.Device_Id);
                    cmd.Parameters.Add("@Device_IMEI_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(dev.Device_IMEI_Id);
                    cmd.Parameters.Add("@Device_Model", SqlDbType.NVarChar, 50).Value = dev.Device_Model;
                    cmd.Parameters.Add("@Device_Model_Year", SqlDbType.NVarChar, 50).Value = dev.Device_Model_Year;
                    cmd.Parameters.Add("@Device_Company", SqlDbType.NVarChar, 50).Value = dev.Device_Company;
                    cmd.Parameters.Add("@Device_Serial_Number", SqlDbType.NVarChar, 50).Value = dev.Device_Serial_Number;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating device.");

            }


        }

        [HttpPost]
        [Route("api/enable_disable_device")]
        public void EnableDisableDevice(Device dev)
        {

/*            Console.WriteLine(dev.Device_Id);
*/            

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_Disable_Device"
                    };

                    
                    cmd.Parameters.Add("@Driver_Device_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(dev.Device_Id);
                    cmd.Parameters.Add("@Driver_Device_IsEnabled", SqlDbType.Bit).Value = (dev.Driver_Device_IsEnabled);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating device.");

            }


        }


        

        [HttpPost]
        [Route("api/create_imei")]
        public async Task<IActionResult> CreateImei(Imei im)
        {
            var Imei_Status = "";

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                    };
                    cmd.CommandText = "p_Check_Device_Imei_Exist";
                    cmd.Parameters.Add("@Device_IMEI_Number", SqlDbType.NVarChar, 50).Value = im.Device_IMEI_Number;
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Device_IMEI_Company_Id);

                    con.Open();


                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Imei_Status = rdr["Imei_Status"].ToString();
                        }
                    }
                    rdr.Close();

                    if (Imei_Status == "Not-Existed")
                    {
                        cmd.Parameters.Clear();
                        cmd.CommandText = "p_Create_Imei";
                        cmd.Parameters.Add("@Device_IMEI_Number", SqlDbType.NVarChar, 50).Value = im.Device_IMEI_Number;
                        cmd.Parameters.Add("@Phone_Number", SqlDbType.NVarChar, 50).Value = im.Phone_Number;
                        cmd.Parameters.Add("@Cell_Company", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Cell_Company);
                        cmd.Parameters.Add("@Cell_Plan", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Cell_Plan);
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Device_IMEI_Company_Id);
                        cmd.ExecuteNonQuery();

                    }
                    else
                    {
                        return Ok(Imei_Status);
                    }
                    //con.Open();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error creating imei.");

            }

            return Ok(Imei_Status);
        }
        [HttpPost]
        [Route("api/update_imei")]
        public void UpdateImei(Imei im)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Imei"
                    };
                  
              
                    cmd.Parameters.Add("@Device_IMEI_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Device_IMEI_Id);
                    cmd.Parameters.Add("@Device_IMEI_Number", SqlDbType.NVarChar, 50).Value = im.Device_IMEI_Number;
                    cmd.Parameters.Add("@Phone_Number", SqlDbType.NVarChar, 50).Value = im.Phone_Number;
                    cmd.Parameters.Add("@Cell_Company", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Cell_Company);
                    cmd.Parameters.Add("@Cell_Plan", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Cell_Plan);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error creating imei.");

            }


        }

        [HttpPost]
        [Route("api/enable_disable_device_imei")]
        public void EnableDisableDeviceIMEI(Imei im )
        {

            /*            Console.WriteLine(dev.Device_Id);
            */

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_Disable_Device_IMEI"
                    };


                    cmd.Parameters.Add("@Device_IMEI_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(im.Device_IMEI_Id);
                    cmd.Parameters.Add("@Device_IMEI_IsEnabled", SqlDbType.Bit).Value = (im.Device_IMEI_IsEnabled);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating Truck.");

            }


        }



        [HttpPost]
        [Route("api/update_truck")]
        public void UpdateTruck(Truck truck)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Truck"
                    };

                    cmd.Parameters.Add("@Truck_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(truck.Truck_Id);
                    cmd.Parameters.Add("@Truck_Name", SqlDbType.NVarChar, 50).Value = truck.Truck_Name;
                    cmd.Parameters.Add("@Truck_Make", SqlDbType.NVarChar, 50).Value = truck.Truck_Make;
                    cmd.Parameters.Add("@Truck_Model", SqlDbType.NVarChar, 50).Value = truck.Truck_Model;
                    cmd.Parameters.Add("@Truck_Year", SqlDbType.NVarChar, 50).Value = truck.Truck_Year;
                    cmd.Parameters.Add("@Truck_Serial_Number", SqlDbType.NVarChar, 50).Value = truck.Truck_Serial_Number;
                    cmd.Parameters.Add("@Truck_License_Plate", SqlDbType.NVarChar, 50).Value = truck.Truck_License_Plate;


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating truck.");

            }


        }
        [HttpPost]
        [Route("api/create_truck")]
        public void CreateTruck(Truck truck)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_Truck"
                    };

                    cmd.Parameters.Add("@Truck_Name", SqlDbType.NVarChar, 50).Value = truck.Truck_Name;
                    cmd.Parameters.Add("@Truck_Make", SqlDbType.NVarChar, 50).Value = truck.Truck_Make;
                    cmd.Parameters.Add("@Truck_Model", SqlDbType.NVarChar, 50).Value = truck.Truck_Model;
                    cmd.Parameters.Add("@Truck_Year", SqlDbType.NVarChar, 50).Value = truck.Truck_Year;
                    cmd.Parameters.Add("@Truck_Serial_Number", SqlDbType.NVarChar, 50).Value = truck.Truck_Serial_Number;
                    cmd.Parameters.Add("@Truck_License_Plate", SqlDbType.NVarChar, 50).Value = truck.Truck_License_Plate;
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(truck.Company_Id);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }


        }
        [HttpPost]
        [Route("api/enable_disable_truck")]
        public void EnableDisableTruck(Truck dev)
        {

            /*            Console.WriteLine(dev.Device_Id);
            */

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {


                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_Disable_Truck"
                    };


                    cmd.Parameters.Add("@Truck_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(dev.Truck_Id);
                    cmd.Parameters.Add("@Truck_IsEnabled", SqlDbType.Bit).Value = (dev.Truck_IsEnabled);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating Truck.");

            }


        }

        [HttpPost]
        [Route("api/create_cell_company")]
        public void CreateCellCompany(CellCompany Cc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_Cell_Company"
                    };
                    cmd.Parameters.Add("@Cell_Company_Name", SqlDbType.NVarChar, 50).Value = Cc.Cell_Company_Name;
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Cc.Company_Id);
                    cmd.Parameters.Add("@Contact_Name", SqlDbType.NVarChar, 50).Value = Cc.Contact_Name;
                    cmd.Parameters.Add("@Contact_Email", SqlDbType.NVarChar, 50).Value = Cc.Contact_Email;
                    cmd.Parameters.Add("@Cell_Company_Phone_Number", SqlDbType.NVarChar, 50).Value = Cc.Cell_Company_Phone_Number;


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error creating cell company.");

            }


        }
        [HttpPost]
        [Route("api/update_cell_company")]
        public void UpdateCellCompany(CellCompany Cc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Cell_Company"
                    };
                    cmd.Parameters.Add("@Cell_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Cc.Cell_Company_Id);
                    cmd.Parameters.Add("@Contact_Name", SqlDbType.NVarChar, 50).Value = Cc.Contact_Name;
                    cmd.Parameters.Add("@Contact_Email", SqlDbType.NVarChar, 50).Value = Cc.Contact_Email;
                    cmd.Parameters.Add("@Cell_Company_Phone_Number", SqlDbType.NVarChar, 50).Value = Cc.Cell_Company_Phone_Number;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating cell company.");

            }


        }
        [HttpPost]
        [Route("api/enable_disable_cell_company")]
        public void EnableDisableCellCompany(CellCompany Cc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_Disable_Cell_Company"
                    };
                    /*                    Cell_Company_IsEnabled = bool.Parse(rdr["Cell_Company_IsEnabled"].ToString()),
                    */
                    cmd.Parameters.Add("@Cell_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Cc.Cell_Company_Id);
                    cmd.Parameters.Add("@Cell_Company_IsEnabled", SqlDbType.Bit).Value = (Cc.Cell_Company_IsEnabled);

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error Cell Company.");
            }



        }

        [HttpPost]
        [Route("api/create_cell_plan")]
        public void CreateCellPlan(CellPlan Cc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Create_Cell_Plan"
                    };
                    cmd.Parameters.Add("@Cell_Plan_Name", SqlDbType.NVarChar, 10).Value = Cc.Cell_Plan_Name;
                    cmd.Parameters.Add("@Cell_Plan_Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Cc.Cell_Plan_Company_Id);
                    cmd.Parameters.Add("@Cell_Plan_Data", SqlDbType.NVarChar, 10).Value = Cc.Cell_Plan_Data;
                    cmd.Parameters.Add("@Cell_Plan_Has_Voice", SqlDbType.Bit).Value = Cc.Cell_Plan_Has_Voice;
                    cmd.Parameters.Add("@Cell_Plan_Price", SqlDbType.NVarChar, 30).Value = Cc.Cell_Plan_Price;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error creating cell company.");

            }


        }
        [HttpPost]
        [Route("api/update_cell_plan")]
        public void UpdateCellPlan(CellPlan Cc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Cell_Plan"
                    };
                    cmd.Parameters.Add("@Cell_Plan_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Cc.Cell_Plan_Id);
                    cmd.Parameters.Add("@Cell_Plan_Name", SqlDbType.NVarChar, 10).Value = Cc.Cell_Plan_Name;
                    cmd.Parameters.Add("@Cell_Plan_Data", SqlDbType.NVarChar, 10).Value = Cc.Cell_Plan_Data;
                    cmd.Parameters.Add("@Cell_Plan_Has_Voice", SqlDbType.Bit).Value = Cc.Cell_Plan_Has_Voice;
                    cmd.Parameters.Add("@Cell_Plan_Price", SqlDbType.NVarChar, 30).Value = Cc.Cell_Plan_Price;


                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error updating cell company.");

            }


        }

        [HttpPost]
        [Route("api/enable_disable_cell_plan")]
        public void EnableDisableCellPlan(CellPlan Cc)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Enable_Disable_Cell_Plan"
                    };
                 
                    cmd.Parameters.Add("@Cell_Plan_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Cc.Cell_Plan_Id);
                    cmd.Parameters.Add("@Cell_Plan_IsEnabled", SqlDbType.Bit).Value = Cc.Cell_Plan_IsEnabled;

                    con.Open();
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch
            {
                throw new Exception("Error Cell Company.");
            }

        }

        
    }


}
