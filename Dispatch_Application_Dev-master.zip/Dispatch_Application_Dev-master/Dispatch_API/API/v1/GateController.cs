﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Api.Data.Entity;
using Driver_Api.Data.Entity;
using Driver_Api.Data.Entity.ActionModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Dispatch_Api.Data.Entity;
using SoapHttpClient;
using System.Xml.Linq;
using SoapHttpClient.Enums;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;

namespace Api.API.v1
{
    [ApiController]
    [Authorize]
    public class GateController : Controller
    {
        private static readonly HttpClient client = new HttpClient();


        [HttpGet]
        [Route("api/get_lineup_info")]
        public List<LineupList> GetLineupInfo(string Company_Id)
        {
            List<LineupList> lineupList = new List<LineupList>();

            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Lineup_Info"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            LineupList Dr = new LineupList()
                            {
                                Gate_Id = rdr["Gate_Id"].ToString(),
                                Container_Number = Convert.ToString(rdr["Container_Number"]),
                                Carrier_Name  = Convert.ToString(rdr["Carrier_Name"]),
                                Driver_Number = Convert.ToString(rdr["Driver_Number"]),
                                License_Plate = Convert.ToString(rdr["License_Plate"]),
                                Pickup_Number = Convert.ToString(rdr["Pickup_Number"]),
                                Gate_Status   = Convert.ToString(rdr["Gate_Status"]),
                                Lane_Position = Convert.ToString(rdr["Lane_Position"]),
                                Driver_Job_Status =  Convert.ToString(rdr["Driver_Job_Status"]),
                            };
                            lineupList.Add(Dr);

                        }
                    }


                    rdr.Close();
                    con.Close();

                }

            }
            catch (Exception Ex)
            {
                //throw new Exception("Error retrieving driver info.");
                Console.WriteLine(Ex.Message);
            }

            return lineupList;
        }
        [HttpGet]
        [Route("api/get_ingate_list")]
        public List<InGateList> GetIngateList(string Company_Id)
        {
            List<InGateList> IngateList = new List<InGateList>();

            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_InGate_List"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            InGateList Dr = new InGateList()
                            {
                                Gate_Id = rdr["Gate_Id"].ToString(),
                                Carrier_Name = rdr["Carrier_Name"].ToString(),
                                Driver_Number = rdr["Driver_Number"].ToString(),
                                Gate_Status = rdr["Gate_Status"].ToString(),
                                Lane_Position = rdr["Lane_Position"].ToString(),
                                Acknowledge_Status = Convert.ToBoolean( rdr["Acknowledge_Status"]),
                                Yard_Location = Convert.ToString(rdr["Yard_Location"]),
                                Driver_Job_Status = Convert.ToString(rdr["Driver_Job_Status"]),
                                Container_Status = Convert.ToString(rdr["Container_Status"]),
                                Container_Number = Convert.ToString(rdr["Container_Number"])
                                
                            };
                            IngateList.Add(Dr);

                        }
                    }


                    rdr.Close();
                    con.Close();

                }

            }
            catch (Exception Ex)
            {
                //throw new Exception("Error retrieving driver info.");
                Console.WriteLine(Ex.Message);
            }

            return IngateList;
        }
        [HttpGet]
        [Route("api/get_outgate_list")]
        public List<OutGateList> GetOutGateList(string Company_Id)
        {
            List<OutGateList> outgateList = new List<OutGateList>();

            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_OutGate_List"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            OutGateList Dr = new OutGateList()
                            {
                                Gate_Id = Convert.ToString(rdr["Gate_Id"]),
                                Carrier_Name = Convert.ToString(rdr["Carrier_Name"]),
                                Driver_Number = Convert.ToString(rdr["Driver_Number"]),
                                Container_Number = Convert.ToString(rdr["Container_Number"]),
                                Pickup_Number = Convert.ToString(rdr["Pickup_Number"]),
                                Gate_Status = Convert.ToString(rdr["Gate_Status"]),
                                Container_Status = Convert.ToString(rdr["Container_Status"]),
                                Driver_Job_Status = Convert.ToString(rdr["Driver_Job_Status"]),
                                Gate_Driver_Status = Convert.ToString(rdr["Gate_Driver_Status"])


                            };
                            outgateList.Add(Dr);

                        }
                    }


                    rdr.Close();
                    con.Close();

                }

            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

            return outgateList;
        }
        [HttpGet]
        [Route("api/get_gate_info")]
        public List<GateInfo> GetGateInfo(string Company_Id)
        {
            List<GateInfo> GateList = new List<GateInfo>();

            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Gate_Info"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            GateInfo Dr = new GateInfo()
                            {
                                Gate_Id            = Convert.ToString(rdr["Gate_Id"]),
                                Container_Number   = Convert.ToString(rdr["Container_Number"]),
                                Carrier_Name       = Convert.ToString(rdr["Carrier_Name"]),
                                Driver_Number      = Convert.ToString(rdr["Driver_Number"]),
                                License_Plate      = Convert.ToString(rdr["License_Plate"]),
                                Pickup_Number      = Convert.ToString(rdr["Pickup_Number"]),
                                Gate_Status        = Convert.ToString(rdr["Gate_Status"]),
                                Container_Status   = Convert.ToString(rdr["Container_Status"]),
                                Lane_Position      = Convert.ToString(rdr["Lane_Position"]),
                                Acknowledge_Status = Convert.ToString(rdr["Acknowledge_Status"]),
                                Driver_Job_Status  = Convert.ToString(rdr["Driver_Job_Status"]),
                                Lineup_DateTime    = DateTime.Parse(rdr["Lineup_DateTime"].ToString()),


                            };
                            GateList.Add(Dr);

                        }
                    }
                    rdr.Close();
                    con.Close();

                }

            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

            return GateList;
        }
        [HttpGet]
        [Route("api/get_lane_position")]
        public List<LanePosition> GetLanePositions(string Company_Id)
        {
            List<LanePosition> GateList = new List<LanePosition>();

            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Lane_Positions"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);

                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            LanePosition Dr = new LanePosition()
                            {
                                Lane_Id = rdr["Lane_Id"].ToString(),
                                Lane_Name = rdr["Lane_Name"].ToString(),
                                Position_Id = rdr["Position_Id"].ToString(),
                                Position_Number = rdr["Position_Number"].ToString(),
                               
                            };
                            GateList.Add(Dr);

                        }
                    }
                    rdr.Close();
                    con.Close();

                }

            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

            return GateList;
        }
        [HttpGet]
        [Route("api/get_gate_driver_info")]
        public List<GateDriver> GetGateDriverInfo(string Company_Id)
        {
            var DriverList = new List<GateDriver>();

            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Get_Gate_Driver_Info"
                    };
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(Company_Id);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            var Driver = new GateDriver()
                            {
                                Chat_Id    = rdr["Chat_Id"].ToString(),
                                Chat_Name  = rdr["Chat_Name"].ToString(),
                                Chat_Table = rdr["Chat_Table"].ToString(),
                                Role_Id    = rdr["Driver_Role"].ToString()

                            };
                            DriverList.Add(Driver);

                    }
                    }
                    rdr.Close();
                    con.Close();

                }

            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

            return DriverList;
        }
        [HttpPost]
        [Route("api/driver_add_lineupinfo")]
        public async Task driver_AddLineupInfo(LineupForm lineup)
        {
            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                    };
                    con.Open();

                    cmd.CommandText = "p_Add_Lineup_Info";
                    cmd.Parameters.Add("@Container_Number", SqlDbType.NVarChar).Value = lineup.Container_Number;
                    cmd.Parameters.Add("@Container_Size", SqlDbType.NVarChar).Value   = lineup.Container_Size;
                    cmd.Parameters.Add("@Carrier_Name", SqlDbType.NVarChar).Value     = lineup.Carrier_Name;
                    cmd.Parameters.Add("@Driver_Number", SqlDbType.NVarChar).Value    = lineup.Driver_Number;
                    cmd.Parameters.Add("@License_Plate", SqlDbType.NVarChar).Value    = lineup.License_Plate;
                    cmd.Parameters.Add("@Pickup_Number", SqlDbType.NVarChar).Value    = lineup.Pickup_Number;
                    cmd.Parameters.Add("@Gate_In_By", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lineup.In_Gate_By);
                    cmd.Parameters.Add("@Status", SqlDbType.NVarChar).Value           = lineup.Waitime_Status;
                    cmd.Parameters.Add("@p_Container_Number", SqlDbType.NVarChar).Value = lineup.p_Container_Number;
                    cmd.Parameters.Add("@p_Container_Size", SqlDbType.NVarChar).Value   = lineup.p_Container_Size;
                    cmd.Parameters.Add("@p_Pickup_Number", SqlDbType.NVarChar).Value    = lineup.p_Pickup_Number;
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lineup.Company_Id);
                    cmd.ExecuteNonQuery();




                    con.Close();

                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            
            }

        }
        [HttpPost]
        [Route("api/update_gate_status")]
        public void UpdateGateStatus(Dictionary<string, string> lu_info)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Gate_Status"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.ExecuteNonQuery();

                    con.Close();

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        [HttpPost]
        [Route("api/assign_lane_position")]
        public void AssignLanePosition(Dictionary<string, string> lu_info)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Assign_Lane_Position"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.Parameters.Add("@Position_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Position_Id"]);
                    
                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        [HttpPost]
        [Route("api/assign_yard_location")]
        public void AssignYardLocation(Dictionary<string, string> lu_info)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Assign_Yard_Location"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.Parameters.Add("@Location", SqlDbType.NVarChar).Value = lu_info["Location"];

                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [HttpPost]
        [Route("api/acknowledge_driver_position")]
        public void AcknowledgeDriverPosition(Dictionary<string, string> lu_info)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Acknowledge_Driver_Position"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.Parameters.Add("@Seal", SqlDbType.NVarChar).Value = lu_info["Seal"];
                    cmd.Parameters.Add("@Gate_In_By", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Gate_In_By"]);

                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [HttpPost]
        [Route("api/update_ingate_status")]
        public void UpdateInGateStatus(Dictionary<string, string> lu_info)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_InGate_Status"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.Parameters.Add("@Gate_In_By", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Gate_In_By"]);

                    cmd.ExecuteNonQuery();

                    con.Close();

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        [HttpPost]
        [Route("api/update_outgate_status")]
        public void UpdateOutGateStatus(Dictionary<string, string> lu_info)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_OutGate_Status"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.Parameters.Add("@Gate_Out_By", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Gate_Out_By"]);

                    cmd.ExecuteNonQuery();

                    con.Close();

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [HttpPost]
        [Route("api/update_extra_container_pickup")]
        public void UpdateExtraContainerPickup(Dictionary<string, string> lu_info)
        {
           
            try
            {

                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                    };
                    con.Open();

                    cmd.CommandText = "p_Update_Extra_Container_Pickup";
                    cmd.Parameters.Add("@Container_Number", SqlDbType.NVarChar).Value = lu_info["Container_Number"];
                    cmd.Parameters.Add("@Container_Size", SqlDbType.NVarChar).Value   = lu_info["Container_Size"];
                    cmd.Parameters.Add("@Pickup_Number", SqlDbType.NVarChar).Value    = lu_info["Pickup_Number"];
                    cmd.Parameters.Add("@Gate_Out_By", SqlDbType.UniqueIdentifier).Value      = Guid.Parse(lu_info["Gate_Out_By"]);
                    cmd.Parameters.Add("@Dropped_Gate_Id", SqlDbType.UniqueIdentifier).Value  = Guid.Parse(lu_info["Dropped_Gate_Id"]);
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            
            }

        }

        [HttpPost]
        [Route("api/delete_lineup_driver")]
        public void DeleteLineupDriver(Dictionary<string, string> lu_info)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Delete_Lineup_Driver"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Gate_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Gate_Id"]);
                    cmd.Parameters.Add("@Removed_By", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Removed_By"]);
                    cmd.Parameters.Add("@Reason", SqlDbType.NVarChar).Value = lu_info["Reason"];
                    cmd.Parameters.Add("@Gate_Status", SqlDbType.NVarChar).Value = lu_info["Gate_Status"];
                    cmd.Parameters.Add("@Container_Status", SqlDbType.NVarChar).Value = lu_info["Container_Status"];
                    cmd.Parameters.Add("@Container_Number", SqlDbType.NVarChar).Value = lu_info["Container_Number"];
                    cmd.ExecuteNonQuery();

                    con.Close();

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [HttpPost]
        [Route("api/update_pickup_number")]
        public void UpdatePickuupNumber(Dictionary<string, string> lu_info)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Pickup_Number"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Gate_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Gate_Id"]);
                    cmd.Parameters.Add("@Container_Status", SqlDbType.NVarChar).Value = lu_info["Container_Status"];
                    cmd.Parameters.Add("@Container_Number", SqlDbType.NVarChar).Value = lu_info["Container_Number"];
                    cmd.Parameters.Add("@Pickup_Number", SqlDbType.NVarChar).Value = lu_info["Pickup_Number"];
                    cmd.ExecuteNonQuery();

                    con.Close();

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [HttpPost]
        [Route("api/update_container_number")]
        public void UpdateContainerNumber(Dictionary<string, string> lu_info)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Update_Container_Number"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Gate_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Gate_Id"]);
                    cmd.Parameters.Add("@Container_Status", SqlDbType.NVarChar).Value = lu_info["Container_Status"];
                    cmd.Parameters.Add("@Old_Container_Number", SqlDbType.NVarChar).Value = lu_info["Old_Container_Number"];
                    cmd.Parameters.Add("@Container_Number", SqlDbType.NVarChar).Value = lu_info["Container_Number"];
                    cmd.ExecuteNonQuery();

                    con.Close();

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        [HttpPost]
        [Route("api/acknowledge_outgate_driver")]
        public void AcknowledgeOutgateDriver(Dictionary<string, string> lu_info)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Acknowledge_Outgate_Driver"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.Parameters.Add("@Seal", SqlDbType.NVarChar).Value = lu_info["Seal"];
                    cmd.Parameters.Add("@Gate_Out_By", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lu_info["Gate_Out_By"]);

                    cmd.ExecuteNonQuery();

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        [HttpPost]
        [Route("api/send_driver_out")]
        public void Send_Driver_Out(Dictionary<string, string> lu_info)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Send_Driver_Out"
                    };
                    con.Open();
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@Driver", SqlDbType.NVarChar).Value = lu_info["Driver"];
                    cmd.Parameters.Add("@Carrier", SqlDbType.NVarChar).Value = lu_info["Carrier"];
                    cmd.Parameters.Add("@Driver_Job_Status", SqlDbType.NVarChar).Value = lu_info["Driver_Job_Status"];
                    cmd.Parameters.Add("@Status", SqlDbType.NVarChar).Value = lu_info["Status"];
                    cmd.ExecuteNonQuery();

                    con.Close();

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        [HttpPost]
        [Route("api/add_pickup_container")]
        public async Task AddPickupContainer(Dictionary<string,string> lineup)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                    };
                    con.Open();

                    cmd.CommandText = "p_Add_Pickup_Container";
                    cmd.Parameters.Add("@Gate_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lineup["Gate_Id"]);
                    cmd.Parameters.Add("@Container_Number", SqlDbType.NVarChar).Value = lineup["Container_Number"];
                    cmd.Parameters.Add("@Container_Size", SqlDbType.NVarChar).Value = lineup["Container_Size"];
                    cmd.Parameters.Add("@Carrier_Name", SqlDbType.NVarChar).Value = lineup["Carrier_Name"];
                    cmd.Parameters.Add("@Driver_Number", SqlDbType.NVarChar).Value = lineup["Driver_Number"];
                    cmd.Parameters.Add("@Pickup_Number", SqlDbType.NVarChar).Value = lineup["Pickup_Number"];
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(lineup["Company_Id"]);
                    cmd.ExecuteNonQuery();

                    con.Close();

                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);

            }

        }

    }
}
