﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Markup;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MimeKit;
using Renci.SshNet;

namespace Resource.Api.Controllers
{
    public class Mail
    {

        public string Subject { get; set; }
        public string Message { get; set; }
        public List<string> Email { get; set; }
        public string Request { get; set; }
        public List<string> Attachments {get; set;}
        public string Signature { get; set; }

    }



    [Produces("application/json")]
    public class EmailController : Controller
    {
        private readonly IConfiguration config;
        public EmailController(IConfiguration configuration)
        {
            config = configuration;
        }

        [Route("api/sendMail")]
        [HttpPost]
        [AllowAnonymous]
        public IActionResult sendMail([FromBody] Mail email)
        {
            
            string username = config.GetSection("DriverImagesEmail").GetSection("SmtpUsername").Value;
            string smtpserver = config.GetSection("DriverImagesEmail").GetSection("SmtpServer").Value;
            string smtpassword = config.GetSection("DriverImagesEmail").GetSection("SmtpPassword").Value;
            using (var client = new SftpClient("mobilestorage.pauls.ca", port: 22, "dispatch_user", "_)$a8gF3TC"))
            {
                client.Connect();

                if (true)
                {
                    InternetAddressList list = new InternetAddressList();
                    foreach (var emailaddress in email.Email)
                    {
                        list.Add(new MailboxAddress(emailaddress, emailaddress));
                    }

                    var mimeMessage = new MimeMessage();
                    mimeMessage.From.Add(new MailboxAddress(username, username));
                    mimeMessage.To.AddRange(list);
                    mimeMessage.Subject = email.Subject;

                    var builder = new BodyBuilder();
                    builder.HtmlBody = string.Format(@"" + email.Message + "</br></br>" + email.Signature);


                    foreach (var sftpFilePath in email.Attachments)
                    {
                        using (var stream = new MemoryStream())
                        {
                            // Download the file from SFTP server to memory stream
                            client.DownloadFile(sftpFilePath, stream);

                            // Rewind the stream to the beginning before attaching it
                            stream.Position = 0;

                            // Attach the image to the email builder
                            builder.Attachments.Add(Path.GetFileName(sftpFilePath), stream);
                        }
                        //builder.Attachments.Add(image);

                    }

                    mimeMessage.Body = builder.ToMessageBody();

                    using (SmtpClient smtpClient = new SmtpClient())
                    {
                        smtpClient.Connect(smtpserver, 587, SecureSocketOptions.StartTls);
                        smtpClient.Authenticate(username,
                        smtpassword);

                        smtpClient.Send(mimeMessage);
                        smtpClient.Disconnect(true);


                    }

                }
                client.Disconnect();

            }
            return Ok();

        }

    }
}
