﻿using Api.Contracts;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace Api.Infrastructure.Installers
{
    internal class RegisterCors : IServiceRegistration
    {
        public void RegisterAppServices(IServiceCollection services, IConfiguration config)
        {
            string forCors = Startup.FrontendString.Split(":")[0] + ":" + Startup.FrontendString.Split(":")[1];
            var uri = new Uri(Startup.FrontendString);
            var clean = uri.GetComponents(UriComponents.AbsoluteUri & ~UriComponents.Port,
                               UriFormat.UriEscaped);

            //string forCorsYard = Startup.YardApiString.Split(":")[0] + ":" + Startup.YardApiString.Split(":")[1];
            //var uriYard = new Uri(Startup.YardApiString);
            //var cleanYard = uriYard.GetComponents(UriComponents.AbsoluteUri & ~UriComponents.Port,
              //                 UriFormat.UriEscaped);


            //Configure CORS to allow any origin, header and method. 
            //Change the CORS policy based on your requirements.
            //More info see: https://docs.microsoft.com/en-us/aspnet/core/security/cors?view=aspnetcore-3.0
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                builder =>
                {
                    builder
                           .AllowAnyHeader()
                           .AllowAnyMethod()
                           .AllowCredentials()
                           //.WithOrigins(forCors, Startup.FrontendString, clean, forCorsYard, Startup.YardApiString, clean
                           
                           //);
                           .WithOrigins(forCors, Startup.FrontendString, clean);
                });
            });
        }
    }
}
