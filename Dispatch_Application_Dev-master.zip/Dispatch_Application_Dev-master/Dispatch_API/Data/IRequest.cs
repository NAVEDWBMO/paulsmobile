﻿namespace Dispatch_Application_Debug_API.Data
{
    public interface IRequest
    {
    }
}