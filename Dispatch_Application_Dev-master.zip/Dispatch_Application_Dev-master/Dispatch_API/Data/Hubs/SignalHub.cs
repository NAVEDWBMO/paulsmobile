﻿using Api;
using Dispatch_Application_Debug_API.API.v1;
using Resource.Api.Controllers;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Driver_Api.API.v1;
using Driver_Api.Data.Entity;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;

namespace Dispatch_Application_Debug_API.Data.Hubs
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class SignalHub : Hub
    {
        //static Dictionary<string, string> CurrentCon = new Dictionary<string, string>();
        private readonly ILogger<SignalHub> _logger;

        public static List<HubUser> userConnections = new List<HubUser>();
        private readonly StatusHandler _statusHandler = new StatusHandler();

        public SignalHub(ILogger<SignalHub> logger)
        {
           _logger = logger;
        }
        public override Task OnConnectedAsync()
        {

            var claims = Context.User.Claims.ToList();
            var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
            try
            {
                /* List<HubUser> itemsToRemove = new List<HubUser>();
                 foreach (HubUser hu in userConnections)
                 {
                     if (hu.User_Identity_Id == userIdClaim.Value)
                     {
                         Clients.Client(hu.Connection_Id).SendAsync("DisconnectDuplicateUser");

                         itemsToRemove.Add(hu);

                     }
                 }

                 foreach (HubUser hu in itemsToRemove)
                 {
                     Groups.RemoveFromGroupAsync(hu.Connection_Id, hu.Company_Id);
                     userConnections.Remove(hu);

                 }*/
                /*  List<HubUser> hubuserList = userConnections.ToList();
                  if (hubuserList.Count() > 0)
                  {
                      foreach (HubUser hu in hubuserList)
                      {
                          if (!String.IsNullOrWhiteSpace(hu.User_Identity_Id) && hu.User_Identity_Id == userIdClaim.Value)
                          {
                              Clients.Client(hu.Connection_Id).SendAsync("DisconnectDuplicateUser");
                              Groups.RemoveFromGroupAsync(hu.Connection_Id, hu.Company_Id);
                              userConnections.Remove(hu);

                          }
                      }
                  }*/

                if (!String.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    var User_Id = "";
                    var Company_Id = "";
                    var User_Role = "";

                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure
                        };
                        cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                        cmd.CommandText = "p_Get_Current_User_Info_Chat";

                        con.Open();

                        SqlDataReader rdr = cmd.ExecuteReader();

                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                User_Id = rdr["User_Id"].ToString();
                                Company_Id = rdr["Company_Id"].ToString();
                                User_Role = rdr["Permission_Id"].ToString();
                            }
                        }
                        rdr.Close();
                        con.Close();
                    }

                    if (User_Role.ToUpper() == "352C54B4-CBDB-406A-B0D2-9E05544198E4")
                    {
                        Console.WriteLine(Context.ConnectionId + " " + Company_Id);

                        List<HubUser> hubuserList = userConnections.ToList();
                        if (hubuserList.Count() > 0)
                        {
                            foreach (HubUser hu in hubuserList)
                            {
                                if (!String.IsNullOrWhiteSpace(hu.User_Identity_Id) && hu.User_Identity_Id == userIdClaim.Value)
                                {

                                    // Groups.RemoveFromGroupAsync(Context.ConnectionId, hu.Company_Id.ToUpper());
                                    Console.WriteLine(hu.Connection_Id);
                                    userConnections.Remove(hu);
                                }
                            }
                        }

                    }



                    Console.WriteLine(Context.ConnectionId + " " + Company_Id + " " + User_Id);

                    userConnections.Add(new HubUser() { User_Id = User_Id, Company_Id = Company_Id, User_Identity_Id = userIdClaim.Value, Connection_Id = Context.ConnectionId, User_Role = User_Role });

/*                    if (User_Role.ToUpper() == "352C54B4-CBDB-406A-B0D2-9E05544198E4")
                    {*/
                      
                    Groups.AddToGroupAsync(Context.ConnectionId, Company_Id.ToUpper());
                    //}
                    Console.WriteLine(Context.ConnectionId + " " + Company_Id);

                }
                else
                { 
                 
                 throw new Exception(Guid.Parse(userIdClaim.Value) + " user identity is empty");


                }

            }
            catch (Exception Ex)
            {
                throw new Exception(Guid.Parse(userIdClaim.Value) + " " + Ex.Message);

            }

            return base.OnConnectedAsync();
        }

         
        public override Task OnDisconnectedAsync(Exception exception)
        {
            var claims = Context.User.Claims.ToList();
            var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");
            try
            {


                /* using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                   {
                       SqlCommand cmd = new SqlCommand
                       {
                           Connection = con,
                           CommandType = System.Data.CommandType.StoredProcedure
                       };
                       cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                       cmd.Parameters.Add("@Break_Time", SqlDbType.DateTime2).Value = DateTime.Now;
                       cmd.CommandText = "p_End_Pending_Breaks";

                       con.Open();
                       cmd.ExecuteNonQuery();
                       con.Close();
                   }*/

                /*
                                List<HubUser> itemsToRemove = new List<HubUser>();

                                foreach (HubUser hu in userConnections)
                                {
                                    if (hu.Connection_Id == Context.ConnectionId)
                                    {
                                        itemsToRemove.Add(hu);
                                    }
                                }

                                foreach (HubUser hu in itemsToRemove)
                                {
                                    userConnections.Remove(hu);
                                 //   Groups.RemoveFromGroupAsync(hu.Connection_Id, hu.Company_Id);
                                }
                */
           

                if (!String.IsNullOrWhiteSpace(userIdClaim.Value))
                {
                    var User_Id = "";
                    var Company_Id = "";
                    var User_Role = "";

                    using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure
                        };
                        cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userIdClaim.Value);
                        cmd.CommandText = "p_Get_Current_User_Info_Chat";

                        con.Open();

                        SqlDataReader rdr = cmd.ExecuteReader();

                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                User_Id = rdr["User_Id"].ToString();
                                Company_Id = rdr["Company_Id"].ToString();
                                User_Role = rdr["Permission_Id"].ToString();
                            }
                        }
                        rdr.Close();
                        con.Close();
                    }


                    if (User_Role.ToUpper() != "352C54B4-CBDB-406A-B0D2-9E05544198E4") {
                        Console.WriteLine(Context.ConnectionId + " " + Company_Id);

                        List<HubUser> hubuserList = userConnections.ToList();
                        if (hubuserList.Count() > 0)
                        {
                            foreach (HubUser hu in hubuserList)
                            {
                                if (!String.IsNullOrWhiteSpace(hu.User_Identity_Id) && hu.User_Identity_Id == userIdClaim.Value)
                                {

                                    // Groups.RemoveFromGroupAsync(Context.ConnectionId, hu.Company_Id.ToUpper());
                                    Console.WriteLine(hu.Connection_Id);
                                    userConnections.Remove(hu);
                                }
                            }
                        }

                    }

                 
                }



                //HandleUserStatusChange(Guid.Parse(userIdClaim.Value), "has disconnected");

                //Clients.All.SendAsync("UpdatedUserStatus", stUp);
                /*StatusUpdateModel stUp = _statusHandler.StatusUpdateModel(userIdClaim.Value);
                stUp.Company_Id =  _statusHandler.GetCompId(userIdClaim.Value);
                stUp.Message.Message_Text = "has logged out";
                Clients.All.SendAsync("UpdatedUserStatus", stUp);

                _statusHandler.LogOutUserStatus(userIdClaim.Value);*/
            }
            catch(Exception Ex)
            {
                throw new Exception(Guid.Parse(userIdClaim.Value) + " " + Ex.Message);

            }



            return base.OnDisconnectedAsync(exception);
        }
   
           public async Task MessageToServer(MessageModel md)
           {
             try
             {
                List<HubUser> ConnectionList = userConnections.ToList();
 
                 md.Message_Date = DateTime.Now;
                 md.Message_Text = Regex.Replace(md.Message_Text, @"[\']", "\"", RegexOptions.None);

                // From_User_Id - Message_From_User_Role
                var chatlevel = 0;
                if (md.Message_From_User_Role.ToUpper() == "352C54B4-CBDB-406A-B0D2-9E05544198E4" )
                {
                    chatlevel = 2;
                    Dictionary<string,object> msg_chat_info = ChatController.SaveMessage(md, chatlevel,_logger);
                    MessageModel updMessage = (MessageModel)msg_chat_info["message"];
                    Updated_Chat_Level_Info chat_Level_Info = (Updated_Chat_Level_Info)msg_chat_info["chat_level_info"] ;
                    await Clients.All.SendAsync("SetChatLevel", md.Chat_Id, chatlevel,chat_Level_Info.User_Name,chat_Level_Info.Last_Time);

                 //   Clients.Client(md.From_User_Id).SendAsync("SendToDriver", md);

                    var Company_Id = "";
                    foreach (HubUser hu in ConnectionList)
                    {
                        if (hu.User_Id == md.From_User_Id)
                        {
                            Company_Id = hu.Company_Id;
                            break;
                        }
                    }

                   await Clients.Group(Company_Id.ToUpper()).SendAsync("SendToDispatch", md);
  
                }
                 else if (md.Message_From_User_Role.ToUpper() == "D9A95D74-F4FF-4CEC-9161-BD7368576519" || md.Message_From_User_Role.ToUpper() == "B9B77C04-830D-4393-8FBD-6EFB17B4E6B8")
                {
                    chatlevel = 2;

                    Dictionary<string, object> msg_chat_info = ChatController.SaveMessage(md, chatlevel, _logger);
                    MessageModel updMessage = (MessageModel)msg_chat_info["message"];
                    Updated_Chat_Level_Info chat_Level_Info = (Updated_Chat_Level_Info)msg_chat_info["chat_level_info"];
                   await Clients.All.SendAsync("SetChatLevel", md.Chat_Id, chatlevel, chat_Level_Info.User_Name, chat_Level_Info.Last_Time);

                    var Company_Id = "";
                    foreach (HubUser hu in ConnectionList)
                    {
                        if (hu.User_Id == md.From_User_Id)
                        {
                            Company_Id = hu.Company_Id;
                            break;
                        }
                    }

                    await Clients.Group(Company_Id.ToUpper()).SendAsync("SendToDispatch", md);


                    if (md.Message_To_Group != "Dispatch")
                    {
                        try
                        {

                            using SqlConnection con2 = new SqlConnection(Startup.DatabaseString);
                            con2.Open();
                            SqlCommand cmd2 = new SqlCommand
                            {
                                Connection = con2,
                                CommandType = System.Data.CommandType.StoredProcedure
                            };


                            _logger.Log(LogLevel.Warning, "level 2,3 chat id " + md.Chat_Id);
                            
                            cmd2.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Chat_Id);

                            cmd2.CommandText = "p_Get_Driver_Identity_Id";
                            SqlDataReader rdr = cmd2.ExecuteReader();
                            var User_Id = "";
                            if (rdr.HasRows)
                            {
                                while (rdr.Read())
                                {
                                    User_Id = rdr["User_Id"].ToString();
                                }
                            }
                            rdr.Close();
                            con2.Close();

                            foreach (HubUser entry in ConnectionList)
                            {

                                if (entry.User_Id == User_Id)
                                {
                                    await Clients.Client(entry.Connection_Id).SendAsync("SendToDriver", md);
                                    break;

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("at level 2,3 chat id " + md.Chat_Id + " "+  ex.Message);

                        }

                    }

                }
                else if (md.Message_From_User_Role.ToUpper() == "90B8EE57-9290-4D68-9329-C4008BA9DABA")
                {
                    chatlevel = 1;
                    Dictionary<string, object> msg_chat_info = ChatController.SaveMessage(md, chatlevel, _logger);
                    MessageModel updMessage = (MessageModel)msg_chat_info["message"];
                    Updated_Chat_Level_Info chat_Level_Info = (Updated_Chat_Level_Info)msg_chat_info["chat_level_info"];
                    await Clients.All.SendAsync("SetChatLevel", md.Chat_Id, chatlevel, chat_Level_Info.User_Name, chat_Level_Info.Last_Time);

                    var Company_Id = "";
                    foreach (HubUser hu in ConnectionList)
                    {
                        if (hu.User_Id == md.From_User_Id)
                        {
                            Company_Id = hu.Company_Id;
                            break;
                        }
                    }

                    await Clients.Group(Company_Id.ToUpper()).SendAsync("SendToDispatch", md);


                    if (md.Message_To_Group != "Dispatch")
                    {
                        try 
                        {
                        using SqlConnection con2 = new SqlConnection(Startup.DatabaseString);
                        con2.Open();
                        SqlCommand cmd2 = new SqlCommand
                        {
                            Connection = con2,
                            CommandType = System.Data.CommandType.StoredProcedure
                        };

                        _logger.Log(LogLevel.Warning, "level 1 chat id " + md.Chat_Id);

                        cmd2.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Chat_Id);
                        cmd2.CommandText = "p_Get_Driver_Identity_Id";
                        SqlDataReader rdr = cmd2.ExecuteReader();
                        var User_Id = "";
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                User_Id = rdr["User_Id"].ToString();
                            }
                        }
                        rdr.Close();
                        con2.Close();

                            foreach (HubUser entry in ConnectionList)
                            {

                                if (entry.User_Id == User_Id)
                                {
                                    await Clients.Client(entry.Connection_Id).SendAsync("SendToDriver", md);
                                    break;

                                }
                            }
                         }
                       catch (Exception ex)
                        {
                            throw new Exception("at level 1 chat id " +  ex.Message);

                        }
                    }

                }
                
           /*     await Clients.All.SendAsync("SetChatLevel", md.Chat_Id, chatlevel);

                if (md.Message_To_Group != "Dispatch")
                {

                using SqlConnection con2 = new SqlConnection(Startup.DatabaseString);
                con2.Open();
                SqlCommand cmd2 = new SqlCommand
                {
                    Connection = con2,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
*/

              /*  cmd2.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Chat_Id);
                cmd2.CommandText = "p_Get_Driver_Identity_Id";
                SqlDataReader rdr = cmd2.ExecuteReader();
                var Driver_Id = "";
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        Driver_Id = rdr["User_Identity_Id"].ToString();
                    }
                }
                rdr.Close();
                con2.Close();

                foreach (HubUser entry in userConnections)
                {

                    if (entry.User_Identity_Id == Driver_Id)
                    {
                        await Clients.Client(entry.Connection_Id).SendAsync("SendToDriver", md);

                    }
                }
                }*/


                 //if (md.Message_From_User_Role.ToUpper() == "352C54B4-CBDB-406A-B0D2-9E05544198E4" || md.Message_From_User_Role.ToUpper() == "E79307EC-BCE5-4D46-B84B-543B79915936")
              

          //      await Clients.All.SendAsync("SendToDispatch", md);
             }
            catch (Exception Ex)
            {
                throw new Exception(md.From_User_Id + " " + Ex.Message);
            }

        }
      
        public void ChangeUserSignalrConnection(Updated_Connection_Info uci)
        {
            try
            {
                foreach (HubUser us in userConnections)
                {

                    if (us.User_Id == uci.User_Id)
                    {

                       /* if (us.Company_Id.ToLower() != uci.Company_Id.ToLower())
                        {*/

                            Groups.RemoveFromGroupAsync(us.Connection_Id, us.Company_Id.ToUpper());
                            us.Company_Id = uci.Company_Id.ToUpper();
                            Groups.AddToGroupAsync(us.Connection_Id, uci.Company_Id.ToUpper());
                            break;
                      //  }
                    }

                }
            }
            catch
            {
                throw new Exception("Error while updating user ");
            }



        }
        /*public async Task MessageToServer(MessageModel md)
        {
            try
            {
                md.Message_Date = DateTime.Now;

                MessageModel updMessage = ChatController.SaveMessage(md);

                if (md.Message_From_User_Role.ToUpper() == "352C54B4-CBDB-406A-B0D2-9E05544198E4" || md.Message_From_User_Role.ToUpper() == "0841C5B7-C1AE-4E96-B754-E6E3C0FF6941" || md.Message_From_User_Role.ToUpper() == "E79307EC-BCE5-4D46-B84B-543B79915936")
                {

                    ChatController.SetChatLevel(md.Chat_Id, "2");

                    await Clients.All.SendAsync("SetChatLevel", md.Chat_Id, 2);
                }
                else
                {
                    ChatController.SetChatLevel(md.Chat_Id, "1");

                    await Clients.All.SendAsync("SetChatLevel", md.Chat_Id, 1);


                }
                if (md.Message_To_Group != "Dispatch")
                {

                    using SqlConnection con2 = new SqlConnection(Startup.DatabaseString);
                    con2.Open();
                    SqlCommand cmd2 = new SqlCommand
                    {
                        Connection = con2,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };


                    cmd2.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Chat_Id);
                    cmd2.CommandText = "p_Get_Driver_Identity_Id";
                    SqlDataReader rdr = cmd2.ExecuteReader();
                    var Driver_Id = "";
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            Driver_Id = rdr["User_Identity_Id"].ToString();
                        }
                    }
                    rdr.Close();
                    con2.Close();

                    foreach (HubUser entry in userConnections)
                    {

                        if (entry.User_Identity_Id == Driver_Id)
                        {
                            await Clients.Client(entry.Connection_Id).SendAsync("SendToDriver", md);

                        }
                    }
                }

                await Clients.All.SendAsync("SendToDispatch", md);



            }
            catch
            {
                throw new Exception("Error sending message.");

            }

        }*/





        //___________________________________________________________________________________________
        //TYPING METHODS

        public async Task DriverTyping(TypingModel tm)
        {

            await Clients.All.SendAsync("DriverTyping", tm); 

        }

        public async Task UserStartedTyping(DispatchTypingModel tm) {

            await Clients.All.SendAsync("StartedTyping", tm);

        }

        public async Task UserStoppedTyping(DispatchTypingModel tm)
        {
            await Clients.All.SendAsync("StoppedTyping", tm);
        }
        //___________________________________________________________________________________________

        public async Task GetUserList(string company_Id)
        {
            List < OnlineUser > users= new List<OnlineUser>();
            List<HubUser> itemsToGEt = userConnections.ToList();

            foreach (HubUser hu in itemsToGEt)
            {
                if (!String.IsNullOrWhiteSpace(hu.Company_Id) && hu.Company_Id.ToUpper() == company_Id.ToUpper())
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure
                        };
                        con.Open();
                        cmd.CommandText = "p_Get_Online_User_Info";
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(hu.User_Id);

                        SqlDataReader rdr = cmd.ExecuteReader();

                        if (rdr.HasRows)
                            {
                            OnlineUser ou = new OnlineUser();
                            while (rdr.Read())
                            {
                                    ou.User_Id = hu.User_Id;
                                    ou.User_First_Name = rdr["User_First_Name"].ToString();
                                    ou.User_Last_Name = rdr["User_First_Name"].ToString();
                                    ou.User_Role_Name = rdr["Role_Name"].ToString();
                                    ou.Online_Status = rdr["Online_Status"].ToString();
                                }
                                users.Add(ou);

                        }
                        rdr.Close();
                        con.Close();

                    }
                }
                catch
                {
                    throw new Exception("Error hiding message.");

                }
                }
            }
            
            await Clients.Group(company_Id.ToUpper()).SendAsync("CurrentUsersOnlineList", users);
              
        }

        public async Task HideMessage(MessageModel md)
        {
            /*try
            {*/
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@Message_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message_Id);
                cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = md.Chat_Table;
                cmd.Parameters.Add("@Message_Is_Visible", SqlDbType.Bit).Value = md.Message_Is_Visible;
                cmd.CommandText = "p_Update_Message_Visibility";

                con.Open();
                cmd.ExecuteNonQuery();

                    cmd.Parameters.Clear();
                    cmd.CommandText = "p_Get_Message_Date";
                    cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = md.Chat_Table;
                    cmd.Parameters.Add("@Message_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message_Id);

                    SqlDataReader rdr = cmd.ExecuteReader();

                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            md.Message_Date = DateTime.Parse(rdr["Message_Date"].ToString());
                        }
                    }
                    rdr.Close();
                    con.Close();

            }
            await Clients.All.SendAsync("HideMessage", md);
            /*}
            catch
            {
                throw new Exception("Error hiding message.");

            }*/
            

        }


        public async Task SetChatLevelAsClosed(ChatLevelModel cm)
        {
            Updated_Chat_Level_Info Chat_Level_Info = ChatController.SetChatLevel(cm.Chat_Id, cm.Chat_Level.ToString(),cm.User_Id);

            await Clients.All.SendAsync("SetChatLevel", cm.Chat_Id, cm.Chat_Level, Chat_Level_Info.User_Name,Chat_Level_Info.Last_Time);
        }


        //___________________________________________________________________________________________
        //ASSIGNING CHATS
        public async Task AssignChatToDispatch(AssignModel am)
        {
            try
            {
            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                con.Open();

                foreach (string userId in am.User_Ids)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(userId);
                    cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(am.Chat_Id);
                    cmd.Parameters.Add("@Date", SqlDbType.DateTime2).Value = DateTime.Now;

                    cmd.CommandText = "p_Assign_Chat_To_User";

                    cmd.ExecuteNonQuery();
                   
                }

                con.Close();

            }
            await Clients.All.SendAsync("AssignChatToDispatch", am);
            }
            catch
            {
                throw new Exception("Error assigning chat.");

            }
            

        }

        public async Task ReleaseAssignedChat(AssignModel am)
        {
            try
            {
     using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {
                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure
                    };
                    con.Open();
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(am.User_Ids[0]);
                        cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(am.Chat_Id);
                        cmd.Parameters.Add("@Date", SqlDbType.DateTime2).Value = DateTime.Now;

                        cmd.CommandText = "p_Release_Assign";

                        cmd.ExecuteNonQuery();

                    con.Close();

                }
                await Clients.All.SendAsync("ReleaseAssignedChat", am.Chat_Id);
            }
            catch
            {
                throw new Exception("Error releasing chat");

            }
           
        }

        //___________________________________________________________________________________________

        public async Task BroadcastMessage(BroadcastModel md)
        {
            try
            {
                md.Message.Message_Date = DateTime.Now;
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {

                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Save_Message"
                    };
                    con.Open();
                    foreach (string chatTable in md.Chat_Ids)
                    {
                        if (!chatTable.Contains("t_Chat_Status_Updates"))
                        {
                            var chat_table_array = chatTable.Split('_');
                            var chat_Id = chat_table_array[chat_table_array.Length - 1]; 
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add("@From_User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message.From_User_Id);
                            cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = chatTable;
                            cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = md.Message.Message_Text;
                            cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = md.Message.Message_Date;
                            cmd.Parameters.Add("@Message_From_User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message.Message_From_User_Role);
                            cmd.Parameters.Add("@Message_Latitude", SqlDbType.NVarChar, 12).Value = md.Message.Message_Latitude;
                            cmd.Parameters.Add("@Message_Longitude", SqlDbType.NVarChar, 12).Value = md.Message.Message_Longitude;
                            cmd.Parameters.Add("@Message_Is_Visible", SqlDbType.Bit).Value = md.Message.Message_Is_Visible;
                            cmd.Parameters.Add("@Message_To_Group", SqlDbType.NVarChar, 20).Value = md.Message.Message_To_Group;
                            cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(chat_Id);
                            cmd.Parameters.Add("@Chat_Level", SqlDbType.Int, 50).Value = 3;
                            cmd.ExecuteNonQuery();
                        }

                    }

                    con.Close();
                    var Company_Id = "";
                    foreach (HubUser hu in userConnections)
                    {
                        if (hu.User_Id == md.Message.From_User_Id)
                        {
                            Company_Id = hu.Company_Id;
                            break;
                        }
                    }

                    await Clients.Group(Company_Id.ToUpper()).SendAsync("BroadcastMessage", md);
                    //await Clients.All.SendAsync("BroadcastMessage", md);
                }
            }
            catch
            {
                throw new Exception("Error sending broadcast message.");

            }
        }
        public async Task BroadcastRoomsMessage(BroadcastModel md)
        {
            try
            {
                md.Message.Message_Date = DateTime.Now;
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {

                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Save_Message"
                    };
                    con.Open();
                    foreach (string chatTable in md.Chat_Tables)
                    {
                        if (!chatTable.Contains("t_Chat_Status_Updates"))
                        {
                            var chat_table_array = chatTable.Split('_');
                            var chat_Id = chat_table_array[chat_table_array.Length - 1];
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add("@From_User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message.From_User_Id);
                            cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = chatTable;
                            cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = md.Message.Message_Text;
                            cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = md.Message.Message_Date;
                            cmd.Parameters.Add("@Message_From_User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message.Message_From_User_Role);
                            cmd.Parameters.Add("@Message_Latitude", SqlDbType.NVarChar, 12).Value = md.Message.Message_Latitude;
                            cmd.Parameters.Add("@Message_Longitude", SqlDbType.NVarChar, 12).Value = md.Message.Message_Longitude;
                            cmd.Parameters.Add("@Message_Is_Visible", SqlDbType.Bit).Value = md.Message.Message_Is_Visible;
                            cmd.Parameters.Add("@Message_To_Group", SqlDbType.NVarChar, 20).Value = md.Message.Message_To_Group;
                            cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(chat_Id);
                            cmd.Parameters.Add("@Chat_Level", SqlDbType.Int, 50).Value = 3;
                            cmd.ExecuteNonQuery();
                        }

                    }

                    con.Close();
                    var Company_Id = "";
                    foreach (HubUser hu in userConnections)
                    {
                        if (hu.User_Id == md.Message.From_User_Id)
                        {
                            Company_Id = hu.Company_Id;
                            break;
                        }
                    }

                    await Clients.Group(Company_Id.ToUpper()).SendAsync("SendBroadcastMessageToRooms", md);
                  //  await Clients.All.SendAsync("SendBroadcastMessageToDrivers", md);
                }
            }
            catch
            {
                throw new Exception("Error sending broadcast message.");

            }
        }
        public async Task BroadcastDriversMessage(BroadcastModel md)
        {
            try
            {
                md.Message.Message_Date = DateTime.Now;
                using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                {

                    SqlCommand cmd = new SqlCommand
                    {
                        Connection = con,
                        CommandType = System.Data.CommandType.StoredProcedure,
                        CommandText = "p_Save_Message"
                    };
                    con.Open();
                    foreach (string chatTable in md.Chat_Tables)
                    {
                        if (!chatTable.Contains("t_Chat_Status_Updates"))
                        {
                            var chat_table_array = chatTable.Split('_');
                            var chat_Id = chat_table_array[chat_table_array.Length - 1];
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add("@From_User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message.From_User_Id);
                            cmd.Parameters.Add("@Chat_Table", SqlDbType.NVarChar, 70).Value = chatTable;
                            cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = md.Message.Message_Text;
                            cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = md.Message.Message_Date;
                            cmd.Parameters.Add("@Message_From_User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(md.Message.Message_From_User_Role);
                            cmd.Parameters.Add("@Message_Latitude", SqlDbType.NVarChar, 12).Value = md.Message.Message_Latitude;
                            cmd.Parameters.Add("@Message_Longitude", SqlDbType.NVarChar, 12).Value = md.Message.Message_Longitude;
                            cmd.Parameters.Add("@Message_Is_Visible", SqlDbType.Bit).Value = md.Message.Message_Is_Visible;
                            cmd.Parameters.Add("@Message_To_Group", SqlDbType.NVarChar, 20).Value = md.Message.Message_To_Group;
                            cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(chat_Id);
                            cmd.Parameters.Add("@Chat_Level", SqlDbType.Int, 50).Value = 2;
                            cmd.ExecuteNonQuery();
                        }

                    }
                    var Company_Id = "";
                    foreach (HubUser hu in userConnections)
                    {
                        if (hu.User_Id == md.Message.From_User_Id)
                        {
                            Company_Id = hu.Company_Id;
                            break;
                        }
                    }
                    await Clients.Group(Company_Id.ToUpper()).SendAsync("SendBroadcastMessageToRooms", md);
                    foreach (string chatId in md.Chat_Ids)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@Chat_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(chatId);
                        cmd.CommandText = "p_Get_Driver_Identity_Id";
                        SqlDataReader rdr = cmd.ExecuteReader();
                        var User_Id = "";
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                User_Id = rdr["User_Id"].ToString();
                            }
                        }
                        rdr.Close();
                      

                        foreach (HubUser entry in userConnections)
                        {

                            if (entry.User_Id == User_Id)
                            {
                                await Clients .Client(entry.Connection_Id).SendAsync("SendBroadcastMessageToDrivers", md);
                                break;

                            }
                        }

                    }


                    con.Close();
                }
            }
            catch
            {
                throw new Exception("Error sending broadcast message.");

            }
        }
        //___________________________________________________________________________________________
        //BREAKS

        public async Task StartBreak(BreakModel bm)
        {
            try
            {
         using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure
                        };
                        
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.User_Id);
                        cmd.Parameters.Add("@Break_Time", SqlDbType.DateTime2).Value = DateTime.Now;
                        cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = DateTime.Now;
                        cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = "Started a break";
                        cmd.Parameters.Add("@User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Role_Id);
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Company_Id);
                        cmd.CommandText = "p_Start_Break";

                        con.Open();
                       
                  /*      DateTime nw = DateTime.Now;
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.User_Id);
                        cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = nw;
                        cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = "Started a break";
                        cmd.Parameters.Add("@User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Role_Id);
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Company_Id);
                        cmd.CommandText = "p_Save_User_Status";*/

                        cmd.ExecuteNonQuery();


                    con.Close();
                    }
                /* var claims = Context.User.Claims.ToList();
                 var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

             _statusHandler.StartBreakStatus(userIdClaim.Value);
             string comp_id = _statusHandler.GetCompId(userIdClaim.Value);
             stUp.Message.Message_Text = "has started break";
             //SEND TO FE
             Clients.All.SendAsync("UpdatedUserStatus", stUp);*/
                //HandleUserStatusChange(Guid.Parse(userIdClaim.Value), "started break");
                await Clients.Group(bm.Company_Id.ToUpper()).SendAsync("RefreshOnlineDispacthers","RefreshList");
            }
            catch
            {
                throw new Exception("Error starting break.");

            }
           
        }

        public async Task EndBreak(BreakModel bm)
        {
            try
            {
        using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
                    {
                        SqlCommand cmd = new SqlCommand
                        {
                            Connection = con,
                            CommandType = System.Data.CommandType.StoredProcedure
                        };
                    cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.User_Id);
                    cmd.Parameters.Add("@Break_Time", SqlDbType.DateTime2).Value = DateTime.Now;
                    cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = DateTime.Now;
                    cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = "Finished a break";
                    cmd.Parameters.Add("@User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Role_Id);
                    cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Company_Id);
                    cmd.CommandText = "p_End_Break";

                        con.Open();
                        cmd.ExecuteNonQuery();
                   /*     cmd.Parameters.Clear();
                        DateTime nw = DateTime.Now;
                        cmd.Parameters.Add("@User_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.User_Id);
                        cmd.Parameters.Add("@Message_Date", SqlDbType.DateTime2).Value = nw;
                        cmd.Parameters.Add("@Message_Text", SqlDbType.NVarChar, -1).Value = "Finished a break";
                        cmd.Parameters.Add("@User_Role", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Role_Id);
                        cmd.Parameters.Add("@Company_Id", SqlDbType.UniqueIdentifier).Value = Guid.Parse(bm.Company_Id);
                        cmd.CommandText = "p_Save_User_Status";*/

                    con.Close();
                    }
                /*  var claims = Context.User.Claims.ToList();
                  var userIdClaim = claims.FirstOrDefault(x => x.Type == "sub");

              _statusHandler.EndBreakStatus(userIdClaim.Value);
              string comp_id = _statusHandler.GetCompId(userIdClaim.Value);
              StatusUpdateModel stUp = _statusHandler.StatusUpdateModel(userIdClaim.Value);
              stUp.Message.Message_Text = "has ended break";
              //SEND TO FE
              Clients.All.SendAsync("UpdatedUserStatus", stUp);*/
                //HandleUserStatusChange(Guid.Parse(userIdClaim.Value), "finished break");

                await Clients.Group(bm.Company_Id.ToUpper()).SendAsync("RefreshOnlineDispacthers");



            }
            catch
            {
                throw new Exception("Error ending break.");

            }
            
        }


        //___________________________________________________________________________________________

        public async Task HandleUserStatusChange_old(Guid Identity_Id, string message_Text)
        {
            try
            {

            Guid user_Id = new Guid();
            string user_First_Name = "";
            string user_Role = "";
            DateTime nw = DateTime.Now;

            using (SqlConnection con = new SqlConnection(Startup.DatabaseString))
            {
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = System.Data.CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@User_Identity_Id", SqlDbType.UniqueIdentifier).Value = Identity_Id;
                cmd.CommandText = "p_Get_User_Info"; 

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.HasRows)
                    {
                        while (rdr.Read())
                        {
                            user_Id = Guid.Parse(rdr["User_Id"].ToString());
                            user_First_Name = rdr["User_First_Name"].ToString();
                            user_Role = rdr["User_Role"].ToString();
                        }
                    }
                    rdr.Close();


                    MessageModel mes = new MessageModel()
                    {
                        Message_Date = nw,
                        Message_From_User_Name = user_First_Name,
                        From_User_Id = user_Id.ToString(),
                        Message_Text = message_Text
                    };

                    if (message_Text == "has connected" || message_Text == "finished break")
                    {
                        foreach (HubUser hu in userConnections)
                        {
                            if (hu.User_Identity_Id == Identity_Id.ToString())
                            {
                                hu.Status = "Online";
                                hu.User_Id = user_Id.ToString();
                            }
                        }


                    }
                    else if (message_Text == "started break")
                    {
                        foreach (HubUser hu in userConnections)
                        {
                            if (hu.User_Identity_Id == Identity_Id.ToString())
                            {
                                hu.Status = "Break";
                            }
                        }
                    }
                    if (user_Role.ToLower() != "25942536-C57D-4E18-A82D-0CDCC77A74C5".ToLower())
                    {
                        await Clients.All.SendAsync("CurrentUsersOnlineList", userConnections);
                        await Clients.All.SendAsync("UpdatedUserStatus", mes);
                    }
                        
                }
                
                    
                    
            }
            catch
            {
                throw new Exception("Error handling status change.");

            }
            
        }

    }


   

}

public class HubUser
{
    public string User_Id { get; set; }
    public string User_Identity_Id { get; set; }
    public string Connection_Id { get; set; }
    public string User_Role { get; set; }
    public string Status { get; internal set; }
    public string Company_Id { get;  set; }

}

public class TypingModel
{
    public string Chat_Id { get; set; }
    public string Username { get; set; }
}

public class AssignModel
{
    public string Chat_Id { get; set; }
    public string[] User_Ids { get; set; }
}

public class ChatLevelModel
{
    public string Chat_Id { get; set; }
    public string User_Id { get; set; }
    public int Chat_Level { get; set; }

}


public class BroadcastModel
{
    public MessageModel Message { get; set; }
    public List<string> Chat_Ids { get; set; }
    public List<string> Chat_Tables { get; set; }

}
public class BreakModel
{
    public string User_Id { get; set; }
    public string Role_Id { get; set; }
    public string Company_Id { get; set; }
}
public class Updated_Connection_Info
{
    public string User_Id { get; set; }
    public string Company_Id { get; set; }
}
public class DispatchTypingModel
{
    public string Chat_Id { get; set; }
    public string User_Id { get; set; }
    public string Username { get; set; }
}
