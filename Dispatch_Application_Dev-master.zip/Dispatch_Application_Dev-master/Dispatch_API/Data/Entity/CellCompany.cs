﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class CellCompany
    {
        public string Cell_Company_Id { get; set; }
        public string Cell_Company_Name { get; set; }
        public string Company_Name { get; set; }
        public string Company_Id { get; set; }
        public bool Cell_Company_IsEnabled { get; set; }

        public string Contact_Name { get; set; }
        public string Contact_Email { get; set; }
        public string Cell_Company_Phone_Number { get; set; }

    }
}
