﻿using Driver_Api.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Data.Entity
{
    public class GateDriver
    {
        public string Chat_Id { get; set; }
        public string Chat_Name { get; set; }
        public string Chat_Table { get; set; }
        public string Role_Id { get; set; }

        
    }
}
