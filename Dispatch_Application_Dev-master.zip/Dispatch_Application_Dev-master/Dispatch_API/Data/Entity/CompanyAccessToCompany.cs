﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class CompanyAccessToCompany : Company
    {
        public List<CompanyAccess> Access_To_Companies { set; get;}
    }
}
