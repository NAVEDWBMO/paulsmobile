﻿using System;
using System.Collections.Generic;

namespace Dispatch_Application_Debug_API.API.v1
{
    public class AssignedDispactherDriver
    {
        public string Chat_Name { get; set; }
        public string Chat_Id { get; set; }
        public string IsSelected { get; set; }

    }
}