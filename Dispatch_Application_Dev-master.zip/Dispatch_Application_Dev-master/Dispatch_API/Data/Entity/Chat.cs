﻿using System;
using System.Collections.Generic;

namespace Dispatch_Application_Debug_API.API.v1
{
    public class Chat
    {
        public string Chat_Id { get; set; }
        public string Chat_Name { get; set; }
        public bool Chat_Status { get; set; }
        public int Chat_Level { get; set; }
        public List<MessageModel> Messages { get; set; }
        public string Chat_Table { get; set; }
        public string AssignedId { get; set; }
        public string Chat_Type { get;  set; }
        public string Company_Id { get;  set; }
        public string User_Name { get; set; }
        public DateTime Last_Time { get; set; }                                
        public List<string> Roles { get; set; }

        public string Online_Status { get; set; }
    }
}