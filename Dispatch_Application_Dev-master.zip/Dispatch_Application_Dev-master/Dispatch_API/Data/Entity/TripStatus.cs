﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class TripStatus
    {
        public string Trip_Status_ID { get; set; }
        public string Status_Name { get; set; }
    }
}
