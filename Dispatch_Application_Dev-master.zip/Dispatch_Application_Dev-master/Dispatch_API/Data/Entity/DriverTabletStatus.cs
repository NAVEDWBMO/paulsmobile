﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class DriverTabletStatus
    {
        public string LoadOffers_ID { get; set; }
        public string DriverID { get; set; }
        public string DLD { get; set; }
        public string FreightBill { get; set; }
        public string Trip { get; set; }
        public string Container_Number { get; set; }
        public string Origin_Name { get; set; }
        public string Destination_Name { get; set; }
        public string LO_Status { get; set; }
        public string LO_Status_Name { get; set; }
        public string Trip_Status_ID { get; set; }
        public string Trip_Status_Name { get; set; }
        public string Status_Flag { get; set; }



    }
}
