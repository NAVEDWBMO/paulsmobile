﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class Permissions
    {
        public string Permission_Id { get; set; }
        public string Permission_Type_Id { get; set; }
        public string Permission_Function { get; set; }
        public int Sort_Order { get; set; }

    }
}
