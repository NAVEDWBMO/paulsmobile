﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.API.v1
{
    public class OnlineUser
    {
        public string User_Id { get; set; }
        public string User_First_Name { get; set; }
        public string User_Last_Name { get; set; }
        public string User_Role_Name { get; set; }
        public string Online_Status { get; set; }
       
    }
}
