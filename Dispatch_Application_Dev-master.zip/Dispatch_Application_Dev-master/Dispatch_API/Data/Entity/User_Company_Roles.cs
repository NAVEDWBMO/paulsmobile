﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class User_Company_Roles
    {
        public string Role_Id { get; set; }
        public string Role_Name { get; set; }
        public int Role_Access { get; set; }

    }
}
