﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class DriverFtpFiles
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string Image { get; set; }
        public string Driver_u_id { get; set; }
        public string Folder_type { get; set; }
        public DateTime fileCreatedDate { get; set; }

        


    }
}
