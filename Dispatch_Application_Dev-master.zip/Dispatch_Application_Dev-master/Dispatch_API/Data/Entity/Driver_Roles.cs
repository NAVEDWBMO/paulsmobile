﻿using Driver_Api.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Data.Entity
{
    public class Driver_Roles
    {

        public string Driver_Role_Id { get; set; }
        public string Driver_Role_Name { get; set; }
        	
    }
}
