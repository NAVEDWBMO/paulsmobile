﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class Updated_User_Company_Roles
    {
        public string User_Id { get; set; }
        public string Company_Id { get; set; }
        public string Role_Id { get; set; }



    }
}
