﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.API.v1
{
    public class OnlineStatus
    {
        public string Chat_Id { get; set; }
        public string Online_Status { get; set; }
       

    }
}
