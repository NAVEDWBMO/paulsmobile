﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class Permission_Access_Level
    {
        public string Access_Level_Id { get; set; }
        public string Permission_Id { get; set; }
        public int Access_Level { get; set; }
        public string Image_Link { get; set; }
        public string Router_Link { get; set; }
        public bool Permission_Status { get; set; }  
         

    }
}
