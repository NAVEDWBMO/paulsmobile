﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class BroadcastMessageModel
    {
        public string Company_Id { get; set; }
        public MessageModel Message { get; set; }

    }
}
