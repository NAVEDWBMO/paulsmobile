﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class Truck
    {
        public string Truck_Id { get; set; }
        public string Truck_Name { get; set; }
        public string Truck_Make { get; set; }
        public string Truck_Model { get; set; }
        public string Truck_Year { get; set; }
        public string Truck_Vin_Number { get; set; }
        public string Truck_Serial_Number { get; set; }
        public string Truck_License_Plate { get; set; }
        public string Truck_Samsara_Serial { get; set; }
        public string Truck_Samsara_Vin { get; set; }
        public string Truck_TM_Name { get; set; }
        public string Truck_TM_Serial { get; set; }
        public string Truck_TM_Vin { get; set; }
        public string Company_Id { get; set; }
        public bool Truck_IsEnabled { get; set; }
        public string Company_Name { get; set; }
        public string Truck_Driver_Firstname { get; set; }
        public string Truck_Driver_Lastname { get; set; }
        public string Truck_Driver_User_Id { get; set; }
        public string Truck_Driver_Device_Id { get; set; }
        public string Truck_Driver_Id { get; set; }

    }
}
