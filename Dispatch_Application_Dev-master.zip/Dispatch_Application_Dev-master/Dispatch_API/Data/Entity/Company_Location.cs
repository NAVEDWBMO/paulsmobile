﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class Company_Location
    {
        public string Location_Full_Name { get; set; }
        public string Location_Short_Name { get; set; }
        public string Company_Id { get; set; }


    }
}
