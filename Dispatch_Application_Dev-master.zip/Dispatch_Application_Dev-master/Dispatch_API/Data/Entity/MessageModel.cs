﻿using System;

public class MessageModel
{
    public string Message_Id { get; set; }
    public string Message_Text { get; set; }
    public DateTime Message_Date { get; set; }
    public string Message_From_User_Role { get; set; }
    public string From_User_Id { get; set; }
    public bool Message_Is_Visible { get; set; }
    public string Message_Latitude { get; set; }
    public string Message_Longitude { get; set; }
    public string Message_To_Group { get; set; }
    public string Message_From_User_Name { get; set; }
    public string Chat_Id { get; set; }
    public string Chat_Table { get; set; }
    //public string Message_Company_Name { get; set; }


}
