﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class DriverBreak
    {
        public string User_Id { get; set; }
        public Guid Break_Id { get; set; }
        public Guid Shift_Id { get; set; }
        public DateTime BreakStart { get; set; }

        public DateTime BreakEnd { get; set; }

        public string? BreakNotes { get; set; }
    }
}
