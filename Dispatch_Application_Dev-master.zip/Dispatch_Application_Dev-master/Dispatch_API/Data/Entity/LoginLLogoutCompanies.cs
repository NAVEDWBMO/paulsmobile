﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class LoginLLogoutCompanies
    {
        public Company Current_Company { get; set; }
        public Company Previous_Company { get; set; }
      

    }
}
