﻿using Driver_Api.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Data.Entity
{
    public class LineupForm
    {
        public string License_Plate { get; set; }
        public string Container_Number { get; set; }
        public string Container_Size { get; set; }
        public string Carrier_Name { get; set; }
        public string Driver_Number { get; set; }
        public string Pickup_Number { get; set; }
        public string In_Gate_By { get; set; }
        public string Waitime_Status { get; set; }
        public string p_Container_Number { get; set; }
        public string p_Container_Size { get; set; }
        public string p_Pickup_Number { get; set; }
        public string Company_Id { get; set; }

    }
}
