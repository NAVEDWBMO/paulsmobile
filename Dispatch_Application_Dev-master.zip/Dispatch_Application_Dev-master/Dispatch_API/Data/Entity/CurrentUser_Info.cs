﻿namespace Resource.Api.Controllers
{
    public class CurrentUser_Info
    {
        public string User_Id { get; set; }
        public string User_Identity_Id { get; set; }
        public string User_Email { get; set; }
        public string User_First_Name { get; set; }
        public string User_Last_Name { get; set; }
        public string User_Role { get; set; }
        public string User_IsEnabled { get; set; }
        public string User_Company { get; set; }
        public string User_Location { get; set; }
        public string User_Initials { get; set; }
        public string User_Colour { get; set; }
        public string Role_Name { get; set; }
        public string Company_Name { get; set; }
        public string Location_Name { get; set; }

        
    }
}