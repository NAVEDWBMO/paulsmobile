﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class User_Role_Permissions
    {
        public string Permission_Id { get; set; }
        public string Permission_Function { get; set; }
        public string Permission_Type_Id { get; set; }
        public string Access_Level_Id { get; set; }
        public bool Selected { get; set; }
        //   public List<Role_Permission_Access_Level> Access_Levels { get; set; }

        /*       public string Access_Level_Id { get; set; }
               public string Access_Level_Name { get; set; }
               public string Selected { get; set; }*/
        //   public string Access_Type { get; set; }

    }
}
