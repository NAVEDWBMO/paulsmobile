﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class LoadOfferGeoLocations
    {
        public string LoadOffers_Id { get; set; }
        public string Geolocations_Date { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }

    }
}
