﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class LoadOfferUpdateStatus
    {
        public string LoadOffers_ID { get; set; }
        public string LO_Status { get; set; }
        public string Status_Flag { get; set; }
    }
}
