﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class Website_Mobile_Version
    {
        public string Web_Version { get; set; }
        public DateTime Web_Version_Date { get; set; }
        public string Mobile_Version { get; set; }
        public DateTime Mobile_Version_Date { get; set; }

    }
}
