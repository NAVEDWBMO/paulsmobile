﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class IdentityError
    {
        public string code { get; set; }
        public string description { get; set; }

    }
}
