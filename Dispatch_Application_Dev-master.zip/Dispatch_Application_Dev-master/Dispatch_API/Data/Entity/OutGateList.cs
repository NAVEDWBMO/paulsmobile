﻿using Driver_Api.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Data.Entity
{
    public class OutGateList
    {
        public string Gate_Id { get; set; }
        public string Container_Number { get; set; }
        public string Carrier_Name { get; set; }
        public string Driver_Number { get; set; }
        public string Pickup_Number { get; set; }
        public string Gate_Status { get; set; }
        public string Container_Status { get; set; }
        public string Driver_Job_Status { get; set; }
        public string Gate_Driver_Status { get; set; }

    }
}
