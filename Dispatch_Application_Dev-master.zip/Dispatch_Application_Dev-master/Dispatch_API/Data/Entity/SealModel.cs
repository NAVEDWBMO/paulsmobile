﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class SealModel
    {
        public string LoadOffers_ID { get; set; }
        public string DLD { get; set; }
        public string Seal_Number { get; set; }
        public string Seal_Type { get; set; }
        public bool IsConfirmed { get; set; }


    }
}
