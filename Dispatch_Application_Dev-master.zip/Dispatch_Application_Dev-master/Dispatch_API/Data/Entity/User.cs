﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class User
    {
        public Guid User_Id { get; set; }
        public string User_Email { get; set; }
        public string User_First_Name { get; set; }
        public string User_Last_Name { get; set; }
        public string User_Role { get; set; }
        public string User_Company { get; set; }
        public string User_Company_Name { get; set; }
        public List<string> User_Company_Access { get; set; }
        public string User_Location { get; set; }
        public bool User_IsEnabled { get; set; }
        public int Sort_Order { get; set; }
        public string Role_Name { get; set; }

    }
}
