﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class CellPlan
    {
        public string Cell_Plan_Id { get; set; }
        public string Cell_Plan_Name { get; set; }
        public string Cell_Plan_Company_Id { get; set; }
        public string Cell_Plan_Data { get; set; }
        public bool Cell_Plan_Has_Voice { get; set; }
        public string Cell_Plan_Price { get; set; }
        public bool Cell_Plan_IsEnabled { get; set; }

        

    }
}
