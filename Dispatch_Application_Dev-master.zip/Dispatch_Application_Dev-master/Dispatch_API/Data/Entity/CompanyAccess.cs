﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class CompanyAccess
    {
        public string Access_Company_Id { get; set; }
        public string Company_Type_Id { get;  set; }
        public string Company_Name { get; set; }
        public string Selected { get; set; }
    }
}
