﻿using Driver_Api.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Data.Entity
{
    public class LanePosition
    {
        public string Lane_Id { get; set; }
        public string Lane_Name { get; set; }
        public string Position_Id { get; set; }
        public string Position_Number { get; set; }
        
    }
}
