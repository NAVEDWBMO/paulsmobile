﻿using System;
using System.Collections.Generic;

namespace Dispatch_Application_Debug_API.API.v1
{
    public class Updated_Chat_Level_Info
    {
        public string User_Name { get; set; }
        public string Last_Time { get; set; }
    }
}