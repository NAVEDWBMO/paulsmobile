﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class Role_Permissions
    {
        public string Permission_Id { get; set; }
        public string Permission_Type_Id { get; set; }
        public string Permission_Type_Name { get; set; }
        public string Permission_Function { get; set; }
        public string Image_Link { get; set; }
        public string Router_Link { get; set; }
        public string Role_Id { get; set; }

    }
}
