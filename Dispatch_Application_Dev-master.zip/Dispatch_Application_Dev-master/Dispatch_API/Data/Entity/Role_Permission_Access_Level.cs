﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class Role_Permission_Access_Level
    {
        public string Access_Level_Id { get; set; }
        public string Access_Level_Name { get; set; }
        public int Selected { get; set; }



    }
}
