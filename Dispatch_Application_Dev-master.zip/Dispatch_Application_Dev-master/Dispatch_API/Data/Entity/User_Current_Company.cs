﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class User_Current_Company
    {
        public string User_Id { get; set; }
        public string User_Identity_Id { get; set; }
        public string Permission_Id { get; set; }
        public string Company_Id { get; set; }

        
    }
}
