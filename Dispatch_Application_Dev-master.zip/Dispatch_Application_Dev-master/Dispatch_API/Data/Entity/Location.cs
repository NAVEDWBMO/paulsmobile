﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class Location
    {
        public string Location_Id { get; set; }
        public string Location_Full_Name { get; set; }
        public string Location_Short_Name { get; set; }
        public bool Location_IsEnabled { get; set; }
        public List<string> Location_Companies { get; set; }
    }    
}
