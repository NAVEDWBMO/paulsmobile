﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class Device
    {
        public string Device_Id { get; set; }
        public string Device_IMEI_Id { get; set; }
        public string Device_Model { get; set; }
        public string Device_Model_Year { get; set; }
        public string Device_Company { get; set; }
        public string Device_Serial_Number { get; set; }
        public string Phone_Number { get; set; }
        public string Company_Id { get; set; }
        public bool Driver_Device_IsEnabled { get; set; }
        public string Company_Name { get; set; }
        public string Device_IMEI_Number { get; set; }
        public string Device_Driver_User_Id { get; set; }
        public string Device_Driver_Truck_Id { get; set; }
        public string Device_Driver_Firstname { get; set; }
        public string Device_Driver_Lastname { get; set; }
        public string Device_Driver_Id { get; set; }


    }
}
