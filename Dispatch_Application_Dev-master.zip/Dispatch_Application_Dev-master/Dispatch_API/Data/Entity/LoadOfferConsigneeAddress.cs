﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class LoadOfferConsigneeAddress
    {
        public string LoadOffers_ID { get; set; }
        public string Address_Type { get; set; }
        public string Status { get; set; }
        public string Trip_Status { get; set; }
        public string Trip_Status_Name { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string Cell { get; set; }
        public string City { get; set; }
        public string CloseTime { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string Extension { get; set; }
        public string Fax { get; set; }
        public string GPS_Description { get; set; }
        public string GPS_IsValid { get; set; }
        public string GPS_Lat { get; set; }
        public string GPS_Long { get; set; }
        public string ID { get; set; }
        public string Name { get; set; }
        public string OpenTime { get; set; }
        public string Phone { get; set; }
        public string PostalCode { get; set; }
        public string Prov { get; set; }
        public string UnitNo { get; set; }
        public string Dock { get; set; }
        public string DockNum { get; set; }
        public string ZoneID { get; set; }
        public string AppointmentRequired { get; set; }
        public string AppointmentMade { get; set; }
        public string AppointmentSpot { get; set; }
        public string Country { get; set; }
        public DateTime DeliverBy { get; set; }
        public DateTime DeliverByEnd { get; set; }
        public DateTime PickupBy { get; set; }
        public DateTime PickupByEnd { get; set; }
    }
}
