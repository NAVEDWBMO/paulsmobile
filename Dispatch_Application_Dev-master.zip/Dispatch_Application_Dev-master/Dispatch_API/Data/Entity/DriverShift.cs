﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class DriverShift
    {
        public string User_Id { get; set; }
        public Guid Shift_Id { get; set; }
        public DateTime ShiftStart { get; set; }

        public DateTime? ShiftEnd { get; set; }

       
    }
}
