﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class LoadOfferAddressStatus
    {
        public string LoadOffers_ID { get; set; }
        public string User_Id { get; set; }
        public string Address_Type { get; set; }
        public string DLD { get; set; }


    }
}
