﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class User_Company_Access
    {
        public string Company_Id { get; set; }
        public string Company_Name { get; set; }
        
    }
}
