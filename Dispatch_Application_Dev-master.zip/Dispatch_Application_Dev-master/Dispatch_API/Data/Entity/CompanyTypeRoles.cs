﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class CompanyTypeRoles
    {
        public string Company_Type_Id { get; set; }
        public string Role_Id { get; set; }
       public string Role_Name { get; set; }
        public int Sort_Order { get; set; }
        
    }
}
