﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class CreateCustomChatModel
    {
        public string Chat_Name { get; set; }
        public string Chat_Company { get; set; }
        public List<string> Chat_Roles { get; set; }
    }
}
