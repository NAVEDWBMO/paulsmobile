﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class RegisterUserModel
    {
        public string User_Email { get; set; }
        public string User_Password { get; set; }
        public string User_FirstName { get; set; }
        public string User_LastName { get; set; }
        public string User_Role { get; set; }
        public string User_Company { get; set; }
        public List<string> User_Company_Access { get; set; }
        public string User_Location { get; set; }
    }
}
