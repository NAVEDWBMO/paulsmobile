﻿public class RegisterDriverModel
{
    public string Driver_Email { get; set; }
    public string Driver_Password { get; set; }
    public string Driver_FirstName { get; set; }
    public string Driver_LastName { get; set; }
    public string Driver_Role { get; set; }
    public string Driver_Id { get; set; }
    public string Driver_Company { get; set; }
}
