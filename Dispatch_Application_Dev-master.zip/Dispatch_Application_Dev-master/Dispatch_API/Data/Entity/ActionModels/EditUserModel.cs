﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity.ActionModels
{
    public class EditUserModel
    {
            public string User_Id { get; set; }
            public string User_Email_Old { get; set; }
            public string User_Email { get; set; }
            public string User_FirstName { get; set; }
            public string User_LastName { get; set; }
            public string User_Role_Id { get; set; }
            public string Company_Id { get; set; }
            public string User_Location_Id { get; set; }
            public string User_Password { get; set; }
            public List<string> User_Access { get; set; }

    }
}
