﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class SearchModel
    {
        public string Chat_Table { get; set; }
        public string Search_Value { get; set; }
    }
}
