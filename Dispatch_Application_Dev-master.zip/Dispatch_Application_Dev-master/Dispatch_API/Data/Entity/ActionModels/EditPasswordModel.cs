﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class EditPasswordModel
    {
        public String UserName { get; set; }
        public String Password { get; set; }
    }
}
