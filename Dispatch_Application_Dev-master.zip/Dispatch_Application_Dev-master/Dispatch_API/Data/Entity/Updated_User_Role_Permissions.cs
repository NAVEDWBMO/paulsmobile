﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class Updated_User_Role_Permissions
    {
        public string Role_Id { get; set; }
        public string Permission_Id { get; set; }
        public string Permission_Type_Id { get; set; }
        public string Access_Level_Id { get; set; }
        public int Selected { get; set; }

    }
}
