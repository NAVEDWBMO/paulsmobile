﻿using Driver_Api.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Data.Entity
{
    public class Driver
    {

        public string User_Id { get; set; }
        public string Driver_Id { get; set; }
        public string D_Id { get; set; }
        public string Driver_Device_Id { get; set; }
        public string Driver_Truck_Id { get; set; }
        public string Driver_Email { get; set; }
        public string Driver_Phone { get; set; }
        public string Driver_Firstname{ get; set; }
        public string Driver_Lastname { get; set; }
        public Company Company { get; set; }
        public bool Driver_IsEnabled { get; set; }
        public string Chat_Id { get; set; }
        public string Chat_Table { get; set; }
        public string Chat_Type { get; set; }
        public string Driver_Role_Id{ get; set; }
        public string Driver_Role_Name { get; set; }
        
    }
}
