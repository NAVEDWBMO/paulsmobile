﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class Updated_Role_Company_Access
    {
        public string Role_Id { get; set; }

        public List<Role_Company_Access> Role_Company_Access { get; set; }


    }
}
