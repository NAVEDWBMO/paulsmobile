﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class LoadOfferStatus
    {
        public string status_Id { get; set; }
        public string status { get; set; }
    }
}
