﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class Company
    {
        public string Company_Id { get; set; }
        public string Company_Name { get; set; }
        public string Company_Type_Id { get;  set; }
        public bool Company_IsEnabled { get; set; }
        public string Company_Type_Name { get; set; }
        public string Company_Sort_Order { get; set; }


        public List<Location> Locations { get; set; }
    }
}
