﻿namespace Resource.Api.Controllers
{
    public class User_Info
    {
        public string Id { get; set; }
        public string Email { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public string IsEnabled { get; set; }
        public string User_Company { get; set; }
    }
}