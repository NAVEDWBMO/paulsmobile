﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Driver_Api.Data.Entity
{
    public class Imei
    {
        public string Device_IMEI_Id { get; set; }
        public string Device_IMEI_Number { get; set; }
        public string Phone_Number { get; set; }
        public string Cell_Company { get; set; }
        public string Cell_Company_Id { get; set; }
        public string Cell_Plan { get; set; }
        public string Plan_Data { get; set; }
        public string Plan_Cost { get; set; }
        public CellPlan CPlan { get; set; }
        public Device Assigned_to_Device { get; set; }

        public string Device_IMEI_Company_Id { get; set; }
        public string Device_IMEI_Company_Name { get; set; }
        public bool Device_IMEI_IsEnabled { get; set; }

    }
}
