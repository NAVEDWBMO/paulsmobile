﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Application_Debug_API.Data.Entity
{
    public class Role_Company_Access
    {
        public string Access_Company_Id { get; set; }
        public string Company_Name { get; set; }
        public int Access_Type { get; set; }
        public int Default_Company { get; set; }

    }
}
