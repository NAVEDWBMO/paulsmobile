﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dispatch_Api.Data.Entity
{
    public class Permission_Types
    {
        public string Permission_Type_Id { get; set; }
        public string Permission_Type_Name { get; set; }
        
    }
}
